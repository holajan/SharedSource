#region legals - read before modifying or distributing
// iFinity.com.au 
// This is customised software derived from the DotNetNuke core. The below copyright messages should be followed 
// , and any copies of this software should include this message.  However, this software is distributed with the additional
// usage rights and restrictions:
// You may use this software without restriction on the number of installations in private and commercial applications
// You may make modifications to the source code of this software for your own requirements.
// You may not resell copies of this software or software derived from this source code as a licensed product.
// 
// DotNetNuke� - http://www.dotnetnuke.com 
// Copyright (c) 2002-2005 
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca ) 
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software. 
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE. 
// 
#endregion
using System.Web;

namespace iFinity.DNN.Modules.FriendlyUrl

{
    public class RewriterUtils
    {

        static internal void RewriteUrl(HttpContext context, string sendToUrl, bool rebaseClientPath)
        {
            string x = "";
            string y = "";

            RewriteUrl(context, sendToUrl, x, y, rebaseClientPath);
        }

        static internal void RewriteUrl(HttpContext context, string sendToUrl, string sendToUrlLessQString, string filePath, bool rebaseClientPath)
        {

            // see if we need to add any extra querystring information 
            //if ((context.Request.QueryString.Count > 0))
            //{
            //    if ((sendToUrl.IndexOf("?") != -1))
            //    {
            //        sendToUrl = sendToUrl + "&" + context.Request.QueryString.ToString();
            //    }
            //    else
            //    {
            //        sendToUrl = sendToUrl + "?" + context.Request.QueryString.ToString();
            //    }
            //}

            // first strip the querystring, if any 
            string queryString = string.Empty;
            sendToUrlLessQString = sendToUrl;

            if ((sendToUrl.IndexOf("?") > 0))
            {
                sendToUrlLessQString = sendToUrl.Substring(0, sendToUrl.IndexOf("?"));
                queryString = sendToUrl.Substring(sendToUrl.IndexOf("?") + 1);
            }

            // grab the file's physical path 
            filePath = string.Empty;
            filePath = context.Server.MapPath(sendToUrlLessQString);

            //Dim msg As String = "" 
            //If (context Is Nothing) Then 
            // msg = "no context! sendToUrlLessQString = " & sendToUrlLessQString & " queryString = " & queryString 
            //Else 
            // msg = "context ok! sendToUrlLessQString = " & sendToUrlLessQString & " queryString = " & queryString 
            //End If 
            //Dim ex As Exception = New Exception(msg) 
            //Services.Exceptions.LogException(ex) 

            // rewrite the path.. 
            //context.RewritePath(sendToUrlLessQString, String.Empty, queryString) 
            //context.RewritePath(sendToUrl, true);
            context.RewritePath(sendToUrl, rebaseClientPath);

            // NOTE! The above RewritePath() overload is only supported in the .NET Framework 1.1 
            // If you are using .NET Framework 1.0, use the below form instead: 
            // context.RewritePath(sendToUrl); 

        }

        static internal string ResolveUrl(string appPath, string url)
        {

            // String is Empty, just return Url 
            if ((url.Length == 0))
            {
                return url;
            }

            // String does not contain a ~, so just return Url 
            if ((url.StartsWith("~") == false))
            {
                return url;
            }

            // There is just the ~ in the Url, return the appPath 
            if ((url.Length == 1))
            {
                return appPath;
            }

            if ((url[1] == '/' || url[1] == '\\'))
            {
                // Url looks like ~/ or ~\ 
                if ((appPath.Length > 1))
                {
                    return appPath + "/" + url.Substring(2);
                }
                else
                {
                    return "/" + url.Substring(2);
                }
            }
            else
            {
                // Url look like ~something 
                if ((appPath.Length > 1))
                {
                    return appPath + "/" + url.Substring(1);
                }
                else
                {
                    return appPath + url.Substring(1);
                }
            }

        }

    }
}
