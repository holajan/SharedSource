#region legals - read before modifying or distributing
// Copyright iFinity.com.au 
// This is customised software developed entirely by iFinity. The below copyright messages should be followed 
// and any copies of this software should include this message.  
// Usage rights and restrictions:
// You may use this software without restriction on the number of installations in private and commercial applications
// You may make modifications to the source code of this software for your own requirements.
// You may not resell copies of this software or software derived from this source code as a licensed product.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Caching;
using DotNetNuke.Common.Utilities;

namespace iFinity.DNN.Modules.FriendlyUrl

{
    public class CacheController
    {
        static CacheItemRemovedReason reason;
        static bool LogRemovedReason = false;
        CacheItemRemovedCallback onRemove = null;

        private static string TabDictKey = "tabDict";
        private static string DepthInfoKey = "depthInfo";

        private static string UrlDictKey = "urlDict";
        private static string UrlPortalsKey = "urlPortals";

        private static string UserIdsKey = "umUserIds:{0}";
        private static string DisplayNamesKey = "umDisplayNames:{0}"; 

        private static string UserProfileActionsKey = "upa";

        public void SetCache(Dictionary<string, string> tabDictionary, PathSizes depthInfo, FriendlyUrlSettings settings)
        {
            onRemove = new CacheItemRemovedCallback(this.RemovedCallBack);

            DateTime absoluteExpiration = DateTime.Now.Add(settings.CacheTime);

            DataCache.SetCache(TabDictKey, tabDictionary, null, absoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.AboveNormal, onRemove, settings.CachePersistRestart);
            DataCache.SetCache(DepthInfoKey, depthInfo, null, absoluteExpiration, Cache.NoSlidingExpiration, settings.CachePersistRestart);
            LogRemovedReason = settings.LogCacheMessages;
            object cachedObj = DataCache.GetCache(TabDictKey);
            //System.Diagnostics.Trace.Assert(cachedObj == null, "GetCache('tabDict') returned null (after stash)");
        }

        private System.Web.AspNetHostingPermissionLevel GetCurrentTrustLevel()
        {

            foreach (System.Web.AspNetHostingPermissionLevel trustLevel in
                new System.Web.AspNetHostingPermissionLevel[] 
                {
                    System.Web.AspNetHostingPermissionLevel.Unrestricted,
                    System.Web.AspNetHostingPermissionLevel.High,
                    System.Web.AspNetHostingPermissionLevel.Medium,
                    System.Web.AspNetHostingPermissionLevel.Low,
                    System.Web.AspNetHostingPermissionLevel.Minimal
                })
            {
                try
                {
                    new System.Web.AspNetHostingPermission(trustLevel).Demand();
                }
                catch (System.Security.SecurityException)
                {
                    continue;
                }
                return trustLevel;

            }
            return System.Web.AspNetHostingPermissionLevel.None;

        }


        public void RemovedCallBack(string k, object v, CacheItemRemovedReason r)
        {
            reason = r;
#if (DEBUG)
            if (LogRemovedReason)
            {
                DotNetNuke.Services.Log.EventLog.EventLogController elc = new DotNetNuke.Services.Log.EventLog.EventLogController();
                DotNetNuke.Services.Log.EventLog.LogInfo logValue = new DotNetNuke.Services.Log.EventLog.LogInfo();
                logValue.LogTypeKey = "HOST_ALERT";

            logValue.AddProperty("iFinity.FriendlyUrlProvider.Message", "Tab Dictionary Removed on Callback.  Reason: " + reason.ToString());

                elc.AddLog(logValue);
            }
#endif 
        }

    }
}
