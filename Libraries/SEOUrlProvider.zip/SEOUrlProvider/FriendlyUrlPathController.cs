#region legals - read before modifying or distributing
// Copyright iFinity.com.au 
// This is customised software developed entirely by iFinity. The below copyright messages should be followed 
// and any copies of this software should include this message.  
// Usage rights and restrictions:
// You may use this software without restriction on the number of installations in private and commercial applications
// You may make modifications to the source code of this software for your own requirements.
// You may not resell copies of this software or software derived from this source code as a licensed product.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Text;

using System.Text.RegularExpressions;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Common.Utilities;

namespace iFinity.DNN.Modules.FriendlyUrl

{
    internal class FriendlyUrlPathController
    {



    }
}

