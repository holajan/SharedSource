#region legal messages
// iFinity.com.au 
// This is customised software derived from the DotNetNuke core. The below copyright messages should be followed 
// , and any copies of this software should include this message. 
// Please feel free to distribute and modify this code, ensuring that copyright law is respected 

// 
// DotNetNuke� - http://www.dotnetnuke.com 
// Copyright (c) 2002-2005 
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca ) 
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software. 
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE. 
// 
#endregion

#region using
using System;
using System.IO;
using System.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Globalization;
using DotNetNuke;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Framework.Providers;
using System.Web.Configuration;
#endregion


namespace iFinity.DNN.Modules.FriendlyUrl
{


    public class UrlRewriteModule : IHttpModule
    {
        #region private members
        private FriendlyUrlSettings _settings;

        private const string prodName = "FriendlyUrlProvider";

        private bool _useFriendlyUrls = false;

        
        #endregion
        #region Public Properties

        public string ModuleName
        {
            get { return "UrlRewriteModule"; }
        }
        #endregion
        #region Event Handlers
        void IHttpModule.Init(HttpApplication application)
        {
            application.BeginRequest += this.OnBeginRequest;

            //get the values from the FriendlyUrl Provider web.config section. These are shared between the urlRewriter and the FriendyUrlProvider 
            ProviderConfiguration providerConfiguration = ProviderConfiguration.GetProviderConfiguration("friendlyUrl");
            Provider objProvider = (Provider)providerConfiguration.Providers[providerConfiguration.DefaultProvider];
            _settings = new FriendlyUrlSettings(objProvider);
            //648 : move useFriendlyUrls to different location
            //_useFriendlyUrls = (DotNetNuke.Entities.Host.HostSettings.GetHostSetting("UseFriendlyUrls") == "Y");
            

        }
        public void OnBeginRequest(object s, EventArgs e)
        {

            HttpApplication app = (HttpApplication)s;

            //check licensing

            SecurityCheck(app);

            ProcessRequest(app.Context, app.Request, app.Server, app.Response);
        }
        void IHttpModule.Dispose()
        {
        }
        #endregion

        #region public methods

        public void ProcessRequest(HttpContext Context, HttpRequest Request, HttpServerUtility Server, HttpResponse Response)
        {
            UrlAction result = new UrlAction(Request.Url.Scheme , Request.ApplicationPath, Request.PhysicalPath);
            result.IsSecureConnection = Request.IsSecureConnection;
            result.RawUrl = Request.RawUrl;
            _useFriendlyUrls = (DotNetNuke.Entities.Host.HostSettings.GetHostSetting("UseFriendlyUrls") == "Y");
            ProcessRequest(Context, Request,Server, Response, _useFriendlyUrls, Request.RequestType, Request.Url, result, Request.QueryString, _settings);
        }

        public void ProcessRequest(HttpContext context, HttpRequest request, HttpServerUtility Server, HttpResponse response, bool useFriendlyUrls, string requestType, Uri requestUri, UrlAction result, NameValueCollection queryStringCol, FriendlyUrlSettings settings)
        {
            bool ignoreRequest = true; bool finished = false; bool showDebug = false;
            try
            {
                showDebug = CheckForDebug(request, queryStringCol, settings.AllowDebugCode);
                string fullUrl, querystring;
                //699: get the full url based on the request and the quersytring, rather than the requestUri.ToString()
                //there is a difference in encoding, which can corrupt results when an encoded value is in the querystring
                RewriteController.GetUrlWithQuerystring(request, requestUri, out fullUrl, out querystring);

                ignoreRequest = IgnoreRequest(result, fullUrl, settings, request);
                if (!ignoreRequest)
                {
                    //find the portal alias first
                    PortalAliasInfo alias = GetPortalAlias(requestUri.AbsoluteUri);
                    if (alias != null)
                    {
                        result.portalAlias = alias;
                        result.portalId = alias.PortalID;
                    }

                    //set the path of the result object, and determine if a redirect is allowed on this request
                    result.SetOriginalPath(fullUrl, settings);
                    //check to see if a post request
                    bool postRequest = false;
                    if (request != null && request.RequestType == "POST")
                        postRequest = true;

                    PortalSettings portalSettings = null;
                    if (context != null)
                        context.Items.Add("UrlRewrite:OriginalUrl", requestUri.AbsoluteUri);
                    int portalHomeTabId = -1;
                    //Check to see if this to be rewritten into default.aspx?tabId=nn format
                    //result.SetOriginalPath(requestUri.ToString(), settings);

                    bool isPhysicalResource;
                    //this call is the main rewriting matching call.  It makes the decision on whether it is a 
                    //physical file, whether it is toe be rewritten or redirected by way of a stored rule
                    CheckForRewrite(fullUrl, querystring, result, useFriendlyUrls, queryStringCol, settings, out isPhysicalResource);

                    //check for a match on postback for the trigger dictionary rebuild, this time with the rewritten url
                    //this is done after the rewrite, so that pages which have had the name changed still match on their 'old'
                    //url.  If you rebuild the dictionary *before* the rewrite, then the page doesn't match
                    if (result.DoRewrite && postRequest)
                    {
                        bool rebuilt = RewriteController.RebuildDictionaryOnTriggerMatch(request, result, result.RewritePath, settings);
                        if (!rebuilt)
                            //check for match on original url 
                            RewriteController.RebuildDictionaryOnTriggerMatch(request, result, fullUrl, settings);
                    }

                    if (!finished && request != null && result.DoRewrite)
                    {

                        //if so, do the rewrite
                        if (context != null)
                        {
                            if (result.RewritePath.StartsWith(result.Scheme) //632 : use starts with instead of contains, because of un-encoded querystrings
                                || result.RewritePath.StartsWith(Globals.glbDefaultPage) == false)
                            {//TODO: there's got to be a better way of doing this logic than this
                                if (result.RewritePath.Contains(Globals.glbDefaultPage) == false)
                                    RewriterUtils.RewriteUrl(context, "~/" + result.RewritePath, settings.RebaseClientPath);
                                else
                                    RewriterUtils.RewriteUrl(context, result.RewritePath, settings.RebaseClientPath);
                            }
                            else
                            {
                                RewriterUtils.RewriteUrl(context, "~/" + result.RewritePath, settings.RebaseClientPath);
                            }
                        }
                    }

                    //confirm which portal the request is for 
                    if (!finished)
                    {
                        IdentifyPortalAlias(context, request, requestUri, result, queryStringCol, settings);
                        if (result.Action == UrlAction.ActionType.Redirect302Now && response != null)
                        {
                            //performs a 302 redirect if requested
                            response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                            response.Redirect(result.FinalUrl, false);
                            finished = true;
                        }
                        else
                        {
                            if (result.Action == UrlAction.ActionType.Redirect301
                                && result.FinalUrl != null && result.FinalUrl.Length > 0)
                            {
                                finished = true;
                                if (response != null)
                                {
                                    //perform a 301 redirect if one has already been found
                                    response.Status = "301 Moved Permanently";
                                    response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                                    response.AddHeader("Location", result.FinalUrl);
                                }
                            }
                        }
                    }

                    if (!finished)
                    {
                        //check to see if this tab has an external url that should be forwared or not
                        finished = CheckForTabExternalForward(result, response, settings);
                    }

                    if (!finished)
                    {
                        //add the portal settings to the app context if the portal alias has been found and is correct
                        if (result.portalId != -1 && result.portalAlias != null)
                        {
                            Globals.SetApplicationName(result.portalId);
                            // load the PortalSettings into current context 
                            portalSettings = new PortalSettings(result.tabId, result.portalAlias);
                            portalHomeTabId = portalSettings.HomeTabId;
                            if (context != null && portalSettings != null)
                            {
                                context.Items.Add("PortalSettings", portalSettings);
                            }
                            //check if a secure redirection is needed
                            //this would be done earlier in the piece, but need to know the portal settings, tabid etc before processing it
                            bool redirectSecure = CheckForSecureRedirect(portalSettings, requestUri, result, useFriendlyUrls, queryStringCol, settings);
                            if (redirectSecure)
                            {
                                if (response != null)
                                {
                                    //702 : don't check final url until checked for null reference first
                                    if (result.FinalUrl != null)
                                    {
                                        if (result.FinalUrl.StartsWith("https://"))
                                        {
                                            response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                                            response.Redirect(result.FinalUrl, false);
                                            finished = true;
                                        }
                                        else
                                        {
                                            if (settings.SslClientRedirect)
                                            {
                                                //redirect back to http version, use client redirect
                                                response.Clear();
                                                // add a refresh header to the response 
                                                response.AddHeader("Refresh", "0;URL=" + result.FinalUrl);
                                                // add the clientside javascript redirection script
                                                response.Write("<html><head><title></title>");
                                                response.Write(@"<!-- <script language=""javascript"">window.location.replace(""" + result.FinalUrl + @""")</script> -->");
                                                response.Write("</head><body><div><a href='" + result.FinalUrl + "'>" + result.FinalUrl + "</a></div></body></html>");
                                                if (showDebug)
                                                {
                                                    /*
                                                    string debugMsg = "{0}, {1}, {2}, {3}, {4}";
                                                    string productVer = System.Reflection.Assembly.GetExecutingAssembly().GetName(false).Version.ToString();
                                                    response.AppendHeader("X-" + prodName + "-Debug", string.Format(debugMsg, requestUri.AbsoluteUri, result.FinalUrl, result.RewritePath, result.Action, productVer));
                                                     */
                                                    ShowDebugData(response, requestUri.AbsoluteUri, result, null);
                                                }
                                                // send the response
                                                //response.End();
                                                finished = true;
                                            }
                                            else
                                            {
                                                response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                                                response.Redirect(result.FinalUrl, false);
                                                finished = true;
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                //check for, and do a 301 redirect if required 
                                if (CheckForRedirects(requestUri, queryStringCol, result, requestType, settings))
                                {
                                    if (response != null)
                                    {
                                        if (result.Action == UrlAction.ActionType.Redirect301)
                                        {
                                            response.Status = "301 Moved Permanently";
                                            response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                                            response.AddHeader("Location", result.FinalUrl);
                                            finished = true;
                                        }
                                        else if (result.Action == UrlAction.ActionType.Redirect302)
                                        {
                                            response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                                            response.Redirect(result.FinalUrl, false);
                                            finished = true;
                                        }

                                    }
                                }
                                else
                                {
                                    //612 : Don't clear out a 302 redirect if set
                                    if (result.Action != UrlAction.ActionType.Redirect302 && result.Action != UrlAction.ActionType.Redirect302Now)
                                    {
                                        result.Reason = UrlAction.RedirectReason.Not_Redirected;
                                        result.FinalUrl = null;
                                    }
                                }
                            }
                        }
                        else
                        {
                            // alias does not exist in database 
                            // and all attempts to find another have failed 
                            //this should only happen if the HostPortal does not have any aliases 
                            result.Action = UrlAction.ActionType.Output404;
                            if (response != null)
                            {
                                if (showDebug)
                                {
                                    /*string debugMsg = "{0}, {1}, {2}, {3}, {4}";
                                    string productVer = System.Reflection.Assembly.GetExecutingAssembly().GetName(false).Version.ToString();
                                    response.AppendHeader("X-" + prodName + "-Debug", string.Format(debugMsg, requestUri.AbsoluteUri, result.FinalUrl, result.RewritePath, result.Action, productVer));*/
                                    ShowDebugData(response, requestUri.AbsoluteUri, result, null);
                                }
                                Handle404OrException(request, response, Server, null, result);
                                finished = true;
                            }
                        }
                    }

                    if (showDebug)
                    {
                        /*string debugMsg = "{0}, {1}, {2}, {3}, {4}";
                        string productVer = System.Reflection.Assembly.GetExecutingAssembly().GetName(false).Version.ToString();
                        response.AppendHeader("X-" + prodName + "-Debug", string.Format(debugMsg, requestUri.AbsoluteUri, result.FinalUrl, result.RewritePath, result.Action, productVer));*/
                        ShowDebugData(response, requestUri.AbsoluteUri, result, null);

                    }
                }
            }
            catch (Exception ex)
            {
                if (showDebug)
                    DotNetNuke.Services.Exceptions.Exceptions.LogException(ex);
                if (response != null)
                {
                    if (showDebug)
                    {
                        ShowDebugData(response, requestUri.AbsoluteUri, result, ex);
                        /*string debugMsg = "{0}, {1}, {2}, {3}, {4}";
                        string productVer = System.Reflection.Assembly.GetExecutingAssembly().GetName(false).Version.ToString();
                        response.AppendHeader("X-" + prodName + "-Debug", string.Format(debugMsg, requestUri.AbsoluteUri, result.FinalUrl, result.RewritePath, result.Action, productVer));
                        response.AppendHeader("X-" + prodName + "-Ex", ex.Message.ToString());*/

                    }
                    if (result != null)
                        result.Ex = ex;
                    Handle404OrException(request, response, Server, ex, result);
                }
                else
                    throw ex;
            }
            finally
            {
                //808 : add in new code copied from urlRewrite class in standard Url Rewrite module
                if (context != null && context.Items["FirstRequest"] != null)
                {
                    context.Items.Remove("FirstRequest");
                    //process any messages in the eventQueue for the Application_Start_FIrstRequest event
                    DotNetNuke.Services.EventQueue.EventQueueController.ProcessMessages("Application_Start_FirstRequest");
                }
            }
        }
        
        #endregion
        #region Private Methods
        private static void ShowDebugData(HttpResponse response, string requestUri, UrlAction result, Exception ex)
        {
            if (response != null)
            {
                string debugMsg = "{0}, {1}, {2}, {3}, {4}";
                string productVer = System.Reflection.Assembly.GetExecutingAssembly().GetName(false).Version.ToString();
                response.AppendHeader("X-" + prodName + "-Debug", string.Format(debugMsg, requestUri, result.FinalUrl, result.RewritePath, result.Action, productVer));
                int msgNum = 1;
                foreach (string msg in result.DebugMessages)
                {
                    response.AppendHeader("X-" + prodName + "-Debug-" + msgNum.ToString(), msg);
                    msgNum++;
                }
                if (ex != null)
                    response.AppendHeader("X-" + prodName + "-Ex", ex.Message.ToString());
            }
        }
        private static void Handle404OrException(HttpRequest request, HttpResponse response, HttpServerUtility server, Exception ex, UrlAction result)
        {
            CustomErrorsSection ceSection = (CustomErrorsSection)WebConfigurationManager.GetSection("system.web/customErrors");
            string file404 = server.MapPath("~/404.htm");
            if (System.IO.File.Exists(file404) && result.Action == UrlAction.ActionType.Output404)
            {
                StreamReader sr;
                sr = File.OpenText(file404);
                string html = sr.ReadToEnd();
                sr.Close();
                html = html.Replace("[DOMAINNAME]", result.domainName);
                response.Write(html);
                response.StatusCode = 404;
                response.Status = "404 Not Found";
                response.End();
            }
            else
            {
                if (result.Action == UrlAction.ActionType.Output404 || ex == null)
                {
                    response.Write("404 Url Not Found<br>The requested Url (" + request.Url.ToString() + ") does not return any valid content.");
                    response.StatusCode = 404;
                    response.Status = "404 Not Found";
                }
                else
                {
                    response.Write("500 Server Error<br><div style='font-weight:bolder'>An error occured during processing : if possible, check the event log of the server</div>");
                    response.StatusCode = 500;
                    response.Status = "500 Internal Server Error";
                    result.Action = UrlAction.ActionType.Output500;
                }

                if (ex != null)
                {
                    if (ceSection != null && ceSection.Mode == System.Web.Configuration.CustomErrorsMode.Off)
                    {
                        response.Write("<div style='font-weight:bolder'>Exception:</div><div>" + ex.Message + "</div>");
                        response.Write("<div style='font-weight:bolder'>Stack Trace:</div><div>" + ex.StackTrace + "</div>");
                    }
                    else
                    {
                        response.Write("<div style='font-weight:bolder'>Administrators : Obtain more information by changing to debug mode and switching custom errors off in the configuration.</div><div>" + ex.Message + "</div>");
                    }
                }
                
            }

            FriendlyUrlController.LogExceptionInRequest(ex);

        }
        private static bool CheckForDebug(HttpRequest request, NameValueCollection queryStringCol, bool checkRequestParams)
        {
            string debugValue = ""; bool retVal=false;

            string debugToken = "_fpdebug";

            if (queryStringCol != null && queryStringCol[debugToken] != null)
            {
                debugValue =queryStringCol[debugToken];
                
            }
            else
                if (checkRequestParams)
                {
                    //798 : change reference to debug parameters
                    if (request != null && request.Params != null)
                        debugValue = (request.Params.Get("HTTP_" + debugToken.ToUpper()));
                    if (debugValue == null) debugValue = "false";
                }

            switch (debugValue.ToLower())
            {
                case "true":
                    retVal = true;
                    break;
            }
            return retVal;
        }
        /// <summary>
        /// Checks to see if the tab is to be forwarded to an external Url, as defined in the Tab settings.
        /// </summary>
        /// <param name="result">The UrlAction result</param>
        /// <param name="response">The http Response</param>
        /// <param name="settings">The friendly Url Settings</param>
        /// <returns>true if redirected and complete, false if not</returns>
        private static bool CheckForTabExternalForward(UrlAction result, HttpResponse response, FriendlyUrlSettings settings)
        {
            bool finished = false;
            //check for external forwarding
            if (result.tabId > -1 && result.portalId > -1 
                && settings.ForwardExternalUrls != DNNPageForwardTypes.NoForward)
            {
                bool allowRedirect = true;
                //594 : do not redirect settings pages for external urls
                if (result.RewritePath != null && result.RewritePath.ToLower().Contains("&ctl=tab")) 
                {
                    allowRedirect = false;
                }
                if (allowRedirect)
                {
                    TabInfo tab = null;
                    allowRedirect = CheckFor301RedirectExclusion(result.tabId, result.portalId, false, out tab, settings);
                    if (allowRedirect && tab != null && tab.TabType == TabType.Url)
                    {
                        result.FinalUrl = tab.Url;
                        result.Reason = UrlAction.RedirectReason.Tab_External_Url;
                        if (settings.ForwardExternalUrls == DNNPageForwardTypes.Redirect301)
                        {
                            result.Action = UrlAction.ActionType.Redirect301;
                            if (response != null)
                            {
                                //perform a 301 redirect to the external url of the tab
                                response.Status = "301 Moved Permanently";
                                response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                                response.AddHeader("Location", result.FinalUrl);
                            }
                        }
                        else
                        {

                            result.Action = UrlAction.ActionType.Redirect302;
                            if (response != null)
                            {
                                //perform a 301 redirect to the external url of the tab
                                response.AppendHeader("X-Redirect-Reason", result.Reason.ToString().Replace("_", " ") + " Requested");
                                response.Redirect(result.FinalUrl);
                            }
                        }
                        finished = true;
                    }
                }
            }
            return finished;
        }
        /// <summary>
        /// Checks the portal settings for page https, and either redirects the http to https, or back again
        /// </summary>
        /// <param name="portalSettings"></param>
        /// <param name="requestUri"></param>
        /// <param name="retVal"></param>
        /// <param name="useFriendlyUrls"></param>
        /// <param name="queryStringCol"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        private bool CheckForSecureRedirect(PortalSettings portalSettings, Uri requestUri, UrlAction result, bool useFriendlyUrls, NameValueCollection queryStringCol, FriendlyUrlSettings settings)
        {
            bool redirectSecure = false; 
            string url = requestUri.ToString();
            //check ssl enabled
            if (PortalSettings.GetSiteSetting(result.portalId, "SSLEnabled") == "True")
            {
                //check page is secure, connection is not secure
                if (portalSettings.ActiveTab.IsSecure && result.IsSecureConnection == false)
                {
                    redirectSecure = true;
                    string stdUrl = PortalSettings.GetSiteSetting(result.portalId, "STDURL");
                    string sslUrl = PortalSettings.GetSiteSetting(result.portalId, "SSLURL");
                    url = url.Replace("http://", "https://");
                    url = ReplaceDomainName(url, stdUrl, sslUrl);
                }
            }

            //check ssl enforced
            if (PortalSettings.GetSiteSetting(result.portalId, "SSLEnforced") == "True")
            {
                //check page is not secure, connection is secure
                if (portalSettings.ActiveTab.IsSecure == false && result.IsSecureConnection == true)
                {
                    //has connection already been forced to secure?
                    if (queryStringCol["ssl"] == null)
                    {
                        //no? well this page shouldn't be secure
                        string stdUrl = PortalSettings.GetSiteSetting(result.portalId, "STDURL");
                        string sslUrl = PortalSettings.GetSiteSetting(result.portalId, "SSLURL");
                        url = url.Replace("https://", "http://");
                        url = ReplaceDomainName(url, sslUrl , stdUrl);
                        redirectSecure = true;
                    }
                }
            }

            if (redirectSecure)
            {
                //now check to see if excluded.  Why now? because less requests are made to redirect secure,
                //so we don't have to check the exclusion as often.
                bool exclude = false;
                string doNotRedirectSecureRegex = settings.DoNotRedirectSecureRegex;
                if (doNotRedirectSecureRegex != null && doNotRedirectSecureRegex != "")
                {
                    //match the raw url
                    exclude = (Regex.IsMatch(result.RawUrl, doNotRedirectSecureRegex, RegexOptions.IgnoreCase));
                }
                if (!exclude)
                {
                    result.Action = UrlAction.ActionType.Redirect302Now;
                    result.Reason = UrlAction.RedirectReason.Secure_Page_Requested;
                    result.FinalUrl = url;
                    //717 : replace /default.aspx for home page 
                    int homePageTabId = portalSettings.HomeTabId;
                    if (result.tabId == homePageTabId)
                    {
                        //replace the /default.aspx in the Url if it was found
                        url = Regex.Replace(url, @"(?<!(\?.+))/default.aspx", "/", RegexOptions.IgnoreCase);
                    }
                }
                else
                    //702 : change return value if exclusion has occured
                    redirectSecure = false;
            }
            return redirectSecure;
        }
        private string ReplaceDomainName(string url , string replaceDomain, string withDomain)
        {
            if (replaceDomain != "" && withDomain != "")
                if (url.Contains(replaceDomain))
                    url = url.Replace(replaceDomain, withDomain);
            return url;
        }
        protected PortalAliasInfo GetPortalAlias(string requestUrl)
        {
            PortalAliasInfo alias = null;
            PortalAliasController pac = new PortalAliasController();
            OrderedDictionary portalRegexes = GetPortalAliasRegexes();
            foreach (string regexPattern in portalRegexes.Keys)
            {
                //split out the portal alias from the regex pattern representing that alias
                if (Regex.IsMatch(requestUrl, regexPattern, RegexOptions.IgnoreCase))
                {
                    alias = (PortalAliasInfo)portalRegexes[regexPattern];
                    break;
                }
            }
            return alias;
        }
        protected bool CheckforPortalAliasRedirect(HttpContext context, HttpRequest request, Uri requestUri, UrlAction result, NameValueCollection queryStringCol, FriendlyUrlSettings settings)
        {
            //now check to make sure it's the chosen portal alias for this portal
            bool redirected = false;
            if (result.RedirectAllowed)
            {
                if (settings.UsePortalAlias != null && settings.UsePortalAlias.Length > 0
                    && queryStringCol != null && queryStringCol["forceAlias"] != "true")
                {
                    string alias = null;
                    if (settings.ChosenPortalAliases != null 
                     && settings.ChosenPortalAliases.Count > 0 
                     && settings.ChosenPortalAliases.ContainsKey(result.portalId))
                    {
                        alias = settings.ChosenPortalAliases[result.portalId];
                    }
                    else
                    {
                        alias = settings.UsePortalAlias;
                    }
                    if (string.Compare(alias, result.HttpAlias, true) != 0)
                    {
                        //wrong alias for the portal
                        //replaced to the correct alias
                        result.Action = UrlAction.ActionType.Redirect301;
                        result.Reason = UrlAction.RedirectReason.Wrong_Portal_Alias;
                        string destUrl = result.OriginalPath.Replace(result.HttpAlias, alias);
                        destUrl = CheckForSiteRootRedirect(alias, destUrl);
                        redirected = true;
                        result.FinalUrl = destUrl;
                    }
                }
            }
            return redirected;
        }
        /// <summary>
        /// Returns an ordered dictionary of alias regex patterns.  These patterns are used to identify a portal alias by getting a match.
        /// </summary>
        /// <returns></returns>
        protected OrderedDictionary GetPortalAliasRegexes()
        {
            //get all aliases for this DNN install
            PortalAliasController pac = new PortalAliasController();
            PortalAliasCollection aliases = pac.GetPortalAliases();
            //create a new OrderedDictionary.  We use this because we
            //want to key by the correct regex pattern and return the
            //portalAlias that matches, and we want to preserve the
            //order of the items, such that the item with the most path separators (/)
            //is at the front of the list.  
            OrderedDictionary regexList = new OrderedDictionary(aliases.Count);
            //this regex pattern, when formatted with the httpAlias, will match a request 
            //for this portalAlias
            string aliasRegexPattern = @"(?:^(?<http>http[s]{0,1}://){0,1})(?<alias>_ALIAS_(?<path>$|/[\w]*))";
            List<int> pathLengths = new List<int>();
            foreach (string aliasKey in aliases.Keys)
            {
                PortalAliasInfo alias = aliases[aliasKey];
                //regex escape the portal alias for inclusion into a regex pattern
                string plainAlias = alias.HTTPAlias;
                string escapedAlias = Regex.Escape(plainAlias);
                //format up the regex pattern by replacing the alias portion with the portal alias name
                string regexPattern = aliasRegexPattern.Replace("_ALIAS_", escapedAlias);
                //work out how many path separators there are in the portalAlias (ie myalias/mychild = 1 path)
                int pathLength = plainAlias.Split('/').GetUpperBound(0);
                //now work out where in the list we should put this portalAlias regex pattern
                //the list is to be sorted so that those aliases with the most paths 
                //are at the front of the list : ie, they are tested first
                int insertPoint = pathLengths.Count - 1;
                //walk through the existing list of path lengths,
                //and ascertain where in the list this one falls
                //if they are all the same path length, then place them in portal alias order
                for (int i = 0; i < pathLengths.Count; i++)
                {
                    insertPoint = i;
                    if (pathLength > pathLengths[i])
                        //larger than this position, insert at this value
                        break;
                    else
                        insertPoint++; //next one along (if at end, means add)
                }
                if (pathLengths.Count > 0 && insertPoint <= pathLengths.Count - 1)
                {
                    //put the new regex pattern into the correct position
                    regexList.Insert(insertPoint, regexPattern, alias);
                    pathLengths.Insert(insertPoint, pathLength);
                }
                else
                {
                    //put the new regex pattern on the end of the list
                    regexList.Add(regexPattern, alias);
                    pathLengths.Add(pathLength);
                }
            }
            return regexList;
        }
        /// <summary>
        /// Identifies the portal so that the PortalSettings (id, alias, etc) can be loaded for the current request
        /// </summary>
        /// <param name="requestUri"></param>
        /// <param name="retVal"></param>
        /// <param name="queryStringCol"></param>
        /// <param name="settings"></param>
        private void IdentifyPortalAlias(HttpContext context, HttpRequest request, Uri requestUri, UrlAction result, NameValueCollection queryStringCol, FriendlyUrlSettings settings)
        {
            //get the domain name of the request, if it isn't already supplied
            if (request != null && (result.domainName == "" || result.domainName == null))
                result.domainName = Globals.GetDomainName(request);//parse the domain name out of the request

            // get tabId from querystring ( this is mandatory for maintaining portal context for child portals ) 
            if (queryStringCol["tabid"] != null)
            {
                string raw = queryStringCol["tabid"];
                int tabId;
                if (Int32.TryParse(raw, out tabId))
                {
                    result.tabId = tabId;
                }
                else
                {
                    //couldn't parse tab id
                    //split in two?
                    string[] tabids = raw.Split(',');
                    if (tabids.GetUpperBound(0) > 0)
                    {
                        //hmm more than one tabid
                        if (Int32.TryParse(tabids[0], out tabId))
                        {
                            result.tabId = tabId;
                            //but we want to warn against this!
                            Exception ex = new Exception("Illegal request exception : Two TabId parameters provided in a single request: " + requestUri.ToString());

                            FriendlyUrlController.LogExceptionInRequest(ex);


                            result.Ex = ex;
                        }
                        else
                        {
                            //yeah, nothing, divert to 404 
                            result.Action = UrlAction.ActionType.Output404;
                            Exception ex = new Exception("Illegal request exception : TabId parameters in query string, but invalid TabId requested : " + requestUri.ToString());

                            FriendlyUrlController.LogExceptionInRequest(ex);

                            result.Ex = ex;
                        }
                    }
                }
            }
            // get PortalId from querystring ( this is used for host menu options as well as child portal navigation ) 
            if (queryStringCol["portalid"] != null)
            {
                string raw = queryStringCol["portalid"];
                int portalId;
                if (Int32.TryParse(raw, out portalId))
                {
                    if (result.portalId != portalId)
                    {
                        //portal id different to what we expected
                        result.portalId = portalId;
                    }
                }
            }
            else
            {
                //check for a portal alias if there's no portal Id in the query string
                //check for absence of captcha value, because the captcha string re-uses the alias querystring value
                if (queryStringCol["alias"] != null && queryStringCol["captcha"] == null)
                {
                    string alias = (string)queryStringCol["alias"];
                    PortalAliasInfo portalAlias = PortalSettings.GetPortalAliasInfo(alias);
                    if (portalAlias != null)
                    {
                        //ok the portal alias was found by the alias name
                        // check if the alias contains the domain name
                        if (alias.Contains(result.domainName) == false)
                        {
                            // replaced to the domain defined in the alias 
                            if (request != null)
                            {
                                string redirectDomain = Globals.GetPortalDomainName(alias, request, true);
                                //retVal.Url = redirectDomain;
                                result.FinalUrl = redirectDomain;
                                result.Action = UrlAction.ActionType.Redirect302Now;
                                result.Reason = UrlAction.RedirectReason.Alias_In_Url;
                            }
                        }
                        else
                        {
                            // the alias is the same as the current domain 
                            result.HttpAlias = portalAlias.HTTPAlias;
                            result.portalAlias = portalAlias;
                            result.portalId = portalAlias.PortalID;
                            //don't use this crap though - we don't want ?alias=portalAlias in our Url
                            if (result.RedirectAllowed)
                            {
                                string redirect = request.Url.Scheme + System.Uri.SchemeDelimiter + result.portalAlias.HTTPAlias + "/";
                                result.Action = UrlAction.ActionType.Redirect301;
                                result.FinalUrl = redirect;
                                result.Reason = UrlAction.RedirectReason.Unfriendly_Url;
                            }
                        }
                    }
                }
            }
            //first try and identify the portal using the tabId, but only if we identified this tab by looking up the tabid
            //from the original url
            //668 : error in child portal redirects to child portal home page because of mismatch in tab/domain name
            if (result.tabId != -1 && result.FriendlyRewrite == false)
            {
                // get the alias from the tabid, but only if it is for a tab in that domain 
                // 2.0 : change to compare retrieved alias to the already-set httpAlias
                string httpAliasFromTab = PortalSettings.GetPortalByTab(result.tabId, result.domainName);
                if (result.portalAlias != null && httpAliasFromTab != null 
                    && string.Compare(result.portalAlias.HTTPAlias, httpAliasFromTab, true) != 0)
                {
                    //691 : change logic to force change in portal alias context rather than force back.
                    //This is because the tabid in the query string should take precedence over the portal alias
                    //to handle parent.com/default.aspx?tabid=xx where xx lives in parent.com/child/ 
                    TabController tc = new TabController();
                    TabInfo tab = tc.GetTab(result.tabId);
                    if (tab != null && tab.PortalID != result.portalAlias.PortalID)
                    {
                        //the tabid is different to the identified portalid from the original alias identified
                        //so get a new alias 
                        PortalAliasController pac = new PortalAliasController();
                        PortalAliasInfo tabPortalAlias = pac.GetPortalAlias(httpAliasFromTab, tab.PortalID);
                        if (tabPortalAlias != null)
                        {
                            result.portalId = tabPortalAlias.PortalID;
                            result.portalAlias = tabPortalAlias;
                            result.Action = UrlAction.ActionType.CheckFor301;
                            result.Reason = UrlAction.RedirectReason.Wrong_Portal;
                            /*
                            string url = MakeUrlWithAlias(requestUri, result.portalAlias);
                            if (result.RedirectAllowed)
                            {
                                if (url.ToLower().IndexOf(result.domainName.ToLower()) == -1)
                                {
                                    url += requestUri.PathAndQuery;
                                }
                                else
                                {
                                    //append querystring onto end if we are transferring portals
                                    url += requestUri.Query;
                                }
                                //replaced ot the correct portal
                                result.Action = UrlAction.ActionType.Redirect301;
                                result.FinalUrl = url;
                                result.Reason = UrlAction.RedirectReason.Wrong_Portal;
                            }
                             */ 
                        }
                    }
                }
            }


            if (result.HttpAlias != null && result.HttpAlias != "")
            {
                result.portalAlias = PortalSettings.GetPortalAliasInfo(result.HttpAlias);
            }
            else
            {
                result.portalAlias = PortalSettings.GetPortalAliasInfo(result.domainName);
                if (result.portalAlias == null && result.domainName.EndsWith("/"))
                {
                    result.domainName = result.domainName.TrimEnd('/');
                    result.portalAlias = PortalSettings.GetPortalAliasInfo(result.domainName);
                }
            }

            if (result.portalId == -1)
            {
                if (!requestUri.LocalPath.ToLower().EndsWith(Globals.glbDefaultPage.ToLower()))
                {
                    // allows requests for aspx pages in custom folder locations to be processed 
                    return; //TODO: get rid of this unstructed exit!!
                }
                else
                {
                    //the domain name was not found so try using the host portal's first alias 
                    if ((string)Globals.HostSettings["HostPortalId"] != "")
                    {
                        if (Int32.TryParse((string)Globals.HostSettings["HostPortalId"], out result.portalId))
                        {
                            // use the host portal, but replaced to the host portal home page
                            PortalAliasController pac = new PortalAliasController();
                            ArrayList aliases = pac.GetPortalAliasArrayByPortalID(result.portalId);
                            if (aliases.Count > 0)
                            {
                                string strURL = requestUri.AbsolutePath;
                                // 627 : request doesn't match any portal alias, so check for 'usePortalAlias' settings
                                if (settings.UsePortalAlias != null 
                                    && settings.UsePortalAlias.Length > 0 
                                    && settings.ChosenPortalAliases.ContainsKey(result.portalId))
                                {
                                    //get the alias as the chosen portal alias for the host portal
                                    string alias = settings.ChosenPortalAliases[result.portalId];
                                    result.Action = UrlAction.ActionType.Redirect301;
                                    result.Reason = UrlAction.RedirectReason.Host_Portal_Used;
                                    string destUrl = MakeUrlWithAlias(requestUri, alias);
                                    destUrl = CheckForSiteRootRedirect(alias, destUrl);
                                    result.FinalUrl = destUrl;
                                }
                                else
                                {
                                    //Get the first Alias for the host portal
                                    result.portalAlias = (PortalAliasInfo)aliases[result.portalId];
                                    string url = MakeUrlWithAlias(requestUri, result.portalAlias);
                                    if (result.tabId != -1)
                                    {
                                        url += requestUri.Query;
                                    }
                                    result.FinalUrl = url;
                                    result.Reason = UrlAction.RedirectReason.Host_Portal_Used;
                                    result.Action = UrlAction.ActionType.Redirect302Now;
                                }
                            }
                        }
                    }
                }
            }

            //now check to make sure it's the chosen portal alias for this portal
            //627 : don't do it if we're redirecting to the host portal 
            if (result.RedirectAllowed && result.Reason != UrlAction.RedirectReason.Host_Portal_Used)
            {
                if (settings.UsePortalAlias != null && settings.UsePortalAlias.Length > 0
                    && queryStringCol != null && queryStringCol["forceAlias"] != "true")
                {
                    if (settings.ChosenPortalAliases.ContainsKey(result.portalId))
                    {
                        string alias = settings.ChosenPortalAliases[result.portalId];
                        if (string.Compare(alias, result.HttpAlias, true) != 0)
                        {
                            //wrong alias for the portal
                            //replaced to the correct alias
                            result.Action = UrlAction.ActionType.Redirect301;
                            result.Reason = UrlAction.RedirectReason.Wrong_Portal_Alias;
                            string destUrl = result.OriginalPath.Replace(result.HttpAlias, alias);
                            destUrl = CheckForSiteRootRedirect(alias, destUrl);
                            result.FinalUrl = destUrl;
                        }
                    }
                }
            }

            //check to see if we have to avoid the core 302 redirect for the portal alias that is in the /defualt.aspx 
            //for child portals
            if (result.DoRewrite == false && result.Action == UrlAction.ActionType.Continue)
            {
                //what we are going to test for here is that if this is a child portal request, for the /default.aspx of the child portal
                //then we are going to avoid the core 302 redirect to ?alias=portalALias by rewriting to the /default.aspx of the site root
                //684 : don't convert querystring items to lower case
                string requestUrl = request.Url.AbsoluteUri;
                string defaultPageUrl = request.Url.Scheme + System.Uri.SchemeDelimiter + result.portalAlias.HTTPAlias + "/" + Globals.glbDefaultPage.ToLower();
                //660 : look for a querystring on the site root for a child portal, and handle it if so
                bool rewriteAsAliasRoot = false; string aliasQueryString = null;
                if (string.Compare(requestUrl.ToLower(), defaultPageUrl, false) == 0)
                {
                    //exact match : that's the alias root
                    rewriteAsAliasRoot = true;
                    aliasQueryString = "";
                }
                if (!rewriteAsAliasRoot && requestUrl.Contains("?"))
                {
                    //is we didn't get an exact match but there is a querystring, then investigate
                    string[] requestUrlParts = requestUrl.Split('?');
                    if (requestUrlParts.GetUpperBound(0) > 0)
                    {
                        string rootPart = requestUrlParts[0];
                        string queryString = requestUrlParts[1];
                        if (string.Compare(rootPart, defaultPageUrl, true) ==0)
                        {
                            //rewrite, but put in the querystring on the rewrite path
                            rewriteAsAliasRoot = true;
                            aliasQueryString = "?" + queryString;
                            //674: check for 301 if this value is a tabid/xx - otherwise the url will just evaluate as is
                            if (queryString.ToLower().StartsWith("tabid="))
                                result.Action = UrlAction.ActionType.CheckFor301;
                        }
                    }
                }
                if (rewriteAsAliasRoot)
                {
                    result.DoRewrite = true;
                    result.RewritePath = "~/" + Globals.glbDefaultPage + aliasQueryString;
                    //the expected /default.aspx path (defaultPageUrl) matches the requested Url (/default.aspx)
                    RewriterUtils.RewriteUrl(context,result.RewritePath, settings.RebaseClientPath);
                }
            }
        }
        private static string MakeUrlWithAlias(Uri requestUri, string httpAlias)
        {
            string url = requestUri.AbsolutePath;
            if (requestUri.AbsoluteUri.ToLower().StartsWith("https://"))
            {
                url = "https://" + httpAlias.Replace("*.", "") + "/";
            }
            else
            {
                url = "http://" + httpAlias.Replace("*.", "") + "/";
            }
            return url;
        }
        private static string MakeUrlWithAlias(Uri requestUri, PortalAliasInfo alias)
        {
            return MakeUrlWithAlias(requestUri, alias.HTTPAlias);
        }
        
        private bool CheckForRedirectToAlias(NameValueCollection queryStringCol, UrlAction result)
        {
            bool redirect = false;
            //Check for alias redirection for child portal Alias
            // alias parameter can be used to switch portals 
            if ((queryStringCol["alias"] != null))
            {
                // check if the alias is valid 
                result.HttpAlias = (string)queryStringCol["alias"];
                if ((PortalSettings.GetPortalAliasInfo(result.HttpAlias) != null))
                {
                    // check if the alias contains the domain name ('child portal')
                    if (result.HttpAlias.Contains(result.domainName))
                    //if (Strings.InStr(1, queryStringCol["alias"], domainName, CompareMethod.Text) == 0)
                    {
                        // replaced to the url defined in the alias 
                        //response.Redirect(Globals.GetPortalDomainName(queryStringCol["alias"], request, true));
                        redirect = true;
                    }
                }
            }
            return redirect;
        }
        /// <summary>
        /// Determines whether to ignore the request and do not perform any processing at all
        /// </summary>
        /// <param name="requestedPath"></param>
        /// <returns></returns>
        private static bool IgnoreRequest(UrlAction result, string requestedPath, FriendlyUrlSettings settings, HttpRequest request)
        {
            bool retVal = false;
            //check if we are upgrading/installing 
            if (request != null && request.PhysicalPath.EndsWith("install.aspx", true, CultureInfo.InvariantCulture))
            {
                //ignore all install requests
                retVal = true;
            }
            else
            {
                try
                {
                    if ((settings.IgnoreRegex.Length > 0))
                    {
                        if (Regex.IsMatch(requestedPath, settings.IgnoreRegex, RegexOptions.IgnoreCase))
                        {
                            retVal = true;
                        }
                    }
                }
                catch (Exception ex)
                {

                    FriendlyUrlController.LogExceptionInRequest(ex);


                    result.Ex = ex;
                }
            }
            return retVal ;
        }

        /// <summary> 
        /// Process an incoming ASP.NET request for potential tab rewriting, plus identification of which portal the request belongs to 
        /// </summary> 
        /// <param name="context"></param> 
        /// <param name="request"></param> 
        /// <param name="server"></param> 
        /// <param name="response"></param> 
        /// <remarks></remarks> 
        /// 
        private static void CheckForRewrite(string fullUrl, string queryString, UrlAction result, bool useFriendlyUrls, NameValueCollection queryStringCol, FriendlyUrlSettings settings, out bool isPhysicalResource)
        {
            bool doRewrite = false;
            isPhysicalResource = false;
            if (RewriteController.RewriteRequest(result, fullUrl, settings))
            {
                bool doSiteUrlProcessing = false;
                //728 new regex expression to pass values onto the siteurls.config file
                if (settings.UseSiteUrlsRegex != null && settings.UseSiteUrlsRegex != "")
                {
                    doSiteUrlProcessing = Regex.IsMatch(fullUrl, settings.UseSiteUrlsRegex, RegexOptions.IgnoreCase);
                }

                //just check to make sure it isn't a physical resource on the server
                bool checkForRewrites;
                RewriteController.IdentifyByPhysicalResource(result.PhysicalPath, fullUrl, queryStringCol, result, useFriendlyUrls, settings, out isPhysicalResource, out checkForRewrites);
                if (checkForRewrites)  //if a virtual request, go on to find the rewritten path
                {
                    doRewrite = RewriteController.IdentifyByTabPathEx(fullUrl, queryString, result, settings);
                    if (!doRewrite)
                    {
                        doSiteUrlProcessing = true;//check the siteurls.config file for a rule
                    }
                }
                if (doSiteUrlProcessing)
                {
                    //728 : compare requests against the siteurls.config file, either if no other match was found, or if we want to skip the rest of the processing
                    // Try to identify to using a regex, if it fails, try identifying by TabPath. 
                    doRewrite = RewriteController.IdentifyByRegEx(fullUrl, queryString, result.ApplicationPath, result, settings);
                }
            }
        }
        private void SecurityCheck(HttpApplication app)
        {

            HttpRequest request = app.Request;
            HttpServerUtility server = app.Server;

            //675 : unnecessarily strict url validation
            // URL validation 
            // check for ".." escape characters commonly used by hackers to traverse the folder tree on the server 
            // the application should always use the exact relative location of the resource it is requesting 
            string strURL = request.Url.AbsolutePath;
            string strDoubleDecodeURL = server.UrlDecode(server.UrlDecode(request.RawUrl));
            if (Regex.Match(strURL, "[\\\\/]\\.\\.[\\\\/]").Success | Regex.Match(strDoubleDecodeURL, "[\\\\/]\\.\\.[\\\\/]").Success) 
            {
                throw new HttpException(404, "Not Found");
            }

            //fix for ASP.NET canonicalization issues http://support.microsoft.com/?kbid=887459 
            char chr = (char)92;
            if ((request.Path.IndexOf(chr) >= 0 | System.IO.Path.GetFullPath(request.PhysicalPath) != request.PhysicalPath))
            {
                throw new HttpException(404, "Not Found");
            }

        }

        
        private string ReturnAsQueryString(string keyName, string keyValue)
        {
            if ((keyName.Length > 0 && keyName.Substring(0, 1) == "/"))
            {
                keyName = keyName.Substring(1);
            }
            if ((keyValue.Length > 0 && keyValue.Substring(0, 1) == "/"))
            {
                keyValue = keyValue.Substring(1);
            }
            keyName = System.Web.HttpUtility.UrlEncode(keyName, System.Text.Encoding.UTF8);
            keyValue = System.Web.HttpUtility.UrlEncode(keyValue, System.Text.Encoding.UTF8);
            return keyName + "=" + keyValue;
        }
        private string ReturnAsQueryString(string keyAndValue)
        {
            //strip leading / if exists 
            if ((keyAndValue.Length > 0 && keyAndValue.Substring(0, 1) == "/"))
            {
                keyAndValue = keyAndValue.Substring(1);
            }
            string[] key = keyAndValue.Split(Convert.ToChar("/"));
            if ((key.GetUpperBound(0) == 1))
            {
                return ReturnAsQueryString(key[0], key[1]);
            }
            else
            {
                return ReturnAsQueryString(key[0], "");
            }
        }
        private static bool CheckForRedirects(Uri requestUri, NameValueCollection queryStringCol, UrlAction result, string requestType, FriendlyUrlSettings settings)
        {
            bool redirected = false;
            if (queryStringCol["error"] == null && queryStringCol["message"] == null && requestType != "POST")
            {
                //if the / is missing from an extension-less request, then check for a 301 redirect
                if (settings.PageExtensionUsage == PageExtensionUsage.Never)
                {
                    //575 check on absolutePath instead of absoluteUri : this ignores query strings and fragments like #
                    //610 don't always end with '/' - reverses previous setting
                    //687 don't double-check 301 redirects.  'CheckFor301' is less concise than 'Redirect301'
                    if (requestUri.AbsolutePath.EndsWith("/") == true && result.Action != UrlAction.ActionType.Redirect301 )   
                        result.Action = UrlAction.ActionType.CheckFor301;
                }
                string scheme = requestUri.Scheme + Uri.SchemeDelimiter.ToString();
                bool queryStringHas301Parm = (queryStringCol["do301"] != null);//727 : keep a bool value if there is a do301 request in the querystring
                //check for a 301 request in the query string, or an explicit 301 or 302 request
                if (result.tabId > -1 && (result.Action == UrlAction.ActionType.Redirect301 
                    || queryStringCol["do301"] != null || result.Action == UrlAction.ActionType.Redirect302))
                {
                    //we have ordered a 301 redirect earlier in the code
                    TabController tc = new TabController();
                    //get the url for redirection
                    string pathOnly = result.RewritePath;
                    if (result.DoRewrite == false)
                    {//if no rewrite, then the path should have been a non-friendly path, and therefore can be passed in to get the friendly Url
                        pathOnly = requestUri.Authority + requestUri.PathAndQuery;
                        int aliasEnd = pathOnly.IndexOf(result.portalAlias.HTTPAlias, StringComparison.InvariantCultureIgnoreCase) + result.portalAlias.HTTPAlias.Length;
                        if (aliasEnd > -1)
                            pathOnly = pathOnly.Substring(aliasEnd);
                        pathOnly = System.Web.HttpUtility.UrlDecode(pathOnly, System.Text.Encoding.UTF8);
                    }
                    //don't really care what the value is, but need it for replacing 
                    //727 prevent redirectLoop with do301 in querystring
                    if (result.Action == UrlAction.ActionType.Redirect301 || queryStringHas301Parm)
                    {
                        string val = queryStringCol["do301"];
                        if (val == null || val == "")
                            val = "true";
                        //nix the 301 redirect query string value or terminal loops-a-plenty 
                        pathOnly = pathOnly.Replace("&do301=" + val, "");
                        pathOnly = pathOnly.Replace("?do301=" + val, "");
                    }
                    if (result.Action == UrlAction.ActionType.Redirect302)
                    {
                        string val = queryStringCol["do302"];
                        if (val == null || val == "")
                            val = "true";
                        //nix the 302 redirect query string value or terminal loops-a-plenty 
                        pathOnly = pathOnly.Replace("&do302=" + val, "");
                        pathOnly = pathOnly.Replace("?do302=" + val, "");
                    }
                    //check for exclusion by regex for this url
                    if (result.RedirectAllowed)
                    {
                        //get the tab so we know where to go
                        TabInfo tab = null;
                        bool allowRedirect = CheckFor301RedirectExclusion(result.tabId,result.portalId, true, out tab, settings);

                        if (allowRedirect)
                        {
                            string bestFriendlyUrl = null;
                            string cleanPath = pathOnly;
                            //592 : check for permanent redirect
                            bool permRedirect = false;
                            //check using reflection to provide backwards compatibility
                            System.Reflection.PropertyInfo pi = tab.GetType().GetProperty("PermanentRedirect");
                            if (pi != null)
                            {
                                permRedirect = (bool)pi.GetValue(tab, null);
                            }
                            if (permRedirect)
                            {
                                int redirectTabId = -1;
                                if (int.TryParse(tab.Url, out redirectTabId))
                                {
                                    //ok, redirecting to a new tab, specified by the tabid in the Url field
                                    TabInfo redirectTab = tc.GetTab(redirectTabId);
                                    //now get the friendly url for that tab

                                    bestFriendlyUrl = SEOUrlProvider.ImprovedFriendlyUrl(redirectTab, pathOnly, Globals.glbDefaultPage, result.HttpAlias, false, settings);

                                }
                                else
                                {
                                    //use the url, as specified in the dnn tab url property
                                    //776 : when no url, don't redirect 
                                    if (tab.Url != "")
                                    {
                                        bestFriendlyUrl = tab.Url;
                                        redirected = true;
                                    }
                                    else
                                    {
                                        //776: no actual Url for the 'perm redirect'.
                                        //this is a mistake on the part of the person who created the perm redirect
                                        //but don't create a redirect or there will be a terminal loop
                                        permRedirect = false;
                                        redirected = false;
                                        result.Reason = UrlAction.RedirectReason.Not_Redirected;
                                        result.FinalUrl = null;
                                    }

                                    bestFriendlyUrl = tab.Url;
                                }
                            }
                            else
                            {
                                // no dnn based permanent redirect, so find out the destination page by calling the friendlyUrlProvider for the most appropriate url for the page

                                bestFriendlyUrl = SEOUrlProvider.ImprovedFriendlyUrl(tab, pathOnly, Globals.glbDefaultPage, result.HttpAlias, false, settings);

                            }
                            //get what the friendly Url for this tab should be and stick it in as the redirect
                            redirected = true;
                            if (queryStringHas301Parm)//727 : using boolean because we wanted to get rid of the do301 before calculating the correct url
                            {

                                result.Action = UrlAction.ActionType.Redirect301;
                                if (result.Reason == UrlAction.RedirectReason.Not_Redirected)
                                    result.Reason = UrlAction.RedirectReason.Unfriendly_Url;
                            }
                            result.FinalUrl = bestFriendlyUrl;
                            result.RewritePath = pathOnly;
                        }
                        else
                        {
                            //redirect disallowed 618: dont' clear if 302 redirect selected
                            if (result.Action != UrlAction.ActionType.Redirect302Now || result.Action != UrlAction.ActionType.Redirect302)
                            {
                                result.FinalUrl = "";
                                result.Reason = UrlAction.RedirectReason.Not_Redirected;
                                result.Action = UrlAction.ActionType.Continue;
                            }
                        }
                    }
                }
                else if (result.tabId > -1 && result.RedirectAllowed && result.Action == UrlAction.ActionType.CheckFor301)
                {
                    //301 check was requested in earlier processing
                    //get the tab controller and retrieve the tab the request is for 
                    TabInfo tab = null;
                    //don't redirect unless allowed, the tab is valid, and it's not an admin or super tab 
                    if (settings.RedirectUnfriendly)
                    {
                        bool allowRedirect = CheckFor301RedirectExclusion(result.tabId,result.portalId, true, out tab, settings);
                        if (allowRedirect && tab != null)
                        {
                            //remove the http alias from the url. Do this by putting the url back together from the request and removing the alias 
                            string pathOnly = null;
                            if (result.DoRewrite)
                            {
                                pathOnly = result.RewritePath;
                                int pos = pathOnly.IndexOf("default.aspx", StringComparison.OrdinalIgnoreCase);
                                if (pos > -1)
                                {
                                    pathOnly = pathOnly.Substring(pos);
                                }
                            }
                            else
                                pathOnly = requestUri.Host + requestUri.PathAndQuery;
                            int aliasEnd = pathOnly.IndexOf(result.portalAlias.HTTPAlias, StringComparison.InvariantCultureIgnoreCase);
                            if (aliasEnd > -1)
                            {
                                pathOnly = pathOnly.Substring(aliasEnd + result.portalAlias.HTTPAlias.Length);
                            }
                            pathOnly = System.Web.HttpUtility.UrlDecode(pathOnly, System.Text.Encoding.UTF8);
                            //what happens here is that the request is reverse-engineered to see if it matches what the friendly Url shoudl have been 
                            //get what the friendly Url for this tab should be 
                            string bestFriendlyUrl = "";
                            string cleanPath = pathOnly;
                            Match match = Regex.Match(pathOnly, "(?:&(?<parm>.[^&]+)=$)", RegexOptions.IgnoreCase);
                            if (match.Success)
                            {
                                //when the pathOnly value ends with '=' it means there is a query string pair with a key and no value
                                //make the assumption that this was passed in as a page name OTHER than default page
                                string pageName = match.Groups["parm"].Value; //get the last parameter in the list
                                
                                cleanPath = cleanPath.Replace(match.Value, ""); //remove the last parameter from the path
                                
                                //generate teh friendly URl name with the last parameter as the page name, not a query string parameter

                                bestFriendlyUrl = SEOUrlProvider.ImprovedFriendlyUrl(tab, cleanPath, pageName + settings.PageExtension, result.HttpAlias, false, settings);

                            }
                            else

                                bestFriendlyUrl = SEOUrlProvider.ImprovedFriendlyUrl(tab, pathOnly, DotNetNuke.Common.Globals.glbDefaultPage, result.HttpAlias, false, settings);

                            //if the incomign request doesn't match the 'most friendly' url, a 301 Moved Permanently status is returned, along with the friendly url 
                            string rawUrlWithHost = System.Web.HttpUtility.UrlDecode(scheme + requestUri.Host + requestUri.PathAndQuery).ToLower();
                            string rawUrlWithHostNoScheme = rawUrlWithHost.Replace(scheme, "");
                            //check the bestFriendlyUrl against either the url, or rawUrl (with and without host) 
                            string bestFriendlyNoScheme = bestFriendlyUrl.ToLower().Replace(scheme, "");
                            string requestedPathNoScheme = requestUri.AbsoluteUri.Replace(scheme, "").ToLower();
                            if (!(bestFriendlyNoScheme == requestedPathNoScheme
                                || bestFriendlyNoScheme == rawUrlWithHost
                                || bestFriendlyNoScheme == rawUrlWithHostNoScheme
                                || bestFriendlyNoScheme == System.Web.HttpUtility.UrlDecode(requestedPathNoScheme)
                                || bestFriendlyNoScheme == requestUri.AbsoluteUri.ToLower())) //|| bestFriendlyNoScheme == request.RawUrl.ToLower()))
                            {
                                redirected = true;
                                result.Action = UrlAction.ActionType.Redirect301;
                                result.FinalUrl = bestFriendlyUrl;
                                result.Reason = UrlAction.RedirectReason.Unfriendly_Url;
                            }
                        }
                    }
                }

                if (result.RedirectAllowed && (settings.RedirectWrongCase || settings.RedirectToSubDomain != null))
                {
                    //check for redirects where a redirectToSubDomain is specified, 
                    //redirect for Wrong case is specified, and there is a valid tab and it's not already redirected somewhere else
                    bool doRedirect = false;
                    string redirectPath = null;
                    if (redirected)
                        redirectPath = result.FinalUrl;
                    else 
                        redirectPath = requestUri.AbsoluteUri;
                    string redirectPathOnly = redirectPath;
                    if (redirectPathOnly.Contains("?"))
                    {
                        redirectPathOnly = redirectPathOnly.Substring(0, redirectPathOnly.IndexOf("?"));
                    }
                    // Thanks Etienne for the fix for Diacritic Characters Terminal Loop!
                    // if the url contains url encoded characters, they appear here uppercase -> %C3%83%C2
                    // decode the url to get back the original character and do proper casing comparison
                    string urlDecodedRedirectPath = HttpUtility.UrlDecode(redirectPathOnly);
                    //check for wrong case redirection
                    if (settings.RedirectWrongCase && string.Compare(urlDecodedRedirectPath, urlDecodedRedirectPath.ToLower(),false) != 0)
                    {
                        bool allowRedirect = redirected ; //if already redirected, then it was allowed, wasn't it?
                        if (redirected == false)
                        {
                            TabInfo tab = null;
                            allowRedirect = CheckFor301RedirectExclusion(result.tabId,result.portalId ,false, out tab, settings);
                        }
                        if (allowRedirect && settings.ForceLowerCaseRegex != null && settings.ForceLowerCaseRegex != "")
                        {
                            //don't allow redirect if excluded from redirecting in the force lower case regex pattern (606)
                            allowRedirect = !Regex.IsMatch(redirectPath, settings.ForceLowerCaseRegex, RegexOptions.IgnoreCase);
                        }
                        if (allowRedirect)
                        {
                            //special case : when IIS automatically places /default.aspx on the end of the string,
                            //then don't try and redirect to the lower case /default.aspx, just let it through.
                            //we don't know whether IIS appended /Default.aspx on the end, however, we can guess
                            //if the redirectDefault.aspx is turned on (511)
                            if (settings.RedirectDefaultPage == false && redirectPathOnly.EndsWith(Globals.glbDefaultPage, StringComparison.InvariantCultureIgnoreCase))
                            {
                                //ignore this, because it's just a redirect of the /Default.aspx to /default.aspx
                            }
                            else
                            {
                                redirectPath = redirectPath.Replace(redirectPathOnly, redirectPathOnly.ToLower());
                                doRedirect = true;
                                result.Reason = UrlAction.RedirectReason.Not_Lower_Case;
                            }
                        }
                    }
                    //check for subdomain redirection
                    if (settings.RedirectToSubDomain != null)
                    {
                        bool hasScheme = redirectPath.Contains(scheme);
                        redirectPath = redirectPath.Replace(scheme, "");
                        if (TryAndFixSubDomain(redirectPath, out redirectPath, settings))
                        {
                            doRedirect = true;
                            result.Reason = UrlAction.RedirectReason.Wrong_Sub_Domain;
                        }
                        if (hasScheme)
                        {
                            //put the scheme back on again 
                            redirectPath = scheme + redirectPath;
                        }
                    }
                    if (doRedirect)
                    {
                        result.Action = UrlAction.ActionType.Redirect301;
                        result.FinalUrl =  CheckForSiteRootRedirect(result.portalAlias.HTTPAlias, redirectPath);
                        redirected = true;
                    }
                }
            }

            return redirected;
        }
        /// <summary>
        /// Checks to see if a tab is allowed to be 301 redirected
        /// </summary>
        /// <param name="tabId">the tabid of the tab</param>
        /// <param name="rulePortalId">the rulePortalId of the tab</param>
        /// <param name="checkBaseUrls">if true, check in the settings 'useBaseFriendlyUrls' section to see if the tab is excluded from Friendly Urls</param>
        /// <param name="tab">out parameter, returns a tabInfo object for the specified tabid</param>
        /// <param name="settings">Current Friendly Url settings instance</param>
        /// <returns>true if excluded, false if not</returns>
        private static bool CheckFor301RedirectExclusion(int tabId, int portalId, bool checkBaseUrls, out TabInfo tab, FriendlyUrlSettings settings) 
        { 
            bool doRedirect = false; 
            TabController tc = new TabController(); 
            tab = tc.GetTab(tabId, portalId, false); 
            //don't redirect unless allowed, the tab is valid, and it's not an admin or super tab 
            if (tab != null 
                && tab.IsSuperTab == false 
                && tab.IsAdminTab == false )
            {
                doRedirect = true;//we can redirect...unlesss excluded from the doNotRedirect list
                //then check this isn't an excluded tab (not all tabs get the redirected treatment) 
                string doNotRedirectTabs = settings.DoNotRedirect;
                if (doNotRedirectTabs != null && doNotRedirectTabs.Length > 0)  //check that the tab isn't excluded from redirects
                {
                    //should be a semicolon delimted list, so stick one on the back if it isn't already there 
                    if (doNotRedirectTabs.EndsWith(";") == false)
                        doNotRedirectTabs += ";";

                    //check if the requested tab isn't on the 'don't redirect' list 
                    if (doNotRedirectTabs.Contains(tab.TabPath.Replace("//", "/") + ";"))
                        doRedirect = false;
                }
                if (checkBaseUrls && doRedirect == true)
                {
                    //no redirect for friendly url purposes if the tab is in the 'base friendly urls' section
                    doRedirect = !RewriteController.IsExcludedFromFriendlyUrls(tab, settings, true);
                }
            } 
            return doRedirect; 
        }
        /// <summary>
        /// Make sure any redirect to the site root doesn't append the nasty /default.aspx on the end
        /// </summary>
        /// <param name="alias"></param>
        /// <param name="destUrl"></param>
        /// <returns></returns>
        internal static string CheckForSiteRootRedirect(string alias, string destUrl)
        {
            //540 - don't append /default.aspx onto the end of a site root redirect.
            if (destUrl.EndsWith(alias + "/" + Globals.glbDefaultPage, StringComparison.InvariantCultureIgnoreCase))
            {
                //this is just the portal alias root + /defualt.aspx.
                //we don't want that, just the portalAliasRoot + "/"
                string aliasPlusSlash = alias + "/";
                //get everything up to the end of the portal alias
                destUrl = destUrl.Substring(0, destUrl.IndexOf(aliasPlusSlash) + aliasPlusSlash.Length);
            }
            return destUrl;
        }
        private static bool TryAndFixSubDomain(string requestedPath, out string redirectPath, FriendlyUrlSettings settings)
        {
            redirectPath = requestedPath;
            bool doRedirect = false;
            if (settings.RedirectToSubDomain != null)
            {
                string redirectToSubDomain = settings.RedirectToSubDomain;
                //this regex looks for the specified subdomain at the start of the string 
                string lookFor = "(?:(?<right>^" + redirectToSubDomain  + ")\\.{0,1})|(?<wrong>^[\\w\\s\\d]+[^\\.]+)(?:\\.|\\Z)";
                Match domainMatch = Regex.Match(requestedPath, lookFor, RegexOptions.IgnoreCase);
                if ((domainMatch.Success))
                {
                    if ((domainMatch.Groups["wrong"].Success))
                    {
                        //this has a subdomain, but it's not the one wanted 
                        if ((requestedPath.Contains(redirectToSubDomain)))
                        {
                            //the subdomain is in there, but there are other subdomain(s) in front of it 
                            //so get rid of everything to the left 
                            redirectPath = requestedPath.Substring(requestedPath.IndexOf(redirectToSubDomain));
                            doRedirect = true;
                        }
                        else
                        {
                            //put the subdomain on the front 
                            redirectPath = redirectToSubDomain + "." + requestedPath;
                            doRedirect = true;
                        }
                        //check the redirect path to make sure the /default.aspx isn't tacked onto the end
                        //unnecessarily
                        if (redirectPath.EndsWith("/default.aspx", StringComparison.InvariantCultureIgnoreCase))
                        {
                            int start = redirectPath.Length - ("default.aspx").Length;
                            redirectPath = redirectPath.Remove(start);
                        }
                    }
                }
            }
            return doRedirect;
        }

        #endregion

    }
}
