#region legals - read before modifying or distributing
// Copyright iFinity.com.au 
// This is customised software developed entirely by iFinity. The below copyright messages should be followed 
// and any copies of this software should include this message.  
// Usage rights and restrictions:
// You may use this software without restriction on the number of installations in private and commercial applications
// You may make modifications to the source code of this software for your own requirements.
// You may not resell copies of this software or software derived from this source code as a licensed product.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using DotNetNuke.Framework.Providers;

    #region public enums
    public enum PageExtensionUsage
    {
        AlwaysUse,
        PageOnly,
        Never
    }
    public enum ParameterHandling
    {
        OrderedParameters,
        FirstParameterLast
    }
    public enum DeletedTabHandlingTypes
    {
        Do301RedirectToPortalHome,
        Do404Error
    }

    public enum DNNPageForwardTypes
    {
         NoForward
        ,Redirect302
        ,Redirect301
    }
    #endregion
    //587 : change serialization to allow for sql server session state
    [Serializable]
    public class FriendlyUrlSettings
    {

        private const string RegexMatchExpression = "[^a-zA-Z0-9 ]"; 
        #region urlRewrite values
        private bool _includePageName;
        private bool _redirectUnfriendly = true;
        private string _doNotRedirect = "";
        private string _doNotRedirectRegex = @"/LinkClick\.aspx|/Providers/|/DesktopModules/";
        //623 : change standard ignore filter to better handle js + axd requests with querystrings
        private string _ignoreRegex = @"(?<!linkclick\.aspx.+)(?:\.pdf$|\.gif$|\.png($|\?)|\.css$|\.js($|\?)|\.jpg$|\.html$|\.htm$|\.axd($|\?)|\.swf$|\.flv$|\.ico$|\.xml($|\?)|\.txt$)";
        private bool _checkForDupUrls = true;
        private string _doNotRewriteRegex = @"/DesktopModules/|/Providers/|/LinkClick\.aspx";
        //728 new attribute to send urls straight to the site urls processing
        private string _useSiteUrlsRegex = @"/rss\.aspx|Telerik.RadUploadProgressHandler\.ashx|BannerClickThrough\.aspx|/Admin/[^/]+/Tabid/\d+/.*default\.aspx|/Host/[^/]+/Tabid/\d+/.*default\.aspx";
        private string _doNotRedirectSecureRegex = "";
        private string _redirectToSubDomain = null;
        private DeletedTabHandlingTypes _deletedTabHandling = DeletedTabHandlingTypes.Do301RedirectToPortalHome;
        private bool _redirectWrongCase = false;

        //624 : Add in extra regex for new portals 
        //730 : new default for telerik controls
        //752 : old value can cause CPU spikes, const is used for comparison and overriding where necessary
        private const string _triggerDictionaryRebuildRegexDefault = @"&ctl=tab|/ctl/tab|/Admin/Tabs/|/ctl/Signup|cmdAddPage=Add\+Page";
        private const string _oldTriggerRegexValue = @"(.+)(\&ctl=tab)(.+)|(/Admin/Tabs/)";
        private string _triggerDictionaryRebuildRegex = _triggerDictionaryRebuildRegexDefault;

        private string _friendlyUrlProviderType;
        private bool _sslClientRedirect;
        private string _validUrlFolders = null;
        private TimeSpan _cacheTime;
        private bool _cachePersistRestart;
        private bool _redirectDefaultPage;
        private bool _logCacheMessages = false; //change to default false : 560
        private bool _allowDebugCode = true;
        private bool _rebaseClientPath = false; //change to false to stop common icon errors : 560

        private Dictionary<int, string> _adminPageNames;
        private DNNPageForwardTypes _forwardExternalUrls = DNNPageForwardTypes.NoForward;

        public bool AllowDebugCode
        {
            get { return _allowDebugCode; }
            set { _allowDebugCode = value; }
        }
        public bool LogCacheMessages
        {
            get { return _logCacheMessages; }
            set { _logCacheMessages = value; }
        }

        public TimeSpan CacheTime
        {
            get { return _cacheTime; }
            set { _cacheTime = value; }
        }

        public bool CachePersistRestart
        {
            get { return _cachePersistRestart; }
            set { _cachePersistRestart = value; }
        }
        public string FriendlyUrlProviderType
        {
            get { return _friendlyUrlProviderType; }
        }

        public string RedirectToSubDomain
        {
            get { return _redirectToSubDomain; }
            set { _redirectToSubDomain = value; }
        }
        public bool RedirectWrongCase
        {
            get { return _redirectWrongCase; }
            set { _redirectWrongCase = value; }
        }
        public bool RebaseClientPath
        {
            get
            {
                return _rebaseClientPath;
            }
            set
            {
                _rebaseClientPath = value;
            }
        }
        public DeletedTabHandlingTypes DeletedTabHandling
        {
            get { return _deletedTabHandling; }
            set { _deletedTabHandling = value; }
        }

        public string DoNotRewriteRegex
        {
            get { return _doNotRewriteRegex; }
            set { _doNotRewriteRegex = value; }
        }
        public string UseSiteUrlsRegex
        {
            get { return _useSiteUrlsRegex; }
            set { _useSiteUrlsRegex = value; }
        }

        public bool CheckForDupUrls
        {
            get { return _checkForDupUrls; }
            set { _checkForDupUrls = value; }
        }
        public bool RedirectDefaultPage
        {
            get { return _redirectDefaultPage; }
            set { _redirectDefaultPage = value; }
        }
        public string IgnoreRegex
        {
            get { return _ignoreRegex; }
            set { _ignoreRegex = value; }
        }

        public string DoNotRedirectRegex
        {
            get { return _doNotRedirectRegex; }
            set { _doNotRedirectRegex = value; }
        }

        public string DoNotRedirect
        {
            get { return _doNotRedirect; }
            set { _doNotRedirect = value; }
        }

        public string DoNotRedirectSecureRegex
        {
            get { return _doNotRedirectSecureRegex; }
            set { _doNotRedirectSecureRegex = value; }
        }

        public string[] DoNotRedirectPages
        {
            get { 
                return _doNotRedirect.Split(';'); 
                }
            set { 
                _doNotRedirect = string.Join(";", value); 
            }
        }

        public bool RedirectUnfriendly
        {
            get { return _redirectUnfriendly; }
            set { _redirectUnfriendly = value; }
        }
        public bool IncludePageName
        {
            get { return _includePageName; }
            set { _includePageName = value; }
        }
        public string TriggerDictionaryRebuildRegex
        {
            get { return _triggerDictionaryRebuildRegex; }
            set { _triggerDictionaryRebuildRegex = value; }
        }
        public bool SslClientRedirect
        {
            get { return _sslClientRedirect; }
            set { _sslClientRedirect = value; }
        }
        public DNNPageForwardTypes ForwardExternalUrls
        {
            get { return _forwardExternalUrls; }
            set { _forwardExternalUrls = value; }
        }
        
        #endregion

        #region friendlyUrl Settings
        private string _regexMatch = "[^a-zA-Z0-9 _-]"; //default value
        private string _urlFormat="HumanFriendly";
        private string _pageExtension = ".aspx";
        private ParameterHandling _parameterHandling = ParameterHandling.OrderedParameters;
        private PageExtensionUsage _pageExtensionUsage = PageExtensionUsage.AlwaysUse;
        private bool _forceLowerCase = false;
        private string _forceLowerCaseRegex = "";
        private string _replaceSpaceWith = "";
        private string _spaceEncodingValue = "%20"; //625 new space replacement value
        private string _useBaseFriendlyUrls = "/SearchResults;/ModuleDefinitions";
        private string _usePortalAlias = null;
        private string _noFriendlyUrlRegex = null;//655 new regex to not generate friendly urls
        private bool _ignoreUnlicensedPortals = false;
        private Dictionary<int, string> _chosenPortalAliases;
        private List<string> _licensedPortalAliases = null;
        private string _processRequests = "";
        private List<string> _processRequestValues = null;
        public string ProcessRequests
        {
            get { return _processRequests; }
            set { 
                _processRequests = value;
                if (_processRequests != null && _processRequests.Length > 0)
                    _processRequestValues = new List<string>(_processRequests.Split(';'));
                else
                    _processRequestValues = null;
            }
        }
        public List<string> ProcessRequestList
        {
            get
            {
                return _processRequestValues;
            }
        }
        public string UseBaseFriendlyUrls
        {
            get { return _useBaseFriendlyUrls; }
            set { _useBaseFriendlyUrls = value; }
        }
        public string UsePortalAlias
        {
            get
            {
                return _usePortalAlias;
            }
            set
            {
                _usePortalAlias = value;
                ParseChosenPortalAliases();//splits them out
            }
        }
        public Dictionary<int, string> ChosenPortalAliases
        {
            get
            {
                return _chosenPortalAliases;
            }
        }
        public string UrlFormat
        {
            get { return _urlFormat; }
            set { _urlFormat = value; }
        }
        public string RegexMatch
        {
            get { return _regexMatch; }
            set { _regexMatch = value; }
        }
        public string PageExtension
        {
            get { return _pageExtension; }
            set { _pageExtension = value; }
        }
        public PageExtensionUsage PageExtensionUsage
        {
            get { return _pageExtensionUsage; }
            set { _pageExtensionUsage = value; }
        }
        public ParameterHandling ParameterHandling
        {
            get { return _parameterHandling; }
            set { _parameterHandling = value; }
        }
        public bool ForceLowerCase
        {
            get { return _forceLowerCase; }
            set { _forceLowerCase = value; }
        }
        public string ForceLowerCaseRegex
        {
            get {return _forceLowerCaseRegex;}
            set {_forceLowerCaseRegex = value;}
        }
        public string ReplaceSpaceWith
        {
            get { return _replaceSpaceWith; }
            set { _replaceSpaceWith = value; }
        }
        public string SpaceEncodingValue
        {
            get { return _spaceEncodingValue; }
            set { _spaceEncodingValue = value; }
        }
        public bool IgnoreUnlicensedPortals
        {
            get
            {
                return _ignoreUnlicensedPortals;
            }
            set
            {
                _ignoreUnlicensedPortals = value;
            }
        }
        internal List<string> LicensedPortalAliases
        {
            get
            {
                return _licensedPortalAliases;
            }
            set
            {
                _licensedPortalAliases = value;
            }
        }
        public Dictionary<int, string> AdminPageNames
        {
            get
            {
                return _adminPageNames;
            }
            set
            {
                _adminPageNames = value;
            }
        }
        public string NoFriendlyUrlRegex
        {
            get
            {
                return _noFriendlyUrlRegex;
            }
            set
            {
                _noFriendlyUrlRegex = value;
            }
        }
        #endregion
        #region private methods
        private void ParseChosenPortalAliases()
        {
            _chosenPortalAliases = new Dictionary<int, string>();
            string[] aliases = _usePortalAlias.Split(';');
            foreach (string alias in aliases)
            {
                string[] portalBits = alias.Split(',');
                if (portalBits.GetUpperBound(0) == 1)
                {
                    //two parts, add to the dictionary
                    int portalId = -1;
                    if (Int32.TryParse(portalBits[0], out portalId))
                    {
                        if (_chosenPortalAliases.ContainsKey(portalId) == false)
                            _chosenPortalAliases.Add(portalId, portalBits[1]);
                    }
                }
            }
        }
        #endregion

        /// <summary>
        /// Initialiser for FriendlyUrlSettings provider object.  Initialises values by reading in from the web.config file
        /// </summary>
        /// <param name="provider"></param>
        public FriendlyUrlSettings(Provider provider)
        {
            if (provider != null)
            {
                _friendlyUrlProviderType = provider.Type;

                if (provider.Attributes != null)
                {
                    if ((string)(provider.Attributes["includePageName"]) != "")
                    {
                        _includePageName = bool.Parse(provider.Attributes["includePageName"]);
                    }
                    else
                    {
                        _includePageName = true;
                    }

                    if ((string)(provider.Attributes["regexMatch"]) != "")
                    {
                        _regexMatch = provider.Attributes["regexMatch"];
                    }
                    else
                    {
                        _regexMatch = RegexMatchExpression;
                    }

                    if ((provider.Attributes["urlFormat"]) != null && (string)(provider.Attributes["urlFormat"]) != "")
                    {
                        _urlFormat = provider.Attributes["urlFormat"].ToString();
                    }

                    _redirectUnfriendly = false;
                    if (provider.Attributes["redirectUnfriendly"] != null)
                    {
                        if ((provider.Attributes["redirectUnfriendly"].ToLower() == "true"))
                        {
                            _redirectUnfriendly = true;
                        }
                    }
                    //541 moved doNotRedirect and doNotRedirectRegex from under 'redirectUnfriendly' code
                    if (provider.Attributes["doNotRedirect"] != "")
                    {
                        _doNotRedirect = provider.Attributes["doNotRedirect"];
                    }
                    else
                        _doNotRedirect = "";

                    if (provider.Attributes["doNotRedirectRegex"] != "")
                    {
                        _doNotRedirectRegex = provider.Attributes["doNotRedirectRegex"];
                    }
                    
                        

                    if (provider.Attributes["doNotRedirectSecureRegex"] != null)
                    {
                        _doNotRedirectSecureRegex = provider.Attributes["doNotRedirectSecureRegex"];
                    }

                    if (provider.Attributes["allowDebugCode"] != null)
                    {
                        if (!bool.TryParse((string)provider.Attributes["allowDebugCode"], out _allowDebugCode))
                            _allowDebugCode = true;
                    }
                    else
                        _allowDebugCode = true;

                    if (provider.Attributes["redirectDefaultPage"] != null)
                    {
                        if (!bool.TryParse((string)provider.Attributes["redirectDefaultPage"], out _redirectDefaultPage))
                            _redirectDefaultPage = false;
                    }
                    else
                        _redirectDefaultPage = false;

                    if ((provider.Attributes["pageExtension"]) != null)
                    {
                        _pageExtension = (string)(provider.Attributes["pageExtension"]);
                    }
                    if (provider.Attributes["pageExtensionUsage"] != null)
                    {
                        string val = provider.Attributes["pageExtensionUsage"];
                        switch (val.ToLower())
                        {
                            case "always":
                                _pageExtensionUsage = PageExtensionUsage.AlwaysUse;
                                break;
                            case "never":
                                _pageExtensionUsage = PageExtensionUsage.Never;
                                _pageExtension = "";//631 : default page extension to nothing when 'never' used
                                break;
                            case "pageonly":
                                _pageExtensionUsage = PageExtensionUsage.PageOnly;
                                break;
                            default:
                                _pageExtensionUsage = PageExtensionUsage.AlwaysUse;
                                break;

                        }
                    }
                    if (provider.Attributes["forwardExternalUrls"] != null)
                    {
                        string val = provider.Attributes["forwardExternalUrls"];
                        switch (val.ToLower())
                        {
                            case "redirect301":
                                _forwardExternalUrls = DNNPageForwardTypes.Redirect301;
                                break;
                            case "redirect302":
                                _forwardExternalUrls = DNNPageForwardTypes.Redirect302;
                                break;
                            default:
                                _forwardExternalUrls = DNNPageForwardTypes.NoForward;
                                break;
                        }
                    }
                    if ((provider.Attributes["parameterHandling"]) != null)
                    {
                        string val = provider.Attributes["parameterHandling"];
                        switch (val.ToLower())
                        {
                            case "ordered":
                                _parameterHandling = ParameterHandling.OrderedParameters;
                                break;
                            case "firstlast":
                            case "firstparameterlast":
                                _parameterHandling = ParameterHandling.FirstParameterLast;
                                break;
                            default:
                                _parameterHandling = ParameterHandling.OrderedParameters;
                                break;
                        }
                    }
                    if ((provider.Attributes["ignoreFileTypesRegex"]) != null)
                    {
                        _ignoreRegex = provider.Attributes["ignoreFileTypesRegex"];
                    }
                    //655 : new noFriendlyUrlRegex value to ignore generation of certain urls
                    if (provider.Attributes["noFriendlyUrlRegex"] != null)
                        _noFriendlyUrlRegex = provider.Attributes["noFriendlyUrlRegex"];

                    if ((provider.Attributes["checkForDupUrls"]) != null)
                    {
                        if ((provider.Attributes["checkForDupUrls"].ToLower() == "false"))
                        {
                            _checkForDupUrls = false;
                        }
                        else
                        {
                            _checkForDupUrls = true;
                        }
                    }
                    if ((provider.Attributes["deletedTabHandling"]) != null)
                    {
                        switch (provider.Attributes["deletedTabHandling"].ToLower())
                        {
                            case "301redirecttohome":
                                _deletedTabHandling = DeletedTabHandlingTypes.Do301RedirectToPortalHome;
                                break;
                            case "404error":
                            case "do404error"://626 deleted tab handling not working correctly
                                _deletedTabHandling = DeletedTabHandlingTypes.Do404Error;
                                break;
                            default:
                                _deletedTabHandling = DeletedTabHandlingTypes.Do301RedirectToPortalHome;
                                break;
                        }
                    }
                    if (((provider.Attributes["doNotRewriteRegex"]) != null))
                    {
                        _doNotRewriteRegex = provider.Attributes["doNotRewriteRegex"];
                    }
                    //728 : new attribute to go direct to using site urls
                    if (provider.Attributes["useSiteUrlsRegex"] != null)
                        _useSiteUrlsRegex = provider.Attributes["useSiteUrlsRegex"];

                    if (((provider.Attributes["forceLowerCase"]) != null))
                    {
                        if ((provider.Attributes["forceLowerCase"].ToLower() == "true"))
                        {
                            _forceLowerCase = true;
                        }
                    }
                    if (provider.Attributes["forceLowerCaseRegex"] != null)
                    {
                        _forceLowerCaseRegex = (string)provider.Attributes["forceLowerCaseRegex"];
                    }

                    if (((provider.Attributes["redirectWrongCase"]) != null))
                    {
                        if ((provider.Attributes["redirectWrongCase"].ToLower() == "true"))
                        {
                            _redirectWrongCase = true;
                        }
                    }
                    if (provider.Attributes["rebaseClientPath"] != null)
                    {
                        if ((provider.Attributes["rebaseClientPath"].ToLower() == "false"))
                            _rebaseClientPath = false;
                        else
                            _rebaseClientPath = true;
                    }
                    if (provider.Attributes["redirectToSubDomain"] != null)
                    {
                        _redirectToSubDomain = provider.Attributes["redirectToSubDomain"].ToString();
                        //remove a trailing . 
                        if (_redirectToSubDomain.EndsWith("."))
                            _redirectToSubDomain = _redirectToSubDomain.Substring(0, _redirectToSubDomain.Length - 2);
                        //can't have a blank subdomain 
                        /*if (_redirectToSubDomain == "")
                            _redirectToSubDomain = null;*/
                    }
                    if ((provider.Attributes["replaceSpaceWith"]) != null)
                    {
                        _replaceSpaceWith = provider.Attributes["replaceSpaceWith"].ToString();
                    }
                    else
                    {
                        _replaceSpaceWith = "";
                    }

                    if (provider.Attributes["spaceEncodingValue"] != null)
                        _spaceEncodingValue = (string)provider.Attributes["spaceEncodingValue"];
                    else
                        _spaceEncodingValue = "%20";

                    if ((provider.Attributes["triggerDictionaryRebuildRegex"]) != null)
                    {
                        _triggerDictionaryRebuildRegex = (string)(provider.Attributes["triggerDictionaryRebuildRegex"]);
                    }
                    if (_triggerDictionaryRebuildRegex.StartsWith(_oldTriggerRegexValue))
                    {
                        //752 : if still using old trigger dictionary regex, discard and use new value
                        _triggerDictionaryRebuildRegex = _triggerDictionaryRebuildRegexDefault;
                    }

                    if ((provider.Attributes["useBaseFriendlyUrls"]) != null)
                    {
                        _useBaseFriendlyUrls = (string)(provider.Attributes["useBaseFriendlyUrls"]);
                    }
                    if (_useBaseFriendlyUrls.EndsWith(";") == false)
                        _useBaseFriendlyUrls += ";";

                    if (provider.Attributes["usePortalAlias"] != null)
                    {
                        _usePortalAlias = (string)provider.Attributes["usePortalAlias"];
                        ParseChosenPortalAliases();
                    }
                    /*
                    if (provider.Attributes["ignoreUnlicensedPortals"] != null)
                        if (((string)provider.Attributes["ignoreUnlicensedPortals"]).ToLower() == "true")
                            _ignoreUnlicensedPortals = true;
                    */
                    if (provider.Attributes["processRequests"] != null)
                        this.ProcessRequests = (string)provider.Attributes["processRequests"].ToLower();

                    if (provider.Attributes["sslClientRedirect"] != null)
                    {
                        if (bool.TryParse((string)provider.Attributes["sslClientRedirect"], out _sslClientRedirect) == false)

                            _sslClientRedirect = true; //default true if failed validation
                    }
                    else
                        _sslClientRedirect = true; //default true 

                    if (provider.Attributes["logCacheMessages"] != null)
                    {
                        if (bool.TryParse((string)provider.Attributes["logCacheMessages"], out _logCacheMessages) == false)
                            _logCacheMessages = true;
                    }
                    else
                        _logCacheMessages = false; //defauilt false : 560 change default settings

                    if (provider.Attributes["cachePersistRestart"] != null)
                    {
                        if (bool.TryParse((string)provider.Attributes["cachePersistRestart"], out _cachePersistRestart) == false)
                            _cachePersistRestart = false;
                    }
                    else
                        _cachePersistRestart = false; //default false

                    _cacheTime = new TimeSpan(0,  1440, 0); //1440 minutes is 24 hours
                    if (provider.Attributes["cacheTime"] != null)
                    {
                        int value = 1440;
                        string raw = (string)provider.Attributes["cacheTime"];
                        if (int.TryParse(raw, out value))
                            _cacheTime = new TimeSpan(0, value, 0);
                    }

                    //set up the admin page names exclusion (required for dnn 5.0 + above)
                    _adminPageNames = new Dictionary<int, string>();
                    _adminPageNames.Add(-1, "Admin");
                    if (provider.Attributes["adminPageNames"] != null)
                    {
                        string rawValue = provider.Attributes["adminPageNames"];
                        string[] pairs = rawValue.Split(';');
                        foreach (string pair in pairs)
                        {
                            string[] pairItems = pair.Split(',');
                            if (pairItems.GetUpperBound(0) > 0)
                            {
                                string portalIdRaw = pairItems[0];
                                string adminPageName = pairItems[1];
                                int portalId = -1;
                                if (Int32.TryParse(portalIdRaw, out portalId))
                                {
                                    if (_adminPageNames.ContainsKey(portalId) == false)
                                        _adminPageNames.Add(portalId, adminPageName);
                                    else
                                        _adminPageNames[portalId] = adminPageName;
                                }
                            }
                        }
                    }


                }
            }
        }
    }

