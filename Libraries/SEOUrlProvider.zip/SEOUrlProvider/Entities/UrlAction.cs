#region legals - read before modifying or distributing
// Copyright iFinity.com.au 
// This is customised software developed entirely by iFinity. The below copyright messages should be followed 
// and any copies of this software should include this message.  
// Usage rights and restrictions:
// You may use this software without restriction on the number of installations in private and commercial applications
// You may make modifications to the source code of this software for your own requirements.
// You may not resell copies of this software or software derived from this source code as a licensed product.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using DotNetNuke.Entities.Portals;

    public class UrlAction
    {
        public UrlAction(string scheme, string applicationPath, string physicalPath)
        {
            if (scheme.EndsWith("://") == false)
                Scheme = scheme + "://";
            else
                Scheme = scheme;
            ApplicationPath = applicationPath;
            string domainPath = applicationPath.Replace(scheme, "");
            if (domainPath.Contains("/"))
            {
                domainName = domainPath.Substring(0, domainPath.IndexOf('/'));
            }
            else
                domainName = domainPath;
            PhysicalPath = physicalPath;
            portalId = -1;
            tabId = -1;
        }
        public enum ActionType
        {
             IgnoreRequest
            ,Continue
            ,Redirect302Now
            ,Redirect301
            ,CheckFor301
            ,Redirect302
            ,Output404
            ,Output500
        }
        public enum RedirectReason
        {
            Unfriendly_Url
           ,
            Not_Lower_Case
           ,
            Wrong_Sub_Domain
           ,
            Custom_Redirect
           ,
            Wrong_Portal
           ,
            Not_Redirected
           ,
            Page_Deleted
           ,
            Spaces_Replaced
           , Wrong_Portal_Alias
            , Site_Root_Home
            , Secure_Page_Requested
            ,Tab_External_Url
            ,Tab_Permanent_Redirect
            ,Host_Portal_Used
           , Alias_In_Url
            ,User_Profile_Url
            ,Unfriendly_Url_Child_Portal
            ,Unfriendly_Url_TabId
                ,
            Error_Event
                ,
            No_Portal_Alias
                ,
            Requested_404
                ,
            Requested_404_In_Url
                ,
            Page_404
                ,
            Exception
                ,
            File_Url
                , Built_In_Url
        }
        public Uri Url;
        public RedirectReason Reason = RedirectReason.Not_Redirected;
        public bool DoRewrite;
        public bool FriendlyRewrite = false;//friendlyRewrite means it was rewritten without looking up the tabid in the url
        public bool BypassCachedDictionary = false;
        public string RewritePath;
        private string _originalPath;
        public string RawUrl;
        public string DebugData;
        public string PhysicalPath;
        public string ApplicationPath;
        public bool RebuildRequested;
        public string FinalUrl;
        public string Scheme;
        public bool CustomParmRewrite = false;
        public bool IsSecureConnection = false;
        public int tabId;
        public int portalId;
        public string domainName;
        public Exception Ex;
        public string dictKey;
        public string dictVal;
        private bool _redirectAllowed;
        private string _httpAlias;
        private PortalAliasInfo _portalAlias = null;
        private ActionType _action = ActionType.Continue;
        public List<string> DebugMessages = new List<string>();
        public string HttpAlias
        {
            get { return _httpAlias; }
            set { _httpAlias = value; }
        }
        public ActionType Action
        {
            get { return _action; }
            set { _action = value; }
        }
        
        public string OriginalPath
        {
            get
            {
                return _originalPath;
            }
        }
        public bool RedirectAllowed
        {
            get
            {
                return _redirectAllowed;
            }
        }
        public PortalAliasInfo portalAlias
        {
            get
            {
                return _portalAlias;
            }
            set
            {
                if (value != null)
                {
                    portalId = value.PortalID;
                    HttpAlias = value.HTTPAlias;
                }
                _portalAlias = value;
            }

        }
        public void SetOriginalPath(string path, FriendlyUrlSettings settings)
        {
            _originalPath = path;
            string regexExpr = settings.DoNotRedirectRegex;
            try
            {
                if (regexExpr != null && regexExpr.Length > 0)
                    //if a regex match, redirect Not allowed
                    _redirectAllowed = !Regex.IsMatch(path, regexExpr, RegexOptions.IgnoreCase);
                else
                    _redirectAllowed = true;
            }
            catch (Exception ex)
            {
                _redirectAllowed = true; //default : true, unless regex allows it.  So if regex causes an exception
                //then we should allow the redirect

                this.Ex = ex;
            }
        }

    }

