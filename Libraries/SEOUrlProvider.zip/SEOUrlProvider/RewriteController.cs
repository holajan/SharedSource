#region legals - read before modifying or distributing
// iFinity.com.au 
// This is customised software derived from the DotNetNuke core. The below copyright messages should be followed 
// , and any copies of this software should include this message.  However, this software is distributed with the additional
// usage rights and restrictions:
// You may use this software without restriction on the number of installations in private and commercial applications
// You may make modifications to the source code of this software for your own requirements.
// You may not resell copies of this software or software derived from this source code as a licensed product.
// 
// DotNetNuke� - http://www.dotnetnuke.com 
// Copyright (c) 2002-2005 
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca ) 
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software. 
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE. 
// 
#endregion
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Text.RegularExpressions;

using DotNetNuke.Common;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Common.Utilities;


namespace iFinity.DNN.Modules.FriendlyUrl

{
    public class RewriteController
    {
        internal static void GetUrlWithQuerystring(System.Web.HttpRequest request, Uri requestUri, out string fullUrl, out string querystring)
        {
            //699: incorrect encoding in absoluteUri.ToString()
            string urlWoutQuery = requestUri.AbsoluteUri;
            if (requestUri.Query != "")
                urlWoutQuery = urlWoutQuery.Replace(requestUri.Query, ""); // replace the querystring on the reuqest absolute Uri
            querystring = "";
            if (request != null)
                querystring = request.QueryString.ToString();
            else
                querystring = requestUri.Query;
            //get results
            fullUrl = urlWoutQuery;
            if (querystring != null && querystring != "")
            {
                //set up the querystring and the fullUrl to include the querystring
                if (querystring.StartsWith("?") == false)
                    querystring = "?" + querystring;
                fullUrl += querystring;
            }
        }
        /// <summary>
        /// Checks for exclusions on Rewriting the path, based on a regex pattern
        /// </summary>
        /// <param name="requestedPath"></param>
        /// <returns></returns>
        internal static bool RewriteRequest(UrlAction result, string requestedPath, FriendlyUrlSettings settings)
        {
            bool retVal;
            try
            {
                if (settings.DoNotRewriteRegex.Length == 0
                    || (!Regex.IsMatch(requestedPath, settings.DoNotRewriteRegex, RegexOptions.IgnoreCase)))
                    retVal = true;
                else
                    retVal = false;
            }
            catch (Exception ex)
            {
                retVal = true; //always rewrite if an error in the regex 

                FriendlyUrlController.LogExceptionInRequest(ex);


                result.Ex = ex;
            }
            return retVal;
        }
        /// <summary>
        /// Determines if the tab is excluded from FriendlyUrl Processing
        /// </summary>
        /// <param name="tab"></param>
        /// <param name="settings"></param>
        /// <param name="rewriting">If true, we are checking for rewriting purposes, if false, we are checking for friendly Url Generating.</param>
        /// <returns></returns>
        internal static bool IsExcludedFromFriendlyUrls(TabInfo tab, FriendlyUrlSettings settings, bool rewriting)
        {
            
            bool exclude = false; string tabPath = (tab.TabPath.Replace("//", "/") + ";").ToLower();
            //553 change for dnn 5.0 isAdminTab no longer returns true in any case, so
            //check custom admin tab path header
            if (IsAdminTab(tab.PortalID, tab.TabPath, settings))
                exclude = true;

            if (!exclude && settings.UseBaseFriendlyUrls != null)
                exclude = settings.UseBaseFriendlyUrls.ToLower().Contains(tabPath);

            return exclude;
        }
        internal static bool IdentifyByTabQueryString(Uri requestUri, NameValueCollection queryStringCol, bool useFriendlyUrls, UrlAction result)
        {
            bool doRewrite = false;
            string url = requestUri.AbsoluteUri; //local copy cause it gets hacked around
            string queryString = requestUri.Query;
            string requestedPath = requestUri.LocalPath;
            if (queryString != "")
                url = url.Replace(queryString, "");  //nix the query string from the request url

            if (useFriendlyUrls)
            {
                //using friendly URls, so just nab the Tab id from the querystring
                if (result.RedirectAllowed && requestedPath.EndsWith(Globals.glbDefaultPage, StringComparison.OrdinalIgnoreCase)
                    && (queryStringCol["tabId"] != null))
                {
                    result.Action = UrlAction.ActionType.CheckFor301;
                    result.Reason = UrlAction.RedirectReason.Unfriendly_Url;
                    doRewrite = false;
                }
            }
            result.DoRewrite = doRewrite;
            return doRewrite;
        }
        internal static bool IdentifyByRegEx(string absoluteUri, string queryString, string applicationPath, UrlAction result, FriendlyUrlSettings settings)
        {
            string url = absoluteUri; //get local copy because it gets hacked around
            string rewritePath = ""; //no rewrite path unless we match by regex the intended tab
            bool doRewrite = false;
            // Remove querystring if exists.. 
            if (queryString != "")
                url = url.Replace(queryString, "");

            //context.Items.Add("UrlRewrite:OriginalUrl", request.Url.AbsoluteUri);
            //get the DNN rewriterConfiguration rules for rewriting 
            DotNetNuke.HttpModules.Config.RewriterRuleCollection rules = DotNetNuke.HttpModules.Config.RewriterConfiguration.GetConfig().Rules;
            for (int i = 0; i <= rules.Count - 1; i++)
            {
                //iterate the Config Rules looking for a match
                string lookFor = "^" + RewriterUtils.ResolveUrl(applicationPath, rules[i].LookFor) + "$";
                Regex re = new Regex(lookFor, RegexOptions.IgnoreCase);
                if (re.IsMatch(url))
                {
                    //get a new rewritePath location 

                    rewritePath = RewriterUtils.ResolveUrl(applicationPath, re.Replace(url, rules[i].SendTo));

                    Match sesMatch = re.Match(url);
                    string sesUrlParams = sesMatch.Groups[2].Value;
                    //a match by regex means it's probably not a 'friendly' Url, so assume at this stage that this request will end up a 301
                    if (settings.UrlFormat == "HumanFriendly" && settings.RedirectUnfriendly)
                        result.Action = UrlAction.ActionType.CheckFor301;
                    //if a match is found here, there is the potential for a 'friendlier' url 
                    if ((sesUrlParams.Trim().Length > 0))
                    {
                        sesUrlParams = sesUrlParams.Replace("\\", "/");
                        string[] urlParams = sesUrlParams.Split('/');
                        for (int x = 1; x <= urlParams.Length - 1; x++)
                        {
                            if (urlParams[x].Trim().Length > 0 && urlParams[x].ToLower() != Globals.glbDefaultPage.ToLower())
                            {
                                rewritePath = rewritePath + "&" + urlParams[x].Replace(".aspx", "").Trim() + "=";
                                if ((x < (urlParams.Length - 1)))
                                {
                                    x += 1;
                                    if ((urlParams[x].Trim() != ""))
                                    {
                                        rewritePath = rewritePath + urlParams[x].Replace(".aspx", "");
                                    }
                                }
                            }
                        }
                    }
                    doRewrite = true;
                    //add back the query string if it was there
                    rewritePath = AddQueryStringToRewritePath(rewritePath, queryString);

                    SetRewriteParameters(result, rewritePath);
                    result.DoRewrite = doRewrite;
                    break; //exit loop, match found
                }
            }
            return doRewrite;

        }
        /// <summary>
        /// Replaces the core IsAdminTab call which was decommissioned for DNN 5.0
        /// </summary>
        /// <param name="tabPath">The path of the tab //admin//someothername</param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal static bool IsAdminTab(int portalId, string tabPath, FriendlyUrlSettings settings)
        {
            Dictionary<int, string> adminTabNames = settings.AdminPageNames;
            //fallback position - all portals match 'Admin'
            string adminPageName = "Admin";
            if (adminTabNames != null)
            {
                if (adminTabNames.ContainsKey(portalId))
                {
                    adminPageName = adminTabNames[portalId];
                }
                else
                {
                    if (adminTabNames.ContainsKey(-1))
                        adminPageName = adminTabNames[-1];
                }
            }
            //we should be checking that the tab path matches //Admin//pagename or //admin
            //in this way we should avoid partial matches (ie //Administrators
            if (tabPath.StartsWith("//" + adminPageName + "//", StringComparison.CurrentCultureIgnoreCase)
             || string.Compare(tabPath, "//" + adminPageName, true) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// Identifies a request for a physical file on the system
        /// </summary>
        /// <param name="physicalPath">The Physical Path propery of the request</param>
        /// <returns>true if a physical path, false if not</returns>
        internal static void IdentifyByPhysicalResource(string physicalPath, string fullUrl, NameValueCollection queryStringCol, UrlAction result, bool useFriendlyUrls, FriendlyUrlSettings settings, out bool isPhysicalResource, out bool checkFurtherForRewrite)
        {
            isPhysicalResource = false;
            checkFurtherForRewrite = true;
            if (System.IO.File.Exists(physicalPath))
            {
                //resource found
                string appPath = DotNetNuke.Common.Globals.ApplicationMapPath + "\\default.aspx";
                if (string.Compare(physicalPath, appPath, true) != 0)
                {
                    //it's not the default.aspx path, so we haven't identifed the resource
                    isPhysicalResource = true;
                    checkFurtherForRewrite = false;
                }
                else //it is the default aspx path
                {
                    if (queryStringCol != null && queryStringCol.Count > 0)
                    {
                        //when there is a query string supplied, we don't need to rewrite
                        if (useFriendlyUrls)
                        {
                            //using friendly URls, so just nab the Tab id from the querystring
                            if (queryStringCol["tabId"] != null)
                            {
                                if (result.RedirectAllowed)
                                {
                                    result.Action = UrlAction.ActionType.CheckFor301;
                                    result.Reason = UrlAction.RedirectReason.Unfriendly_Url;
                                }
                            }
                            //if a tabid redirect, run the rebuild in case 
                            RewriteController.RebuildDictionaryOnTriggerMatch(null, result, fullUrl, settings);
                        }
                        result.DoRewrite = false;
                        checkFurtherForRewrite = false; //no more checking for rewrites, we have our physical file and our query string
                        //the default.aspx is still a physical resource, but we want to do the rest of the processing
                        isPhysicalResource = false; 
                    }
                    else
                    {
                        //this is the default.aspx with no query string
                        //if 301 redirects are on, then we want to rewrite and replaced this Url
                        //so return false to indicate that the physical resource couldn't be identified
                        if (useFriendlyUrls)
                            isPhysicalResource = false;
                        else
                            isPhysicalResource = true;
                    }
                }
            }
            else
            {
                //physical resource not found : it's a virtual url that needs to be rewritten
                isPhysicalResource = false;
                checkFurtherForRewrite = true;
            }
        }
        internal static bool IdentifyByTabPathEx(string absoluteUri, string queryString, UrlAction result, FriendlyUrlSettings settings)
        {
            string scheme = result.Scheme;
            if (absoluteUri.ToLower().StartsWith(scheme))
            {
                absoluteUri = absoluteUri.Substring(scheme.Length);
            }
            // Remove QueryString if it exists in the Url value 
            if ((queryString != ""))
            {
                absoluteUri = absoluteUri.Replace(queryString, "");
            }
            absoluteUri = System.Web.HttpUtility.UrlDecode(absoluteUri);//decode the incoming request
            string rewritePath = GetTabFromDictionary(absoluteUri, settings, result);
            //put the query string back on the end
            rewritePath = AddQueryStringToRewritePath(rewritePath, queryString);

            result.RewritePath = rewritePath;
            return result.DoRewrite;

        }
        private static string AddQueryStringToRewritePath(string rewritePath, string queryString)
        {
            //now add back querystring if they existed
            if (queryString != "")
            {
                bool rewritePathHasQuery = rewritePath.IndexOf("?") != -1;
                if (queryString.StartsWith("?"))
                    queryString = queryString.Substring(1);
                string[] parms = queryString.Split('&');
                string parmName;
                // iterate through the array of parameters
                for (int i = 0; i < parms.Length; i++)
                {
                    bool hasValue = false;
                    // get parameter name
                    parmName = parms[i];
                    //check if parm name contains a value as well
                    if (parmName.IndexOf("=") != -1)
                    {
                        //snip off the =value part of the parm
                        parmName = parmName.Substring(0, parmName.IndexOf("="));
                        hasValue = true;
                    }
                    //597 : do a compare with the '=' on the end to only
                    //compare the entire parmname, not just the start
                    string comparePath1 = "?" + parmName.ToLower();
                    string comparePath2 = "&" + parmName.ToLower();
                    if (hasValue)
                    {
                        comparePath1 += "=";
                        comparePath2 += "=";
                    }
                    // check if parameter already exists in the rewrite path
                    // we only want to add the querystring back on if the 
                    // query string keys were not already shown in the friendly
                    // url path
                    if (!rewritePath.ToLower().Contains(comparePath1) 
                     && !rewritePath.ToLower().Contains(comparePath2))
                    {
                        //622 : remove encoding from querystring paths
                        //699 : reverses 622 because works from Request.QUeryString instead of Request.Url.Query
                        //string queryStringPiece = System.Web.HttpUtility.UrlDecode(parms[i]);
                        string queryStringPiece = parms[i];//no decoding - querystring passes through rewriting process untouched
                        // add parameter to SendTo value
                        if (rewritePathHasQuery)
                        {
                            rewritePath = rewritePath + "&" + queryStringPiece;
                        }
                        else
                        {
                            rewritePath = rewritePath + "?" + queryStringPiece;
                            rewritePathHasQuery = true;
                        }
                    }
                }
            }
            return rewritePath;
        }
        internal static string GetTabFromDictionary(string url, FriendlyUrlSettings settings, UrlAction result)
        {
            //retrive the tab dictionary from the cache and get the path depth values 
            int maxAliasPathDepth = 0;
            int maxTabPathDepth = 0;
            int minAliasPathDepth = 0;
            int minTabPathDepth = 0;
            //bool refreshedCache = false;
            bool triedFixingSubdomain = false;
            Dictionary<string, string> tabDict = TabDictController.FetchTabDictionary(out minTabPathDepth, out maxTabPathDepth, out minAliasPathDepth, out maxAliasPathDepth, settings, false, result.BypassCachedDictionary);
            int curTabPathDepth = minTabPathDepth;
            int curAliasPathDepth = 0;

            //clean up and prepare the url for scanning
            if (url.EndsWith("/"))
                url = url.TrimEnd('/');
            //ok now scan for the language modifier 
            Match langMatch = Regex.Match(url, "/language/(?:.[^/]+)(?:/|$)", RegexOptions.IgnoreCase); //searches for a string like language/en-US/ in the url
            string langParms = "";
            if (langMatch.Success)
            {
                //OK there is a language modifier in the path
                //we want to shift this so it is back on the end where it belongs
                langParms = langMatch.Value.TrimEnd('/');//in the format of /language/en-US only
                //it doesn't matter if you get /home.aspx/language/en-US in the url field because the .aspx gets 
                //removed when matching with the tab dictionary
                url = url.Replace(langParms, "") + langParms; 
            }

            string[] splitUrl = url.Split('/');
            string newUrl = url;

            //initialise logic switches 
            bool reWritten = false;
            bool finished = false;

            //first, check if this is just one of the portal aliases 
            string defaultPage = Globals.glbDefaultPage.ToLower();
            string portalAliasUrl = url.ToLower().Replace("/" + defaultPage, "");
            //if there is a straight match on a portal alias, it's the home page for that portal requested 
            PortalAliasInfo portalAlias = PortalSettings.GetPortalAliasInfo(portalAliasUrl);
            if (portalAlias != null)
            {
                //special case : sometimes, some servers issue root/default.aspx when root/ was requested, sometimes not.  It depends
                //on other server software installed (apparently)
                //so check the raw Url and the url, and see if they are the same except for the /default.aspx
                string rawUrl = result.RawUrl;
                if (url.ToLower().EndsWith(rawUrl + defaultPage.ToLower()))
                {
                    //special case - change the url to be equal to the raw Url
                    url = url.Substring(0, url.Length - defaultPage.Length);
                    //url = url.Replace(defaultPage, "");
                }

                if (settings.RedirectDefaultPage 
                    && url.ToLower().EndsWith("/" + defaultPage) 
                    && result.RedirectAllowed)
                {
                    if (newUrl.Contains("?"))
                        newUrl += "&do301=true";
                    else
                        newUrl += "?do301=true";
                    result.Reason = UrlAction.RedirectReason.Site_Root_Home;
                    result.FinalUrl = DotNetNuke.Common.Globals.AddHTTP(portalAliasUrl + "/");
                    result.Action = UrlAction.ActionType.Redirect301;
                    reWritten = false;
                }
                else
                {
                    //special case -> look in the tabdict for a blank intercept
                    PortalController pc = new PortalController();
                    PortalInfo portal = pc.GetPortal(portalAlias.PortalID);
                    if (portal.HomeTabId == -1)
                    {
                        string tabKey = url;
                        if (tabKey.EndsWith("/"))
                            tabKey = tabKey.TrimEnd('/');
                        tabKey += "::";
                        if (tabDict.ContainsKey(tabKey))
                        {
                            newUrl = tabDict[tabKey];
                            reWritten = true;
                        }
                    }
                    else
                    {
                        newUrl = Globals.glbDefaultPage + "?TabId=" + portal.HomeTabId.ToString();
                        reWritten = true;
                    }
                }
                //check for replaced to site root from /default.aspx 
                //that's it! no more to do 
                finished = true;
            }

            //start looping through the url segments looking for a match in the tab dictionary 
            while (finished == false)
            {
                //first, try forming up a key based on alias/tabpath 
                int lastIndex = splitUrl.GetUpperBound(0);
                int arraySize = lastIndex + 1;
                int totalDepth = maxAliasPathDepth + 1 + maxTabPathDepth + 1;
                //the maximum depth of segments of a valid url 
                for (int i = lastIndex; i >= 0; i += -1)
                {
                    //only start checking the url when it is in the range of the min->max number of segments 
                    if ((i > minAliasPathDepth & i <= totalDepth))
                    {
                        //join all the tab path sections together 
                        bool hadExtension = false;
                        //flag to remember if the incoming path had a .aspx or other pageAndExtension on it 
                        int tabPathStart = curAliasPathDepth + 1;
                        int tabPathLength = i - curAliasPathDepth;
                        if ((tabPathStart + tabPathLength) <= arraySize)
                        {
                            string tabPath = "";
                            if ((tabPathLength > -1))
                                tabPath = string.Join("/", splitUrl, tabPathStart, tabPathLength);
                            string aliasPath = "";
                            if ((curAliasPathDepth <= lastIndex))
                            {
                                aliasPath = string.Join("/", splitUrl, 0, curAliasPathDepth + 1);
                            }
                            else
                            {
                                finished = true;
                                break;
                            }
                            //make up the index that is looked for in the Tab Dictionary
                            string urlPart = aliasPath + "::" + tabPath; //the :: allows separation of pagename and portal alias
                            //get rid of any page pageAndExtension - the dictionary does not use page extensions
                            urlPart = CleanExtension(urlPart, settings, out hadExtension);
                            
                            string tabKeyVal = urlPart.ToLower();  //force lower case lookup, all keys are lower case
                            bool found = tabDict.ContainsKey(tabKeyVal);  //lookup the tabpath in the tab dictionary
                            int parmsSize = lastIndex - i;int parmStart = i + 1;//determine if any parameters on this value

                            //special case, if no extensions and the last part of the tabKeyVal contains default.aspx, then
                            //split off the default.aspx part and try again - compensating for gemini issue http://support.dotnetnuke.com/issue/ViewIssue.aspx?id=8651&PROJID=39
                            if (!found && settings.PageExtensionUsage != PageExtensionUsage.AlwaysUse)
                            {
                                int pathStart = tabKeyVal.LastIndexOf("::"); //look for portal alias separator
                                int lastPath = tabKeyVal.LastIndexOf('/'); //get any path separator in the tab path portion
                                if (pathStart > lastPath)
                                    lastPath = pathStart;
                                if (lastPath >= 0)
                                {
                                    int defaultStart = tabKeyVal.ToLower().IndexOf("default", lastPath); //no .aspx on the end anymore
                                    if (defaultStart > 0 && defaultStart > lastPath) //there is a default in the path, and it's not the entire path (ie pagnamedefault and not default)
                                    {
                                        tabKeyVal = tabKeyVal.Substring(0, defaultStart);//get rid of the default.aspx part
                                        found = tabDict.ContainsKey(tabKeyVal);  //lookup the tabpath in the tab dictionary again
                                    }
                                }
                            }

                            if (found)
                            {
                                //determine what the rewritten URl will be 
                                newUrl = tabDict[tabKeyVal];
                                //if this is a match on the trigger dictionary rebuild,
                                //then temporarily store this value in case it's a page name change
                                //677 : only match if is on actual tabKeyVal match, to prevent site root redirects
                                //statements were moved into this 'if' statement
                                result.dictVal = newUrl;
                                result.dictKey = tabKeyVal;

                                if (settings.ProcessRequestList != null)
                                {
                                    newUrl = ReplaceDefaultPage(newUrl, url, settings.ProcessRequestList);
                                }

                                if (newUrl == Globals.glbDefaultPage || newUrl == Globals.glbDefaultPage + "[UseBase]")

                                {
                                    //the [UseBase] moniker is a shortcut hack.  It's used to recognise pages which have been excluded 
                                    //from using Friendly Urls.  The request will go on to be processed by the dnn siteurls.config processing.
                                    //this stops the loop and exits the function
                                    newUrl = newUrl.Replace("[UseBase]", ""); //get rid of usebase hack pattern
                                    finished = true;
                                }
                                else
                                {
                                    //found the correct rewrite page, now investigate whether there 
                                    //is part of the url path that needs to be converted to tab id's 
                                    if (parmsSize > 0)
                                    {
                                        bool rewriteParms = false;

                                        //determine the url action and reason from embedded rewriting tokens
                                        UrlAction.ActionType action; UrlAction.RedirectReason reason; string resultingUrl;
                                        RedirectTokens.DetermineRedirectReasonAndAction(newUrl, result, true, settings, out resultingUrl, out reason, out action);
                                        newUrl = resultingUrl;
                                        result.Action = action;
                                        result.Reason = reason;

                                        //copy the parms into a separate array 
                                        string[] urlParms = new string[parmsSize];
                                        Array.ConstrainedCopy(splitUrl, parmStart, urlParms, 0, parmsSize);

                                        if (!rewriteParms)

                                        {
                                            //or we can just leave the original parameter rewriting in if there is nothing defined for this tab
                                            //check how to handle the parms 
                                            bool firstParmLast = (settings.ParameterHandling == ParameterHandling.FirstParameterLast);
                                            if (firstParmLast && langParms != "" && urlParms.GetUpperBound(0) == 1)
                                                //when there are only two parameters, and there was language parameters
                                                //then it's the language parameters, and they are never ever reversed
                                                firstParmLast = false;
                                            //put those parms on the back of the url as a query string 
                                            newUrl = RewriteParameters(newUrl, tabKeyVal, urlParms, firstParmLast, settings.PageExtension, settings.PageExtensionUsage, result, langParms);
                                        }
                                        //now check if the request involved a page pageAndExtension, (.aspx) and shouldn't have 
                                        if ((settings.PageExtensionUsage == PageExtensionUsage.Never 
                                            || settings.PageExtensionUsage == PageExtensionUsage.PageOnly) & hadExtension)
                                        {
                                            result.Action = UrlAction.ActionType.CheckFor301;
                                        }

                                        //rewriting done whether or not the parameters were rewritten
                                        reWritten = true;
                                        finished = true;

                                    }
                                    else
                                    {
                                        //determine the url action and redirect reason from embedded toeksn in the url rewrite path
                                        string resultUrl; UrlAction.RedirectReason reason; UrlAction.ActionType action;
                                        RedirectTokens.DetermineRedirectReasonAndAction(newUrl, result, false, settings, out resultUrl, out reason, out action);
                                        newUrl = resultUrl; result.Reason = reason; result.Action = action;

                                        //this is a page only, no parameters to deal with 
                                        if ((settings.PageExtensionUsage == PageExtensionUsage.Never & hadExtension))
                                        {
                                            result.Action = UrlAction.ActionType.CheckFor301;
                                            //potentially a 301 replaced because shouldn't be using page extensions 
                                        }
                                        //rewriting done
                                        reWritten = true;
                                        finished = true;
                                    }
                                    
                                    
                                }
                                if (finished)
                                {                                  
                                    break;
                                }
                            }
                        }
                    }
                }
                //next, try forming up a key based on alias1/alias2/tabpath 
                if (!finished)
                {
                    curTabPathDepth += 1;
                    curAliasPathDepth += 1;
                    //gone too deep 
                    if ((curAliasPathDepth > maxAliasPathDepth) & (reWritten == false))
                    {
                        //if (refreshedCache)
                        //{
                            // no hope of finding it then 
                            if (triedFixingSubdomain == false && (TryAndFixSubDomain(newUrl, settings)))
                            {
                                //resplit the new url 
                                splitUrl = newUrl.Split(Convert.ToChar("/"));
                                curTabPathDepth = minTabPathDepth;
                                curAliasPathDepth = minAliasPathDepth;
                                if (result.RedirectAllowed)
                                    result.Action = UrlAction.ActionType.Redirect301;
                                //this should be redirected 
                                triedFixingSubdomain = true;
                            }
                            else
                            {
                                //nothing left to try 
                                break;
                            }
                        //}
                        //else
                        //{
                            //effectively resets the search with a full search of the tab dictionary again. 
                            //this is for when a new page is added - it forces a full re-fetch of the tab dictionary 
                            //so that it can be searched through again - but it only happens once 
                        //  refreshedCache = true;
                            /*tabDict = TabDictController.FetchTabDictionary(out minTabPathDepth, out maxTabPathDepth, out minAliasPathDepth, out maxAliasPathDepth, settings, true, false);
                            curAliasPathDepth = minAliasPathDepth;
                            curTabPathDepth = minTabPathDepth;*/
                        //}
                    }
                }
            }
            if (finished & reWritten)
            {
                SetRewriteParameters(result, newUrl);

            }
            result.FriendlyRewrite = reWritten;
            result.DoRewrite = reWritten;
            return newUrl;
        }

        /// <summary>
        /// Checks a rewritten url, and if it matches the TriggerDictionaryRebuild regex, invalidates the cache
        /// </summary>
        /// <param name="requestedUrl"></param>
        /// <param name="settings"></param>
        /// <remarks>This procedure will also just add a specified value if dictKey and dictValue strings in the 
        /// result object are not null.  This is used to just add a single value to the tab dictionary, rather than
        /// rebuild the entire thing.</remarks>
        /// <returns>true if a match was made, false if not</returns>
        internal static bool RebuildDictionaryOnTriggerMatch(System.Web.HttpRequest request, UrlAction result, string requestedUrl, FriendlyUrlSettings settings)
        {
            bool rebuildTriggerMatch = false;
            try
            {
                string tdrr = settings.TriggerDictionaryRebuildRegex;
                if (tdrr != null && tdrr != "")
                {
                    bool rebuildCache = false; string matchType = "None";
                    //triggers a rebuild on the dictionary if there is a match on the regex for the 'trigger rebuild'. 
                    //this allows a rebuild on certain postbacks, for instance adding a new page 
                    if (Regex.IsMatch(requestedUrl, tdrr, RegexOptions.IgnoreCase))
                    {
                        rebuildCache = true;
                        rebuildTriggerMatch = true;
                        matchType = "Url";
                    }
                    else
                    {
                        //730: if no match on url, also check on the request form
                        //catches telerik controls
                        if (request != null && request.Form != null)
                        {
                            string formRaw = request.Form.ToString();
                            if (Regex.IsMatch(formRaw, tdrr, RegexOptions.IgnoreCase))
                            {
                                rebuildCache = true;
                                rebuildTriggerMatch = true;
                                matchType = "Form";
                            }
                        }
                    }
                    if (rebuildCache)
                    {
                        if (rebuildCache)
                        {
                            //the cache is cleared out, so that the following request will trigger a rebuild 
                            //and pick up any new pages 
                            PageIndexData rebuildData = null;
                            if (result.dictKey != null && result.dictKey != "" && result.dictVal != null && result.dictVal != "")
                            {
                                //keep the old url that we're working off, but 301 redirect it
                                rebuildData = new PageIndexData();
                                string oldUrl = result.dictVal;
                                //677 : don't double up on do301 calls
                                if (!oldUrl.Contains("do301=true"))
                                {
                                    if (oldUrl.Contains("?"))
                                        oldUrl += "&do301=true";
                                    else
                                        oldUrl += "?do301=true";
                                }
                                rebuildData.LastPageValue = oldUrl;
                                rebuildData.LastPageKey = result.dictKey;
                            }
                            //invalidate the dictionary, so the next request will rebuild it.  Provide the rebuild data
                            TabDictController.InvalidateDictionary("TriggerRebuildMatch - " + matchType + " : " + requestedUrl, rebuildData, -1);
                            result.RebuildRequested = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                FriendlyUrlController.LogExceptionInRequest(ex);

                result.Ex = ex;
            }
            return rebuildTriggerMatch;
        }

        private static string ReplaceDefaultPage(string newUrl, string requestUrl, List<string> list)
        {
            string url = newUrl;//fall back case: we don't change anything
            //iterate the list and replace in the url is a match is found
            foreach (string requestPage in list)
            {
                if (requestUrl.ToLower().Contains(requestPage))
                {
                    url = newUrl.Replace(Globals.glbDefaultPage, requestPage);
                    break;
                }
            }
            return url;
        }
        private static void SetRewriteParameters(UrlAction result, string rewritePath)
        {
            //split out found replaced and store tabid, rulePortalId and do301 if found
            result.RewritePath = rewritePath;
            MatchCollection qsItems = Regex.Matches(rewritePath, @"(?:\&|\?)(?:(?<key>.[^\=\&]*)\=(?<val>.[^\=\&]*))");
            foreach (Match itemMatch in qsItems)
            {
                string val = itemMatch.Groups["val"].Value;
                string key = itemMatch.Groups["key"].Value;
                switch (key.ToLower())
                {
                    case "tabid":
                        Int32.TryParse(val, out result.tabId);
                        break;
                    case "portalid":
                        Int32.TryParse(val, out result.portalId);
                        break;
                    case "do301":
                        result.Action = UrlAction.ActionType.Redirect301;
                        break;
                    case "do302":
                        result.Action = UrlAction.ActionType.Redirect302;
                        break;
                    case "ctl":
                        //786: force redirect for ctl/terms or ctl/privacy
                        RequestRedirectOnBuiltInUrl(val, rewritePath, result);
                        break;
                }
            }
        }
    internal static string RewriteParameters(string newUrl, string tabKeyVal, string[] urlParms, bool firstParmLast, string pageExtension, PageExtensionUsage extensionUsage, UrlAction result, string langParms)
    {
        if (urlParms != null)
        {
            StringBuilder parmString = new StringBuilder();
            bool valueField = false;
            int lastParmToProcessTo = 0;
            string lastParm = null; string rewrittenLangParms = "";
            int upperBound = urlParms.GetUpperBound(0);
            bool evenParms = ((upperBound + 1) % 2) == 0;//determine if even number of parms
            //recheck firstParmLast - just because it is set to be that way in the config doesn't 
            //mean that the url will come in that way. 
            //first strip out any language parameters
            if (langParms != null)
            {
                string[] langValues = langParms.TrimStart('/').Split('/');
                if (langValues.GetUpperBound(0) == 1)
                {
                    int pos1 = -1, pos2 = -1;
                    for (int i= 0; i< urlParms.GetUpperBound(0); i++)
                    {
                        //match this part of the urlParms with the language parms
                        if (urlParms[i] == langValues[0] && urlParms[i + 1] == langValues[1])
                        {
                            pos1 = i;
                            pos2 = i + 1;
                            break;
                        }
                    }
                    if (pos1 > -1 && pos2 > -1)
                    {
                        //this hacky operation removes the language urls from the array
                        List<string> temp = new List<string>(urlParms);
                        temp.RemoveAt(pos2);
                        temp.RemoveAt(pos1);
                        urlParms = (string[])temp.ToArray();
                        upperBound = urlParms.GetUpperBound(0);
                        //656 : don't allow forced lower case of the culture identifier - always convert the case to aa-AA to match the standard
                        string cultureId = langValues[1];
                        Match cultureMatch = Regex.Match(cultureId, "([a-z]{2})-([a-z]{2})", RegexOptions.IgnoreCase);
                        if (cultureMatch != null && cultureMatch.Success)
                            cultureId = cultureMatch.Groups[1].Value + "-" + cultureMatch.Groups[2].ToString().ToUpper();
                        rewrittenLangParms = "&" + langValues[0] + "=" + cultureId;
                    }
                }
            }

            /* remove first parm last option interpretation
            if (!firstParmLast && evenParms && extensionUsage != PageExtensionUsage.AlwaysUse
                && upperBound > -1 && (urlParms[upperBound].Contains(pageExtension)
                | urlParms[upperBound].ToLower().Contains(Globals.glbDefaultPage.ToLower())))
            {
                //well, it's not default.aspx, and it's got a .aspx in it, it's for an even number of parameters. 
                //Assume it's a first parm last value 
                lastParmToProcessTo = urlParms.GetUpperBound(0) - 1;
                valueField = true;
                result.Action = UrlAction.ActionType.CheckFor301;
                //want to replaced it back to the correct format 
                firstParmLast = true;
                //it is a first parm last, after all 
            }
            else*/ 
            if (firstParmLast)
            {
                if (upperBound > -1)
                {
                    lastParmToProcessTo = upperBound - 1;
                    lastParm = urlParms[upperBound];
                    valueField = true;
                }
            }
            else if (!firstParmLast)
            {
                lastParmToProcessTo = urlParms.GetUpperBound(0);
                valueField = false;
            }
            string keyName = null; bool skip = false; 
            for (int i = 0; i <= lastParmToProcessTo; i++)
            {
                string thisParm = urlParms[i];
                //here's the thing - we either take the last one and put it at the start, or just go two-by-two 
                if (!(thisParm.ToLower() == Globals.glbDefaultPage.ToLower()))
                {
                    if (thisParm.ToLower() == "tabid")
                    {
                        skip = true;
                        //discovering the tabid in the list of parameters means that 
                        //it was likely a request for an old-style tab url that 
                        //found a retVal due to match in the tab path.  
                        //while this may mean a 301, we definitely don't want to force a 301,
                        //just investigate it and let the 301 redirect logic work it out
                        //we also want to skip the next parameter, because it is the tabid value
                        if (result.Reason != UrlAction.RedirectReason.Custom_Redirect)
                        {
                            //only reason not to let this one through and count on the 
                            //friendly url checking code is if it was a custom redirect set up
                            result.Reason = UrlAction.RedirectReason.Not_Redirected;
                            result.Action = UrlAction.ActionType.CheckFor301;
                            //set the value field back to false, because, even if the parameter handling is
                            //first parm last, this was an old style URl desitned to be redirected.
                            //and we would expect old-style urls to have the correct parameter order
                            //note this assumes tabid is the first parm in the list.
                            valueField = false;
                        }
                    }
                    else if (!skip)
                    {
                        bool extReplaced = false;
                        string urlParm = CleanExtension(thisParm, pageExtension, out extReplaced);
                        /*string urlParm = thisParm.Replace(".aspx", "");
                        if (pageExtension != "" && pageExtension != null)
                            urlParm = urlParm.Replace(pageExtension, "");*/
                        if (extReplaced && pageExtension == "") //replacing a .aspx extension
                            result.Action = UrlAction.ActionType.CheckFor301;
                        if (valueField)
                        {
                            parmString.Append("=");
                            parmString.Append(urlParm);
                            valueField = false;

                            //786 : redirect ctl/terms etc
                            if (keyName != null && keyName.ToLower() == "ctl")
                            {
                                RequestRedirectOnBuiltInUrl(urlParm, parmString.ToString(), result);
                            }
                        }
                        else
                        {
                            keyName = urlParm;
                            parmString.Append("&");
                            parmString.Append(urlParm);
                            valueField = true;
                        }
                    }
                    else if (skip)
                        skip = false;

                }
            }
            //now stick the last one on the start, if we are looking for the last one. 
            if (firstParmLast && lastParm != null 
                && lastParm.ToLower() != Globals.glbDefaultPage.ToLower())
            {
                string parm = lastParm.Replace(pageExtension, "");
                parmString.Insert(0, parm);
                parmString.Insert(0, "&");
            }
            newUrl += rewrittenLangParms + parmString.ToString();
            //chop the last char off if it is an empty parameter 
            if ((newUrl[newUrl.Length - 1] == '&'))
                newUrl = newUrl.Substring(0, newUrl.Length - 1);
        }
        return newUrl;

    }
    /// <summary>
    /// Checks for a current parameter belonging to one of the built in 'ctl' values
    /// </summary>
    /// <param name="urlParm"></param>
    /// <param name="rewritePath"></param>
    /// <param name="result"></param>
    /// <remarks>Sets the Action parameter of the Result to 'CheckFor301' if suspected. Actual redirect taken care of by friendly url redirection logic</remarks>
    internal static void RequestRedirectOnBuiltInUrl(string urlParm, string rewritePath, UrlAction result)
    {
        //on the lookout for items to potentially redirect
        if ("terms|privacy|login|register".Contains(urlParm.ToLower()))
        {
            //likely that this should be redirected, because we don't want ctl/terms, ctl/register, etc
            result.Reason = UrlAction.RedirectReason.Built_In_Url;
            result.Action = UrlAction.ActionType.CheckFor301;
            result.DebugMessages.Add("Built-in Url found: " + rewritePath);
        }
    }

        internal static string CleanExtension(string value, string extension, out bool replaced)
        {
            string result = value; string ext = extension.ToLower();
            replaced = false;
            if (result.ToLower().EndsWith(ext) && ext != "")
            {
                result = result.Substring(0, result.Length - ext.Length);
                replaced = true;
            }
            else
            {
                if (result.ToLower().EndsWith(".aspx"))
                {
                    result = result.Substring(0, result.Length - 5);
                    replaced = true;
                }
                else
                    if (result.EndsWith("/"))
                    {
                        result = result.Substring(0, result.Length - 1);
                        replaced = true;
                    }
            }
            return result;
        }
        internal static string CleanExtension(string value, FriendlyUrlSettings settings, out bool replaced)
        {
            return CleanExtension(value, settings.PageExtension, out replaced);   
        }
        private static bool TryAndFixSubDomain(string requestedPath, FriendlyUrlSettings settings)
        {
            string redirectPath = requestedPath;
            bool doRedirect = false;
            if (((settings.RedirectToSubDomain != null)))
            {
                //this regex looks for the specified subdomain at the start of the string 
                string lookFor = "(?:(?<right>^" + settings.RedirectToSubDomain + ")\\.{0,1})|(?<wrong>^[\\w\\s\\d]+[^\\.]+)(?:\\.|\\Z)";
                Match domainMatch = Regex.Match(requestedPath, lookFor, RegexOptions.IgnoreCase);
                if ((domainMatch.Success))
                {
                    if ((domainMatch.Groups["wrong"].Success))
                    {
                        //this has a subdomain, but it's not the one wanted 
                        if ((requestedPath.Contains(settings.RedirectToSubDomain)))
                        {
                            //the subdomain is in there, but there are other subdomain(s) in front of it 
                            //so get rid of everything to the left 
                            redirectPath = requestedPath.Substring(requestedPath.IndexOf(settings.RedirectToSubDomain));
                            doRedirect = true;
                        }
                        else
                        {
                            //put the subdomain on the front 
                            redirectPath = settings.RedirectToSubDomain + "." + requestedPath;
                            doRedirect = true;
                        }
                    }
                }
            }
            if ((doRedirect))
            {
                requestedPath = redirectPath;
            }
            return doRedirect;
        }

    }
}
