#region legal messages
// iFinity.com.au 
// This is customised software derived from the DotNetNuke core. The below copyright messages should be followed 
// , and any copies of this software should include this message.   
// Please feel free to distribute and modify this code, ensuring that copyright law is respected 
// You may not sell this version of the iFinity modifications to the DotNetNuke core code, either in this format,
// or with minor modifications such as conversion to a different source language.
// 
// DotNetNuke� - http://www.dotnetnuke.com 
// Copyright (c) 2002-2005 
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca ) 
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software. 
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE. 
// 
#endregion

#region using 
using System;
using System.Web;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using DotNetNuke.Common; 
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Framework.Providers; 
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Services.Url.FriendlyUrl; 
#endregion

namespace iFinity.DNN.Modules.FriendlyUrl
{
    /// <summary>
    /// SEO UrlProvider base on iFinity FriendlyUrlProvider by Bruce Chapman's Bertrob Pty Ltd.
    /// </summary>
    public class SEOUrlProvider : FriendlyUrlProvider 
    { 
        #region Constants
        
        private const string ProviderType = "friendlyUrl"; 
        //private const string RegexMatchExpression = "[^a-zA-Z0-9 ]"; 
        
        #endregion 
        
        #region Private Members
        
        private ProviderConfiguration _providerConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType); 

        FriendlyUrlSettings _settings;
        
        #endregion 
        
        #region Constructors

        public SEOUrlProvider() 
        { 
            // Read the configuration specific information for this provider 
            Provider objProvider = (Provider)_providerConfiguration.Providers[_providerConfiguration.DefaultProvider];
            //stash settings in the settings object
            _settings = new FriendlyUrlSettings(objProvider);
          
        } 
        
        #endregion 
        #region Friend Properties
        internal FriendlyUrlSettings Settings
        {
            get
            {
                return _settings;
            }
        }
        #endregion 
        #region Public Properties

        #endregion 
        
        #region Public Methods
        /// <summary>
        /// Return a FriendlyUrl for the supplied Tab
        /// </summary>
        /// <param name="tab"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public override string FriendlyUrl(TabInfo tab, string path) 
        { 
            
            PortalSettings _portalSettings = PortalController.GetCurrentPortalSettings(); 
            
            return FriendlyUrl(tab, path, DotNetNuke.Common.Globals.glbDefaultPage, _portalSettings); 
            
        }
        /// <summary>
        /// Return a FriendlyUrl for the supplied Tab
        /// </summary>
       
        public override string FriendlyUrl(TabInfo tab, string path, string pageName) 
        { 
            
            PortalSettings _portalSettings = PortalController.GetCurrentPortalSettings(); 
            
            return FriendlyUrl(tab, path, pageName, _portalSettings); 
            
        }

        /// <summary>
        /// Return a FriendlyUrl for the supplied Tab
        /// </summary>
        public override string FriendlyUrl(TabInfo tab, string path, string pageName, PortalSettings portalSettings) 
        {
            //System.Web.HttpContext.Current.ApplicationInstance.Context.Response.Filter = new FriendlyUrlFilter(System.Web.HttpContext.Current.ApplicationInstance.Context.Response.Filter);
            string friendlyPath = path; 
            //Call GetFriendlyAlias to get the Alias part of the url 
            friendlyPath = GetFriendlyAlias(path, portalSettings.PortalAlias.HTTPAlias);
            if (tab == null && path == "~/" && string.Compare(pageName, DotNetNuke.Common.Globals.glbDefaultPage, true) == 0)
            {
                //this is a request for the site root for he dnn logo skin object (642)
                //do nothing, the friendly alias is already correct - we don't want to append 'default.aspx' on the end
            }
            else
            {
                //Get friendly path gets the standard dnn-style friendly path 
                friendlyPath = GetFriendlyQueryString(tab, friendlyPath, pageName, _settings);
                //ImproveFriendlyUrl will attempt to remove tabid/nn and other information from the Url 
                friendlyPath = ImproveFriendlyUrl(tab, friendlyPath, pageName, portalSettings, false, _settings);
            }
            //set it to lower case if so allowed by settings
            friendlyPath = ForceLowerCaseIfAllowed(tab, friendlyPath, Settings);
            
            return friendlyPath; 
        }

        /// <summary>
        /// Return a FriendlyUrl for the supplied Tab
        /// </summary>
        public override string FriendlyUrl(TabInfo tab, string path, string pageName, string portalAlias) 
        {
            //System.Web.HttpContext.Current.ApplicationInstance.Context.Response.Filter = new FriendlyUrlFilter(System.Web.HttpContext.Current.ApplicationInstance.Context.Response.Filter);
            string friendlyPath = path; 
            //Call GetFriendlyAlias to get the Alias part of the url 
            friendlyPath = GetFriendlyAlias(path, portalAlias);
            if (tab == null && path == "~/" && string.Compare(pageName, DotNetNuke.Common.Globals.glbDefaultPage, true) == 0)
            {
                //642 do not process the end of the path for site root requests
            }
            else
            {
                //Call GetFriendlyQueryString to get the QueryString part of the url 
                friendlyPath = GetFriendlyQueryString(tab, friendlyPath, pageName, _settings);
                //ImproveFriendlyUrl will attempt to remove tabid/nn and other information from the Url 
                PortalAliasController pac = new PortalAliasController();
                PortalAliasInfo alias = pac.GetPortalAlias(portalAlias, tab.PortalID);
                PortalSettings portalSettings = new PortalSettings(tab.TabID, alias);
                friendlyPath = ImproveFriendlyUrl(tab, friendlyPath, pageName, portalSettings, false, _settings);
            }
            friendlyPath = ForceLowerCaseIfAllowed(tab, friendlyPath, Settings);
            
            return friendlyPath; 
            
        }
        /// <summary>
        /// Return a FriendlyUrl for the supplied Tab, but don't improve it past the standard DNN Friendly Url version
        /// </summary>
        public static string BaseFriendlyUrl(TabInfo tab, string path, string pageName, string httpAlias, FriendlyUrlSettings settings)
        {
            string friendlyPath = path;
            //Call GetFriendlyAlias to get the Alias part of the url 
            friendlyPath = GetFriendlyAlias(path, httpAlias);
            //Call GetFriendlyQueryString to get the QueryString part of the url 
            friendlyPath = GetFriendlyQueryString(tab, friendlyPath, pageName, settings);
            return friendlyPath;
        }
        /// <summary>
        /// Return a full-improved Friendly Url for the supplied tab
        /// </summary>
        /// <param name="tab"></param>
        /// <param name="path"></param>
        /// <param name="pageName"></param>
        /// <returns></returns>
       /* public static string ImprovedFriendlyUrl(TabInfo tab, string path, string pageName, string httpAlias, FriendlyUrlSettings settings)
        {
            string friendlyPath = path;
            //Call GetFriendlyAlias to get the Alias part of the url 
            friendlyPath = GetFriendlyAlias(path, httpAlias);
            //Call GetFriendlyQueryString to get the QueryString part of the url 
            friendlyPath = GetFriendlyQueryString(tab, friendlyPath, pageName, settings);
            //ImproveFriendlyUrl will attempt to remove tabid/nn and other information from the Url 
            friendlyPath = ImproveFriendlyUrl(tab, friendlyPath, pageName, httpAlias, false, settings);
            if (settings.ForceLowerCase)
            {
                friendlyPath = friendlyPath.ToLower();
            }
            return friendlyPath;
        }*/
        /// <summary>
        /// Return a full-improved Friendly Url for the supplied tab
        /// </summary>
        /// <param name="tab">The current page</param>
        /// <param name="path">The non-friendly path to the page</param>
        /// <param name="pageName">The name of the page</param>
        /// <param name="httpAlias">The current portal alias to use</param>
        /// <param name="ignoreCustomRedirects">If true, then the Friendly Url will be constructed without using any custom redirects</param>
        /// <param name="settings">The current Friendly Url Settings to use</param>
        /// <returns></returns>
        public static string ImprovedFriendlyUrl(TabInfo tab, string path, string pageName, string httpAlias, bool ignoreCustomRedirects, FriendlyUrlSettings settings)
        {
            List<string> messages = null;
            return ImprovedFriendlyUrlWithMessages(tab, path, pageName, httpAlias, ignoreCustomRedirects, settings, out messages);
        }
        public static string ImprovedFriendlyUrlWithMessages(TabInfo tab, string path, string pageName, string httpAlias, bool ignoreCustomRedirects, FriendlyUrlSettings settings, out List<string> messages)
        {
            string friendlyPath = path;
            //Call GetFriendlyAlias to get the Alias part of the url 
            friendlyPath = GetFriendlyAlias(path, httpAlias);
            //Call GetFriendlyQueryString to get the QueryString part of the url 
            friendlyPath = GetFriendlyQueryString(tab, friendlyPath, pageName, settings);
            //ImproveFriendlyUrl will attempt to remove tabid/nn and other information from the Url 
            PortalAliasController pac = new PortalAliasController();
            PortalAliasInfo alias = pac.GetPortalAlias(httpAlias, tab.PortalID);
            PortalSettings portalSettings = new PortalSettings(tab.TabID, alias);
            friendlyPath = ImproveFriendlyUrlWithMessages(tab, friendlyPath, pageName, portalSettings, ignoreCustomRedirects, settings, out messages);
            friendlyPath = ForceLowerCaseIfAllowed(tab, friendlyPath, settings);
            
            return friendlyPath;
        }
        public static string ImprovedFriendlyUrlWithSettings(TabInfo tab, string path, string pageName, PortalSettings portalSettings, bool ignoreCustomRedirects, FriendlyUrlSettings settings)
        {
            List<string> messages = null;
            return ImprovedFriendlyUrlWithSettingsAndMessages(tab, path, pageName, portalSettings, ignoreCustomRedirects, settings, out messages);
        }
        public static string ImprovedFriendlyUrlWithSettingsAndMessages(TabInfo tab, string path, string pageName, PortalSettings portalSettings, bool ignoreCustomRedirects, FriendlyUrlSettings settings, out List<string> messages)
        {
            string friendlyPath = path;
            //Call GetFriendlyAlias to get the Alias part of the url 
            friendlyPath = GetFriendlyAlias(path, portalSettings.PortalAlias.HTTPAlias);
            //Call GetFriendlyQueryString to get the QueryString part of the url 
            friendlyPath = GetFriendlyQueryString(tab, friendlyPath, pageName, settings);
            //ImproveFriendlyUrl will attempt to remove tabid/nn and other information from the Url 
            friendlyPath = ImproveFriendlyUrlWithMessages(tab, friendlyPath, pageName, portalSettings, ignoreCustomRedirects, settings, out messages);
            //force lower case if allowed
            friendlyPath = ForceLowerCaseIfAllowed(tab, friendlyPath, settings);

            return friendlyPath;
        }


        #endregion 
        
        #region Private Methods
        /// <summary>
        /// Improve Friendly Url takes a base friendly Url and improves it further
        /// </summary>
        /// <param name="tab">The tab of the Url</param>
        /// <param name="friendlyPath">The existing friendly Path generated by the base code</param>
        /// <param name="pageName">The current page name being used</param>
        /// <param name="portalAlias">The portal alias being used</param>
        /// <returns>The friendliest url possible</returns>
        private static string ImproveFriendlyUrl(TabInfo tab, string friendlyPath, string pageName, PortalSettings portalSettings, bool ignoreCustomRedirects, FriendlyUrlSettings settings)
        {
            //older overload does not include informational/debug messages on return
            List<string> messages = null;
            return ImproveFriendlyUrlWithMessages(tab, friendlyPath, pageName, portalSettings, ignoreCustomRedirects, settings, out messages);
        }
        private static string ImproveFriendlyUrlWithMessages(TabInfo tab, string friendlyPath, string pageName, PortalSettings portalSettings, bool ignoreCustomRedirects, FriendlyUrlSettings settings, out List<string> messages) 
        {
            messages = new List<string>();
            string portalAlias = portalSettings.PortalAlias.HTTPAlias;
            //invalid call just return the path
            if (tab == null)
                return friendlyPath;

            //no improved friendly urls for super tabs, admin tabs
            if (tab.IsSuperTab ||
                tab.IsAdminTab || 
                RewriteController.IsAdminTab(tab.PortalID, tab.TabPath, settings)) 
                return friendlyPath;
 
            //655 : no friendly url if matched with regex
            if (settings.NoFriendlyUrlRegex != null && settings.NoFriendlyUrlRegex != "")
                if (Regex.IsMatch(friendlyPath, settings.NoFriendlyUrlRegex, RegexOptions.IgnoreCase))
                    return friendlyPath;
            
            string result = ""; 
            result = friendlyPath; 
            //determine if an improved friendly Url is wanted at all
            if (settings.UrlFormat  == "HumanFriendly" 
                &&  !RewriteController.IsExcludedFromFriendlyUrls(tab, settings, false))
            {
                string newTabPath = "";
                //do a regex check on the base friendly Path, to see if there is parameters on the end or not
                Regex tabOnlyRegex = new Regex( "[^?]*/tabId/(?<tabid>\\d+)/" + pageName + @"($|\?(?<qs>.+$))", RegexOptions.IgnoreCase);
                
                if (tabOnlyRegex.IsMatch(friendlyPath) && (tab != null))
                {
                    MatchCollection tabOnlyMatches = tabOnlyRegex.Matches(friendlyPath);
                    string qs = "";
                    if (tabOnlyMatches.Count > 0)
                    {
                        Match rgxMatch = tabOnlyMatches[0];
                        if (rgxMatch.Groups["qs"] != null && rgxMatch.Groups["qs"].Success)
                        {
                            qs = "?" + rgxMatch.Groups["qs"].Value;
                        }
                    }
                    newTabPath = SEOTabPathHelper.GetTabPath(tab, settings, ignoreCustomRedirects, true, portalSettings.HomeTabId);
                    //it is a straight page.aspx reference, with just the tabid to specify parameters 
                    string extension="";
                    if (tab.TabID != portalSettings.HomeTabId)  //no pageAndExtension for the home page when no query string specified
                    {
                        //the ending of the url depends on the current page pageAndExtension settings
                        if (settings.PageExtensionUsage == PageExtensionUsage.AlwaysUse
                            || settings.PageExtensionUsage == PageExtensionUsage.PageOnly)
                        {
                            //check whether a 'custom' (other than default.aspx) page was supplied, and insert that as the pageAndExtension 
                            if (string.Compare(pageName, DotNetNuke.Common.Globals.glbDefaultPage, true) != 0)
                            {
                                extension = "/" + pageName.Replace(".aspx", settings.PageExtension);
                            }
                            else
                            {
                                extension = settings.PageExtension;
                                //default page pageAndExtension 
                            }
                        }
                        else
                        {
                            if (string.Compare(pageName, DotNetNuke.Common.Globals.glbDefaultPage, true) != 0)
                            {
                                //get rid of the .aspx on the page if it was there 
                                extension = "/" + pageName.Replace(".aspx", "");// +"/"; //610 : don't always end with /
                            }
                            else
                            {
                                //no pageAndExtension 
                                extension = ""; //610 dont always end with "/";
                            }
                        }
                    }
                    result = Globals.AddHTTP(portalAlias + "/" + newTabPath.TrimStart('/') + extension) + qs; 
                } 
                else 
                {
                    //When the home page is requested with a querystring value, the path for the home page is included.  This is because path items without the home page 
                    //qualifier are incorrectly checked for as dnn pages, and will result in a 404.  Ie domain.com/key/value will fail looking for a DNN path called 'key/value'.
                    //This gets around the problem because it places the path aas /home/key/value - which correctly identifies the tab as '/Home' and the key/value parameters as
                    // &key=value.
                    newTabPath = SEOTabPathHelper.GetTabPath(tab, settings, ignoreCustomRedirects, false, portalSettings.HomeTabId);
                    //there are parameters on the base friendly url path, so split them off and process separately
                    MatchCollection matches; 
                    //this regex splits the incoming friendly path pagename/tabid/56/default.aspx into the non-tabid path, and individual parms for each /parm/ in the friendly path 
                    //550 : add in \. to allow '.' in the parameter path.
                    //667 : allow non-word characters (specifically %) in the path
                    Regex rgx = new Regex("[^?]*(?<tabs>/tabId/(?<tabid>\\d+))(?<path>(?<parms>(?:/[\\d\\w\\s\\+\\.\\W'-]*[^/]){1})+)(?:/" + pageName + @")($|\?(?<qs>.+$))", RegexOptions.IgnoreCase); 
                    matches = rgx.Matches(friendlyPath); 
                    if (matches.Count > 0) 
                    { 
                        //it is a friendly url with other parameters in it 
                        //format it up with the parameters in the end, keeping the same page name 
                        //find the first param name in the params of the Url (the first path piece after the tabid/nn/ value) 
                        Match rgxMatch = matches[0]; 
                        //check we matched on some parms in the path 
                        if (rgxMatch.Groups["parms"] != null && rgxMatch.Groups["parms"].Success)
                        { 
                            if (rgxMatch.Groups["parms"].Captures.Count > 0) 
                            { 
                                string newPageName=""; 
                                string newPath=rgxMatch.Groups["path"].Value;
                                string qs = rgxMatch.Groups["qs"].Value;
                                string langParms = "";
                                Match langMatch = Regex.Match(newPath, "/language/(?:.[^/]+)(?:/|$)", RegexOptions.IgnoreCase);
                                if (langMatch.Success)
                                {
                                    //a language specifier parameter is in the string
                                    //this is always the last parameter in the list, which
                                    //gives nasty pagename results, so shift the language query to before the page name
                                    // ie home/tabid/66/language/en-us/default.aspx will give home/language/en-us.aspx
                                    // we really want language/en-us/home.aspx
                                    langParms = langMatch.Value;
                                    langParms = langParms.TrimEnd('/');
                                    newPath = newPath.Replace(langParms, "");
                                }

                                        if (settings.ParameterHandling == ParameterHandling.FirstParameterLast)
                                        {
                                            //the new page name (page.aspx) is actually the text value of the first parm key after the tabid/nn pair 
                                            if (langParms != "")
                                            {
                                                //if we have language parameters in the query, step around by looking for the first parm that isn't a lang parm
                                                Match parmsMatch = rgx.Match(newPath);
                                                if (parmsMatch.Success)
                                                    newPageName = parmsMatch.Groups["parms"].Captures[0].Value;
                                            }
                                            else
                                                newPageName = rgxMatch.Groups["parms"].Captures[0].Value;
                                            //get the first capture of the parm group captures 
                                            //the rest of the path is just stuck in as-is, with the first parm removed (because it became the page name) 
                                            //remove the new page name from the path 
                                            if (newPageName != "" && newPath != null && newPath.Length >= 1)
                                            {
                                                int firstPos = newPath.IndexOf('/', 1);//get the first / path marker
                                                newPath = newPath.Substring(firstPos);
                                            }
                                        }

                                
                                //put on the portal alias and http, replace the // in the tab path, and append it all together 
                                string pageAndExtension = ""; 
                                if (settings.PageExtensionUsage == PageExtensionUsage.Never 
                                    || settings.PageExtensionUsage == PageExtensionUsage.PageOnly)
                                { 
                                    if (pageName != DotNetNuke.Common.Globals.glbDefaultPage) 
                                    { 
                                        if (pageName == "Logoff.aspx")
                                        { 
                                            pageAndExtension = "/" + pageName; 
                                        } 
                                        else
                                            if (settings.ProcessRequestList != null && settings.ProcessRequestList.Contains(pageName.ToLower()))
                                            {
                                                pageAndExtension = "/" + pageName;
                                            }
                                            else
                                            {
                                                pageAndExtension = "/" + pageName.Replace(".aspx", "");//610 + "/";
                                                //get rid of the .aspx on the page if it was there 
                                            } 
                                    } 
                                    else 
                                    {
                                        pageAndExtension = "";//610 don't end with "/"; 
                                        //no pageAndExtension 
                                    } 
                                } 
                                else 
                                { 
                                    if (pageName != DotNetNuke.Common.Globals.glbDefaultPage)
                                    { 
                                        if (pageName == "Logoff.aspx")
                                        { 
                                            pageAndExtension = "/" + pageName; 
                                        } 
                                        else
                                            if (settings.ProcessRequestList != null && settings.ProcessRequestList.Contains(pageName.ToLower()))
                                            {
                                                pageAndExtension = "/" + pageName;
                                            }
                                            else
                                            {
                                                pageAndExtension = "/" + pageName.Replace(".aspx", settings.PageExtension);
                                            }
                                    } 
                                    else 
                                    { 
                                        pageAndExtension = settings.PageExtension; 
                                        //default page extension 
                                    } 
                                    
                                }
                                if (qs != null && qs.Length > 0)
                                {
                                    qs = "?" + qs;
                                }
                                else
                                    qs = "";
                                
                                string finalPath; 

                                //contstruct the final Url
                                finalPath = Globals.AddHTTP(portalAlias + langParms + "/");
                                finalPath += newTabPath.TrimStart('/') + newPath + newPageName + pageAndExtension + qs;

                                //'and we're done! 
                                result = Globals.AddHTTP(finalPath); 
                                
                            } 
                        } 
                    } 
                    else { 
                        Regex re = new Regex("[^?]*/tabId/(\\d+)/ctl/([A-Z][a-z]+)/" + pageName + "$", RegexOptions.IgnoreCase); 
                        if ((re.IsMatch(friendlyPath))) { 
                            Match sesMatch = re.Match(friendlyPath); 
                            if ((sesMatch.Groups.Count > 2)) { 
                                switch (sesMatch.Groups[2].Value.ToLower()) { 
                                    case "terms": 
                                        result = Globals.AddHTTP(portalAlias + "/" + sesMatch.Groups[2].Value + ".aspx"); 
                                        break; 
                                    case "privacy": 
                                        result = Globals.AddHTTP(portalAlias + "/" + sesMatch.Groups[2].Value + ".aspx"); 
                                        break; 
                                    case "login": 
                                        result = Globals.AddHTTP(portalAlias + "/" + sesMatch.Groups[2].Value + ".aspx"); 
                                        break; 
                                    case "register": 
                                        result = Globals.AddHTTP(portalAlias + "/" + sesMatch.Groups[2].Value + ".aspx"); 
                                        break; 
                                    default: 
                                        result = friendlyPath; 
                                        break; 
                                } 
                            } 
                        } 
                    } 
                } 
            } 
            return result; 
        }

        /// ----------------------------------------------------------------------------- 
        /// <summary> 
        /// AddPage adds the page to the friendly url 
        /// </summary> 
        /// <remarks> 
        /// </remarks> 
        /// <param name="path">The path to format.</param> 
        /// <param name="pageName">The page name.</param> 
        /// <returns>The formatted url</returns> 
        /// <history> 
        /// [cnurse] 12/16/2004 created 
        /// </history> 
        /// ----------------------------------------------------------------------------- 
        private static string AddPage(string path, string pageName) 
        { 
            
            string friendlyPath = path;
            if (friendlyPath.EndsWith(pageName + "/"))
                friendlyPath = friendlyPath.TrimEnd('/');
            else 
                if (friendlyPath.EndsWith(pageName) == false)
                {
                    if (friendlyPath.EndsWith("/"))
                    {
                        friendlyPath = friendlyPath + pageName;
                    }
                    else
                    {
                        friendlyPath = friendlyPath + "/" + pageName;
                    }
                } 
            return friendlyPath; 
            
        } 
        
        /// ----------------------------------------------------------------------------- 
        /// <summary> 
        /// GetFriendlyAlias returns the supplied path with the correct portal Alias on the front
        /// </summary> 
        /// <remarks> 
        /// Must handle paths in the form of /path/page.aspx?key=value, ~/path/page.aspx , http://domainname/path/ and path/page.aspx
        /// As well as the special case of http://www.domain.com/Default.aspx?alias=www.domain.com/child
        /// </remarks> 
        /// <param name="path">The path to format.</param> 
        /// <param name="portalAlias">The portal alias of the site.</param> 
        /// <returns>The formatted url</returns> 
        /// ----------------------------------------------------------------------------- 
        private static string GetFriendlyAlias(string path, string portalAlias) 
        {

            string friendlyPath = path; bool done = false; string httpAliasFull= null;
            //this regex identifies if the correct http://portalAlias already is in the path
            Regex portalMatchRegex = new Regex("^http[s]*://" + portalAlias, RegexOptions.IgnoreCase);
            if (portalMatchRegex.IsMatch(path) == false)
            {
                //the portal alias is not in the path already, so we need to get it in there
                if (friendlyPath.StartsWith("~/"))
                    friendlyPath = friendlyPath.Substring(1);
                if (friendlyPath.StartsWith("/") == false)
                    friendlyPath = "/" + friendlyPath;
                //should now have a standard /path/path/page.aspx?key=value style of Url
                httpAliasFull = Globals.AddHTTP(portalAlias);

                string originalUrl = null;
                if (HttpContext.Current.Items["UrlRewrite:OriginalUrl"] != null)
                {
                    originalUrl = HttpContext.Current.Items["UrlRewrite:OriginalUrl"].ToString();
                    //confirming this portal was the original one requested, making all the generated aliases
                    //for the same portal
                    Match portalMatch = Regex.Match(originalUrl, "^" + httpAliasFull, RegexOptions.IgnoreCase);
                    if (portalMatch.Success == false)
                    {
                        //Manage the special case where original url contains the alias as 
                        //http://www.domain.com/Default.aspx?alias=www.domain.com/child" 
                        portalMatch = Regex.Match(originalUrl, "^?alias=" + portalAlias, RegexOptions.IgnoreCase);
                        if (portalMatch.Success)
                        {
                            friendlyPath = Globals.ResolveUrl(friendlyPath);
                            done = true;
                        }
                    }
                }
            }
            else
                done = true;// well, the friendly path passed in had the right portal alias

            if (!done)
            {
                if (httpAliasFull == null)
                    httpAliasFull = Globals.AddHTTP(portalAlias);
                friendlyPath = httpAliasFull + friendlyPath;
                done = true;
            }

            /*
            //Start with a leading / if neither prefixed with a scheme 
            //or with a ~/ relative path
            if (friendlyPath.StartsWith("http") == false 
                && friendlyPath.StartsWith("~/") == false 
                && friendlyPath.StartsWith("/") == false)
                friendlyPath = "/" + friendlyPath;

            string matchString = "";

            if (portalAlias != Null.NullString)
            {
                string originalUrl = null;
                if (HttpContext.Current.Items["UrlRewrite:OriginalUrl"] != null)
                {
                    originalUrl = HttpContext.Current.Items["UrlRewrite:OriginalUrl"].ToString();
                    Match portalMatch = Regex.Match(originalUrl, "^" + Globals.AddHTTP(portalAlias), RegexOptions.IgnoreCase);
                    if (!object.ReferenceEquals(portalMatch, Match.Empty))
                    {
                        matchString = Globals.AddHTTP(portalAlias);
                    }

                    if (matchString == "" && originalUrl != null)
                    {
                        //Manage the special case where original url contains the alias as 
                        //http://www.domain.com/Default.aspx?alias=www.domain.com/child" 
                        portalMatch = Regex.Match(originalUrl, "^?alias=" + portalAlias, RegexOptions.IgnoreCase);
                        if (!object.ReferenceEquals(portalMatch, Match.Empty))
                        {
                            matchString = Globals.AddHTTP(portalAlias);
                        }
                    }
                }
            }
            
            if (matchString != "")
            { 
                if (path.IndexOf("~") != -1)
                { 
                    friendlyPath = friendlyPath.Replace("~", matchString); 
                } 
                else 
                { 
                    friendlyPath = matchString + friendlyPath; 
                } 
            } 
            else
            { 
                friendlyPath = Globals.ResolveUrl(friendlyPath); 
            } 
            */
            return friendlyPath; 
            
        } 
        
        ///// ----------------------------------------------------------------------------- 
        ///// <summary> 
        ///// GetFriendlyQueryString gets the Querystring part of the friendly url 
        ///// </summary> 
        ///// <remarks> 
        ///// </remarks> 
        ///// <param name="path">The path to format.</param> 
        ///// <param name="portalSettings">The Portal Settings for the site.</param> 
        ///// <returns>The formatted url</returns> 
        ///// <history> 
        ///// [cnurse] 12/16/2004 created 
        ///// [smcculloch]10/10/2005 Regex update for rewritten characters 
        ///// </history> 
        ///// ----------------------------------------------------------------------------- 
        //private static string GetFriendlyQueryString(TabInfo tab, string path, PortalSettings portalSettings, string pageName, FriendlyUrlSettings settings) 
        //{ 
            
        //    string friendlyPath = path; 
        //    Match queryStringMatch = Regex.Match(friendlyPath, "(.[^\\\\?]*)\\\\?(.*)", RegexOptions.IgnoreCase); 
        //    string queryStringSpecialChars = ""; 
            
        //    if ((!object.ReferenceEquals(queryStringMatch, Match.Empty))) { 
        //        friendlyPath = queryStringMatch.Groups[1].Value; 
        //        friendlyPath = Regex.Replace(friendlyPath, DotNetNuke.Common.Globals.glbDefaultPage, "", RegexOptions.IgnoreCase); 
                
        //        string queryString = queryStringMatch.Groups[2].Value.Replace("&amp;", "&"); 
        //        if ((queryString.StartsWith("?"))) { 
        //            queryString = queryString.TrimStart('?'); 
        //        } 
                
        //        string[] nameValuePairs = queryString.Split('&'); 
        //        for (int i = 0; i <= nameValuePairs.Length - 1; i++) { 
        //            string pathToAppend = ""; 
        //            string[] pair = nameValuePairs[i].Split('='); 
                    
        //            if ((friendlyPath.EndsWith("/"))) { 
        //                pathToAppend = pathToAppend + pair[0]; 
        //            } 
        //            else { 
        //                pathToAppend = pathToAppend + "/" + pair[0]; 
        //            } 
                    
        //            if ((pair.Length > 1)) { 
        //                if ((pair[1].Length > 0)) { 
                            
        //                    if ((Regex.IsMatch(pair[1], settings.RegexMatch) == false)) { 
        //                        // Contains Non-AlphaNumeric Characters 
        //                        if (pair[0].ToLower() == "tabid")
        //                        {
        //                            int tabId = -1;
        //                            if (System.Int32.TryParse(pair[1], out tabId))
        //                            { 
        //                                if (tab != null)
        //                                { 
        //                                    if (tab.TabID == tabId)
        //                                    { 
        //                                        if ((tab.TabPath != Null.NullString) & settings.IncludePageName) { 
        //                                            pathToAppend = tab.TabPath.Replace("//", "/").TrimStart('/') + "/" + pathToAppend; 
        //                                        } 
        //                                    } 
        //                                } 
        //                            } 
        //                        } 
                                
        //                        //pathToAppend = pathToAppend + "/" + pair[1].Replace(" ", System.Web.HttpUtility.UrlEncode((Strings.Chr(32)).ToString())); 
        //                        pathToAppend = pathToAppend + "/" + pair[1].Replace(" ", "+");
        //                    } 
                            
        //                    else { 
                                
        //                        // Rewrite into URL, contains only alphanumeric and the % or space 
        //                        if ((queryStringSpecialChars.Length == 0)) { 
        //                            queryStringSpecialChars = pair[0] + "=" + pair[1]; 
        //                        } 
        //                        else { 
        //                            queryStringSpecialChars = queryStringSpecialChars + "&" + pair[0] + "=" + pair[1]; 
        //                        } 
                                
        //                        pathToAppend = ""; 
                                
        //                    } 
        //                } 
                        
        //                else 
        //                { 
        //                    //pathToAppend = pathToAppend + "/" + System.Web.HttpUtility.UrlEncode((Strings.Chr(32)).ToString()); 
        //                    pathToAppend = pathToAppend + "/+"; //encode space
        //                } 
        //            } 
                    
        //            friendlyPath = friendlyPath + pathToAppend; 
        //        } 
        //    } 
            
        //    if ((queryStringSpecialChars.Length > 0)) { 
        //        return AddPage(friendlyPath, pageName) + "?" + queryStringSpecialChars; 
        //    } 
        //    else { 
        //        return AddPage(friendlyPath, pageName); 
        //    } 
            
        //} 
        
        /// ----------------------------------------------------------------------------- 
        /// <summary> 
        /// GetFriendlyQueryString gets the Querystring part of the friendly url 
        /// </summary> 
        /// <remarks> 
        /// </remarks> 
        /// <param name="tab">The tab whose url is being formatted.</param> 
        /// <param name="path">The path to format.</param> 
        /// <returns>The formatted url</returns> 
        /// <history> 
        /// [cnurse] 12/16/2004 created 
        /// [smcculloch]10/10/2005 Regex update for rewritten characters 
        /// </history> 
        /// ----------------------------------------------------------------------------- 
        private static string GetFriendlyQueryString(TabInfo tab, string path, string pageName, FriendlyUrlSettings settings) 
        { 
            
            string friendlyPath = path; 
            Match queryStringMatch = Regex.Match(friendlyPath, "(.[^\\\\?]*)\\\\?(.*)", RegexOptions.IgnoreCase); 
            string queryStringSpecialChars = ""; 
            string defaultPageName = DotNetNuke.Common.Globals.glbDefaultPage;
            if (!object.ReferenceEquals(queryStringMatch, Match.Empty))
            { 
                friendlyPath = queryStringMatch.Groups[1].Value; 
                friendlyPath = Regex.Replace(friendlyPath, defaultPageName, "", RegexOptions.IgnoreCase); 
                if (string.Compare(pageName, defaultPageName , true) != 0) //take out the end page name, it will get re-added
                    friendlyPath = Regex.Replace(friendlyPath, pageName, "", RegexOptions.IgnoreCase); 
                string queryString = queryStringMatch.Groups[2].Value.Replace("&amp;", "&"); 
                if ((queryString.StartsWith("?"))) { 
                    queryString = queryString.TrimStart('?'); 
                } 
                
                string[] nameValuePairs = queryString.Split('&'); 
                for (int i = 0; i <= nameValuePairs.Length - 1; i++) { 
                    string pathToAppend = ""; 
                    string[] pair = nameValuePairs[i].Split('='); 
                    
                    //Add name part of name/value pair 
                    if (friendlyPath.EndsWith("/"))
                        if (pair[0].ToLower() == "tabid")  //always lowercase the tabid part of the path
                            pathToAppend = pathToAppend + pair[0].ToLower(); 
                        else
                            pathToAppend = pathToAppend + pair[0]; 
                    else 
                        pathToAppend = pathToAppend + "/" + pair[0]; 
                    
                    if (pair.Length > 1)
                    { 
                        if (pair[1].Length > 0)
                        { 
                            if (Regex.IsMatch(pair[1], settings.RegexMatch) == false)
                            { 
                                // Contains Non-AlphaNumeric Characters 
                                if (pair[0].ToLower() == "tabid") 
                                {
                                    int tabId = -1;
                                    if (Int32.TryParse(pair[1], out tabId))
                                    { 
                                        if (tab != null && tab.TabID == tabId)
                                        { 
                                            if (tab.TabPath != Null.NullString && settings.IncludePageName) 
                                            {
                                                if (pathToAppend.StartsWith("/") == false)
                                                    pathToAppend = "/" + pathToAppend;
                                                pathToAppend = tab.TabPath.Replace("//", "/").TrimStart('/').TrimEnd('/') + pathToAppend; 
                                            } 
                                        } 
                                    } 
                                }
                                if (pair[1].Contains(" "))
                                {
                                    if (tab.IsSuperTab || tab.IsAdminTab || RewriteController.IsAdminTab(tab.PortalID, tab.TabPath, settings))
                                        //741 : check admin paths to make sure they aren't using + encoding 
                                        pathToAppend = pathToAppend + "/" + pair[1].Replace(" ", "%20");
                                    else
                                        pathToAppend = pathToAppend + "/" + pair[1].Replace(" ", settings.SpaceEncodingValue);  //625 : replace space with specified url encoding value 

                                }
                                else
                                    pathToAppend = pathToAppend + "/" + pair[1];                                
                                
                            } 
                            else 
                            {
                                string key = pair[0];
                                string value = pair[1];
                                //if the querystring has been decoded and has a '=' in it, the value will get split more times.  Put those back together with a loop.
                                if (pair.GetUpperBound(0) > 1)
                                {
                                    for (int j = 2; j <= pair.GetUpperBound(0); j++)
                                    {
                                        value += "=" + pair[j];
                                    }   
                                }
                                // Rewrite into URL, contains only alphanumeric and the % or space 
                                if (queryStringSpecialChars.Length == 0)
                                    queryStringSpecialChars = key + "=" + value; 
                                else 
                                    queryStringSpecialChars = queryStringSpecialChars + "&" + key + "=" + value; 
                                pathToAppend = ""; 
                            } 
                        } 
                        else 
                        { 
                            pathToAppend = pathToAppend + "/" + settings.SpaceEncodingValue; //625 : replace with specified space encoding value
                        } 
                    } 
                    
                    friendlyPath = friendlyPath + pathToAppend; 
                } 
            } 
            
            if ((queryStringSpecialChars.Length > 0)) { 
                return AddPage(friendlyPath, pageName) + "?" + queryStringSpecialChars; 
            } 
            else { 
                return AddPage(friendlyPath, pageName); 
            } 
        }
        /// <summary>
        /// Checks to see whether a url is allowed to be switched to lower case, and if so, is set to a lowercase version of itself.
        /// </summary>
        /// <param name="tab"></param>
        /// <param name="url"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal static string ForceLowerCaseIfAllowed(TabInfo tab, string url, FriendlyUrlSettings settings)
        {
            bool forceLowerCase = false;
            //606 : include regex to stop lower case in certain circumstances
            forceLowerCase = (settings.ForceLowerCase && tab != null && tab.IsAdminTab == false);
            if (forceLowerCase)
            {
                if (settings.ForceLowerCaseRegex != null && settings.ForceLowerCaseRegex != "")
                    forceLowerCase = !Regex.IsMatch(url, settings.ForceLowerCaseRegex, RegexOptions.IgnoreCase);
            }
            if (forceLowerCase)
                //don't force lower case for admin tab, some hard-coded parameters dependent on case exist 
                forceLowerCase = (!RewriteController.IsExcludedFromFriendlyUrls(tab, settings, false));

            if (forceLowerCase)
                url = url.ToLower();
            
            return url;
        }
        #endregion 
        
    }

    /// <summary>
    /// The TabPathHelper class provides helper methods for working with tab urls
    /// </summary>
    internal class SEOTabPathHelper 
    {
        /// <summary>
        /// For the supplied options, return a tab path for the specified tab
        /// </summary>
        /// <param name="tab">TabInfo object of selected tab</param>
        /// <param name="settings">FriendlyUrlSettings</param>
        /// <param name="ignoreCustomRedirects">Whether to add in the customised Tab redirects or not</param>
        /// <returns>The tab path</returns>
        internal static string GetTabPath(TabInfo tab, FriendlyUrlSettings settings, bool ignoreCustomRedirects, bool homePageSiteRoot, int portalHomeTabId)
        {
            string newTabPath;
            if (homePageSiteRoot && tab.TabID == portalHomeTabId)
            {
                newTabPath = "/"; //site root for home page
            }
            else
            {
                //build up tab path with space replacement in SEO format
                newTabPath = BuildTabPath(tab).Replace("//", "/");
            }
            return newTabPath;
        }

        public static string BuildTabPath(TabInfo tab) 
        { 
            TabInfo parenttab = null; 
            string path = ""; 
            if (tab.ParentId > -1) 
            {
                DotNetNuke.Entities.Tabs.TabController tc = new TabController();
                parenttab = tc.GetTab(tab.ParentId, tab.PortalID, false);
                path = BuildTabPath(parenttab); 
            } 
            path = AppendToTabPath(path, tab); 
            return path; 
        }

        private static string AppendToTabPath(string path, TabInfo tab)
        {
            return path + "/" + GetSEOString(tab.TabName);
        }

        /// <summary>
        /// Returns string in SEO format
        /// </summary>
        private static string GetSEOString(string str)
        {
            str = str.Normalize(System.Text.NormalizationForm.FormD);
            var sb = new System.Text.StringBuilder();

            for (int i = 0; i < str.Length; i++)
            {
                //Do �et�zce p�id� v�echny znaky krom� modifik�tor�
                if (CharUnicodeInfo.GetUnicodeCategory(str[i]) != UnicodeCategory.NonSpacingMark)
                {
                    sb.Append(str[i]);
                }
            }

            sb.Replace((char)8211, '-');
            sb.Replace(' ', '-');
            sb.Replace("\r", "");
            sb.Replace("\n", "");
            sb.Replace("\t", "-");
            sb.Replace(",", "");
            sb.Replace(":", "");
            sb.Replace("?", "");
            sb.Replace("!", "");
            sb.Replace('.', '-');
            sb.Replace(";", "");
            sb.Replace("@", "");
            sb.Replace("\"", "");
            sb.Replace("'", "");
            sb.Replace("$", "");
            sb.Replace("/", "");

            string value = System.Text.RegularExpressions.Regex.Replace(sb.ToString(), "-+", "-");

            int index;
            while ((index = value.IndexOf("--")) != -1)
            {
                value.Replace("--", "-");
            }

            return value.ToLowerInvariant();
        }
    } 
}