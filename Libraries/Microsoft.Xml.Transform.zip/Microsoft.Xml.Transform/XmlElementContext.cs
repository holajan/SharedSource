namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text.RegularExpressions;
    using System.Xml;
    using Microsoft.Xml.Transform;

    internal class XmlElementContext : XmlNodeContext
    {
        private XmlAttribute locatorAttribute;
        private static Regex nameAndArgumentsRegex;
        private XmlNamespaceManager namespaceManager;
        private XmlElementContext parentContext;
        private string parentXPath;
        private IServiceProvider serviceProvider;
        private XmlNodeList targetNodes;
        private XmlNodeList targetParents;
        private XmlAttribute transformAttribute;
        private XmlNode transformNodes;
        private XmlDocument xmlTargetDoc;
        private string xpath;

        public XmlElementContext(XmlElementContext parent, XmlElement element, XmlDocument xmlTargetDoc, IServiceProvider serviceProvider) : base(element)
        {
            this.parentContext = parent;
            this.xmlTargetDoc = xmlTargetDoc;
            this.serviceProvider = serviceProvider;
        }

        private string ConstructParentXPath()
        {
            string str3;
            try
            {
                string str;
                string parentPath = (this.parentContext == null) ? string.Empty : this.parentContext.XPath;
                str3 = this.CreateLocator(out str).ConstructParentPath(parentPath, this, str);
            }
            catch (Exception exception)
            {
                throw this.WrapException(exception);
            }
            return str3;
        }

        public Transform ConstructTransform(out string argumentString)
        {
            Transform transform;
            try
            {
                transform = this.CreateObjectFromAttribute<Transform>(out argumentString, out this.transformAttribute);
            }
            catch (Exception exception)
            {
                throw this.WrapException(exception);
            }
            return transform;
        }

        private string ConstructXPath()
        {
            string str3;
            try
            {
                string str;
                string parentPath = (this.parentContext == null) ? string.Empty : this.parentContext.XPath;
                str3 = this.CreateLocator(out str).ConstructPath(parentPath, this, str);
            }
            catch (Exception exception)
            {
                throw this.WrapException(exception);
            }
            return str3;
        }

        private XmlNode CreateCloneInTargetDocument(XmlNode sourceNode)
        {
            XmlNode node;
            XmlFileInfoDocument targetDocument = this.TargetDocument as XmlFileInfoDocument;
            if (targetDocument != null)
            {
                node = targetDocument.CloneNodeFromOtherDocument(sourceNode);
            }
            else
            {
                XmlReader reader = new XmlTextReader(new StringReader(sourceNode.OuterXml));
                node = this.TargetDocument.ReadNode(reader);
            }
            this.ScrubTransformAttributes(node);
            return node;
        }

        private Locator CreateLocator(out string argumentString)
        {
            Locator instance = this.CreateObjectFromAttribute<Locator>(out argumentString, out this.locatorAttribute);
            if (instance == null)
            {
                argumentString = null;
                instance = DefaultLocator.Instance;
            }
            return instance;
        }

        private ObjectType CreateObjectFromAttribute<ObjectType>(out string argumentString, out XmlAttribute objectAttribute) where ObjectType: class
        {
            objectAttribute = this.Element.Attributes.GetNamedItem(typeof(ObjectType).Name, XmlTransformation.TransformNamespace) as XmlAttribute;
            try
            {
                if (objectAttribute != null)
                {
                    string str = this.ParseNameAndArguments(objectAttribute.Value, out argumentString);
                    if (!string.IsNullOrEmpty(str))
                    {
                        return this.GetService<NamedTypeFactory>().Construct<ObjectType>(str);
                    }
                }
            }
            catch (Exception exception)
            {
                throw this.WrapException(exception, objectAttribute);
            }
            argumentString = null;
            return default(ObjectType);
        }

        private bool ExistedInOriginal(string xpath)
        {
            IXmlOriginalDocumentService service = this.GetService<IXmlOriginalDocumentService>();
            if (service != null)
            {
                XmlNodeList list = service.SelectNodes(xpath);
                if ((list != null) && (list.Count > 0))
                {
                    return true;
                }
            }
            return false;
        }

        private XmlNamespaceManager GetNamespaceManager()
        {
            if (this.namespaceManager == null)
            {
                XmlNodeList list = this.Element.SelectNodes("namespace::*");
                this.namespaceManager = new XmlNamespaceManager(this.Element.OwnerDocument.NameTable);
                foreach (XmlAttribute attribute in list)
                {
                    string prefix = string.Empty;
                    int index = attribute.Name.IndexOf(':');
                    if (index >= 0)
                    {
                        prefix = attribute.Name.Substring(index + 1);
                    }
                    this.namespaceManager.AddNamespace(prefix, attribute.Value);
                }
            }
            return this.namespaceManager;
        }

        public ServiceType GetService<ServiceType>() where ServiceType: class
        {
            if (this.serviceProvider != null)
            {
                return (this.serviceProvider.GetService(typeof(ServiceType)) as ServiceType);
            }
            return default(ServiceType);
        }

        private XmlNodeList GetTargetNodes(string xpath)
        {
            return this.TargetDocument.SelectNodes(xpath, this.GetNamespaceManager());
        }

        internal bool HasTargetNode(out XmlElementContext failedContext, out bool existedInOriginal)
        {
            failedContext = null;
            existedInOriginal = false;
            if (this.TargetNodes.Count != 0)
            {
                return true;
            }
            failedContext = this;
            while ((failedContext.parentContext != null) && (failedContext.parentContext.TargetNodes.Count == 0))
            {
                failedContext = failedContext.parentContext;
            }
            existedInOriginal = this.ExistedInOriginal(failedContext.XPath);
            return false;
        }

        internal bool HasTargetParent(out XmlElementContext failedContext, out bool existedInOriginal)
        {
            failedContext = null;
            existedInOriginal = false;
            if (this.TargetParents.Count != 0)
            {
                return true;
            }
            failedContext = this;
            while (((failedContext.parentContext != null) && !string.IsNullOrEmpty(failedContext.parentContext.ParentXPath)) && (failedContext.parentContext.TargetParents.Count == 0))
            {
                failedContext = failedContext.parentContext;
            }
            existedInOriginal = this.ExistedInOriginal(failedContext.XPath);
            return false;
        }

        private string ParseNameAndArguments(string name, out string arguments)
        {
            arguments = null;
            System.Text.RegularExpressions.Match match = this.NameAndArgumentsRegex.Match(name);
            if (!match.Success)
            {
                throw new XmlTransformationException("Transform and Locator attributes must contain only a type name, or a type name followed by a list of attributes in parentheses.");
            }
            if (match.Groups["arguments"].Success)
            {
                CaptureCollection captures = match.Groups["arguments"].Captures;
                if ((captures.Count == 1) && !string.IsNullOrEmpty(captures[0].Value))
                {
                    arguments = captures[0].Value;
                }
            }
            return match.Groups["name"].Captures[0].Value;
        }

        private void ScrubTransformAttributes(XmlNode node)
        {
            if (node.Attributes != null)
            {
                List<XmlAttribute> list = new List<XmlAttribute>();
                foreach (XmlAttribute attribute in node.Attributes)
                {
                    if (attribute.NamespaceURI == XmlTransformation.TransformNamespace)
                    {
                        list.Add(attribute);
                    }
                    else if (attribute.Prefix.Equals("xmlns") && attribute.Value.Equals(XmlTransformation.TransformNamespace))
                    {
                        list.Add(attribute);
                    }
                }
                foreach (XmlAttribute attribute2 in list)
                {
                    node.Attributes.Remove(attribute2);
                }
            }
            foreach (XmlNode node2 in node.ChildNodes)
            {
                this.ScrubTransformAttributes(node2);
            }
        }

        private Exception WrapException(Exception ex)
        {
            return XmlNodeException.Wrap(ex, this.Element);
        }

        private Exception WrapException(Exception ex, XmlNode node)
        {
            return XmlNodeException.Wrap(ex, node);
        }

        public XmlElement Element
        {
            get
            {
                return (base.Node as XmlElement);
            }
        }

        public XmlAttribute LocatorAttribute
        {
            get
            {
                return this.locatorAttribute;
            }
        }

        private Regex NameAndArgumentsRegex
        {
            get
            {
                if (nameAndArgumentsRegex == null)
                {
                    nameAndArgumentsRegex = new Regex(@"\A\s*(?<name>\w+)(\s*\((?<arguments>.*)\))?\s*\Z", RegexOptions.Singleline | RegexOptions.Compiled);
                }
                return nameAndArgumentsRegex;
            }
        }

        public string ParentXPath
        {
            get
            {
                if (this.parentXPath == null)
                {
                    this.parentXPath = this.ConstructParentXPath();
                }
                return this.parentXPath;
            }
        }

        private XmlDocument TargetDocument
        {
            get
            {
                return this.xmlTargetDoc;
            }
        }

        internal XmlNodeList TargetNodes
        {
            get
            {
                if (this.targetNodes == null)
                {
                    this.targetNodes = this.GetTargetNodes(this.XPath);
                }
                return this.targetNodes;
            }
        }

        internal XmlNodeList TargetParents
        {
            get
            {
                if ((this.targetParents == null) && (this.parentContext != null))
                {
                    this.targetParents = this.GetTargetNodes(this.ParentXPath);
                }
                return this.targetParents;
            }
        }

        public XmlAttribute TransformAttribute
        {
            get
            {
                return this.transformAttribute;
            }
        }

        public int TransformLineNumber
        {
            get
            {
                IXmlLineInfo transformAttribute = this.transformAttribute as IXmlLineInfo;
                if (transformAttribute != null)
                {
                    return transformAttribute.LineNumber;
                }
                return base.LineNumber;
            }
        }

        public int TransformLinePosition
        {
            get
            {
                IXmlLineInfo transformAttribute = this.transformAttribute as IXmlLineInfo;
                if (transformAttribute != null)
                {
                    return transformAttribute.LinePosition;
                }
                return base.LinePosition;
            }
        }

        internal XmlNode TransformNode
        {
            get
            {
                if (this.transformNodes == null)
                {
                    this.transformNodes = this.CreateCloneInTargetDocument(this.Element);
                }
                return this.transformNodes;
            }
        }

        public string XPath
        {
            get
            {
                if (this.xpath == null)
                {
                    this.xpath = this.ConstructXPath();
                }
                return this.xpath;
            }
        }
    }
}

