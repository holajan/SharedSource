using System;
using System.Xml;
using Microsoft.Web.Publishing.Tasks;

namespace Microsoft.Xml.Transform
{
    [Serializable]
    public class XmlTransformationException : Exception
    {
        public XmlTransformationException(string message) : base(message) { }

        public XmlTransformationException(string message, Exception innerException) : base(message, innerException) { }
    }

    [Serializable]
    public class XmlTransformationFailedException : Exception
    {
        #region member varible and default property initialization
        public string Log { get; private set; }
        #endregion

        #region constructors and destructors
        internal XmlTransformationFailedException(string message, string log)
            : base(message)
        {
            this.Log = log;
        }

        internal XmlTransformationFailedException(string message, string log, Exception innerException)
            : base(message, innerException)
        {
            this.Log = log;
        }
        #endregion
    }

    [Serializable]
    public class XmlNodeException : XmlTransformationException
    {
        private XmlFileInfoDocument document;
        private IXmlLineInfo lineInfo;

        internal XmlNodeException(Exception innerException, XmlNode node)
            : base(innerException.Message, innerException)
        {
            this.lineInfo = node as IXmlLineInfo;
            this.document = node.OwnerDocument as XmlFileInfoDocument;
        }

        internal XmlNodeException(string message, XmlNode node)
            : base(message)
        {
            this.lineInfo = node as IXmlLineInfo;
            this.document = node.OwnerDocument as XmlFileInfoDocument;
        }

        internal static Exception Wrap(Exception ex, XmlNode node)
        {
            if (ex is XmlNodeException)
            {
                return ex;
            }
            return new XmlNodeException(ex, node);
        }

        public string FileName
        {
            get
            {
                if (this.document == null)
                {
                    return null;
                }
                return this.document.FileName;
            }
        }

        public bool HasErrorInfo
        {
            get
            {
                return (this.lineInfo != null);
            }
        }

        public int LineNumber
        {
            get
            {
                if (this.lineInfo == null)
                {
                    return 0;
                }
                return this.lineInfo.LineNumber;
            }
        }

        public int LinePosition
        {
            get
            {
                if (this.lineInfo == null)
                {
                    return 0;
                }
                return this.lineInfo.LinePosition;
            }
        }
    }
}