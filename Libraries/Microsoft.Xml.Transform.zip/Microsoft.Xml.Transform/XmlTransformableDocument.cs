namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Xml;

    internal class XmlTransformableDocument : XmlFileInfoDocument, IXmlOriginalDocumentService
    {
        private XmlDocument xmlOriginal;

        private void CloneOriginalDocument()
        {
            this.xmlOriginal = (XmlDocument) this.Clone();
        }

        private bool IsXmlEqual(XmlDocument xmlOriginal, XmlDocument xmlTransformed)
        {
            return false;
        }

        XmlNodeList IXmlOriginalDocumentService.SelectNodes(string xpath)
        {
            if (this.xmlOriginal != null)
            {
                return this.xmlOriginal.SelectNodes(xpath);
            }
            return null;
        }

        internal void OnAfterChange()
        {
        }

        internal void OnBeforeChange()
        {
            if (this.xmlOriginal == null)
            {
                this.CloneOriginalDocument();
            }
        }

        public bool IsChanged
        {
            get
            {
                if (this.xmlOriginal == null)
                {
                    return false;
                }
                return !this.IsXmlEqual(this.xmlOriginal, this);
            }
        }
    }
}

