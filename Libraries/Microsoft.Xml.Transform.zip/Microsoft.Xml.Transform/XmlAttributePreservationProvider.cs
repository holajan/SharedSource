namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.IO;
    using System.Text;

    internal class XmlAttributePreservationProvider : IDisposable
    {
        private PositionTrackingTextReader reader;

        public XmlAttributePreservationProvider(string fileName)
        {
            this.reader = new PositionTrackingTextReader(new StreamReader(File.OpenRead(fileName)));
        }

        public XmlAttributePreservationDict GetDictAtPosition(int lineNumber, int linePosition)
        {
            if (this.reader.ReadToPosition(lineNumber, linePosition))
            {
                int num;
                StringBuilder builder = new StringBuilder();
                do
                {
                    num = this.reader.Read();
                    builder.Append((char)num);
                }
                while ((num > 0) && (((ushort)num) != 0x3e));
                if (num > 0)
                {
                    XmlAttributePreservationDict dict = new XmlAttributePreservationDict();
                    dict.ReadPreservationInfo(builder.ToString());
                    return dict;
                }
            }
            return null;
        }

        public void Dispose()
        {
            this.reader.Close();
        }
    }
}