namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Collections.Generic;
    using System.Xml;
    using Microsoft.Xml.Transform;

    internal enum XPathAxis
    {
        Child,
        Descendant,
        Parent,
        Ancestor,
        FollowingSibling,
        PrecedingSibling,
        Following,
        Preceding,
        Self,
        DescendantOrSelf,
        AncestorOrSelf
    }

    internal abstract class Locator
    {
        private IList<string> arguments;
        private string argumentString;
        private XmlElementContext context;
        private XmlTransformationLogger logger;
        private string parentPath;

        protected Locator()
        {
        }

        protected string AppendStep(string basePath, string stepNodeTest)
        {
            return this.AppendStep(basePath, XPathAxis.Child, stepNodeTest, string.Empty);
        }

        protected string AppendStep(string basePath, XPathAxis stepAxis, string stepNodeTest)
        {
            return this.AppendStep(basePath, stepAxis, stepNodeTest, string.Empty);
        }

        protected string AppendStep(string basePath, string stepNodeTest, string predicate)
        {
            return this.AppendStep(basePath, XPathAxis.Child, stepNodeTest, predicate);
        }

        protected string AppendStep(string basePath, XPathAxis stepAxis, string stepNodeTest, string predicate)
        {
            return (this.EnsureTrailingSlash(basePath) + this.GetAxisString(stepAxis) + stepNodeTest + this.EnsureBracketedPredicate(predicate));
        }

        internal string ConstructParentPath(string parentPath, XmlElementContext context, string argumentString)
        {
            string str = string.Empty;
            if (((this.parentPath == null) && (this.context == null)) && (this.argumentString == null))
            {
                try
                {
                    this.parentPath = parentPath;
                    this.context = context;
                    this.argumentString = argumentString;
                    str = this.ParentPath;
                }
                finally
                {
                    this.parentPath = null;
                    this.context = null;
                    this.argumentString = null;
                    this.arguments = null;
                    this.ReleaseLogger();
                }
            }
            return str;
        }

        protected virtual string ConstructPath()
        {
            return this.AppendStep(this.ParentPath, this.NextStepAxis, this.NextStepNodeTest, this.ConstructPredicate());
        }

        internal string ConstructPath(string parentPath, XmlElementContext context, string argumentString)
        {
            string str = string.Empty;
            if (((this.parentPath == null) && (this.context == null)) && (this.argumentString == null))
            {
                try
                {
                    this.parentPath = parentPath;
                    this.context = context;
                    this.argumentString = argumentString;
                    str = this.ConstructPath();
                }
                finally
                {
                    this.parentPath = null;
                    this.context = null;
                    this.argumentString = null;
                    this.arguments = null;
                    this.ReleaseLogger();
                }
            }
            return str;
        }

        protected virtual string ConstructPredicate()
        {
            return string.Empty;
        }

        protected void EnsureArguments()
        {
            this.EnsureArguments(1);
        }

        protected void EnsureArguments(int min)
        {
            if ((this.Arguments == null) || (this.Arguments.Count < min))
            {
                throw new XmlTransformationException(string.Format("{0} requires at least {1} arguments", new object[] { base.GetType().Name, min }));
            }
        }

        protected void EnsureArguments(int min, int max)
        {
            if ((min == max) && ((this.Arguments == null) || (this.Arguments.Count != min)))
            {
                throw new XmlTransformationException(string.Format("{0} requires exactly {1} arguments", new object[] { base.GetType().Name, min }));
            }
            this.EnsureArguments(min);
            if (this.Arguments.Count > max)
            {
                throw new XmlTransformationException(string.Format("Too many arguments for {0}", new object[] { base.GetType().Name }));
            }
        }

        private string EnsureBracketedPredicate(string predicate)
        {
            if (string.IsNullOrEmpty(predicate))
            {
                return string.Empty;
            }
            if (!predicate.StartsWith("[", StringComparison.Ordinal))
            {
                predicate = "[" + predicate;
            }
            if (!predicate.EndsWith("]", StringComparison.Ordinal))
            {
                predicate = predicate + "]";
            }
            return predicate;
        }

        private string EnsureTrailingSlash(string basePath)
        {
            if (!basePath.EndsWith("/", StringComparison.Ordinal))
            {
                basePath = basePath + "/";
            }
            return basePath;
        }

        private string GetAxisString(XPathAxis stepAxis)
        {
            switch (stepAxis)
            {
                case XPathAxis.Child:
                    return string.Empty;

                case XPathAxis.Descendant:
                    return "descendant::";

                case XPathAxis.Parent:
                    return "parent::";

                case XPathAxis.Ancestor:
                    return "ancestor::";

                case XPathAxis.FollowingSibling:
                    return "following-sibling::";

                case XPathAxis.PrecedingSibling:
                    return "preceding-sibling::";

                case XPathAxis.Following:
                    return "following::";

                case XPathAxis.Preceding:
                    return "preceding::";

                case XPathAxis.Self:
                    return "self::";

                case XPathAxis.DescendantOrSelf:
                    return "/";

                case XPathAxis.AncestorOrSelf:
                    return "ancestor-or-self::";
            }
            return string.Empty;
        }

        private void ReleaseLogger()
        {
            if (this.logger != null)
            {
                this.logger.CurrentReferenceNode = null;
                this.logger = null;
            }
        }

        protected IList<string> Arguments
        {
            get
            {
                if ((this.arguments == null) && (this.argumentString != null))
                {
                    this.arguments = XmlArgumentUtility.SplitArguments(this.argumentString);
                }
                return this.arguments;
            }
        }

        protected string ArgumentString
        {
            get
            {
                return this.argumentString;
            }
        }

        protected XmlNode CurrentElement
        {
            get
            {
                return this.context.Element;
            }
        }

        protected XmlTransformationLogger Log
        {
            get
            {
                if (this.logger == null)
                {
                    this.logger = this.context.GetService<XmlTransformationLogger>();
                    if (this.logger != null)
                    {
                        this.logger.CurrentReferenceNode = this.context.LocatorAttribute;
                    }
                }
                return this.logger;
            }
        }

        protected virtual XPathAxis NextStepAxis
        {
            get
            {
                return XPathAxis.Child;
            }
        }

        protected virtual string NextStepNodeTest
        {
            get
            {
                return this.CurrentElement.Name;
            }
        }

        protected virtual string ParentPath
        {
            get
            {
                return this.parentPath;
            }
        }
    }
}

