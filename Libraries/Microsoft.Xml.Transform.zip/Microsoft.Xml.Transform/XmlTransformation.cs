namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.ComponentModel.Design;
    using System.Xml;
    using Microsoft.Xml.Transform;

    internal class XmlTransformation : IServiceProvider
    {
        private ServiceContainer documentServiceContainer;
        private bool hasTransformNamespace;
        private XmlTransformationLogger logger;
        private NamedTypeFactory namedTypeFactory;
        internal static readonly string SupressWarnings = "SupressWarnings";
        private ServiceContainer transformationServiceContainer;
        private string transformFile;
        internal static readonly string TransformNamespace = "http://schemas.microsoft.com/XML-Document-Transform";
        private XmlDocument xmlTarget;
        private XmlTransformableDocument xmlTransformable;
        private XmlDocument xmlTransformation;

        public XmlTransformation(string transform, bool isTransformAFile, IXmlTransformationLogger logger)
        {
            this.transformationServiceContainer = new ServiceContainer();
            this.transformFile = transform;
            this.logger = new XmlTransformationLogger(logger);
            this.xmlTransformation = new XmlFileInfoDocument();
            if (isTransformAFile)
            {
                this.xmlTransformation.Load(transform);
            }
            else
            {
                this.xmlTransformation.LoadXml(transform);
            }
            this.InitializeTransformationServices();
            this.PreprocessTransformDocument();
        }

        public XmlTransformation(string transformName, System.IO.Stream transform, IXmlTransformationLogger logger)
        {
            this.transformationServiceContainer = new ServiceContainer();
            this.transformFile = transformName;
            this.logger = new XmlTransformationLogger(logger);
            this.xmlTransformation = new XmlFileInfoDocument();
            this.xmlTransformation.Load(transform);
            this.InitializeTransformationServices();
            this.PreprocessTransformDocument();
        }

        public XmlTransformation(string transformName, System.IO.TextReader transform, IXmlTransformationLogger logger)
        {
            this.transformationServiceContainer = new ServiceContainer();
            this.transformFile = transformName;
            this.logger = new XmlTransformationLogger(logger);
            this.xmlTransformation = new XmlFileInfoDocument();
            this.xmlTransformation.Load(transform);
            this.InitializeTransformationServices();
            this.PreprocessTransformDocument();
        }

        public void AddTransformationService(Type serviceType, object serviceInstance)
        {
            this.transformationServiceContainer.AddService(serviceType, serviceInstance);
        }

        public bool Apply(XmlDocument xmlTarget)
        {
            if (this.xmlTarget != null)
            {
                return false;
            }
            this.logger.HasLoggedErrors = false;
            this.xmlTarget = xmlTarget;
            this.xmlTransformable = xmlTarget as XmlTransformableDocument;
            try
            {
                if (this.hasTransformNamespace)
                {
                    this.InitializeDocumentServices(xmlTarget);
                    this.TransformLoop(this.xmlTransformation);
                }
                else
                {
                    this.logger.LogMessage(MessageType.Normal, "The expected namespace {0} was not found in the transform file", new object[] { TransformNamespace });
                }
            }
            catch (Exception exception)
            {
                this.HandleException(exception);
            }
            finally
            {
                this.ReleaseDocumentServices();
                this.xmlTarget = null;
                this.xmlTransformable = null;
            }
            return !this.logger.HasLoggedErrors;
        }

        private XmlElementContext CreateElementContext(XmlElementContext parentContext, XmlElement element)
        {
            return new XmlElementContext(parentContext, element, this.xmlTarget, this);
        }

        public object GetService(Type serviceType)
        {
            object service = null;
            if (this.documentServiceContainer != null)
            {
                service = this.documentServiceContainer.GetService(serviceType);
            }
            if (service == null)
            {
                service = this.transformationServiceContainer.GetService(serviceType);
            }
            return service;
        }

        private void HandleElement(XmlElementContext context)
        {
            string str;
            Transform transform = context.ConstructTransform(out str);
            if (transform != null)
            {
                bool supressWarnings = this.logger.SupressWarnings;
                XmlAttribute namedItem = context.Element.Attributes.GetNamedItem(SupressWarnings, TransformNamespace) as XmlAttribute;
                if (namedItem != null)
                {
                    bool flag2 = Convert.ToBoolean(namedItem.Value);
                    this.logger.SupressWarnings = flag2;
                }
                try
                {
                    this.OnApplyingTransform();
                    transform.Execute(context, str);
                    this.OnAppliedTransform();
                }
                catch (Exception exception)
                {
                    this.HandleException(exception, context);
                }
                finally
                {
                    this.logger.SupressWarnings = supressWarnings;
                }
            }
            this.TransformLoop(context);
        }

        private void HandleException(Exception ex)
        {
            this.logger.LogErrorFromException(ex);
        }

        private void HandleException(Exception ex, XmlNodeContext context)
        {
            this.HandleException(this.WrapException(ex, context));
        }

        private void InitializeDocumentServices(XmlDocument document)
        {
            this.documentServiceContainer = new ServiceContainer();
            if (document is IXmlOriginalDocumentService)
            {
                this.documentServiceContainer.AddService(typeof(IXmlOriginalDocumentService), document);
            }
        }

        private void InitializeTransformationServices()
        {
            this.namedTypeFactory = new NamedTypeFactory(this.transformFile);
            this.transformationServiceContainer.AddService(this.namedTypeFactory.GetType(), this.namedTypeFactory);
            this.transformationServiceContainer.AddService(this.logger.GetType(), this.logger);
        }

        private void OnAppliedTransform()
        {
            if (this.xmlTransformable != null)
            {
                this.xmlTransformable.OnAfterChange();
            }
        }

        private void OnApplyingTransform()
        {
            if (this.xmlTransformable != null)
            {
                this.xmlTransformable.OnBeforeChange();
            }
        }

        private void PreprocessImportElement(XmlElementContext context)
        {
            string assemblyName = null;
            string nameSpace = null;
            string path = null;
            foreach (XmlAttribute attribute in context.Element.Attributes)
            {
                string str4;
                if ((attribute.NamespaceURI.Length != 0) || ((str4 = attribute.Name) == null))
                {
                    goto Label_0089;
                }
                if (!(str4 == "assembly"))
                {
                    if (str4 == "namespace")
                    {
                        goto Label_0077;
                    }
                    if (str4 == "path")
                    {
                        goto Label_0080;
                    }
                    goto Label_0089;
                }
                assemblyName = attribute.Value;
                continue;
            Label_0077:
                nameSpace = attribute.Value;
                continue;
            Label_0080:
                path = attribute.Value;
                continue;
            Label_0089: ;
                throw new XmlNodeException(string.Format("Import tag does not support '{0}' attribute", new object[] { attribute.Name }), attribute);
            }
            if ((assemblyName != null) && (path != null))
            {
                throw new XmlNodeException("Import tag cannot have both a 'path' and an 'assembly'", context.Element);
            }
            if ((assemblyName == null) && (path == null))
            {
                throw new XmlNodeException("Import tag must have a 'path' or an 'assembly'", context.Element);
            }
            if (nameSpace == null)
            {
                throw new XmlNodeException("Import tag must have a 'namespace'", context.Element);
            }
            if (assemblyName != null)
            {
                this.namedTypeFactory.AddAssemblyRegistration(assemblyName, nameSpace);
            }
            else
            {
                this.namedTypeFactory.AddPathRegistration(path, nameSpace);
            }
        }

        private void PreprocessTransformDocument()
        {
            this.hasTransformNamespace = false;
            foreach (XmlAttribute attribute in this.xmlTransformation.SelectNodes("//namespace::*"))
            {
                if (attribute.Value.Equals(TransformNamespace, StringComparison.Ordinal))
                {
                    this.hasTransformNamespace = true;
                    break;
                }
            }
            if (this.hasTransformNamespace)
            {
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(new NameTable());
                nsmgr.AddNamespace("xdt", TransformNamespace);
                foreach (XmlNode node in this.xmlTransformation.SelectNodes("//xdt:*", nsmgr))
                {
                    XmlElement element = node as XmlElement;
                    if (element != null)
                    {
                        XmlElementContext context = null;
                        try
                        {
                            try
                            {
                                string str;
                                if (((str = element.LocalName) != null) && (str == "Import"))
                                {
                                    context = this.CreateElementContext(null, element);
                                    this.PreprocessImportElement(context);
                                }
                                else
                                {
                                    this.logger.LogWarning(element, "Unknown tag '{0}'", new object[] { element.Name });
                                }
                            }
                            catch (Exception exception)
                            {
                                if (context != null)
                                {
                                    exception = this.WrapException(exception, context);
                                }
                                this.logger.LogErrorFromException(exception);
                                throw new XmlTransformationException("Fatal syntax error", exception);
                            }
                            continue;
                        }
                        finally
                        {
                            context = null;
                        }
                    }
                }
            }
        }

        private void ReleaseDocumentServices()
        {
            if (this.documentServiceContainer != null)
            {
                this.documentServiceContainer.RemoveService(typeof(IXmlOriginalDocumentService));
                this.documentServiceContainer = null;
            }
        }

        public void RemoveTransformationService(Type serviceType)
        {
            this.transformationServiceContainer.RemoveService(serviceType);
        }

        private void TransformLoop(XmlNodeContext parentContext)
        {
            foreach (XmlNode node in parentContext.Node.ChildNodes)
            {
                XmlElement element = node as XmlElement;
                if (element != null)
                {
                    XmlElementContext context = this.CreateElementContext(parentContext as XmlElementContext, element);
                    try
                    {
                        this.HandleElement(context);
                        continue;
                    }
                    catch (Exception exception)
                    {
                        this.HandleException(exception, context);
                        continue;
                    }
                }
            }
        }

        private void TransformLoop(XmlDocument xmlSource)
        {
            this.TransformLoop(new XmlNodeContext(xmlSource));
        }

        private Exception WrapException(Exception ex, XmlNodeContext context)
        {
            return XmlNodeException.Wrap(ex, context.Node);
        }
    }
}