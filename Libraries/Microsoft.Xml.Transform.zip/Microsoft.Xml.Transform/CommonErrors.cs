namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Xml;

    internal static class CommonErrors
    {
        internal static void ExpectNoArguments(XmlTransformationLogger log, string transformName, string argumentString)
        {
            if (!string.IsNullOrEmpty(argumentString))
            {
                log.LogWarning("{0} does not expect arguments; ignoring", new object[] { transformName });
            }
        }

        internal static void WarnIfMultipleTargets(XmlTransformationLogger log, string transformName, XmlNodeList targetNodes, bool applyTransformToAllTargets)
        {
            if (targetNodes.Count > 1)
            {
                log.LogWarning("Found multiple target elements, but the '{0}' Transform only applies to the first match", new object[] { transformName });
            }
        }
    }
}

