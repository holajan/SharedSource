namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Collections.Generic;
    using System.Xml;

    internal class XmlFormatter
    {
        private LinkedList<string> attributeIndents = new LinkedList<string>();
        private string currentAttributeIndent;
        private string currentIndent = string.Empty;
        private XmlNode currentNode;
        private string defaultTab = "\t";
        private XmlFileInfoDocument document;
        private LinkedList<string> indents = new LinkedList<string>();
        private string oneTab;
        private string originalFileName;
        private XmlNode previousNode;

        private XmlFormatter(XmlFileInfoDocument document)
        {
            this.document = document;
            this.originalFileName = document.FileName;
        }

        private string ComputeCurrentAttributeIndent()
        {
            string str = this.LookForSiblingIndent(this.CurrentNode);
            if (str != null)
            {
                return str;
            }
            return (this.CurrentIndent + this.OneTab);
        }

        private string ComputeCurrentIndent()
        {
            string str = this.LookAheadForIndent();
            if (str != null)
            {
                return str;
            }
            return (this.PreviousIndent + this.OneTab);
        }

        private string ComputeOneTab()
        {
            if (this.indents.Count < 0)
            {
                return this.DefaultTab;
            }
            LinkedListNode<string> last = this.indents.Last;
            for (LinkedListNode<string> node2 = last.Previous; node2 != null; node2 = last.Previous)
            {
                if (last.Value.StartsWith(node2.Value, StringComparison.Ordinal))
                {
                    return last.Value.Substring(node2.Value.Length);
                }
                last = node2;
            }
            return this.ConvertIndentToTab(last.Value);
        }

        private string ConvertIndentToTab(string indent)
        {
            for (int i = 0; i < (indent.Length - 1); i++)
            {
                char ch = indent[i];
                if ((ch != '\n') && (ch != '\r'))
                {
                    return indent.Substring(i + 1);
                }
            }
            return this.DefaultTab;
        }

        private int EnsureNodeIndent(XmlNode node, bool indentBeforeEnd)
        {
            int num = 0;
            if (!this.NeedsIndent(node, this.PreviousNode))
            {
                return num;
            }
            if (indentBeforeEnd)
            {
                this.InsertIndentBeforeEnd(node);
                return num;
            }
            this.InsertIndentBefore(node);
            return 1;
        }

        private int FindLastNewLine(string whitespace)
        {
            for (int i = whitespace.Length - 1; i >= 0; i--)
            {
                switch (whitespace[i])
                {
                    case '\t':
                    case ' ':
                    {
                        continue;
                    }
                    case '\n':
                        if ((i <= 0) || (whitespace[i - 1] != '\r'))
                        {
                            return i;
                        }
                        return (i - 1);

                    case '\r':
                        return i;
                }
                return -1;
            }
            return -1;
        }

        public static void Format(XmlDocument document)
        {
            XmlFileInfoDocument parentNode = document as XmlFileInfoDocument;
            if (parentNode != null)
            {
                new XmlFormatter(parentNode).FormatLoop(parentNode);
            }
        }

        private void FormatAttributes(XmlNode node)
        {
            IXmlFormattableAttributes attributes = node as IXmlFormattableAttributes;
            if (attributes != null)
            {
                attributes.FormatAttributes(this);
            }
        }

        private void FormatLoop(XmlNode parentNode)
        {
            for (int i = 0; i < parentNode.ChildNodes.Count; i++)
            {
                XmlNode node = parentNode.ChildNodes[i];
                this.CurrentNode = node;
                switch (node.NodeType)
                {
                    case XmlNodeType.Element:
                        i += this.HandleElement(node);
                        break;

                    case XmlNodeType.Entity:
                    case XmlNodeType.Comment:
                        i += this.EnsureNodeIndent(node, false);
                        break;

                    case XmlNodeType.Whitespace:
                        i += this.HandleWhiteSpace(node);
                        break;
                }
            }
        }

        private string GetIndentFromWhiteSpace(XmlNode node)
        {
            string outerXml = node.OuterXml;
            int startIndex = this.FindLastNewLine(outerXml);
            if (startIndex >= 0)
            {
                return outerXml.Substring(startIndex);
            }
            return null;
        }

        private int HandleElement(XmlNode node)
        {
            int num = this.HandleStartElement(node);
            this.ReorderNewItemsAtEnd(node);
            this.FormatLoop(node);
            this.CurrentNode = node;
            return (num + this.HandleEndElement(node));
        }

        private int HandleEndElement(XmlNode node)
        {
            int num = 0;
            this.PopIndent();
            if (!((XmlElement) node).IsEmpty)
            {
                num = this.EnsureNodeIndent(node, true);
            }
            return num;
        }

        private int HandleStartElement(XmlNode node)
        {
            int num = this.EnsureNodeIndent(node, false);
            this.FormatAttributes(node);
            this.PushIndent();
            return num;
        }

        private int HandleWhiteSpace(XmlNode node)
        {
            int num = 0;
            if (this.IsWhiteSpace(this.PreviousNode))
            {
                XmlNode previousNode = this.PreviousNode;
                if ((this.FindLastNewLine(node.OuterXml) < 0) && (this.FindLastNewLine(this.PreviousNode.OuterXml) >= 0))
                {
                    previousNode = node;
                }
                previousNode.ParentNode.RemoveChild(previousNode);
                num = -1;
            }
            string indentFromWhiteSpace = this.GetIndentFromWhiteSpace(node);
            if (indentFromWhiteSpace != null)
            {
                this.SetIndent(indentFromWhiteSpace);
            }
            return num;
        }

        private void InsertIndentBefore(XmlNode node)
        {
            node.ParentNode.InsertBefore(this.document.CreateWhitespace(this.CurrentIndent), node);
        }

        private void InsertIndentBeforeEnd(XmlNode node)
        {
            node.AppendChild(this.document.CreateWhitespace(this.CurrentIndent));
        }

        private bool IsNewNode(XmlNode node)
        {
            return ((node != null) && this.document.IsNewNode(node));
        }

        private bool IsText(XmlNode node)
        {
            return ((node != null) && (node.NodeType == XmlNodeType.Text));
        }

        private bool IsWhiteSpace(XmlNode node)
        {
            return ((node != null) && (node.NodeType == XmlNodeType.Whitespace));
        }

        private string LookAheadForIndent()
        {
            if (this.currentNode.ParentNode != null)
            {
                foreach (XmlNode node in this.currentNode.ParentNode.ChildNodes)
                {
                    if (this.IsWhiteSpace(node) && (node.NextSibling != null))
                    {
                        string outerXml = node.OuterXml;
                        int startIndex = this.FindLastNewLine(outerXml);
                        if (startIndex >= 0)
                        {
                            return outerXml.Substring(startIndex);
                        }
                    }
                }
            }
            return null;
        }

        private string LookForSiblingIndent(XmlNode currentNode)
        {
            bool flag = true;
            string attributeIndent = null;
            foreach (XmlNode node in currentNode.ParentNode.ChildNodes)
            {
                if (node == currentNode)
                {
                    flag = false;
                }
                else
                {
                    IXmlFormattableAttributes attributes = node as IXmlFormattableAttributes;
                    if (attributes != null)
                    {
                        attributeIndent = attributes.AttributeIndent;
                    }
                }
                if (!flag && (attributeIndent != null))
                {
                    return attributeIndent;
                }
            }
            return null;
        }

        private bool NeedsIndent(XmlNode node, XmlNode previousNode)
        {
            if (this.IsWhiteSpace(previousNode) || this.IsText(previousNode))
            {
                return false;
            }
            if (!this.IsNewNode(node))
            {
                return this.IsNewNode(previousNode);
            }
            return true;
        }

        private void PopIndent()
        {
            if (this.indents.Count <= 0)
            {
                throw new InvalidOperationException();
            }
            this.currentIndent = this.indents.Last.Value;
            this.indents.RemoveLast();
            this.currentAttributeIndent = this.attributeIndents.Last.Value;
            this.attributeIndents.RemoveLast();
        }

        private void PushIndent()
        {
            this.indents.AddLast(new LinkedListNode<string>(this.CurrentIndent));
            this.currentIndent = null;
            this.attributeIndents.AddLast(new LinkedListNode<string>(this.currentAttributeIndent));
            this.currentAttributeIndent = null;
        }

        private void ReorderNewItemsAtEnd(XmlNode node)
        {
            if (!this.IsNewNode(node))
            {
                XmlNode lastChild = node.LastChild;
                if ((lastChild != null) && (lastChild.NodeType != XmlNodeType.Whitespace))
                {
                    XmlNode oldChild = null;
                    while (lastChild != null)
                    {
                        XmlNodeType nodeType = lastChild.NodeType;
                        if (nodeType != XmlNodeType.Element)
                        {
                            if (nodeType == XmlNodeType.Whitespace)
                            {
                                oldChild = lastChild;
                            }
                            break;
                        }
                        if (!this.IsNewNode(lastChild))
                        {
                            break;
                        }
                        lastChild = lastChild.PreviousSibling;
                    }
                    if (oldChild != null)
                    {
                        node.RemoveChild(oldChild);
                        node.AppendChild(oldChild);
                    }
                }
            }
        }

        private void SetIndent(string indent)
        {
            if ((this.currentIndent == null) || !this.currentIndent.Equals(indent))
            {
                this.currentIndent = indent;
                this.oneTab = null;
                this.currentAttributeIndent = null;
            }
        }

        public string CurrentAttributeIndent
        {
            get
            {
                if (this.currentAttributeIndent == null)
                {
                    this.currentAttributeIndent = this.ComputeCurrentAttributeIndent();
                }
                return this.currentAttributeIndent;
            }
        }

        private string CurrentIndent
        {
            get
            {
                if (this.currentIndent == null)
                {
                    this.currentIndent = this.ComputeCurrentIndent();
                }
                return this.currentIndent;
            }
        }

        private XmlNode CurrentNode
        {
            get
            {
                return this.currentNode;
            }
            set
            {
                this.previousNode = this.currentNode;
                this.currentNode = value;
            }
        }

        public string DefaultTab
        {
            get
            {
                return this.defaultTab;
            }
            set
            {
                this.defaultTab = value;
            }
        }

        private string OneTab
        {
            get
            {
                if (this.oneTab == null)
                {
                    this.oneTab = this.ComputeOneTab();
                }
                return this.oneTab;
            }
        }

        private string PreviousIndent
        {
            get
            {
                return this.indents.Last.Value;
            }
        }

        private XmlNode PreviousNode
        {
            get
            {
                return this.previousNode;
            }
        }
    }
}

