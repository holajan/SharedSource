namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using Microsoft.Xml.Transform;

    internal class NamedTypeFactory
    {
        private List<Registration> registrations = new List<Registration>();
        private string relativePathRoot;

        internal NamedTypeFactory(string relativePathRoot)
        {
            this.relativePathRoot = relativePathRoot;
            this.CreateDefaultRegistrations();
        }

        internal void AddAssemblyRegistration(Assembly assembly, string nameSpace)
        {
            this.registrations.Add(new Registration(assembly, nameSpace));
        }

        internal void AddAssemblyRegistration(string assemblyName, string nameSpace)
        {
            this.registrations.Add(new AssemblyNameRegistration(assemblyName, nameSpace));
        }

        internal void AddPathRegistration(string path, string nameSpace)
        {
            if (!Path.IsPathRooted(path))
            {
                path = Path.Combine(Path.GetDirectoryName(this.relativePathRoot), path);
            }
            this.registrations.Add(new PathRegistration(path, nameSpace));
        }

        internal ObjectType Construct<ObjectType>(string typeName) where ObjectType: class
        {
            if (string.IsNullOrEmpty(typeName))
            {
                return default(ObjectType);
            }
            Type type = this.GetType(typeName);
            if (type == null)
            {
                throw new XmlTransformationException(string.Format("Could not resolve '{0}' as a type of {1}", new object[] { typeName, typeof(ObjectType).Name }));
            }
            if (!type.IsSubclassOf(typeof(ObjectType)))
            {
                throw new XmlTransformationException(string.Format("'{0}' is not a type of {1}", new object[] { type.FullName, typeof(ObjectType).Name }));
            }
            ConstructorInfo constructor = type.GetConstructor(Type.EmptyTypes);
            if (constructor == null)
            {
                throw new XmlTransformationException(string.Format("Type '{0}' must have a no-argument constructor to be instantiated by the transformation engine", new object[] { type.FullName }));
            }
            return (constructor.Invoke(new object[0]) as ObjectType);
        }

        private void CreateDefaultRegistrations()
        {
            this.AddAssemblyRegistration(base.GetType().Assembly, base.GetType().Namespace);
        }

        private Type GetType(string typeName)
        {
            Type type = null;
            foreach (Registration registration in this.registrations)
            {
                if (registration.IsValid)
                {
                    Type type2 = registration.Assembly.GetType(registration.NameSpace + "." + typeName);
                    if (type2 != null)
                    {
                        if (type != null)
                        {
                            throw new XmlTransformationException(string.Format("Type '{0}' was found in more than one assembly", new object[] { typeName }));
                        }
                        type = type2;
                    }
                }
            }
            return type;
        }

        private class AssemblyNameRegistration : NamedTypeFactory.Registration
        {
            public AssemblyNameRegistration(string assemblyName, string nameSpace) : base(Assembly.Load(assemblyName), nameSpace)
            {
            }
        }

        private class PathRegistration : NamedTypeFactory.Registration
        {
            public PathRegistration(string path, string nameSpace) : base(Assembly.LoadFile(path), nameSpace)
            {
            }
        }

        private class Registration
        {
            private System.Reflection.Assembly assembly;
            private string nameSpace;

            public Registration(System.Reflection.Assembly assembly, string nameSpace)
            {
                this.assembly = assembly;
                this.nameSpace = nameSpace;
            }

            public System.Reflection.Assembly Assembly
            {
                get
                {
                    return this.assembly;
                }
            }

            public bool IsValid
            {
                get
                {
                    return (this.assembly != null);
                }
            }

            public string NameSpace
            {
                get
                {
                    return this.nameSpace;
                }
            }
        }
    }
}

