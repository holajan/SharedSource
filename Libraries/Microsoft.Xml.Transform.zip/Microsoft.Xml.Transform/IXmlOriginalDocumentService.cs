namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Xml;

    internal interface IXmlOriginalDocumentService
    {
        XmlNodeList SelectNodes(string path);
    }
}

