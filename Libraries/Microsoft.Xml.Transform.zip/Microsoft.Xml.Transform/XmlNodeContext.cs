namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Xml;

    internal class XmlNodeContext
    {
        private XmlNode node;

        public XmlNodeContext(XmlNode node)
        {
            this.node = node;
        }

        public bool HasLineInfo
        {
            get
            {
                return (this.node is IXmlLineInfo);
            }
        }

        public int LineNumber
        {
            get
            {
                IXmlLineInfo node = this.node as IXmlLineInfo;
                if (node != null)
                {
                    return node.LineNumber;
                }
                return 0;
            }
        }

        public int LinePosition
        {
            get
            {
                IXmlLineInfo node = this.node as IXmlLineInfo;
                if (node != null)
                {
                    return node.LinePosition;
                }
                return 0;
            }
        }

        public XmlNode Node
        {
            get
            {
                return this.node;
            }
        }
    }
}

