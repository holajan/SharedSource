namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Xml;

    internal class SetAttributes : AttributeTransform
    {
        protected override void Apply()
        {
            foreach (XmlAttribute attribute in base.TransformAttributes)
            {
                XmlAttribute namedItem = base.TargetNode.Attributes.GetNamedItem(attribute.Name) as XmlAttribute;
                if (namedItem != null)
                {
                    namedItem.Value = attribute.Value;
                }
                else
                {
                    base.TargetNode.Attributes.Append((XmlAttribute) attribute.Clone());
                }
                base.Log.LogMessage(MessageType.Verbose, "Set '{0}' attribute", new object[] { attribute.Name });
            }
            if (base.TransformAttributes.Count > 0)
            {
                base.Log.LogMessage(MessageType.Verbose, "Set {0} attributes", new object[] { base.TransformAttributes.Count });
            }
            else
            {
                base.Log.LogWarning("No attributes found to set", new object[0]);
            }
        }
    }
}

