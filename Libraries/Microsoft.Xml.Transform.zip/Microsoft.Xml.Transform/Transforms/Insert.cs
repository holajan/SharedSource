namespace Microsoft.Web.Publishing.Tasks
{
    using System;

    internal class Insert : Transform
    {
        public Insert() : base(TransformFlags.UseParentAsTargetNode, MissingTargetMessage.Error)
        {
        }

        protected override void Apply()
        {
            CommonErrors.ExpectNoArguments(base.Log, base.TransformNameShort, base.ArgumentString);
            base.TargetNode.AppendChild(base.TransformNode);
            base.Log.LogMessage(MessageType.Verbose, "Inserted '{0}' element", new object[] { base.TransformNode.Name });
        }
    }
}

