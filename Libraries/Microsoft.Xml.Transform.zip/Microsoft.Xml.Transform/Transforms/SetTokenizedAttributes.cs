namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Xml;
    using Microsoft.Xml.Transform;

    internal class SetTokenizedAttributes : AttributeTransform
    {
        //private bool fInitStorageDictionary;
        public static readonly string ParameterAttribute = "Parameter";
        private static Regex s_dirRegex = null;
        private static Regex s_parentAttribRegex = null;
        private static Regex s_tokenFormatRegex = null;
        //private SetTokenizedAttributeStorage storageDictionary;
        public static readonly string Token = "Token";
        private XmlAttribute tokenizeValueCurrentXmlAttribute;
        public static readonly string TokenNumber = "TokenNumber";
        public static readonly string XpathLocator = "XpathLocator";
        public static readonly string XPathWithIndex = "XPathWithIndex";
        public static readonly string XPathWithLocator = "XPathWithLocator";

        protected override void Apply()
        {
            //bool fTokenizeParameter = false;
            //SetTokenizedAttributeStorage transformStorage = this.TransformStorage;
            //List<Dictionary<string, string>> parameters = null;
            //if (transformStorage != null)
            //{
            //    fTokenizeParameter = transformStorage.EnableTokenizeParameters;
            //    if (fTokenizeParameter)
            //    {
            //        parameters = transformStorage.DictionaryList;
            //    }
            //}
            foreach (XmlAttribute attribute in base.TransformAttributes)
            {
                XmlAttribute namedItem = base.TargetNode.Attributes.GetNamedItem(attribute.Name) as XmlAttribute;
                string str = this.TokenizeValue(namedItem, attribute); //fTokenizeParameter, parameters);
                if (namedItem != null)
                {
                    namedItem.Value = str;
                }
                else
                {
                    XmlAttribute node = (XmlAttribute) attribute.Clone();
                    node.Value = str;
                    base.TargetNode.Attributes.Append(node);
                }
                base.Log.LogMessage(MessageType.Verbose, "Set '{0}' attribute", new object[] { attribute.Name });
            }
            if (base.TransformAttributes.Count > 0)
            {
                base.Log.LogMessage(MessageType.Verbose, "Set {0} attributes", new object[] { base.TransformAttributes.Count });
            }
            else
            {
                base.Log.LogWarning("No attributes found to set", new object[0]);
            }
        }

        protected string EscapeDirRegexSpecialCharacter(string value, bool escape)
        {
            if (escape)
            {
                return value.Replace("'", "&apos;");
            }
            return value.Replace("&apos;", "'");
        }

        protected string GetAttributeValue(string attributeName)
        {
            string str = null;
            XmlAttribute namedItem = base.TargetNode.Attributes.GetNamedItem(attributeName) as XmlAttribute;
            if ((namedItem == null) && (string.Compare(attributeName, this.tokenizeValueCurrentXmlAttribute.Name, StringComparison.OrdinalIgnoreCase) != 0))
            {
                namedItem = base.TransformNode.Attributes.GetNamedItem(attributeName) as XmlAttribute;
            }
            if (namedItem != null)
            {
                str = namedItem.Value;
            }
            return str;
        }

        private string GetXPathToAttribute(XmlAttribute xmlAttribute)
        {
            return this.GetXPathToAttribute(xmlAttribute, null);
        }

        private string GetXPathToAttribute(XmlAttribute xmlAttribute, IList<string> locators)
        {
            string str = string.Empty;
            if (xmlAttribute == null)
            {
                return str;
            }
            string xPathToNode = this.GetXPathToNode(xmlAttribute.OwnerElement);
            if (!string.IsNullOrEmpty(xPathToNode))
            {
                StringBuilder builder = new StringBuilder(0x100);
                if ((locators != null) && (locators.Count != 0))
                {
                    foreach (string str3 in locators)
                    {
                        string attributeValue = this.GetAttributeValue(str3);
                        if (string.IsNullOrEmpty(attributeValue))
                        {
                            throw new XmlTransformationException(string.Format("No attribute '{0}' exists for the Match Locator", new object[] { str3 }));
                        }
                        if (builder.Length != 0)
                        {
                            builder.Append(" and ");
                        }
                        builder.Append(string.Format(CultureInfo.InvariantCulture, "@{0}='{1}'", new object[] { str3, attributeValue }));
                    }
                }
                if (builder.Length == 0)
                {
                    for (int i = 0; i < base.TargetNodes.Count; i++)
                    {
                        if (base.TargetNodes[i] == xmlAttribute.OwnerElement)
                        {
                            builder.Append((i + 1).ToString());
                            break;
                        }
                    }
                }
                xPathToNode = xPathToNode + "[" + builder.ToString() + "]";
            }
            return (xPathToNode + "/@" + xmlAttribute.Name);
        }

        private string GetXPathToNode(XmlNode xmlNode)
        {
            if ((xmlNode != null) && (xmlNode.NodeType != XmlNodeType.Document))
            {
                return (this.GetXPathToNode(xmlNode.ParentNode) + "/" + xmlNode.Name);
            }
            return null;
        }

        protected static string SubstituteKownValue(string transformValue, Regex patternRegex, string patternPrefix, GetValueCallBack getValueCallBack)
        {
            int startIndex = 0;
            List<System.Text.RegularExpressions.Match> list = new List<System.Text.RegularExpressions.Match>();
            do
            {
                startIndex = transformValue.IndexOf(patternPrefix, startIndex);
                if (startIndex > -1)
                {
                    System.Text.RegularExpressions.Match item = patternRegex.Match(transformValue, startIndex);
                    if (item.Success)
                    {
                        list.Add(item);
                        startIndex = item.Index + item.Length;
                    }
                    else
                    {
                        startIndex++;
                    }
                }
            }
            while (startIndex > -1);
            StringBuilder builder = new StringBuilder(transformValue.Length);
            if (list.Count > 0)
            {
                builder.Remove(0, builder.Length);
                startIndex = 0;
                int num2 = 0;
                foreach (System.Text.RegularExpressions.Match match2 in list)
                {
                    builder.Append(transformValue.Substring(startIndex, match2.Index - startIndex));
                    Capture capture = match2.Groups["tagname"];
                    string key = capture.Value;
                    string str2 = getValueCallBack(key);
                    if (str2 != null)
                    {
                        builder.Append(str2);
                    }
                    else
                    {
                        builder.Append(match2.Value);
                    }
                    startIndex = match2.Index + match2.Length;
                    num2++;
                }
                builder.Append(transformValue.Substring(startIndex));
                transformValue = builder.ToString();
            }
            return transformValue;
        }

        private string TokenizeValue(XmlAttribute targetAttribute, XmlAttribute transformAttribute) //, bool fTokenizeParameter, List<Dictionary<string, string>> parameters)
        {
            this.tokenizeValueCurrentXmlAttribute = transformAttribute;
            string transformValue = transformAttribute.Value;
            string xPathToAttribute = this.GetXPathToAttribute(targetAttribute);
            transformValue = SubstituteKownValue(transformValue, ParentAttributeRegex, "$(", delegate (string key) {
                return this.EscapeDirRegexSpecialCharacter(this.GetAttributeValue(key), true);
            });
            //if (!fTokenizeParameter || (parameters == null))
            //{
                return transformValue;
            //}
            //int startIndex = 0;
            //StringBuilder builder = new StringBuilder(transformValue.Length);
            //startIndex = 0;
            //List<System.Text.RegularExpressions.Match> list = new List<System.Text.RegularExpressions.Match>();
            //do
            //{
            //    startIndex = transformValue.IndexOf("{%", startIndex);
            //    if (startIndex > -1)
            //    {
            //        System.Text.RegularExpressions.Match item = DirRegex.Match(transformValue, startIndex);
            //        if (item.Success)
            //        {
            //            list.Add(item);
            //            startIndex = item.Index + item.Length;
            //        }
            //        else
            //        {
            //            startIndex++;
            //        }
            //    }
            //}
            //while (startIndex > -1);
            //if (list.Count <= 0)
            //{
            //    return transformValue;
            //}
            //builder.Remove(0, builder.Length);
            //startIndex = 0;
            //int num2 = 0;
            //foreach (System.Text.RegularExpressions.Match match2 in list)
            //{
            //    builder.Append(transformValue.Substring(startIndex, match2.Index - startIndex));
            //    CaptureCollection captures = match2.Groups["attrname"].Captures;
            //    if ((captures != null) && (captures.Count > 0))
            //    {
            //        string str9;
            //        GetValueCallBack getValueCallBack = null;
            //        CaptureCollection captures2 = match2.Groups["attrval"].Captures;
            //        Dictionary<string, string> paramDictionary = new Dictionary<string, string>(4, StringComparer.InvariantCultureIgnoreCase);
            //        paramDictionary[XPathWithIndex] = xPathToAttribute;
            //        paramDictionary[TokenNumber] = num2.ToString();
            //        for (int i = 0; i < captures.Count; i++)
            //        {
            //            string str3 = captures[i].Value;
            //            string str4 = null;
            //            if ((captures2 != null) && (i < captures2.Count))
            //            {
            //                str4 = this.EscapeDirRegexSpecialCharacter(captures2[i].Value, false);
            //            }
            //            paramDictionary[str3] = str4;
            //        }
            //        string tokenFormat = null;
            //        if (!paramDictionary.TryGetValue(Token, out tokenFormat))
            //        {
            //            tokenFormat = this.storageDictionary.TokenFormat;
            //        }
            //        if (!string.IsNullOrEmpty(tokenFormat))
            //        {
            //            paramDictionary[Token] = tokenFormat;
            //        }
            //        int count = paramDictionary.Count;
            //        string[] array = new string[count];
            //        paramDictionary.Keys.CopyTo(array, 0);
            //        for (int j = 0; j < count; j++)
            //        {
            //            string str6 = array[j];
            //            string str7 = paramDictionary[str6];
            //            if (getValueCallBack == null)
            //            {
            //                getValueCallBack = delegate (string key) {
            //                    if (!paramDictionary.ContainsKey(key))
            //                    {
            //                        return null;
            //                    }
            //                    return paramDictionary[key];
            //                };
            //            }
            //            string str8 = SubstituteKownValue(str7, TokenFormatRegex, "#(", getValueCallBack);
            //            paramDictionary[str6] = str8;
            //        }
            //        if (paramDictionary.TryGetValue(Token, out tokenFormat))
            //        {
            //            builder.Append(tokenFormat);
            //        }
            //        if (paramDictionary.TryGetValue(XpathLocator, out str9) && !string.IsNullOrEmpty(str9))
            //        {
            //            IList<string> locators = XmlArgumentUtility.SplitArguments(str9);
            //            string str10 = this.GetXPathToAttribute(targetAttribute, locators);
            //            if (!string.IsNullOrEmpty(str10))
            //            {
            //                paramDictionary[XPathWithLocator] = str10;
            //            }
            //        }
            //        parameters.Add(paramDictionary);
            //    }
            //    startIndex = match2.Index + match2.Length;
            //    num2++;
            //}
            //builder.Append(transformValue.Substring(startIndex));
            //return builder.ToString();
        }

        internal static Regex DirRegex
        {
            get
            {
                if (s_dirRegex == null)
                {
                    s_dirRegex = new Regex(@"\G\{%(\s*(?<attrname>\w+(?=\W))(\s*(?<equal>=)\s*'(?<attrval>[^']*)'|\s*(?<equal>=)\s*(?<attrval>[^\s%>]*)|(?<equal>)(?<attrval>\s*?)))*\s*?%\}");
                }
                return s_dirRegex;
            }
        }

        internal static Regex ParentAttributeRegex
        {
            get
            {
                if (s_parentAttribRegex == null)
                {
                    s_parentAttribRegex = new Regex(@"\G\$\((?<tagname>[\w:\.]+)\)");
                }
                return s_parentAttribRegex;
            }
        }

        internal static Regex TokenFormatRegex
        {
            get
            {
                if (s_tokenFormatRegex == null)
                {
                    s_tokenFormatRegex = new Regex(@"\G\#\((?<tagname>[\w:\.]+)\)");
                }
                return s_tokenFormatRegex;
            }
        }

        //protected SetTokenizedAttributeStorage TransformStorage
        //{
        //    get
        //    {
        //        if ((this.storageDictionary == null) && !this.fInitStorageDictionary)
        //        {
        //            this.storageDictionary = base.GetService<SetTokenizedAttributeStorage>();
        //            this.fInitStorageDictionary = true;
        //        }
        //        return this.storageDictionary;
        //    }
        //}

        protected delegate string GetValueCallBack(string key);

        //public class SetTokenizedAttributeStorage
        //{
        //    public List<Dictionary<string, string>> DictionaryList;
        //    //public bool EnableTokenizeParameters;
        //    public string TokenFormat;
        //    public bool UseXpathToFormParameter;

        //    public SetTokenizedAttributeStorage()
        //        : this(4)
        //    {
        //    }

        //    public SetTokenizedAttributeStorage(int capacity)
        //    {
        //        this.TokenFormat = "$(ReplacableToken_#(" + SetTokenizedAttributes.ParameterAttribute + ")_#(" + SetTokenizedAttributes.TokenNumber + "))";
        //        this.UseXpathToFormParameter = true;
        //        this.DictionaryList = new List<Dictionary<string, string>>(capacity);
        //    }
        //}
    }
}

