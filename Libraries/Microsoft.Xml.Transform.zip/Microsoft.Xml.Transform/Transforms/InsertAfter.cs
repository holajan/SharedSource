namespace Microsoft.Web.Publishing.Tasks
{
    using System;

    internal class InsertAfter : InsertBase
    {
        protected override void Apply()
        {
            base.SiblingElement.ParentNode.InsertAfter(base.TransformNode, base.SiblingElement);
            base.Log.LogMessage(MessageType.Verbose, "Inserted '{0}' element", new object[] { base.TransformNode.Name });
        }
    }
}

