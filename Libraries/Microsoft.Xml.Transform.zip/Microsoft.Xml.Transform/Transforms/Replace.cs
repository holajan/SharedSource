namespace Microsoft.Web.Publishing.Tasks
{
    using System;

    internal class Replace : Transform
    {
        protected override void Apply()
        {
            CommonErrors.ExpectNoArguments(base.Log, base.TransformNameShort, base.ArgumentString);
            CommonErrors.WarnIfMultipleTargets(base.Log, base.TransformNameShort, base.TargetNodes, base.ApplyTransformToAllTargetNodes);
            base.TargetNode.ParentNode.ReplaceChild(base.TransformNode, base.TargetNode);
            base.Log.LogMessage(MessageType.Verbose, "Replaced '{0}' element", new object[] { base.TargetNode.Name });
        }
    }
}

