namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Xml;
    using Microsoft.Xml.Transform;

    internal abstract class InsertBase : Transform
    {
        private XmlElement siblingElement;

        internal InsertBase() : base(TransformFlags.UseParentAsTargetNode, MissingTargetMessage.Error)
        {
        }

        protected XmlElement SiblingElement
        {
            get
            {
                if (this.siblingElement == null)
                {
                    if ((base.Arguments == null) || (base.Arguments.Count == 0))
                    {
                        throw new XmlTransformationException(string.Format("{0} requires an XPath argument", new object[] { base.GetType().Name }));
                    }
                    if (base.Arguments.Count > 1)
                    {
                        throw new XmlTransformationException(string.Format("Too many arguments to {0}", new object[] { base.GetType().Name }));
                    }
                    string xpath = base.Arguments[0];
                    XmlNodeList list = base.TargetNode.SelectNodes(xpath);
                    if (list.Count == 0)
                    {
                        throw new XmlTransformationException(string.Format("No element in the source document matches '{0}'", new object[] { xpath }));
                    }
                    this.siblingElement = list[0] as XmlElement;
                    if (this.siblingElement == null)
                    {
                        throw new XmlTransformationException(string.Format("'{0}' does not evaluate to an element", new object[] { xpath }));
                    }
                }
                return this.siblingElement;
            }
        }
    }
}

