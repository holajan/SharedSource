namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Xml;

    internal class RemoveAttributes : AttributeTransform
    {
        protected override void Apply()
        {
            foreach (XmlAttribute attribute in base.TargetAttributes)
            {
                base.TargetNode.Attributes.Remove(attribute);
                base.Log.LogMessage("Removed '{0}' attribute", new object[] { attribute.Name });
            }
            if (base.TargetAttributes.Count > 0)
            {
                base.Log.LogMessage(MessageType.Verbose, "Removed {0} attributes", new object[] { base.TargetAttributes.Count });
            }
            else
            {
                base.Log.LogWarning(base.TargetNode, "No attributes found to remove", new object[0]);
            }
        }
    }
}

