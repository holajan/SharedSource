namespace Microsoft.Web.Publishing.Tasks
{
    using System;

    internal interface IXmlFormattableAttributes
    {
        void FormatAttributes(XmlFormatter formatter);

        string AttributeIndent { get; }
    }
}

