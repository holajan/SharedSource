namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Globalization;
    using System.Xml;
    using Microsoft.Xml.Transform;

    internal sealed class Match : Locator
    {
        protected override string ConstructPredicate()
        {
            base.EnsureArguments(1);
            string str = null;
            foreach (string str2 in base.Arguments)
            {
                XmlAttribute namedItem = base.CurrentElement.Attributes.GetNamedItem(str2) as XmlAttribute;
                if (namedItem == null)
                {
                    throw new XmlTransformationException(string.Format("No attribute '{0}' exists for the Match Locator", new object[] { str2 }));
                }
                string str3 = string.Format(CultureInfo.InvariantCulture, "@{0}='{1}'", new object[] { namedItem.Name, namedItem.Value });
                if (str == null)
                {
                    str = str3;
                }
                else
                {
                    str = str + " and " + str3;
                }
            }
            return str;
        }
    }
}

