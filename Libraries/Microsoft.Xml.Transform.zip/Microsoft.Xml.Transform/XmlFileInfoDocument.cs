namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.IO;
    using System.Text;
    using System.Xml;

    internal class XmlFileInfoDocument : XmlDocument
    {
        private string _fileName;
        private bool _firstLoad = true;
        private int _lineNumberOffset;
        private int _linePositionOffset;
        private XmlAttributePreservationProvider _preservationProvider;
        private XmlTextReader _reader;
        private Encoding _textEncoding;

        internal XmlNode CloneNodeFromOtherDocument(XmlNode element)
        {
            XmlTextReader reader = this._reader;
            string str = this._fileName;
            XmlNode node = null;
            try
            {
                IXmlLineInfo info = element as IXmlLineInfo;
                if (info != null)
                {
                    this._reader = new XmlTextReader(new StringReader(element.OuterXml));
                    this._lineNumberOffset = info.LineNumber - 1;
                    this._linePositionOffset = info.LinePosition - 2;
                    this._fileName = element.OwnerDocument.BaseURI;
                    return this.ReadNode(this._reader);
                }
                this._fileName = null;
                this._reader = null;
                node = this.ReadNode(new XmlTextReader(new StringReader(element.OuterXml)));
            }
            finally
            {
                this._lineNumberOffset = 0;
                this._linePositionOffset = 0;
                this._fileName = str;
                this._reader = reader;
            }
            return node;
        }

        public override XmlAttribute CreateAttribute(string prefix, string localName, string namespaceURI)
        {
            if (this.HasErrorInfo)
            {
                return new XmlFileInfoAttribute(prefix, localName, namespaceURI, this);
            }
            return base.CreateAttribute(prefix, localName, namespaceURI);
        }

        public override XmlElement CreateElement(string prefix, string localName, string namespaceURI)
        {
            if (this.HasErrorInfo)
            {
                return new XmlFileInfoElement(prefix, localName, namespaceURI, this);
            }
            return base.CreateElement(prefix, localName, namespaceURI);
        }

        private XmlElement FindContainingElement(XmlNode node)
        {
            while ((node != null) && !(node is XmlElement))
            {
                node = node.ParentNode;
            }
            return (node as XmlElement);
        }

        private Encoding GetEncodingFromStream(Stream stream)
        {
            Encoding bigEndianUnicode = null;
            if (stream.CanSeek)
            {
                byte[] buffer = new byte[3];
                stream.Read(buffer, 0, buffer.Length);
                if (((buffer[0] == 0xef) && (buffer[1] == 0xbb)) && (buffer[2] == 0xbf))
                {
                    bigEndianUnicode = Encoding.UTF8;
                }
                else if ((buffer[0] == 0xfe) && (buffer[1] == 0xff))
                {
                    bigEndianUnicode = Encoding.BigEndianUnicode;
                }
                else if ((buffer[0] == 0xff) && (buffer[1] == 0xfe))
                {
                    bigEndianUnicode = Encoding.Unicode;
                }
                else if (((buffer[0] == 0x2b) && (buffer[1] == 0x2f)) && (buffer[2] == 0x76))
                {
                    bigEndianUnicode = Encoding.UTF7;
                }
                stream.Seek(0L, SeekOrigin.Begin);
            }
            return bigEndianUnicode;
        }

        internal bool IsNewNode(XmlNode node)
        {
            XmlFileInfoElement element = this.FindContainingElement(node) as XmlFileInfoElement;
            return ((element != null) && !element.IsOriginal);
        }

        public override void Load(Stream inStream)
        {
            this.LoadFromTextReader(new StreamReader(inStream, true));
            this._firstLoad = false;
        }

        public override void Load(TextReader txtReader)
        {
            this.LoadFromTextReader(txtReader);
            this._firstLoad = false;
        }

        public override void Load(string filename)
        {
            this.LoadFromFileName(filename);
            this._firstLoad = false;
        }

        public override void Load(XmlReader reader)
        {
            this._reader = reader as XmlTextReader;
            if (this._reader != null)
            {
                this._fileName = this._reader.BaseURI;
            }
            base.Load(reader);
            if (this._reader != null)
            {
                this._textEncoding = this._reader.Encoding;
            }
            this._firstLoad = false;
        }

        private void LoadFromFileName(string filename)
        {
            this._fileName = filename;
            try
            {
                if (base.PreserveWhitespace)
                {
                    this._preservationProvider = new XmlAttributePreservationProvider(filename);
                }
                using (var reader = new StreamReader(filename, true))
                {
                    this.LoadFromTextReader(reader);
                }
            }
            finally
            {
                if (this._preservationProvider != null)
                {
                    this._preservationProvider.Dispose();
                }
                this._preservationProvider = null;
            }
        }

        private void LoadFromTextReader(TextReader textReader)
        {
            StreamReader reader = textReader as StreamReader;
            if (reader != null)
            {
                FileStream baseStream = reader.BaseStream as FileStream;
                if (baseStream != null)
                {
                    this._fileName = baseStream.Name;
                }
                this._textEncoding = this.GetEncodingFromStream(reader.BaseStream);
            }
            this._reader = new XmlTextReader(this._fileName, textReader);
            base.Load(this._reader);
            if (this._textEncoding == null)
            {
                this._textEncoding = this._reader.Encoding;
            }
        }

        public override void Save(string filename)
        {
            XmlWriter writer = null;
            try
            {
                if (base.PreserveWhitespace)
                {
                    XmlFormatter.Format(this);
                    writer = new XmlAttributePreservingWriter(filename, this.TextEncoding);
                }
                else
                {
                    XmlTextWriter writer2 = new XmlTextWriter(filename, this.TextEncoding);
                    writer2.Formatting = Formatting.Indented;
                    writer = writer2;
                }
                this.WriteTo(writer);
            }
            finally
            {
                if (writer != null)
                {
                    writer.Flush();
                    writer.Close();
                }
            }
        }

        public void Save(Stream outputStream, bool leaveOpen)
        {
            XmlWriter writer = null;
            try
            {
                if (base.PreserveWhitespace)
                {
                    XmlFormatter.Format(this);
                    writer = new XmlAttributePreservingWriter(outputStream, this.TextEncoding);
                }
                else
                {
                    XmlTextWriter writer2 = new XmlTextWriter(outputStream, this.TextEncoding);
                    writer2.Formatting = Formatting.Indented;
                    writer = writer2;
                }
                this.WriteTo(writer);
            }
            finally
            {
                if (writer != null)
                {
                    writer.Flush();
                    if (!leaveOpen)
                    {
                        writer.Close();
                    }
                }
            }
        }

        public void Save(TextWriter textWriter, bool leaveOpen)
        {
            XmlWriter writer = null;
            try
            {
                if (base.PreserveWhitespace)
                {
                    XmlFormatter.Format(this);
                    writer = new XmlAttributePreservingWriter(textWriter);
                }
                else
                {
                    XmlTextWriter writer2 = new XmlTextWriter(textWriter);
                    writer2.Formatting = Formatting.Indented;
                    writer = writer2;
                }
                this.WriteTo(writer);
            }
            finally
            {
                if (writer != null)
                {
                    writer.Flush();
                    if (!leaveOpen)
                    {
                        writer.Close();
                    }
                }
            }
        }

        private int CurrentLineNumber
        {
            get
            {
                if (this._reader == null)
                {
                    return 0;
                }
                return (this._reader.LineNumber + this._lineNumberOffset);
            }
        }

        private int CurrentLinePosition
        {
            get
            {
                if (this._reader == null)
                {
                    return 0;
                }
                return (this._reader.LinePosition + this._linePositionOffset);
            }
        }

        internal string FileName
        {
            get
            {
                return this._fileName;
            }
        }

        private bool FirstLoad
        {
            get
            {
                return this._firstLoad;
            }
        }

        internal bool HasErrorInfo
        {
            get
            {
                return (this._reader != null);
            }
        }

        private XmlAttributePreservationProvider PreservationProvider
        {
            get
            {
                return this._preservationProvider;
            }
        }

        private Encoding TextEncoding
        {
            get
            {
                if (this._textEncoding != null)
                {
                    return this._textEncoding;
                }
                if (this.HasChildNodes)
                {
                    XmlDeclaration firstChild = this.FirstChild as XmlDeclaration;
                    if (firstChild != null)
                    {
                        string encoding = firstChild.Encoding;
                        if (encoding.Length > 0)
                        {
                            return Encoding.GetEncoding(encoding);
                        }
                    }
                }
                return null;
            }
        }

        private class XmlFileInfoAttribute : XmlAttribute, IXmlLineInfo
        {
            private int lineNumber;
            private int linePosition;

            internal XmlFileInfoAttribute(string prefix, string localName, string namespaceUri, XmlFileInfoDocument document) : base(prefix, localName, namespaceUri, document)
            {
                this.lineNumber = document.CurrentLineNumber;
                this.linePosition = document.CurrentLinePosition;
            }

            public bool HasLineInfo()
            {
                return true;
            }

            public int LineNumber
            {
                get
                {
                    return this.lineNumber;
                }
            }

            public int LinePosition
            {
                get
                {
                    return this.linePosition;
                }
            }
        }

        private class XmlFileInfoElement : XmlElement, IXmlLineInfo, IXmlFormattableAttributes
        {
            private bool isOriginal;
            private int lineNumber;
            private int linePosition;
            private XmlAttributePreservationDict preservationDict;

            internal XmlFileInfoElement(string prefix, string localName, string namespaceUri, XmlFileInfoDocument document) : base(prefix, localName, namespaceUri, document)
            {
                this.lineNumber = document.CurrentLineNumber;
                this.linePosition = document.CurrentLinePosition;
                this.isOriginal = document.FirstLoad;
                if (document.PreservationProvider != null)
                {
                    this.preservationDict = document.PreservationProvider.GetDictAtPosition(this.lineNumber, this.linePosition - 1);
                }
                if (this.preservationDict == null)
                {
                    this.preservationDict = new XmlAttributePreservationDict();
                }
            }

            public bool HasLineInfo()
            {
                return true;
            }

            void IXmlFormattableAttributes.FormatAttributes(XmlFormatter formatter)
            {
                this.preservationDict.UpdatePreservationInfo(this.Attributes, formatter);
            }

            private void WriteAttributesTo(XmlWriter w)
            {
                XmlAttributeCollection attributes = this.Attributes;
                for (int i = 0; i < attributes.Count; i++)
                {
                    attributes[i].WriteTo(w);
                }
            }

            private void WritePreservedAttributesTo(XmlAttributePreservingWriter preservingWriter)
            {
                this.preservationDict.WritePreservedAttributes(preservingWriter, this.Attributes);
            }

            public override void WriteTo(XmlWriter w)
            {
                string prefix = this.Prefix;
                if (!string.IsNullOrEmpty(this.NamespaceURI))
                {
                    prefix = w.LookupPrefix(this.NamespaceURI);
                    if (prefix == null)
                    {
                        prefix = this.Prefix;
                    }
                }
                w.WriteStartElement(prefix, this.LocalName, this.NamespaceURI);
                if (this.HasAttributes)
                {
                    XmlAttributePreservingWriter preservingWriter = w as XmlAttributePreservingWriter;
                    if ((preservingWriter == null) || (this.preservationDict == null))
                    {
                        this.WriteAttributesTo(w);
                    }
                    else
                    {
                        this.WritePreservedAttributesTo(preservingWriter);
                    }
                }
                if (base.IsEmpty)
                {
                    w.WriteEndElement();
                }
                else
                {
                    this.WriteContentTo(w);
                    w.WriteFullEndElement();
                }
            }

            public bool IsOriginal
            {
                get
                {
                    return this.isOriginal;
                }
            }

            public int LineNumber
            {
                get
                {
                    return this.lineNumber;
                }
            }

            public int LinePosition
            {
                get
                {
                    return this.linePosition;
                }
            }

            string IXmlFormattableAttributes.AttributeIndent
            {
                get
                {
                    return this.preservationDict.GetAttributeNewLineString(null);
                }
            }
        }
    }
}

