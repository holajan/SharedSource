namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Collections.Generic;

    internal static class XmlArgumentUtility
    {
        private static int CountParens(string str)
        {
            int num = 0;
            string str2 = str;
            for (int i = 0; i < str2.Length; i++)
            {
                switch (str2[i])
                {
                    case '(':
                        num++;
                        break;

                    case ')':
                        num--;
                        break;
                }
            }
            return num;
        }

        private static IList<string> RecombineArguments(IList<string> arguments, char separator)
        {
            List<string> list = new List<string>();
            string item = null;
            int num = 0;
            foreach (string str2 in arguments)
            {
                if (item == null)
                {
                    item = str2;
                }
                else
                {
                    item = item + separator + str2;
                }
                num += CountParens(str2);
                if (num == 0)
                {
                    list.Add(item);
                    item = null;
                }
            }
            if (item != null)
            {
                list.Add(item);
            }
            if (arguments.Count != list.Count)
            {
                arguments = list;
            }
            return arguments;
        }

        internal static IList<string> SplitArguments(string argumentString)
        {
            if (argumentString.IndexOf(',') == -1)
            {
                return new string[] { argumentString };
            }
            List<string> arguments = new List<string>();
            arguments.AddRange(argumentString.Split(new char[] { ',' }));
            RecombineArguments(arguments, ',');
            TrimStrings(arguments);
            return arguments;
        }

        private static void TrimStrings(IList<string> arguments)
        {
            for (int i = 0; i < arguments.Count; i++)
            {
                arguments[i] = arguments[i].Trim();
            }
        }
    }
}

