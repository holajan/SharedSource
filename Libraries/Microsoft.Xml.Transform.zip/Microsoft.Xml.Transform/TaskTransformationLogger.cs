namespace Microsoft.Web.Publishing.Tasks
{
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using System;
    using System.Text;

    internal class TaskTransformationLogger : IXmlTransformationLogger
    {
        private int indentLevel;
        private string indentString;
        private readonly string indentStringPiece;
        private TaskLoggingHelper loggingHelper;
        private bool stackTrace;

        public TaskTransformationLogger(TaskLoggingHelper loggingHelper)
            : this(loggingHelper, false)
        {
        }

        public TaskTransformationLogger(TaskLoggingHelper loggingHelper, bool stackTrace)
        {
            this.indentStringPiece = "  ";
            this.loggingHelper = loggingHelper;
            this.stackTrace = stackTrace;
        }

        void IXmlTransformationLogger.EndSection(string message, params object[] messageArgs)
        {
            ((IXmlTransformationLogger)this).EndSection(MessageType.Normal, message, messageArgs);
        }

        void IXmlTransformationLogger.EndSection(MessageType type, string message, params object[] messageArgs)
        {
            if (this.IndentLevel > 0)
            {
                this.IndentLevel--;
            }
            ((IXmlTransformationLogger)this).LogMessage(type, message, messageArgs);
        }

        void IXmlTransformationLogger.LogError(string message, params object[] messageArgs)
        {
            this.loggingHelper.LogError(message, messageArgs);
        }

        void IXmlTransformationLogger.LogError(string file, string message, params object[] messageArgs)
        {
            ((IXmlTransformationLogger)this).LogError(file, 0, 0, message, messageArgs);
        }

        void IXmlTransformationLogger.LogError(string file, int lineNumber, int linePosition, string message, params object[] messageArgs)
        {
            this.loggingHelper.LogError(null, null, null, file, lineNumber, linePosition, 0, 0, this.loggingHelper.FormatString(message, messageArgs), new object[0]);
        }

        void IXmlTransformationLogger.LogErrorFromException(Exception ex)
        {
            this.loggingHelper.LogErrorFromException(ex, this.stackTrace, this.stackTrace, null);
        }

        void IXmlTransformationLogger.LogErrorFromException(Exception ex, string file)
        {
            this.loggingHelper.LogErrorFromException(ex, this.stackTrace, this.stackTrace, file);
        }

        void IXmlTransformationLogger.LogErrorFromException(Exception ex, string file, int lineNumber, int linePosition)
        {
            string message = ex.Message;
            if (this.stackTrace)
            {
                StringBuilder builder = new StringBuilder();
                for (Exception exception = ex; exception != null; exception = exception.InnerException)
                {
                    builder.AppendFormat("{0} : {1}", exception.GetType().Name, exception.Message);
                    builder.AppendLine();
                    if (!string.IsNullOrEmpty(exception.StackTrace))
                    {
                        builder.Append(exception.StackTrace);
                    }
                }
                message = builder.ToString();
            }
            ((IXmlTransformationLogger)this).LogError(file, lineNumber, linePosition, message, new object[0]);
        }

        void IXmlTransformationLogger.LogMessage(string message, params object[] messageArgs)
        {
            ((IXmlTransformationLogger)this).LogMessage(MessageType.Normal, message, messageArgs);
        }

        void IXmlTransformationLogger.LogMessage(MessageType type, string message, params object[] messageArgs)
        {
            MessageImportance normal;
            switch (type)
            {
                case MessageType.Normal:
                    normal = MessageImportance.Normal;
                    break;

                case MessageType.Verbose:
                    normal = MessageImportance.Low;
                    break;

                default:
                    normal = MessageImportance.Normal;
                    break;
            }
            this.loggingHelper.LogMessage(normal, this.IndentString + message, messageArgs);
        }

        void IXmlTransformationLogger.LogWarning(string message, params object[] messageArgs)
        {
            this.loggingHelper.LogWarning(message, messageArgs);
        }

        void IXmlTransformationLogger.LogWarning(string file, string message, params object[] messageArgs)
        {
            ((IXmlTransformationLogger)this).LogWarning(file, 0, 0, message, messageArgs);
        }

        void IXmlTransformationLogger.LogWarning(string file, int lineNumber, int linePosition, string message, params object[] messageArgs)
        {
            this.loggingHelper.LogWarning(null, null, null, file, lineNumber, linePosition, 0, 0, this.loggingHelper.FormatString(message, messageArgs), new object[0]);
        }

        void IXmlTransformationLogger.StartSection(string message, params object[] messageArgs)
        {
            ((IXmlTransformationLogger)this).StartSection(MessageType.Normal, message, messageArgs);
        }

        void IXmlTransformationLogger.StartSection(MessageType type, string message, params object[] messageArgs)
        {
            ((IXmlTransformationLogger)this).LogMessage(type, message, messageArgs);
            this.IndentLevel++;
        }

        private int IndentLevel
        {
            get
            {
                return this.indentLevel;
            }
            set
            {
                if (this.indentLevel != value)
                {
                    this.indentLevel = value;
                    this.indentString = null;
                }
            }
        }

        private string IndentString
        {
            get
            {
                if (this.indentString == null)
                {
                    this.indentString = string.Empty;
                    for (int i = 0; i < this.indentLevel; i++)
                    {
                        this.indentString = this.indentString + this.indentStringPiece;
                    }
                }
                return this.indentString;
            }
        }
    }
}