namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Globalization;
    using System.Xml;
    using Microsoft.Xml.Transform;

    internal class XmlTransformationLogger
    {
        private XmlNode currentReferenceNode;
        private IXmlTransformationLogger externalLogger;
        private bool fSupressWarnings;
        private bool hasLoggedErrors;

        internal XmlTransformationLogger(IXmlTransformationLogger logger)
        {
            this.externalLogger = logger;
        }

        private static string ConvertUriToFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return null;
            }

            try
            {
                Uri uri = new Uri(fileName);
                if (uri.IsFile && string.IsNullOrEmpty(uri.Host))
                {
                    fileName = uri.LocalPath;
                }
            }
            catch (UriFormatException)
            {
                //Ignore exception
            }
            return fileName;
        }

        private static string ConvertUriToFileName(XmlDocument xmlDocument)
        {
            string fileName;
            XmlFileInfoDocument document = xmlDocument as XmlFileInfoDocument;
            if (document != null)
            {
                fileName = document.FileName;
            }
            else
            {
                fileName = document.BaseURI;
            }
            return ConvertUriToFileName(fileName);
        }

        public void EndSection(string message, params object[] messageArgs)
        {
            if (this.externalLogger != null)
            {
                this.externalLogger.EndSection(message, messageArgs);
            }
        }

        public void EndSection(MessageType type, string message, params object[] messageArgs)
        {
            if (this.externalLogger != null)
            {
                this.externalLogger.EndSection(type, message, messageArgs);
            }
        }

        public void LogError(string message, params object[] messageArgs)
        {
            this.hasLoggedErrors = true;
            if (this.CurrentReferenceNode != null)
            {
                this.LogError(this.CurrentReferenceNode, message, messageArgs);
            }
            else
            {
                if (this.externalLogger == null)
                {
                    throw new XmlTransformationException(string.Format(CultureInfo.CurrentUICulture, message, messageArgs));
                }
                this.externalLogger.LogError(message, messageArgs);
            }
        }

        public void LogError(XmlNode referenceNode, string message, params object[] messageArgs)
        {
            this.hasLoggedErrors = true;
            if (this.externalLogger == null)
            {
                throw new XmlNodeException(string.Format(CultureInfo.CurrentUICulture, message, messageArgs), referenceNode);
            }
            string file = ConvertUriToFileName(referenceNode.OwnerDocument);
            IXmlLineInfo info = referenceNode as IXmlLineInfo;
            if (info != null)
            {
                this.externalLogger.LogError(file, info.LineNumber, info.LinePosition, message, messageArgs);
            }
            else
            {
                this.externalLogger.LogError(file, message, messageArgs);
            }
        }

        internal void LogErrorFromException(Exception ex)
        {
            this.hasLoggedErrors = true;
            if (this.externalLogger == null)
            {
                throw ex;
            }
            XmlNodeException exception = ex as XmlNodeException;
            if ((exception != null) && exception.HasErrorInfo)
            {
                this.externalLogger.LogErrorFromException(exception, ConvertUriToFileName(exception.FileName), exception.LineNumber, exception.LinePosition);
            }
            else
            {
                this.externalLogger.LogErrorFromException(ex);
            }
        }

        public void LogMessage(string message, params object[] messageArgs)
        {
            if (this.externalLogger != null)
            {
                this.externalLogger.LogMessage(message, messageArgs);
            }
        }

        public void LogMessage(MessageType type, string message, params object[] messageArgs)
        {
            if (this.externalLogger != null)
            {
                this.externalLogger.LogMessage(type, message, messageArgs);
            }
        }

        public void LogWarning(string message, params object[] messageArgs)
        {
            if (this.SupressWarnings)
            {
                this.LogMessage(message, messageArgs);
            }
            else if (this.CurrentReferenceNode != null)
            {
                this.LogWarning(this.CurrentReferenceNode, message, messageArgs);
            }
            else if (this.externalLogger != null)
            {
                this.externalLogger.LogWarning(message, messageArgs);
            }
        }

        public void LogWarning(XmlNode referenceNode, string message, params object[] messageArgs)
        {
            if (this.SupressWarnings)
            {
                this.LogMessage(message, messageArgs);
            }
            else if (this.externalLogger != null)
            {
                string file = ConvertUriToFileName(referenceNode.OwnerDocument);
                IXmlLineInfo info = referenceNode as IXmlLineInfo;
                if (info != null)
                {
                    this.externalLogger.LogWarning(file, info.LineNumber, info.LinePosition, message, messageArgs);
                }
                else
                {
                    this.externalLogger.LogWarning(file, message, messageArgs);
                }
            }
        }

        public void StartSection(string message, params object[] messageArgs)
        {
            if (this.externalLogger != null)
            {
                this.externalLogger.StartSection(message, messageArgs);
            }
        }

        public void StartSection(MessageType type, string message, params object[] messageArgs)
        {
            if (this.externalLogger != null)
            {
                this.externalLogger.StartSection(type, message, messageArgs);
            }
        }

        internal XmlNode CurrentReferenceNode
        {
            get
            {
                return this.currentReferenceNode;
            }
            set
            {
                this.currentReferenceNode = value;
            }
        }

        internal bool HasLoggedErrors
        {
            get
            {
                return this.hasLoggedErrors;
            }
            set
            {
                this.hasLoggedErrors = false;
            }
        }

        public bool SupressWarnings
        {
            get
            {
                return this.fSupressWarnings;
            }
            set
            {
                this.fSupressWarnings = value;
            }
        }
    }
}

