namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.IO;
    using System.Text;
    using System.Xml;

    internal class XmlAttributePreservingWriter : XmlWriter
    {
        private AttributeTextWriter textWriter;
        private XmlTextWriter xmlWriter;

        public XmlAttributePreservingWriter(TextWriter textWriter)
        {
            this.textWriter = new AttributeTextWriter(textWriter);
            this.xmlWriter = new XmlTextWriter(this.textWriter);
        }

        public XmlAttributePreservingWriter(string fileName, Encoding encoding) : this((encoding == null) ? new StreamWriter(fileName) : new StreamWriter(fileName, false, encoding)) { }

        public XmlAttributePreservingWriter(Stream outputStream, Encoding encoding) : this((encoding == null) ? new StreamWriter(outputStream) : new StreamWriter(outputStream, encoding)) { }

        public override void Close()
        {
            this.xmlWriter.Close();
        }

        public override void Flush()
        {
            this.xmlWriter.Flush();
        }

        private bool IsOnlyWhitespace(string whitespace)
        {
            foreach (char ch in whitespace)
            {
                if (!char.IsWhiteSpace(ch))
                {
                    return false;
                }
            }
            return true;
        }

        public override string LookupPrefix(string ns)
        {
            return this.xmlWriter.LookupPrefix(ns);
        }

        public string SetAttributeNewLineString(string newLineString)
        {
            string attributeNewLineString = this.textWriter.AttributeNewLineString;
            if ((newLineString == null) && (this.xmlWriter.Settings != null))
            {
                newLineString = this.xmlWriter.Settings.NewLineChars;
            }
            if (newLineString == null)
            {
                newLineString = "\r\n";
            }
            this.textWriter.AttributeNewLineString = newLineString;
            return attributeNewLineString;
        }

        public void WriteAttributeTrailingWhitespace(string whitespace)
        {
            if (this.WriteState == System.Xml.WriteState.Attribute)
            {
                this.WriteEndAttribute();
            }
            else if (this.WriteState != System.Xml.WriteState.Element)
            {
                throw new InvalidOperationException();
            }
            this.textWriter.Write(whitespace);
        }

        public void WriteAttributeWhitespace(string whitespace)
        {
            if (this.WriteState == System.Xml.WriteState.Attribute)
            {
                this.WriteEndAttribute();
            }
            else if (this.WriteState != System.Xml.WriteState.Element)
            {
                throw new InvalidOperationException();
            }
            this.textWriter.AttributeLeadingWhitespace = whitespace;
        }

        public override void WriteBase64(byte[] buffer, int index, int count)
        {
            this.xmlWriter.WriteBase64(buffer, index, count);
        }

        public override void WriteCData(string text)
        {
            this.xmlWriter.WriteCData(text);
        }

        public override void WriteComment(string text)
        {
            this.xmlWriter.WriteComment(text);
        }

        public override void WriteDocType(string name, string pubid, string sysid, string subset)
        {
            this.xmlWriter.WriteDocType(name, pubid, sysid, subset);
        }

        public override void WriteEndAttribute()
        {
            this.xmlWriter.WriteEndAttribute();
            this.textWriter.EndAttribute();
        }

        public override void WriteEndDocument()
        {
            this.xmlWriter.WriteEndDocument();
        }

        public override void WriteEndElement()
        {
            this.xmlWriter.WriteEndElement();
        }

        public override void WriteEntityRef(string name)
        {
            this.xmlWriter.WriteEntityRef(name);
        }

        public override void WriteFullEndElement()
        {
            this.xmlWriter.WriteFullEndElement();
        }

        public override void WriteCharEntity(char ch)
        {
            this.xmlWriter.WriteCharEntity(ch);
        }

        public override void WriteChars(char[] buffer, int index, int count)
        {
            this.xmlWriter.WriteChars(buffer, index, count);
        }

        public override void WriteProcessingInstruction(string name, string text)
        {
            this.xmlWriter.WriteProcessingInstruction(name, text);
        }

        public override void WriteRaw(string data)
        {
            this.xmlWriter.WriteRaw(data);
        }

        public override void WriteRaw(char[] buffer, int index, int count)
        {
            this.xmlWriter.WriteRaw(buffer, index, count);
        }

        public override void WriteStartAttribute(string prefix, string localName, string ns)
        {
            this.textWriter.StartAttribute();
            this.xmlWriter.WriteStartAttribute(prefix, localName, ns);
        }

        public override void WriteStartDocument()
        {
            this.xmlWriter.WriteStartDocument();
        }

        public override void WriteStartDocument(bool standalone)
        {
            this.xmlWriter.WriteStartDocument(standalone);
        }

        public override void WriteStartElement(string prefix, string localName, string ns)
        {
            this.xmlWriter.WriteStartElement(prefix, localName, ns);
        }

        public override void WriteString(string text)
        {
            this.xmlWriter.WriteString(text);
        }

        public override void WriteSurrogateCharEntity(char lowChar, char highChar)
        {
            this.xmlWriter.WriteSurrogateCharEntity(lowChar, highChar);
        }

        public override void WriteWhitespace(string ws)
        {
            this.xmlWriter.WriteWhitespace(ws);
        }

        public override System.Xml.WriteState WriteState
        {
            get
            {
                return this.xmlWriter.WriteState;
            }
        }

        private class AttributeTextWriter : TextWriter
        {
            private TextWriter baseWriter;
            private string leadingWhitespace;
            private int lineNumber;
            private int linePosition;
            private int maxLineLength;
            private string newLineString;
            private State state;
            private StringBuilder writeBuffer;

            public AttributeTextWriter(TextWriter baseWriter)
                : base(System.Globalization.CultureInfo.InvariantCulture)
            {
                this.lineNumber = 1;
                this.linePosition = 1;
                this.maxLineLength = 160;
                this.newLineString = "\r\n";
                this.baseWriter = baseWriter;
            }

            public override void Close()
            {
                this.baseWriter.Close();
            }

            private void CreateBuffer()
            {
                if (this.writeBuffer == null)
                {
                    this.writeBuffer = new StringBuilder();
                }
            }

            public void EndAttribute()
            {
                this.WriteQueuedAttribute();
            }

            public override void Flush()
            {
                this.baseWriter.Flush();
            }

            private void FlushBuffer()
            {
                if (this.writeBuffer != null)
                {
                    State state = this.state;
                    try
                    {
                        this.state = State.FlushingBuffer;
                        this.Write(this.writeBuffer.ToString());
                        this.writeBuffer = null;
                    }
                    finally
                    {
                        this.state = state;
                    }
                }
            }

            private void ChangeState(State newState)
            {
                if (this.state != newState)
                {
                    State state = this.state;
                    this.state = newState;
                    if (this.StateRequiresBuffer(newState))
                    {
                        this.CreateBuffer();
                    }
                    else if (this.StateRequiresBuffer(state))
                    {
                        this.FlushBuffer();
                    }
                }
            }

            private void ReallyWriteCharacter(char value)
            {
                this.baseWriter.Write(value);
                if (value == '\n')
                {
                    this.lineNumber++;
                    this.linePosition = 1;
                }
                else
                {
                    this.linePosition++;
                }
            }

            public void StartAttribute()
            {
                this.ChangeState(State.WaitingForAttributeLeadingSpace);
            }

            private bool StateRequiresBuffer(State state)
            {
                if (state != State.Buffering)
                {
                    return (state == State.ReadingAttribute);
                }
                return true;
            }

            private void UpdateState(char value)
            {
                switch (value)
                {
                    case ' ':
                        if (this.state != State.Writing)
                        {
                            break;
                        }
                        this.ChangeState(State.Buffering);
                        return;

                    case '/':
                        break;

                    case '>':
                        {
                            if (this.state != State.Buffering)
                            {
                                break;
                            }
                            string str = this.writeBuffer.ToString();
                            if (str.EndsWith(" /", StringComparison.Ordinal))
                            {
                                this.writeBuffer.Remove(str.LastIndexOf(' '), 1);
                            }
                            this.ChangeState(State.Writing);
                            return;
                        }
                    default:
                        if (this.state == State.Buffering)
                        {
                            this.ChangeState(State.Writing);
                        }
                        break;
                }
            }

            public override void Write(char value)
            {
                this.UpdateState(value);
                switch (this.state)
                {
                    case State.Writing:
                    case State.FlushingBuffer:
                        break;

                    case State.WaitingForAttributeLeadingSpace:
                        if (value != ' ')
                        {
                            break;
                        }
                        this.ChangeState(State.ReadingAttribute);
                        return;

                    case State.ReadingAttribute:
                    case State.Buffering:
                        this.writeBuffer.Append(value);
                        return;

                    default:
                        return;
                }
                this.ReallyWriteCharacter(value);
            }

            private void WriteQueuedAttribute()
            {
                if (this.leadingWhitespace != null)
                {
                    this.writeBuffer.Insert(0, this.leadingWhitespace);
                    this.leadingWhitespace = null;
                }
                else
                {
                    int num = (this.linePosition + this.writeBuffer.Length) + 1;
                    if (num > this.MaxLineLength)
                    {
                        this.writeBuffer.Insert(0, this.AttributeNewLineString);
                    }
                    else
                    {
                        this.writeBuffer.Insert(0, ' ');
                    }
                }
                this.ChangeState(State.Writing);
            }

            public string AttributeLeadingWhitespace
            {
                set
                {
                    this.leadingWhitespace = value;
                }
            }

            public string AttributeNewLineString
            {
                get
                {
                    return this.newLineString;
                }
                set
                {
                    this.newLineString = value;
                }
            }

            public override System.Text.Encoding Encoding
            {
                get
                {
                    return this.baseWriter.Encoding;
                }
            }

            public int MaxLineLength
            {
                get
                {
                    return this.maxLineLength;
                }
                set
                {
                    this.maxLineLength = value;
                }
            }

            private enum State
            {
                Writing,
                WaitingForAttributeLeadingSpace,
                ReadingAttribute,
                Buffering,
                FlushingBuffer
            }
        }
    }
}