namespace Microsoft.Web.Publishing.Tasks
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Xml;
    using Microsoft.Xml.Transform;

    [Flags]
    internal enum TransformFlags
    {
        None,
        ApplyTransformToAllTargetNodes,
        UseParentAsTargetNode
    }

    internal enum MissingTargetMessage
    {
        None,
        Information,
        Warning,
        Error
    }

    internal abstract class Transform
    {
        private bool applyTransformToAllTargetNodes;
        private IList<string> arguments;
        private string argumentString;
        private XmlElementContext context;
        private XmlNode currentTargetNode;
        private XmlNode currentTransformNode;
        private XmlTransformationLogger logger;
        private Microsoft.Web.Publishing.Tasks.MissingTargetMessage missingTargetMessage;
        private bool useParentAsTargetNode;

        protected Transform() : this(TransformFlags.None)
        {
        }

        protected Transform(TransformFlags flags) : this(flags, Microsoft.Web.Publishing.Tasks.MissingTargetMessage.Warning)
        {
        }

        protected Transform(TransformFlags flags, Microsoft.Web.Publishing.Tasks.MissingTargetMessage message)
        {
            this.missingTargetMessage = message;
            this.applyTransformToAllTargetNodes = (flags & TransformFlags.ApplyTransformToAllTargetNodes) == TransformFlags.ApplyTransformToAllTargetNodes;
            this.useParentAsTargetNode = (flags & TransformFlags.UseParentAsTargetNode) == TransformFlags.UseParentAsTargetNode;
        }

        protected abstract void Apply();
        private bool ApplyOnAllTargetNodes()
        {
            bool flag = false;
            XmlNode transformNode = this.TransformNode;
            foreach (XmlNode node2 in this.TargetNodes)
            {
                try
                {
                    this.currentTargetNode = node2;
                    this.currentTransformNode = transformNode.Clone();
                    this.ApplyOnce();
                    continue;
                }
                catch (Exception exception)
                {
                    this.Log.LogErrorFromException(exception);
                    flag = true;
                    continue;
                }
            }
            this.currentTargetNode = null;
            return flag;
        }

        private void ApplyOnce()
        {
            this.WriteApplyMessage(this.TargetNode);
            this.Apply();
        }

        internal void Execute(XmlElementContext context, string argumentString)
        {
            if ((this.context == null) && (this.argumentString == null))
            {
                bool flag = false;
                bool flag2 = false;
                try
                {
                    this.context = context;
                    this.argumentString = argumentString;
                    this.arguments = null;
                    if (this.ShouldExecuteTransform())
                    {
                        flag2 = true;
                        this.Log.StartSection("Executing {0}", new object[] { this.TransformNameLong });
                        this.Log.LogMessage("on {0}", new object[] { context.XPath });
                        if (this.ApplyTransformToAllTargetNodes)
                        {
                            this.ApplyOnAllTargetNodes();
                        }
                        else
                        {
                            this.ApplyOnce();
                        }
                    }
                }
                catch (Exception exception)
                {
                    flag = true;
                    if (context.TransformAttribute != null)
                    {
                        this.Log.LogErrorFromException(XmlNodeException.Wrap(exception, context.TransformAttribute));
                    }
                    else
                    {
                        this.Log.LogErrorFromException(exception);
                    }
                }
                finally
                {
                    if (flag2)
                    {
                        if (flag)
                        {
                            this.Log.EndSection("Error during {0}", new object[] { this.TransformNameShort });
                        }
                        else
                        {
                            this.Log.EndSection("Done executing {0}", new object[] { this.TransformNameShort });
                        }
                    }
                    else
                    {
                        this.Log.LogMessage("Not executing {0}", new object[] { this.TransformNameLong });
                    }
                    this.context = null;
                    this.argumentString = null;
                    this.arguments = null;
                    this.ReleaseLogger();
                }
            }
        }

        protected ServiceType GetService<ServiceType>() where ServiceType: class
        {
            return this.context.GetService<ServiceType>();
        }

        private void HandleMissingTarget(XmlElementContext matchFailureContext, bool existedInOriginal)
        {
            string name = existedInOriginal ? "'{0}' did not find a match, because matching nodes in the source document were modified or removed by a previous transform" : "No element in the source document matches '{0}'";
            string message = string.Format(name, new object[] { matchFailureContext.XPath });
            switch (this.MissingTargetMessage)
            {
                case Microsoft.Web.Publishing.Tasks.MissingTargetMessage.None:
                    this.Log.LogMessage(MessageType.Verbose, message, new object[0]);
                    return;

                case Microsoft.Web.Publishing.Tasks.MissingTargetMessage.Information:
                    this.Log.LogMessage(MessageType.Normal, message, new object[0]);
                    return;

                case Microsoft.Web.Publishing.Tasks.MissingTargetMessage.Warning:
                    this.Log.LogWarning(matchFailureContext.Node, message, new object[0]);
                    return;

                case Microsoft.Web.Publishing.Tasks.MissingTargetMessage.Error:
                    throw new XmlNodeException(message, matchFailureContext.Node);
            }
        }

        private bool HasRequiredTarget()
        {
            XmlElementContext context;
            bool flag = false;
            bool existedInOriginal = false;
            if (this.UseParentAsTargetNode)
            {
                flag = this.context.HasTargetParent(out context, out existedInOriginal);
            }
            else
            {
                flag = this.context.HasTargetNode(out context, out existedInOriginal);
            }
            if (!flag)
            {
                this.HandleMissingTarget(context, existedInOriginal);
                return false;
            }
            return true;
        }

        private void ReleaseLogger()
        {
            if (this.logger != null)
            {
                this.logger.CurrentReferenceNode = null;
                this.logger = null;
            }
        }

        private bool ShouldExecuteTransform()
        {
            return this.HasRequiredTarget();
        }

        private void WriteApplyMessage(XmlNode targetNode)
        {
            IXmlLineInfo info = targetNode as IXmlLineInfo;
            if (info != null)
            {
                this.Log.LogMessage("Applying to '{0}' element (source line {1}, {2})", new object[] { targetNode.Name, info.LineNumber, info.LinePosition });
            }
            else
            {
                this.Log.LogMessage("Applying to '{0}' element (no source line info)", new object[] { targetNode.Name });
            }
        }

        protected bool ApplyTransformToAllTargetNodes
        {
            get
            {
                return this.applyTransformToAllTargetNodes;
            }
            set
            {
                this.applyTransformToAllTargetNodes = value;
            }
        }

        protected IList<string> Arguments
        {
            get
            {
                if ((this.arguments == null) && (this.argumentString != null))
                {
                    this.arguments = XmlArgumentUtility.SplitArguments(this.argumentString);
                }
                return this.arguments;
            }
        }

        protected string ArgumentString
        {
            get
            {
                return this.argumentString;
            }
        }

        protected XmlTransformationLogger Log
        {
            get
            {
                if (this.logger == null)
                {
                    this.logger = this.context.GetService<XmlTransformationLogger>();
                    if (this.logger != null)
                    {
                        this.logger.CurrentReferenceNode = this.context.TransformAttribute;
                    }
                }
                return this.logger;
            }
        }

        protected Microsoft.Web.Publishing.Tasks.MissingTargetMessage MissingTargetMessage
        {
            get
            {
                return this.missingTargetMessage;
            }
            set
            {
                this.missingTargetMessage = value;
            }
        }

        protected XmlNode TargetNode
        {
            get
            {
                if (this.currentTargetNode == null)
                {
                    foreach (XmlNode node in this.TargetNodes)
                    {
                        return node;
                    }
                }
                return this.currentTargetNode;
            }
        }

        protected XmlNodeList TargetNodes
        {
            get
            {
                if (this.UseParentAsTargetNode)
                {
                    return this.context.TargetParents;
                }
                return this.context.TargetNodes;
            }
        }

        private string TransformName
        {
            get
            {
                return base.GetType().Name;
            }
        }

        private string TransformNameLong
        {
            get
            {
                if (this.context.HasLineInfo)
                {
                    return string.Format("{0} (transform line {1}, {2})", new object[] { this.TransformName, this.context.TransformLineNumber, this.context.TransformLinePosition });
                }
                return this.TransformNameShort;
            }
        }

        internal string TransformNameShort
        {
            get
            {
                return string.Format("{0}", new object[] { this.TransformName });
            }
        }

        protected XmlNode TransformNode
        {
            get
            {
                if (this.currentTransformNode == null)
                {
                    return this.context.TransformNode;
                }
                return this.currentTransformNode;
            }
        }

        protected bool UseParentAsTargetNode
        {
            get
            {
                return this.useParentAsTargetNode;
            }
            set
            {
                this.useParentAsTargetNode = value;
            }
        }
    }
}

