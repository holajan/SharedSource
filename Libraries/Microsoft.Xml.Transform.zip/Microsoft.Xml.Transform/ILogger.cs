﻿using System;

namespace Microsoft.Xml.Transform
{
    #region public enum declarations
    public enum LoggerVerbosity
    {
        Quiet,
        Minimal,
        Normal,
        Detailed
    }
    #endregion

    public interface ILogger
    {
        #region member varible and default property initialization
        LoggerVerbosity Verbosity { get; set; }
        #endregion

        #region action methods
        void WriteLine(string message);
        #endregion
    }

    public static class LoggerExtensions
    {
        public static bool IsVerbosityAtLeast(this ILogger logger, LoggerVerbosity checkVerbosity)
        {
            if (logger == null)
            {
                throw new ArgumentNullException("logger");
            }
            return logger.Verbosity >= checkVerbosity;
        }
    }

    public class AnonymousLogger : ILogger
    {
        #region member varible and default property initialization
        public LoggerVerbosity Verbosity { get; set; }

        private Action<string> writeLine;
        #endregion

        #region constructors and destructors
        public AnonymousLogger(Action<string> writeLine)
        {
            if (writeLine == null)
            {
                throw new ArgumentNullException("writeLine");
            }

            this.Verbosity = LoggerVerbosity.Detailed;
            this.writeLine = writeLine;
        }
        #endregion

        #region action methods
        void ILogger.WriteLine(string message)
        {
            this.writeLine(message);
        }
        #endregion
    }
}