using System;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using Microsoft.Build.Shared;
using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;
using Microsoft.Web.Publishing.Tasks;

namespace Microsoft.Xml.Transform
{
    internal enum InputItemType
    {
        File,
        Stream,
        TextReader
    }

    [System.Diagnostics.DebuggerDisplay("{ToString()}")]
    public class InputItem
    {
        #region member varible and default property initialization
        internal InputItemType Type { get; private set; }
        internal string Filename { get; private set; }
        internal Stream InputStream { get; private set; }
        internal TextReader TextReader { get; private set; }
        #endregion

        #region constructors and destructors
        public InputItem(string filename)
        {
            if (filename == null)
            {
                throw new ArgumentNullException("filename");
            }
            this.Type = InputItemType.File;
            this.Filename = filename;
        }

        public InputItem(Stream inputStream) : this(inputStream, null) { }

        public InputItem(Stream inputStream, string name)
        {
            if (inputStream == null)
            {
                throw new ArgumentNullException("inputStream");
            }
            this.Type = InputItemType.Stream;
            this.Filename = name;
            this.InputStream = inputStream;
        }

        public InputItem(TextReader textReader) : this(textReader, null) { }

        public InputItem(TextReader textReader, string name)
        {
            if (textReader == null)
            {
                throw new ArgumentNullException("textReader");
            }
            this.Type = InputItemType.TextReader;
            this.Filename = name;
            this.TextReader = textReader;
        }
        #endregion

        #region action methods
        public override string ToString()
        {
            if (this.Type == InputItemType.File)
            {
                return this.Filename;
            }

            return "{" + ((object)this.InputStream ?? this.TextReader).ToString() + (this.Filename == null ? "" : ": " + this.Filename) + "}";
        }
        #endregion
    }

    internal enum OutputItemType
    {
        File,
        Stream,
        TextWriter
    }

    [System.Diagnostics.DebuggerDisplay("{ToString()}")]
    public class OutputItem
    {
        #region member varible and default property initialization
        internal OutputItemType Type { get; private set; }
        internal string Filename { get; private set; }
        internal Stream OutputStream { get; private set; }
        internal TextWriter TextWriter { get; private set; }
        internal bool LeaveOpen { get; private set; }
        #endregion

        #region constructors and destructors
        public OutputItem(string filename)
        {
            if (filename == null)
            {
                throw new ArgumentNullException("filename");
            }
            this.Type = OutputItemType.File;
            this.Filename = filename;
        }

        public OutputItem(Stream outputStream) : this(outputStream, false, null) { }

        public OutputItem(Stream outputStream, string name) : this(outputStream, false, name) { }

        public OutputItem(Stream outputStream, bool leaveOpen) : this(outputStream, leaveOpen, null) { }

        public OutputItem(Stream outputStream, bool leaveOpen, string name)
        {
            if (outputStream == null)
            {
                throw new ArgumentNullException("outputStream");
            }
            this.Type = OutputItemType.Stream;
            this.Filename = name;
            this.OutputStream = outputStream;
            this.LeaveOpen = leaveOpen;
        }

        public OutputItem(TextWriter textWriter) : this(textWriter, false, null) { }

        public OutputItem(TextWriter textWriter, string name) : this(textWriter, false, name) { }

        public OutputItem(TextWriter textWriter, bool leaveOpen) : this(textWriter, leaveOpen, null) { }

        public OutputItem(TextWriter textWriter, bool leaveOpen, string name)
        {
            if (textWriter == null)
            {
                throw new ArgumentNullException("textWriter");
            }
            this.Type = OutputItemType.TextWriter;
            this.Filename = name;
            this.TextWriter = textWriter;
            this.LeaveOpen = leaveOpen;
        }
        #endregion

        #region action methods
        public override string ToString()
        {
            if (this.Type == OutputItemType.File)
            {
                return this.Filename;
            }

            return "{" + ((object)this.OutputStream ?? this.TextWriter).ToString() + (this.Filename == null ? "" : ": " + this.Filename) + "}";
        }
        #endregion
    }

    public class TransformXml
    {
        #region member types definition
        private class BuildEngine : IBuildEngine
        {
            #region member varible and default property initialization
            private List<ILogger> loggers = null;
            #endregion

            #region constructors and destructors
            public void AddLogger(ILogger logger)
            {
                if (logger == null)
                {
                    return;
                }

                if (this.loggers == null)
                {
                    this.loggers = new List<ILogger>();
                }

                this.loggers.Add(logger);
            }
            #endregion

            #region IBuildEngine Members
            void IBuildEngine.LogMessageEvent(BuildMessageEventArgs e)
            {
                if (this.loggers == null)
                {
                    return;
                }

                foreach (ILogger logger in this.loggers)
                {
                    bool flag = false;
                    switch (e.Importance)
                    {
                        case MessageImportance.High:
                            flag = logger.IsVerbosityAtLeast(LoggerVerbosity.Minimal);
                            break;
                        case MessageImportance.Normal:
                            flag = logger.IsVerbosityAtLeast(LoggerVerbosity.Normal);
                            break;
                        case MessageImportance.Low:
                            flag = logger.IsVerbosityAtLeast(LoggerVerbosity.Detailed);
                            break;
                    }
                    if (flag)
                    {
                        logger.WriteLine(e.Message ?? string.Empty);
                    }
                }
            }

            void IBuildEngine.LogWarningEvent(BuildWarningEventArgs e)
            {
                if (this.loggers == null)
                {
                    return;
                }

                foreach (ILogger logger in this.loggers)
                {
                    logger.WriteLine(EventArgsFormatting.FormatEventMessage(e));
                }
            }

            void IBuildEngine.LogErrorEvent(BuildErrorEventArgs e)
            {
                if (this.loggers == null)
                {
                    return;
                }

                foreach (ILogger logger in this.loggers)
                {
                    logger.WriteLine(EventArgsFormatting.FormatEventMessage(e));
                }
            }
            #endregion
        }
        #endregion

        #region member varible and default property initialization
        public bool StackTrace { get; set; }
        public ILogger Logger { get; set; }
        #endregion

        #region action methods
        public void Execute(InputItem sourceFile, InputItem transformFile, OutputItem destinationFile)
        {
            Execute(sourceFile, transformFile, destinationFile, true);
        }

        public bool Execute(InputItem sourceFile, InputItem transformFile, OutputItem destinationFile, bool throwOnError)
        {
            if (sourceFile == null)
            {
                throw new ArgumentNullException("sourceFile");
            }
            if (transformFile == null)
            {
                throw new ArgumentNullException("transformFile");
            }
            if (destinationFile == null)
            {
                throw new ArgumentNullException("destinationFile");
            }

            var buildEngine = new BuildEngine();
            buildEngine.AddLogger(this.Logger);

            System.Text.StringBuilder sb = null;
            if (throwOnError)
            {
                sb = new System.Text.StringBuilder();
                buildEngine.AddLogger(new AnonymousLogger(message => sb.Append(sb.Length == 0 ? null : "\r\n").Append(message)));
            }

            bool result;
            try
            {
                result = ExecuteInternal(sourceFile, transformFile, destinationFile, buildEngine, throwOnError);
            }
            catch (Exception ex)
            {
                if (throwOnError)
                {
                    throw new XmlTransformationFailedException(ex.Message, sb.ToString(), ex);
                }
                throw;
            }

            if (!result && throwOnError)
            {
                throw new XmlTransformationFailedException("Transformation failed, see log for more details", sb.ToString());
            }
            return result;
        }
        #endregion

        #region private member functions
        private bool ExecuteInternal(InputItem sourceFile, InputItem transformFile, OutputItem destinationFile, BuildEngine buildEngine, bool throwOnError)
        {
            bool flag = true;
            IXmlTransformationLogger logger = new TaskTransformationLogger(new TaskLoggingHelper(buildEngine, typeof(TransformXml).Name), this.StackTrace);
            try
            {
                logger.StartSection(string.Format("Transforming Source File: {0}", new object[] { sourceFile.ToString() }), new object[0]);
                XmlTransformableDocument xmlTarget = this.OpenSourceFile(sourceFile);
                logger.LogMessage(string.Format("Applying Transform File: {0}", new object[] { transformFile.ToString() }), new object[0]);
                flag = this.OpenTransformFile(transformFile, logger).Apply(xmlTarget);
                if (flag)
                {
                    logger.LogMessage(string.Format("Output File: {0}", new object[] { destinationFile.ToString() }), new object[0]);
                    this.SaveTransformedFile(xmlTarget, destinationFile);
                }
            }
            catch (XmlException exception)
            {
                flag = false;
                logger.LogError(ConvertUriToFileName(exception.SourceUri), exception.LineNumber, exception.LinePosition, exception.Message, new object[0]);
                if (throwOnError)
                {
                    throw;
                }
            }
            catch (Exception exception2)
            {
                flag = false;
                logger.LogErrorFromException(exception2);
                if (throwOnError)
                {
                    throw;
                }
            }
            finally
            {
                logger.EndSection(flag ? "Transformation succeeded" : "Transformation failed", new object[0]);
            }
            return flag;
        }

        private XmlTransformableDocument OpenSourceFile(InputItem sourceFile)
        {
            try
            {
                XmlTransformableDocument document = new XmlTransformableDocument();
                document.PreserveWhitespace = true;
                switch (sourceFile.Type)
                {
                    case InputItemType.Stream:
                        document.Load(sourceFile.InputStream);
                        break;
                    case InputItemType.TextReader:
                        document.Load(sourceFile.TextReader);
                        break;
                    default:
                        document.Load(sourceFile.Filename);
                        break;
                }
                return document;
            }
            catch (XmlException)
            {
                throw;
            }
            catch (Exception exception2)
            {
                throw new Exception(string.Format("Could not open Source file: {0}", new object[] { exception2.Message }), exception2);
            }
        }

        private XmlTransformation OpenTransformFile(InputItem transformFile, IXmlTransformationLogger logger)
        {
            try
            {
                switch (transformFile.Type)
                {
                    case InputItemType.Stream:
                        return new XmlTransformation(transformFile.Filename, transformFile.InputStream, logger);
                    case InputItemType.TextReader:
                        return new XmlTransformation(transformFile.Filename, transformFile.TextReader, logger);
                }

                return new XmlTransformation(transformFile.Filename, true, logger);
            }
            catch (XmlException)
            {
                throw;
            }
            catch (Exception exception2)
            {
                throw new Exception(string.Format("Could not open Transform file: {0}", new object[] { exception2.Message }), exception2);
            }
        }

        private void SaveTransformedFile(XmlTransformableDocument document, OutputItem destinationFile)
        {
            try
            {
                switch (destinationFile.Type)
                {
                    case OutputItemType.Stream:
                        document.Save(destinationFile.OutputStream, destinationFile.LeaveOpen);
                        break;
                    case OutputItemType.TextWriter:
                        document.Save(destinationFile.TextWriter, destinationFile.LeaveOpen);
                        break;
                    default:
                        document.Save(destinationFile.Filename);
                        break;
                }
            }
            catch (XmlException)
            {
                throw;
            }
            catch (Exception exception2)
            {
                throw new Exception(string.Format("Could not write Destination file: {0}", new object[] { exception2.Message }), exception2);
            }
        }

        private static string ConvertUriToFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return null;
            }

            try
            {
                Uri uri = new Uri(fileName);
                if (uri.IsFile && string.IsNullOrEmpty(uri.Host))
                {
                    fileName = uri.LocalPath;
                }
            }
            catch (UriFormatException)
            {
                //Ignore exception
            }
            return fileName;
        }
        #endregion
    }
}