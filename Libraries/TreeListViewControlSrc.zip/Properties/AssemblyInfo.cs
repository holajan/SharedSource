﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("TreeListViewControl")]
[assembly: AssemblyDescription("TreeListView Control")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("h2net")]
[assembly: AssemblyProduct("TreeListViewControl")]
[assembly: AssemblyCopyright("Copyright © h2net 2009")]
[assembly: AssemblyTrademark("Copyright © 2009")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d8783071-1cba-4752-95ab-4e511c7717c8")]

[assembly: CLSCompliant(true)]

[assembly: NeutralResourcesLanguageAttribute("en-US")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.*")]
