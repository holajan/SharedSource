﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using System.Windows.Forms.VisualStyles;

namespace IMP.SharedControls
{
    #region public delegates
    /// <summary>
    /// Delegate that handles events on the TreeListView control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void TreeListViewEventHandler(object sender, TreeListViewEventArgs e);

    /// <summary>
    /// Delegate that handles events on the TreeListView control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void TreeListViewCancelEventHandler(object sender, TreeListViewCancelEventArgs e);

    /// <summary>
    /// Delegate that handles events on the TreeListView control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void TreeListViewItemDragEventHandler(object sender, TreeListViewItemDragEventArgs e);

    /// <summary>
    /// Delegate that handles events on the TreeListView control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void TreeListViewItemDropEventHandler(object sender, TreeListViewItemDropEventArgs e);
    #endregion

    #region EventArgs types declarations
    #region TreeListViewEventArgs class
    /// <summary>
    /// Provides data for the TreeListViewEventHandler delegate
    /// </summary>
    public class TreeListViewEventArgs : ContainerListViewEventArgs
    {
		#region member varible and default property initialization
        private TreeViewAction action;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListViewEventArgs.
        /// </summary>
        /// <param name="Node">The TreeListNode that the event is responding to.</param>
        public TreeListViewEventArgs(TreeListNode Node)
            : base(Node)
        {
            this.action = TreeViewAction.Unknown;
        }

        /// <summary>
        /// Creates a new instance of TreeListViewEventArgs.
        /// </summary>
        /// <param name="Node">The TreeListNode that the event is responding to.</param>
        /// <param name="Action">The type of TreeViewAction that raised the event.</param>
        public TreeListViewEventArgs(TreeListNode Node, TreeViewAction Action)
            : base(Node)
        {
            this.action = Action;
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the type of action that raised the event.
        /// </summary>
        public TreeViewAction Action
        {
            get { return this.action; }
        }

        /// <summary>
        /// Gets the TreeListNode that has been checked, expanded, collapsed, or selected.
        /// </summary>
        public new TreeListNode Item
        {
            get { return (TreeListNode)base.Item; }
        }
        #endregion
    }
    #endregion

	#region TreeListViewCancelEventArgs class
    /// <summary>
    /// Provides data for the TreeListViewCancelEventHandler delegate
    /// </summary>
    public class TreeListViewCancelEventArgs : ContainerListViewCancelEventArgs
    {
        #region member varible and default property initialization
        private TreeViewAction action;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListViewCancelEventArgs.
        /// </summary>
        /// <param name="Node">The TreeListNode that the event is responding to.</param>
        /// <param name="Cancel"><c>true</c> to cancel the event; otherwise, <c>false</c>.</param>
        /// <param name="Action">The type of TreeViewAction that raised the event.</param>
        public TreeListViewCancelEventArgs(TreeListNode Node, bool Cancel, TreeViewAction Action)
            : base(Node, Cancel)
        {
            this.action = Action;
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the type of action that raised the event.
        /// </summary>
        public TreeViewAction Action
        {
            get { return this.action; }
        }

        /// <summary>
        /// Gets the TreeListNode that has been checked, expanded, collapsed, or selected.
        /// </summary>
        public new TreeListNode Item
        {
            get { return (TreeListNode)base.Item; }
        }
        #endregion
    }
	#endregion

    #region TreeListViewDragEventArgs class
    /// <summary>
    /// TreeListViewDragEventArgs class
    /// </summary>
    public abstract class TreeListViewDragEventArgs : ItemDragEventArgs
    {
		#region member varible and default property initialization
        private Point mousePosition;
        #endregion

		#region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListViewDragEventArgs
        /// </summary>
        /// <param name="Button">An enumerated MouseButtons value.</param>
        /// <param name="MousePos">The current position of the Mouse pointer in client coordinates.</param>
        /// <param name="Nodes">An array of nodes being dragged.</param>
        protected TreeListViewDragEventArgs(MouseButtons Button, Point MousePos, TreeListNode[] Nodes)
            : base(Button, Nodes)
        {
            this.mousePosition = MousePos;
        }
        #endregion

		#region property getters/setters
        /// <summary>
        /// Gets the TreeListNodes that are being dragged.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public new TreeListNode[] Item
        {
            get { return (TreeListNode[])base.Item; }
        }

        /// <summary>
        /// The current position of the mouse pointer in client coordinates.
        /// </summary>
        public Point MousePosition
        {
            get { return this.mousePosition; }
        }
        #endregion
    }
	#endregion

    #region TreeListViewItemDragEventArgs class
    /// <summary>
    /// Provides data for the TreeListViewItemDragEventHandler delegate
    /// </summary>
    public class TreeListViewItemDragEventArgs : TreeListViewDragEventArgs
    {
		#region member varible and default property initialization
        private bool cancel;
        #endregion

		#region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListViewItemDragEventArgs.
        /// </summary>
        /// <param name="Button">An enumerated MouseButtons value.</param>
        /// <param name="MousePos">The current position of the Mouse pointer in client coordinates.</param>
        /// <param name="Nodes">An array of nodes being dragged.</param>
        public TreeListViewItemDragEventArgs(MouseButtons Button, Point MousePos, TreeListNode[] Nodes)
            : base(Button, MousePos, Nodes) { }

        /// <summary>
        /// Creates a new instance of TreeListViewItemDragEventArgs.
        /// </summary>
        /// <param name="Button">An enumerated MouseButtons value.</param>
        /// <param name="MousePos">The current position of the Mouse pointer in client coordinates.</param>
        /// <param name="Nodes">An array of nodes being dragged.</param>
        /// <param name="Cancel"><c>true</c> to cancel the event; otherwise, <c>false</c>.</param>
        public TreeListViewItemDragEventArgs(MouseButtons Button, Point MousePos, TreeListNode[] Nodes, bool Cancel)
            : base(Button, MousePos, Nodes)
        {
            this.cancel = Cancel;
        }
        #endregion

		#region property getters/setters
        /// <summary>
        /// Gets or sets a value indicating whether the event should be canceled.
        /// </summary>
        public bool Cancel
        {
            get { return this.cancel; }
            set { this.cancel = value; }
        }
        #endregion
    }
    #endregion

    #region TreeListViewItemDropEventArgs class
    /// <summary>
    /// Provides data for the TreeListViewItemDropEventHandler delegate
    /// </summary>
    public class TreeListViewItemDropEventArgs : TreeListViewDragEventArgs
    {
        #region member varible and default property initialization
        private TreeListNode dropNode;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListViewItemDropEventArgs.
        /// </summary>
        /// <param name="Button">An enumerated MouseButtons value.</param>
        /// <param name="MousePos">The current position of the Mouse pointer in client coordinates.</param>
        /// <param name="Nodes">An array of nodes being dragged.</param>
        /// <param name="TargetNode">The TreeListNode the data is being dropped on.</param>
        public TreeListViewItemDropEventArgs(MouseButtons Button, Point MousePos, TreeListNode[] Nodes, TreeListNode TargetNode) : base(Button, MousePos, Nodes)
        {
            this.dropNode = TargetNode;
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the target TreeListNode the data is being dropped on.
        /// </summary>
        public TreeListNode TargetNode
        {
            get { return this.dropNode; }
        }
        #endregion
    }
    #endregion
    #endregion

    #region public types declarations
    #region TreeListNode class
    /// <summary>
    /// Tree node in TreeListView control.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2240:ImplementISerializableCorrectly")]
    [DesignTimeVisible(false), ToolboxItem(false), Serializable, DefaultProperty("Text"), TypeConverter(typeof(TreeListNodeConverter))]
    public class TreeListNode : ContainerListViewObject, ISerializable
    {
        #region public member types
        /// <summary>
        /// TreeListNodeBranch Class
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible")]
        public class TreeListNodeBranch
        {
            #region OriginalValues struct
            [StructLayout(LayoutKind.Sequential)]
            private struct OriginalValues
            {
                private Color backColor;
                private Color foreColor;
                private Font font;
                private bool useItemStyleForSubItems;

                public OriginalValues(Color backColor, Color foreColor, Font font, bool useItemStyleForSubItems)
                {
                    this.backColor = backColor;
                    this.foreColor = foreColor;
                    this.font = font;
                    this.useItemStyleForSubItems = useItemStyleForSubItems;
                }

                public Color BackColor
                {
                    get { return this.backColor; }
                }

                public Font Font
                {
                    get { return this.font; }
                }

                public Color ForeColor
                {
                    get { return this.foreColor; }
                }

                public bool UseItemStyleForSubItems
                {
                    get { return this.useItemStyleForSubItems; }
                }
            }
            #endregion

            #region member varible and default property initialization
            private Color backColor = SystemColors.Highlight;
            private Color foreColor = Color.Blue;
            private Font font;
            private bool highLighted;
            private HybridDictionary mapping;
            private TreeListNode rootNode;
		    #endregion

   		    #region constructors and destructors
            /// <summary>
            /// Creates a new instance of TreeListNodeBranch.
            /// </summary>
            /// <param name="Node">The root TreeListNode of the Branch</param>
            internal TreeListNodeBranch(TreeListNode Node)
            {
                if (Node == null)
                {
                    throw new ArgumentNullException("Node");
                }

                this.rootNode = Node;
                this.font = this.rootNode.Font;
                this.RebuildMapper();
            }
		    #endregion

		    #region action methods
            /// <summary>
            /// Returns every TreeListNode belonging to this branch.
            /// </summary>
            /// <returns>An array of TreeListNodes.</returns>
            public TreeListNode[] GetBranchNodes()
            {
                ArrayList ArrList = new ArrayList();
                ArrList.Add(this.rootNode);

                foreach (TreeListNode item in this.rootNode.Nodes)
	            {
            	    this.FetchBranchNodes(ArrList, item);
	            }

                return (TreeListNode[]) ArrList.ToArray(typeof(TreeListNode));
            }

            /// <summary>
            /// Refreshes all branch TreeListNodes.
            /// </summary>
            public void Refresh()
            {
                this.RefreshMapper();
            }

            /// <summary>
            /// Sets the specified Property on all Branch nodes.
            /// </summary>
            /// <param name="PropertyName">The property name whose value to set on all branch nodes.</param>
            /// <param name="Value">The value to set.</param>
            public void SetProperty(string PropertyName, object Value)
            {
                if (!string.IsNullOrEmpty(PropertyName))
                {
                    PropertyInfo Prop = this.rootNode.GetType().GetProperty(PropertyName);

                    if (Prop != null && Prop.CanWrite)
                    {
                        TreeListNode[] TreeListNodes = this.GetBranchNodes();

                        if (this.rootNode.ListView != null)
                        {
                            this.rootNode.ListView.BeginUpdate();
                        }

                        foreach (TreeListNode TreeListNode in TreeListNodes)
                        {
                            Prop.SetValue(TreeListNode, Value, null);
                        }

                        if (this.rootNode.ListView != null)
                        {
                            this.rootNode.ListView.EndUpdate();
                        }
                    }
                }
            }
		    #endregion

		    #region property getters/setters
            /// <summary>
            /// Gets or Sets a value that determines if the branch should be highlighted or not.
            /// </summary>
            public bool HighLighted
            {
                get { return this.highLighted; }
                set
                {
                    if (!this.highLighted.Equals(value))
                    {
                        this.highLighted = value;

                        if (this.highLighted)
                        {
                            this.RebuildMapper();
                        }

                        this.HighLightChanged();
                    }
                }
            }

            /// <summary>
            /// Gets or Sets the highlighted branch BackColor.
            /// </summary>
            public Color HighLightBackColor
            {
                get { return this.backColor; }
                set
                {
                    if (!this.backColor.Equals(value))
                    {
                        this.backColor = value;

                        if (this.highLighted)
                        {
                            this.HighLightChanged();
                        }
                    }
                }
            }

            /// <summary>
            /// Gets or Sets the highlighted branch ForeColor.
            /// </summary>
            public Color HighLightForeColor
            {
                get { return this.foreColor; }
                set
                {
                    if (!this.foreColor.Equals(value))
                    {
                        this.foreColor = value;

                        if (this.highLighted)
                        {
                            this.HighLightChanged();
                        }
                    }
                }
            }

            /// <summary>
            /// Gets or Sets the highlighted branch Font.
            /// </summary>
            public Font HighLightFont
            {
                get { return this.font; }
                set
                {
                    if (!this.font.Equals(value))
                    {
                        this.font = value;

                        if (this.highLighted)
                        {
                            this.HighLightChanged();
                        }
                    }
                }
            }
    		#endregion

		    #region private member functions
            private void FetchBranchNodes(ArrayList List, TreeListNode Node)
            {
                List.Add(Node);

                foreach (TreeListNode item in Node.Nodes)
	            {
                    this.FetchBranchNodes(List, item);
	            }
            }

            private void HighLightChanged()
            {
                if (this.rootNode.ListView != null)
                {
                    this.rootNode.ListView.BeginUpdate();
                }

                try
                {
                    if (this.highLighted)
                    {
                        foreach (TreeListNode Node in this.mapping.Keys)
                        {
                            Node.UseItemStyleForSubItems = false;
                            Node.BackColor = this.backColor;
                            Node.Font = this.font;
                            Node.ForeColor = this.foreColor;
                        }
                    }
                    else
                    {
                        foreach (TreeListNode Node in this.mapping.Keys)
                        {
                            OriginalValues OV = (OriginalValues)this.mapping[Node];

                            Node.UseItemStyleForSubItems = OV.UseItemStyleForSubItems;
                            Node.backColorValue = OV.BackColor;
                            Node.foreColorValue = OV.ForeColor;
                            Node.fontValue = OV.Font;
                        }
                    }
                }
                finally
                {
                    if (this.rootNode.ListView != null)
                    {
                        this.rootNode.ListView.EndUpdate();
                    }
                }
            }

            private void RebuildMapper()
            {
                TreeListNode[] Nodes = this.GetBranchNodes();

                if (this.mapping == null)
                {
                    this.mapping = new HybridDictionary(Nodes.Length, false);
                }
                else
                {
                    this.mapping.Clear();
                }

                foreach (TreeListNode Node in Nodes)
                {
                    OriginalValues OV = new OriginalValues(Node.backColorValue, Node.foreColorValue, Node.fontValue, Node.UseItemStyleForSubItems);
                    this.mapping.Add(Node, OV);
                }
            }

            private void RefreshMapper()
            {
                if (this.mapping == null || this.mapping.Count == 0)
                {
                    this.RebuildMapper();
                }
                else
                {
                    foreach (TreeListNode Node in this.GetBranchNodes())
                    {
                        if (!this.mapping.Contains(Node))
                        {
                            OriginalValues OV = new OriginalValues(Node.backColorValue, Node.foreColorValue, Node.fontValue, Node.UseItemStyleForSubItems);
                            this.mapping.Add(Node, OV);
                        }
                    }

                    this.HighLightChanged();
                }
            }
		    #endregion
        }
        #endregion

        #region member varible and default property initialization
        private string name;
        private TreeListNodeBranch branch;
        private int childCount;
        private int childVisibleCount;
        private bool expanded;
        private bool isVirtualRoot;
        private TreeListNodeCollection nodes;
        private TreeListNode parent;
        private bool selected;
        private int selectedImageIndex = -1;
        #endregion

		#region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListNode.
        /// </summary>
        public TreeListNode()
        {
            this.InitNodesAndBranches();
        }

        /// <summary>
        /// Creates a new instance of TreeListNode.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        public TreeListNode(string Text)
            : base(Text)
        {
            this.InitNodesAndBranches();
        }

        /// <summary>
        /// Creates a new instance of TreeListNode.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        /// <param name="SubItems">An array of SubItems to add to the new TreeListNode.</param>
        public TreeListNode(string Text, ContainerListViewObject.ContainerListViewSubItem[] SubItems)
            : base(Text)
        {
            this.InitNodesAndBranches();

            if (SubItems != null)
            {
                this.SubItems.AddRange(SubItems);
            }
        }

        /// <summary>
        /// Creates a new instance of TreeListNode.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        /// <param name="ImageIndex">The ImageIndex of the TreeListNode.</param>
        public TreeListNode(string Text, int ImageIndex)
            : base(Text)
        {
            this.ImageIndex = ImageIndex;

            this.InitNodesAndBranches();
        }

        /// <summary>
        /// Creates a new instance of TreeListNode.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        /// <param name="ImageIndex">The ImageIndex of the TreeListNode.</param>
        /// <param name="SelectedImageIndex">The SelectedImageIndex of the TreeListNode.</param>
        public TreeListNode(string Text, int ImageIndex, int SelectedImageIndex)
            : base(Text)
        {
            this.ImageIndex = ImageIndex;
            this.selectedImageIndex = SelectedImageIndex;

            this.InitNodesAndBranches();
        }

        /// <summary>
        /// Creates a new instance of TreeListNode.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        /// <param name="SubItems">An array of SubItems to add to the new TreeListNode.</param>
        /// <param name="ImageIndex">The ImageIndex of the TreeListNode.</param>
        /// <param name="SelectedImageIndex">The SelectedImageIndex of the TreeListNode.</param>
        public TreeListNode(string Text, ContainerListViewObject.ContainerListViewSubItem[] SubItems, int ImageIndex, int SelectedImageIndex)
            : base(Text)
        {
            this.ImageIndex = ImageIndex;
            this.selectedImageIndex = SelectedImageIndex;

            this.InitNodesAndBranches();

            if (SubItems != null)
            {
                this.SubItems.AddRange(SubItems);
            }
        }

        /// <summary>
        /// Creates a new instance of TreeListNode.
        /// </summary>
        /// <param name="Tree">The TreeListView that owns this TreeListNode.</param>
        protected internal TreeListNode(TreeListView Tree)
        {
            if (Tree == null)
            {
                throw new ArgumentNullException("Tree");
            }

            this.isVirtualRoot = true;
            base.OwnerListView = Tree;

            this.InitNodesAndBranches();
        }

        /// <summary>
        /// Initializes a new instance of the TreeListNode class using the specified serialization information and context.
        /// </summary>
        /// <param name="serializationInfo">A System.Runtime.Serialization.SerializationInfo containing the data to deserialize the class.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext containing the source and destination of the serialized stream.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        protected TreeListNode(SerializationInfo serializationInfo, StreamingContext context)
            : this()
        {
            this.Deserialize(serializationInfo, context);
        }
    	#endregion

		#region action methods
        /// <summary>
        /// Check or UnCheck all the nodes in the Node collection.
        /// </summary>
        /// <param name="Checked"><c>true</c> to check all the nodes; otherwise <c>false</c> to uncheck them.</param>
        /// <param name="ImmediateOnly"><c>true</c> to check only the immediate children; otherwise <c>false</c> to check all children.</param>
        public void CheckNodes(bool Checked, bool ImmediateOnly)
        {
            if (base.OwnerListView != null)
            {
                base.OwnerListView.BeginUpdate();
            }

            this.Checked = Checked;

            try
            {
                foreach (TreeListNode item in this.nodes)
	            {
                    item.Checked = Checked;

                    if (!ImmediateOnly)
                    {
                        item.CheckNodes(Checked, ImmediateOnly);
                    }
                }
            }
            finally
            {
                if (base.OwnerListView != null)
                {
                    base.OwnerListView.EndUpdate();
                }
            }
        }

        /// <summary>
        /// Copies the TreeListNode and the entire subtree rooted at this node.
        /// </summary>
        /// <returns>A cloned TreeListNode and it's entire subtree.</returns>
        public override object Clone()
        {
            TreeListNode Node = new TreeListNode();

            Node.name = this.name;
            Node.backColorValue = this.backColorValue;
            Node.foreColorValue = this.foreColorValue;
            Node.fontValue = this.fontValue;
            Node.CheckBoxEnabled = this.CheckBoxEnabled;
            Node.CheckBoxVisible = this.CheckBoxVisible;
            Node.Checked = this.Checked;
            Node.ImageIndex = this.ImageIndex;
            Node.SelectedImageIndex = this.selectedImageIndex;
            Node.Tag = this.Tag;
            Node.Text = this.Text;
            Node.TextAlign = this.TextAlign;
            Node.UseItemStyleForSubItems = this.UseItemStyleForSubItems;

            //Clone child Nodes
            foreach (TreeListNode item in this.nodes)
        	{
                Node.Nodes.Add((TreeListNode)item.Clone());
	        }

            //Clone the SubItems
            foreach (ContainerListViewObject.ContainerListViewSubItem item in this.SubItems)
        	{
                Node.SubItems.Add((ContainerListViewObject.ContainerListViewSubItem)item.Clone());
	        }

            return Node;
        }

        /// <summary>
        /// Collapses the TreeListNode.
        /// </summary>
        public void Collapse()
        {
            if (this.expanded)
            {
                bool Cancel = false;
                if (this.ListView != null)
                {
                    Cancel = this.ListView.TreeListViewBeforeCollapse(this);
                }

                if (!Cancel)
                {
                    this.expanded = false;
                    this.PropagateNodeChange(0, 0 - this.childVisibleCount);

                    if (this.ListView != null)
                    {
                        this.ListView.ChangeSelectionOnCollapse(this);

                        this.ListView.TreeListViewAfterCollapse(this);

                        this.ListView.OnAdjustScrollBars();
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Collapses the current Node and all of its children.
        /// </summary>
        public void CollapseAll()
        {
            foreach (TreeListNode Node in this.nodes)
	        {
        	    Node.CollapseAll();
            }

            this.Collapse();
        }

        /// <summary>
        ///  Expands the current TreeListNode.
        /// </summary>
        public void Expand()
        {
            if (!this.expanded)
            {
                bool Cancel = false;
                if (this.ListView != null)
                {
                    Cancel = this.ListView.TreeListViewBeforeExpand(this);
                }

                if (!Cancel)
                {
                    this.expanded = true;
                    this.childVisibleCount = 0;
                    this.PropagateNodeChange(0, this.GetVisibleNodesCount());

                    if (this.ListView != null)
                    {
                        this.ListView.TreeListViewAfterExpand(this);
                        this.ListView.OnAdjustScrollBars();
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Expands the current TreeListNode and all of its children.
        /// </summary>
        public void ExpandAll()
        {
            this.Expand();

            foreach (TreeListNode Node in this.nodes)
	        {
        	    Node.ExpandAll();
            }
        }

        /// <summary>
        /// Ensures that the tree node is visible, expanding tree nodes and scrolling the TreeListView control as necessary.
        /// </summary>
        public void EnsureVisible()
        {
            if (this.ListView != null)
            {
                this.ListView.EnsureNodeVisible(this);
                this.ListView.Invalidate();
            }
        }

        /// <summary>
        /// Returns the number of child tree nodes.
        /// </summary>
        /// <param name="IncludeSubTrees"><c>true</c> if the resulting count includes all nodes indirectly rooted at this node; otherwise <c>false</c>.</param>
        /// <returns>An integer representing the number of child nodes.</returns>
        public int GetNodeCount(bool IncludeSubTrees)
        {
            if (IncludeSubTrees)
            {
                return this.ChildrenCount;
            }

            return this.Nodes.Count;
        }

        /// <summary>
        /// Returns all the Nodes in the path from the RootNode to the current Node.  The Nodes are indexed in the array starting from the RootNode.
        /// </summary>
        /// <returns>A TreeListNode array containing the Nodes in the path of the current node.</returns>
        public TreeListNode[] GetNodesInPath()
        {
            ArrayList Nodes = new ArrayList();

            //Check to make sure that we don't get the virtual parent (the TreeView's node collection owner) also.
            if (this.HasParent && !this.parent.IsVirtualRootNode)
            {
                Nodes.AddRange(this.parent.GetNodesInPath());
            }

            Nodes.Add(this);

            return (TreeListNode[]) Nodes.ToArray(typeof(TreeListNode));
        }

        /// <summary>
        /// Returns a value that determines if the specified node is a child (direct or indirect) somewhere in this Node's branch.
        /// </summary>
        /// <param name="Node">The TreeListNode to search for in the path of the current node.</param>
        /// <returns><c>true</c> if the specified TreeListNode is in the current node's branch; otherwise <c>false</c> if it is not.</returns>
        /// <remarks>
        /// This is the opposite of IsNodeInPath.  Instead of traversing up the nodes to find the path, this function traverses down (starting from this node) 
        /// to determine if the specified node is a child somewhere in the branch.
        /// </remarks>
        public bool IsNodeInBranch(TreeListNode Node)
        {
            TreeListNode[] NodeArray = this.Branch.GetBranchNodes();

            if (NodeArray != null)
            {
                foreach (TreeListNode Nde in NodeArray)
                {
                    if (Nde == Node)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Returns a value that determines if the specified node is in the path of the current node.
        /// </summary>
        /// <param name="Node">The TreeListNode to search for in the path of the current node.</param>
        /// <returns><c>true</c> if the specified TreeListNode is in the current node's path; otherwise <c>false</c> if it is not.</returns>
        /// <remarks>
        /// This is the opposite of IsNodeInBranch.  Instead of traversing down the nodes to find the path, this function traverses up (starting from this node) 
        /// to determine if the specified node is somewhere in this node's path.
        /// </remarks>
        public bool IsNodeInPath(TreeListNode Node)
        {
            TreeListNode[] NodeArray = this.GetNodesInPath();

            if (NodeArray != null)
            {
                foreach (TreeListNode item in NodeArray)
                {
                    if (item == Node)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Removes the current tree node from the TreeListView control.
        /// </summary>
        public void Remove()
        {
            if (this.HasParent)
            {
                this.parent.Nodes.Remove(this);
            }
        }

        /// <summary>
        /// Checks or unchecks all child TreeListNodes.
        /// </summary>
        /// <param name="Value"><c>true</c> to check the child nodes; otherwise <c>false</c> to uncheck them.</param>
        /// <param name="IncludeAllChildNodes"><c>true</c> to go down and include all child nodes; <c>false</c> to check only the immediate child nodes.</param>
        public void SetChildNodesCheckBox(bool Value, bool IncludeAllChildNodes)
        {
            if (base.OwnerListView != null)
            {
                base.OwnerListView.BeginUpdate();
            }

            this.Checked = Value;
            try
            {
                foreach (TreeListNode item in this.nodes)
                {
                    item.Checked = Value;

                    if (IncludeAllChildNodes)
                    {
                        item.SetChildNodesCheckBox(Value, IncludeAllChildNodes);
                    }
                }
            }
            finally
            {
                if (base.OwnerListView != null)
                {
                    base.OwnerListView.EndUpdate();
                }
            }
        }

        /// <summary>
        /// Toggles the current Node. If the Node is expanded it will collapse and vice-versa.
        /// </summary>
        public void Toggle()
        {
            if (this.expanded)
            {
                this.Collapse();
            }
            else
            {
                this.Expand();
            }
        }

        /// <summary>
        /// Informs the Node (and it's parent) of any changes in it's children.  For internal use only.
        /// </summary>
        /// <param name="TotalCountDelta">The Total number of children.</param>
        /// <param name="VisibleChildrenDelta">The total number of visible children.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void PropagateNodeChange(int TotalCountDelta, int VisibleChildrenDelta)
        {
            this.childCount += TotalCountDelta;
            this.childVisibleCount += VisibleChildrenDelta;

            if (this.HasParent)
            {
                this.parent.PropagateNodeChange(TotalCountDelta, (!this.parent.IsExpanded && !this.parent.isVirtualRoot) ? 0 : VisibleChildrenDelta);
            }
        }

        /// <summary>
        /// Sets the ParentNode of the current Node.
        /// </summary>
        /// <param name="ParentNode">The ParentNode of the current Node.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void SetParentNode(TreeListNode ParentNode)
        {
            if (ParentNode == this)
            {
                throw new ArgumentException("Invalid ParentNode", "ParentNode");
            }

            this.parent = ParentNode;
        }

        /// <summary>
        /// Assigns the TreeView_PA that the Item belongs to.
        /// </summary>
        /// <param name="TreeView">The TreeView that owns the item.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal override void SetParent(ContainerListView TreeView)
        {
            if (TreeView != this.ListView)
            {
                if (this.ListView != null)
                {
                    if (this.Checked)
                    {
                        this.ListView.CheckedItems.Remove(this);
                    }
                    if (this.Selected)
                    {
                        this.ListView.SelectedItems.Remove(this);
                    }
                }
 
                //Assign the tree and add to any necessary collections
                base.OwnerListView = TreeView;

                if (this.ListView != null)
                {
                    if (this.Checked)
                    {
                        this.ListView.CheckedItems.Add(this);
                    }
                    if (this.Selected)
                    {
                        this.ListView.SetSelectedObject(this);

                        this.ListView.SelectedItems.Add(this);
                    }
                }

                //Reset the SubItems
                foreach (ContainerListViewSubItem item in this.SubItems)
	            {
		             item.SetParentOwner(TreeView);
	            }

                //Reset the child Nodes
                foreach (TreeListNode Node in this.nodes)
	            {
                    Node.SetParent(this.ListView);
                }
            }
        }
		#endregion

		#region property getters/setters
        /// <summary>
        /// Gets the child Nodes of the current Node.
        /// </summary>
        [
        Browsable(false), ListBindable(false),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Content)
        ]
        public TreeListNodeCollection Nodes
        {
            get { return this.nodes; }
        }

        /// <summary>
        /// Gets or sets the index of the image that is displayed for the TreeListNode when it is in a selected state.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The index of the image that is displayed for the TreeListNode when it is in a selected state."),
        DefaultValue(-1),
        Localizable(true),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor)),
        TypeConverter(typeof(TreeViewImageIndexConverter)),
        ]
        public int SelectedImageIndex
        {
            get { return this.selectedImageIndex; }
            set
            {
                if (!this.selectedImageIndex.Equals(value))
                {
                    this.selectedImageIndex = value;
                }
            }
        }

        /// <summary>
        /// Gets the zero-based position of the TreeListNode within the TreeListNode collection.
        /// </summary>
        [Browsable(false)]
        public override int Index
        {
            get
            {
                if (this.HasParent)
                {
                    return this.parent.Nodes.IndexOf(this);
                }

                return -1;
            }
        }

        /// <summary>
        /// Gets or sets the name of the tree node.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The name of the tree node.")
        ]
        public string Name
        {
            get
            {
                if (this.name != null)
                {
                    return this.name;
                }

                return "";
            }
            set { this.name = value; }
        }

        /// <summary>
        /// Gets the zero-based Index of the virtual Row the node belongs to in the TreeListView.  This is NOT an index into the TreeListNode collection!
        /// </summary>
        [Browsable(false)]
        public int RowIndex
        {
            get { return this.GetRowIndex(); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the item is selected.
        /// </summary>
        [Browsable(false), DefaultValue(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public override bool Selected
        {
            get { return this.selected; }
            set
            {
                if (this.AllowSelection && !this.selected.Equals(value))
                {
                    bool InvalidTree = this.ListView == null;

                    if (!this.selected)
                    {
                        bool Cancel = false;
                        if (!InvalidTree)
                        {
                            Cancel = this.ListView.ContainerListViewBeforeSelect(this);
                        }

                        if (!Cancel)
                        {
                            this.selected = true;
                            if (!InvalidTree)
                            {
                                this.ListView.SetSelectedObject(this);

                                if (!this.ListView.MultiSelect)
                                {
                                    this.ListView.SelectedItems.Clear();
                                    this.Focused = true;
                                }

                                this.ListView.SelectedItems.Add(this);
                                this.ListView.ContainerListViewAfterSelect(this);
                            }
                        }
                    }
                    else
                    {
                        if (!InvalidTree)
                        {
                            this.ListView.SelectedItems.Remove(this);
                        }

                        this.selected = false;
                    }

                    if (!InvalidTree)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets the branch that this TreeListNode represents (this node and ALL child nodes).
        /// </summary>
        /// <remarks>
        /// A branch consists of the current node and ALL child nodes (recursive) beneath it.  The current TreeListNode is considered the 
        /// root of the branch.
        /// </remarks>
        [Browsable(false)]
        public TreeListNodeBranch Branch
        {
            get { return this.branch; }
        }

        /// <summary>
        /// Gets the zero-based Level the Node is at from the RootNode.
        /// </summary>
        /// <remarks>
        /// For Example, if a Nodes' path is 'One\Two\Three', with 'Three' being the current Node, then the current Node's Level is 2 (not 3) because the levels are zero-based.
        /// You could also look at it as being 2 nodes away from the RootNode.
        /// </remarks>
        [Browsable(false)]
        public int Level
        {
            get { return (this.GetNodesInPath().Length - 1); }
        }

        /// <summary>
        ///  Gets the path from the Root TreeListNode to the current TreeListNode.
        /// </summary>
        [Browsable(false)]
        public string FullPath
        {
            get { return this.GetFullPath(); }
        }

        /// <summary>
        /// Determines if the current TreeListNode has a parent node.
        /// </summary>
        [Browsable(false)]
        public override bool HasParent
        {
            get { return (this.parent != null); }
        }

        /// <summary>
        /// Gets the parent node of the current node.
        /// </summary>
        [Browsable(false)]
        public TreeListNode Parent
        {
            get
            {
                if (this.HasParent && !this.parent.IsVirtualRootNode)
                {
                    return this.parent;
                }

                return null;
            }
        }

        /// <summary>
        /// Gets or Sets the count of all the children.
        /// </summary>
        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        internal int ChildrenCount
        {
            get { return this.childCount; }
            set { this.childCount = value; }
        }

        /// <summary>
        /// Gets a value that determines if a TreeListNode is in an expanded state.
        /// </summary>
        [Browsable(false)]
        public bool IsExpanded
        {
            get { return this.expanded; }
        }

        /// <summary>
        /// Gets or Sets the count of the visible children.
        /// </summary>
        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        internal int VisibleChildren
        {
            get { return this.childVisibleCount; }
            set { this.childVisibleCount = value; }
        }

        /// <summary>
        /// Gets a value that determines if the TreeListNode is a virtual rootNode.
        /// </summary>
        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        protected internal bool IsVirtualRootNode
        {
            get { return this.isVirtualRoot; }
        }

        /// <summary>
        /// Gets a value that determines if the TreeListNode is a root (topmost) Node.
        /// </summary>
        [Browsable(false)]
        public bool IsRootNode
        {
            get
            {
                if (this.HasParent && !this.parent.IsVirtualRootNode)
                {
                    return false;
                }

                return true;
            }
        }

        /// <summary>
        /// The topmost Node that this Node and all Nodes in it's subtree are directly or indirectly rooted to.
        /// </summary>
        [Browsable(false)]
        public TreeListNode RootNode
        {
            get
            {
                TreeListNode[] Arr = this.GetNodesInPath();
                if ((Arr != null) && (Arr.Length > 0))
                {
                    return Arr[0];
                }

                return null;
            }
        }

        /// <summary>
        /// Gets the first Child in the collection.
        /// </summary>
        [Browsable(false)]
        public TreeListNode FirstChildNode
        {
            get
            {
                if (this.nodes.Count > 0)
                {
                    return this.nodes[0];
                }

                return null;
            }
        }

        /// <summary>
        /// Gets the Last child in the list.
        /// </summary>
        [Browsable(false)]
        public TreeListNode LastChildNode
        {
            get
            {
                if (this.nodes.Count > 0)
                {
                    return this.nodes[this.nodes.Count - 1];
                }

                return null;
            }
        }

        /// <summary>
        /// Gets the Next Node in the collection.
        /// </summary>
        [Browsable(false)]
        public TreeListNode NextSiblingNode
        {
            get
            {
                if (this.HasParent && (this.Index < (this.parent.Nodes.Count - 1)))
                {
                    return this.parent.Nodes[this.Index + 1];
                }

                return null;
            }
        }

        /// <summary>
        /// Gets the Previous node in the collection.
        /// </summary>
        [Browsable(false)]
        public TreeListNode PreviousSiblingNode
        {
            get
            {
                if (this.HasParent && (this.Index > 0))
                {
                    return this.parent.Nodes[this.Index - 1];
                }

                return null;
            }
        }

        /// <summary>
        /// Gets the parent TreeListView the TreeListNode is assigned to.
        /// </summary>
        [Browsable(false)]
        public new TreeListView ListView
        {
            get { return (TreeListView)base.OwnerListView; }
        }
		#endregion

		#region private member functions
        private void InitNodesAndBranches()
        {
            if (this.IsVirtualRootNode)
            {
                this.nodes = new TreeListNodeCollection(this, this.ListView);
            }
            else
            {
                this.nodes = new TreeListNodeCollection(this);
            }

            this.branch = new TreeListNodeBranch(this);
        }
     
        private string GetFullPath()
        {
            string Sep = @"\";

            //Get our separator if we are attached to a ListView. otherwise use the default.
            if (base.OwnerListView != null)
            {
                Sep = ((TreeListView)base.OwnerListView).PathSeparator;
            }

            //Check to make sure that we don't get the virtual parent (the TreeView's node collection owner) also.
            if (this.HasParent && !this.parent.IsVirtualRootNode)
            {
                return (this.parent.FullPath + Sep + this.Text);
            }

            return this.Text;
        }

        private int GetRowIndex()
        {
            if (this.ListView == null)
            {
                return -1;
            }

            TreeListNode[] Nodes = this.GetNodesInPath();

            //Tally up the visible nodes prior to this node
            int RowCount = 0;
            for (int i = 0; i <= this.RootNode.Index - 1; i++)
            {
                RowCount += this.ListView.Nodes[i].VisibleChildren + 1;
            }

            for (int i = 0; i <= Nodes.GetUpperBound(0); i++)
            {
                TreeListNode TN = Nodes[i];

                if (i > 0)
                {
                    for (int j = 0; j <= TN.Index - 1; j++)
                    {
                        RowCount += TN.Parent.Nodes[j].VisibleChildren + 1;
                    }

                    RowCount++;
                }
            }

            return RowCount;
        }

        private int GetVisibleNodesCount()
        {
            int VCount = 0;

            foreach (TreeListNode item in this.nodes)
	        {
                //Add the number of expanded nodes beneath this node
                if (item.IsExpanded)
                {
                    VCount += item.VisibleChildren;
                }

                //This node is now visible so add it also
                VCount++;        		 
	        }

            return VCount;
        }
		#endregion

        #region Serializable members
        /// <summary>
        /// Populates a System.Runtime.Serialization.SerializationInfo with the data needed to serialize the target object.
        /// </summary>
        /// <param name="si">The System.Runtime.Serialization.SerializationInfo to populate with data.</param>
        /// <param name="context">The destination (see System.Runtime.Serialization.StreamingContext) for this serialization.</param>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
        void ISerializable.GetObjectData(SerializationInfo si, StreamingContext context)
        {
            this.Serialize(si, context);
        }

        /// <summary>
        /// Saves the state of the TreeListNode to the specified System.Runtime.Serialization.SerializationInfo.
        /// </summary>
        /// <param name="si">The System.Runtime.Serialization.SerializationInfo that describes the TreeListNode.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext that indicates the state of the stream during serialization</param>
        [SecurityPermission(SecurityAction.Demand, Flags = SecurityPermissionFlag.SerializationFormatter), SecurityPermission(SecurityAction.InheritanceDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
        protected virtual void Serialize(SerializationInfo si, StreamingContext context)
        {
            si.AddValue("Text", this.Text);
            si.AddValue("Name", this.Name);

            if (this.backColorValue != Color.Empty)
            {
                si.AddValue("BackColor", this.backColorValue, typeof(Color));
            }
            if (this.foreColorValue != Color.Empty)
            {
                si.AddValue("ForeColor", this.foreColorValue, typeof(Color));
            }
            if (this.fontValue != null)
            {
                si.AddValue("Font", this.fontValue, typeof(Font));
            }
            si.AddValue("TextAlign", this.TextAlign);
            si.AddValue("UseItemStyleForSubItems", this.UseItemStyleForSubItems);
            si.AddValue("CheckBoxEnabled", this.CheckBoxEnabled);
            si.AddValue("CheckBoxVisible", this.CheckBoxVisible);
            si.AddValue("IsChecked", this.Checked);
            si.AddValue("ImageIndex", this.ImageIndex);
            si.AddValue("SelectedImageIndex", this.selectedImageIndex);

            if (this.Tag != null && this.Tag.GetType().IsSerializable)
            {
                si.AddValue("UserData", this.Tag, this.Tag.GetType());
            }

            //SubItems
            si.AddValue("SubItemsCount", this.SubItems.Count);
            if (this.nodes.Count > 0)
            {
                for (int i = 0; i < this.SubItems.Count; i++)
                {
                    si.AddValue("SubItem" + i, this.SubItems[i], typeof(ContainerListViewObject.ContainerListViewSubItem));
                }
            }

            //Child Nodes
            si.AddValue("NodesCount", this.nodes.Count);
            if (this.nodes.Count > 0)
            {
                for (int i = 0; i < this.nodes.Count; i++)
                {
                    si.AddValue("Node" + i, this.nodes[i], typeof(TreeListNode));
                }
            }
        }

        /// <summary>
        /// Loads the state of the TreeListNode from the specified System.Runtime.Serialization.SerializationInfo.
        /// </summary>
        /// <param name="serializationInfo">The System.Runtime.Serialization.SerializationInfo that describes the TreeListNode.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext that indicates the state of the stream during deserialization.</param>
        protected virtual void Deserialize(SerializationInfo serializationInfo, StreamingContext context)
        {
            int SubItemsCount = 0;
            int NodesCount = 0;

            foreach (var item in serializationInfo)
            {
                switch (item.Name)
                {
                    case "Text":
                        this.Text = serializationInfo.GetString(item.Name);
                        break;
                    case "Name":
                        this.name = serializationInfo.GetString(item.Name);
                        break;
                    case "BackColor":
                        this.backColorValue = (Color)item.Value;
                        break;
                    case "ForeColor":
                        this.foreColorValue = (Color)item.Value;
                        break;
                    case "Font":
                        this.fontValue = (Font)item.Value;
                        break;
                    case "UseItemStyleForSubItems":
                        this.UseItemStyleForSubItems = serializationInfo.GetBoolean(item.Name);
                        break;
                    case "TextAlign":
                        this.TextAlign = (HorizontalAlignment)serializationInfo.GetInt32(item.Name);
                        break;
                    case "CheckBoxEnabled":
                        this.CheckBoxEnabled = serializationInfo.GetBoolean(item.Name);
                        break;
                    case "CheckBoxVisible":
                        this.CheckBoxVisible = serializationInfo.GetBoolean(item.Name);
                        break;
                    case "IsChecked":
                        this.Checked = serializationInfo.GetBoolean(item.Name);
                        break;
                    case "ImageIndex":
                        this.ImageIndex = serializationInfo.GetInt32(item.Name);
                        break;
                    case "SelectedImageIndex":
                        this.selectedImageIndex = serializationInfo.GetInt32(item.Name);
                        break;
                    case "UserData":
                        this.Tag = item.Value;
                        break;
                    case "SubItemsCount":
                        SubItemsCount = serializationInfo.GetInt32(item.Name);
                        break;
                    case "NodesCount":
                        NodesCount = serializationInfo.GetInt32(item.Name);
                        break;
                }
            }

            //SubItems
            if (SubItemsCount > 0)
            {
                ContainerListViewObject.ContainerListViewSubItem[] SubItems = new ContainerListViewObject.ContainerListViewSubItem[SubItemsCount];
                for (int i = 0; i < SubItemsCount; i++)
                {
                    SubItems[i] = (ContainerListViewObject.ContainerListViewSubItem)serializationInfo.GetValue("SubItem" + i, typeof(ContainerListViewObject.ContainerListViewSubItem));
                }

                this.SubItems.AddRange(SubItems);
            }

            //Child Nodes
            if (NodesCount > 0)
            {
                TreeListNode[] TreeListNodes = new TreeListNode[NodesCount];
                for (int i = 0; i < NodesCount; i++)
                {
                    TreeListNodes[i] = (TreeListNode)serializationInfo.GetValue("Node" + i, typeof(TreeListNode));
                }

                this.Nodes.AddRange(TreeListNodes);
            }
        }
        #endregion
    }
    #endregion

    #region TreeListNodeCollection class
    /// <summary>
    /// A collection of TreeListNode objects.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
    [Editor(typeof(IMP.SharedControls.Design.TreeListNodeCollectionEditor), typeof(UITypeEditor))]
    public class TreeListNodeCollection : ContainerListViewObjectCollection
    {
        #region member varible and default property initialization
        private TreeListNode parentNode;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListNodeCollection.
        /// </summary>
        /// <param name="ParentNode">The TreeListNode that owns the collection.</param>
        internal TreeListNodeCollection(TreeListNode ParentNode)
        {
            if (ParentNode == null)
            {
                throw new ArgumentNullException("ParentNode");
            }

            this.parentNode = ParentNode;
        }

        /// <summary>
        /// Creates a new instance of TreeListNodeCollection.
        /// </summary>
        /// <param name="VirtualNode">The VirtualRootNode that owns the collection.</param>
        /// <param name="Tree">The TreeListView that the collection is a part of.</param>
        internal TreeListNodeCollection(TreeListNode VirtualNode, TreeListView Tree)
            : base(Tree)
        {
            if (VirtualNode == null)
            {
                throw new ArgumentNullException("VirtualNode");
            }

            if (!VirtualNode.IsVirtualRootNode)
            {
                throw new ArgumentException("The TreeListNode must be a VirtualNode");
            }

            this.parentNode = VirtualNode;
        }
        #endregion

        #region action methods
        /// <summary>
        /// Adds an Item to the collection.
        /// </summary>
        /// <param name="Node">The TreeListNode to add.</param>
        /// <returns>An integer representing the zero-based Index within the collection.</returns>
        public int Add(TreeListNode Node)
        {
            return this.List.Add(Node);
        }

        /// <summary>
        /// Adds an item to the collection.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        /// <returns>A newly created TreeListNode that was just added to the collection.</returns>
        public TreeListNode Add(string Text)
        {
            return Add(Text, -1, -1);
        }

        /// <summary>
        /// Adds an item to the collection.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        /// <param name="ImageIndex">The ImageIndex of the TreeListNode.</param>
        /// <returns>A newly created TreeListNode that was just added to the collection.</returns>
        public TreeListNode Add(string Text, int ImageIndex)
        {
            return Add(Text, ImageIndex, -1);
        }

        /// <summary>
        /// Adds an item to the collection.
        /// </summary>
        /// <param name="Text">The Text of the new TreeListNode.</param>
        /// <param name="ImageIndex">The ImageIndex of the TreeListNode.</param>
        /// <param name="SelectedImageIndex">The SelectedImageIndex of the TreeListNode.</param>
        /// <returns>A newly created TreeListNode that was just added to the collection.</returns>
        public TreeListNode Add(string Text, int ImageIndex, int SelectedImageIndex)
        {
            TreeListNode Node = new TreeListNode(Text, ImageIndex, SelectedImageIndex);
            this.Add(Node);

            return Node;
        }

        /// <summary>
        /// Adds an array of Items.
        /// </summary>
        /// <param name="Nodes">The array of TreeListNodes to add.</param>
        public void AddRange(TreeListNode[] Nodes)
        {
            if (Nodes != null)
            {
                lock (this.List.SyncRoot)
                {
                    for (int i = 0; i <= Nodes.GetUpperBound(0); i++)
                    {
                        this.List.Add(Nodes[i]);
                    }
                }
            }
        }

        /// <summary>
        /// Inserts an Item at the specified position.
        /// </summary>
        /// <param name="Index">The zero-based index at which the item should be inserted.</param>
        /// <param name="Node">The TreeListNode to insert.</param>
        public void Insert(int Index, TreeListNode Node)
        {
            base.List.Insert(Index, Node);
        }

        /// <summary>
        /// Occurs after an add or insert to the collection.
        /// </summary>
        /// <param name="ClObj">The Item that was added.</param>
        /// <param name="Index">The Index where the Item was added.</param>
        protected override void OnAddProcessing(ContainerListViewObject ClObj, int Index)
        {
            base.OnAddProcessing(ClObj, Index);

            TreeListNode Node = (TreeListNode)ClObj;

            //Order is important here! Always set the tree last!
            Node.SetParentNode(this.parentNode);
            if (this.parentNode != null)
            {
                if (this.parentNode.IsVirtualRootNode)
                {
                    Node.SetParent(this.Parent);
                }
                else
                {
                    Node.SetParent(this.parentNode.ListView);
                }

                int ParentVisibleChildren = (!this.parentNode.IsExpanded && !this.parentNode.IsVirtualRootNode) ? 0 : Node.VisibleChildren + 1;
                this.parentNode.PropagateNodeChange(Node.ChildrenCount + 1, ParentVisibleChildren);

                if (base.Parent != null && !base.Parent.InUpdateMode)
                {
                    base.Parent.Invalidate();
                }
            }
        }

        /// <summary>
        /// Does post-processing before an Item has been removed.
        /// </summary>
        /// <param name="index">The Index of the Item that was removed.</param>
        /// <param name="value">The Value of the Item.</param>
        protected override void OnRemove(int index, object value)
        {
            base.OnRemove(index, value);

            if (this.parentNode != null || base.Parent != null)
            {
                TreeListNode Node = (TreeListNode)value;

                if (Node.Selected)
                {
                    TreeListView TV;
                    if (base.Parent != null)
                    {
                        TV = (TreeListView)base.Parent;
                    }
                    else
                    {
                        TV = this.parentNode.ListView;
                    }

                    if (TV != null && !TV.MultiSelect || TV.MultiSelect && Node.Focused)
                    {
                        TreeListNode TempNode = TreeListView.GetPreviousNode(Node);

                        if (TempNode != null)
                        {
                            TempNode.Selected = true;
                            if (!TempNode.Focused)
                            {
                                TempNode.Focused = Node.Focused;
                            }
                        }
                        else
                        {
                            TempNode = TreeListView.GetNextNode(Node);
                            if (TempNode != null)
                            {
                                TempNode.Selected = true;

                                if (!TempNode.Focused)
                                {
                                    TempNode.Focused = Node.Focused;
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Occurs after an Item has been removed from the collection.
        /// </summary>
        /// <param name="CObj"></param>
        protected override void OnRemoveProcessing(ContainerListViewObject CObj)
        {
            TreeListNode Node = (TreeListNode)CObj;

            //Order is important here! Always set the tree last!
            Node.SetParentNode(null);

            base.OnRemoveProcessing(CObj);

            if (this.parentNode != null)
            {
                int ParentVisibleChildren = (!this.parentNode.IsExpanded && !this.parentNode.IsVirtualRootNode) ? 0 : Node.VisibleChildren + 1;
                this.parentNode.PropagateNodeChange(Node.ChildrenCount - 1, -ParentVisibleChildren);

                if (base.Parent != null && !base.Parent.InUpdateMode)
                {
                    base.Parent.Invalidate();
                }
            }
        }

        /// <summary>
        /// Sorts the elements in the entire Collection.
        /// </summary>
        public override void Sort()
        {
            if (this.parentNode != null && this.parentNode.ListView != null)
            {
                if (this.parentNode.ListView.SortComparer == null)
                {
                    this.InnerList.Sort(this.parentNode.ListView.DefaultComparer);
                }
                else
                {
                    this.InnerList.Sort(this.parentNode.ListView.SortComparer);
                }
            }
            else
            {
                base.Sort();
            }
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the number of TreeListNodes in the current collection. This does not include any children of the nodes in the current collection.
        /// </summary>
        public new int Count
        {
            get { return base.List.Count; }
        }

        /// <summary>
        /// Gets or Sets the item in the Collection.
        /// </summary>
        /// <param name="Index">The index of the item to get or set.</param>
        /// <returns></returns>
        public TreeListNode this[int Index]
        {
            get { return (TreeListNode)this.List[Index]; }
            set { this.List[Index] = value; }
        }
        #endregion
    }
    #endregion
    #endregion

    /// <summary>
    /// Represents TreeView / ListView combination control.
	/// </summary>
    /// <remarks>
    /// Treeview/listview hybrid control
    /// Multiple columns treeview or listview with subnodes
    /// </remarks>
	/// <histories>
	/// <history date="07.08.2008" author="Jan Holan">Vytvoření</history>
	/// </histories>
    [
    ToolboxItem(true),
    ToolboxBitmap(typeof(TreeListView), "TreeListView"),
    Description("TreeView / ListView combination control."),
    DefaultProperty("Nodes"),
    DefaultBindingProperty("Text"),
    DefaultEvent("AfterSelect"),
    Designer(typeof(IMP.SharedControls.Design.TreeListViewDesigner))
    ]
    //TODO: ImageIndex, SelectedImageIndex - ImageKey
    //TODO: Nodes properties
    //TODO: Nodes SelectedImageIndex - podle Expand né Selected
    public class TreeListView : ContainerListView
    {
        #region public member types
        #region SelectedTreeListNodeCollection class
        /// <summary>
        /// Strongly typed collection of TreeListNode objects that are in a selected state. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers")]
        public class SelectedTreeListNodeCollection : ICollection, IEnumerable<TreeListNode>
        {
            #region member varible and default property initialization
            private SelectedContainerListViewObjectCollection InnerCollection;
            #endregion

            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of SelectedTreeListNodeCollection.
            /// </summary>
            internal SelectedTreeListNodeCollection(SelectedContainerListViewObjectCollection col)
            {
                if (col == null)
                {
                    throw new ArgumentNullException("col");
                }

                InnerCollection = col;
            }
            #endregion

            #region action methods
            /// <summary>
            /// Returns an enumerator that iterates through the collection instance.
            /// </summary>
            /// <returns>An IEnumerator for the collection instance.</returns>
            public IEnumerator<TreeListNode> GetEnumerator()
            {
                foreach (TreeListNode Node in InnerCollection)
                {
                    yield return Node;
                }
            }

            /// <summary>
            /// Returns an enumerator that iterates through the System.Collections.ReadOnlyCollectionBase instance.
            /// </summary>
            /// <returns>An System.Collections.IEnumerator for the System.Collections.ReadOnlyCollectionBase instance.</returns>
            IEnumerator IEnumerable.GetEnumerator()
            {
                return InnerCollection.GetEnumerator();
            }

            /// <summary>
            /// Copies the entire collection into an existing array at a specified location within the array.
            /// </summary>
            /// <param name="dest">The destination array.</param>
            /// <param name="index">The index in the destination array at which storing begins.</param>
            public void CopyTo(TreeListNode[] dest, int index)
            {
                ((ICollection)this).CopyTo(dest, index);
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets the number of elements contained in the System.Collections.ReadOnlyCollectionBase instance.
            /// </summary>
            public int Count
            {
                get { return InnerCollection.Count; }
            }

            /// <summary>
            /// Gets the Node in the Collection.
            /// </summary>
            /// <param name="Index">The index of the Node to get.</param>
            /// <returns>A TreeListNode at the specified index</returns>
            public TreeListNode this[int Index]
            {
                get { return (TreeListNode)InnerCollection[Index]; }
            }
            #endregion

            #region ICollection Members
            /// <summary>
            /// Copies the entire Collection to the compatible array starting at the specified index.
            /// </summary>
            /// <param name="Array">The Array to copy all Items of the collection to.</param>
            /// <param name="Index">The index to start copying at.</param>
            void ICollection.CopyTo(Array Array, int Index)
            {
                InnerCollection.CopyTo(Array, Index);
            }

            /// <summary>
            /// Gets a value indicating whether access to the System.Collections.ICollection is synchronized (thread safe).
            /// </summary>
            public bool IsSynchronized
            {
                get { return ((ICollection)InnerCollection).IsSynchronized; }
            }

            /// <summary>
            /// Gets an object that can be used to synchronize access to the System.Collections.ICollection.
            /// </summary>
            public object SyncRoot
            {
                get { return ((ICollection)InnerCollection).SyncRoot; }
            }
            #endregion
        }
        #endregion
        #endregion

        #region constants
        private const int cDragScroll = 4;
		#endregion

        #region delegate and events
        /// <summary>
        /// Occurs after the TreeListNode is selected.
        /// </summary>
        public new event TreeListViewEventHandler AfterSelect;

        /// <summary>
        /// Occurs after the TreeListNode has collapsed.
        /// </summary>
        public event TreeListViewEventHandler AfterCollapse;

        /// <summary>
        /// Occurs before the TreeListNode is collapsed.
        /// </summary>
        public event TreeListViewCancelEventHandler BeforeCollapse;

        /// <summary>
        /// Occurs after the TreeListNode has expanded.
        /// </summary>
        public event TreeListViewEventHandler AfterExpand;

        /// <summary>
        /// Occurs before the TreeListNode is expanded.
        /// </summary>
        public event TreeListViewCancelEventHandler BeforeExpand;

        /// <summary>
        /// Occurs when the user begins dragging a node.
        /// </summary>
        public event TreeListViewItemDragEventHandler ItemDrag;

        /// <summary>
        /// Occurs when the user has dropped data on a node.
        /// </summary>
        /// <remarks>
        /// This event will not fire if property AllowDefaultDragDrop = <c>false</c>. This is only a convenience event for the developer so
        /// they don't have to handle the normal DragDrop event during drag operations. Also, it will only fire if the user is
        /// dragging nodes from within the control itself. If you are expecting any outside dragging onto this control, you will have
        /// to handle the normal DragDrop event.
        /// </remarks>
        public event TreeListViewItemDropEventHandler ItemDrop;
        #endregion

        #region events methods
        /// <summary>
        /// Raises the AfterSelect event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnAfterSelect(TreeListViewEventArgs e)
        {
            if (this.AfterSelect != null)
            {
                this.AfterSelect(this, e);
            }
        }

        /// <summary>
        /// Raises the AfterCollapse event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnAfterCollapse(TreeListViewEventArgs e)
        {
            if (this.AfterCollapse != null)
            {
                this.AfterCollapse(this, e);
            }
        }

        /// <summary>
        /// Raises the BeforeCollapse event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnBeforeCollapse(TreeListViewCancelEventArgs e)
        {
            if (this.BeforeCollapse != null)
            {
                this.BeforeCollapse(this, e);
            }
        }

        /// <summary>
        /// Raises the AfterExpand event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnAfterExpand(TreeListViewEventArgs e)
        {
            if (this.AfterExpand != null)
            {
                this.AfterExpand(this, e);
            }
        }

        /// <summary>
        /// Raises the BeforeExpand event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnBeforeExpand(TreeListViewCancelEventArgs e)
        {
            if (this.BeforeExpand != null)
            {
                this.BeforeExpand(this, e);
            }
        }

        /// <summary>
        /// Raises the ItemDrag event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnItemDrag(TreeListViewItemDragEventArgs e)
        {
            if (this.ItemDrag != null)
            {
                this.ItemDrag(this, e);
            }
        }

        /// <summary>
        /// Raises the ItemDrop event.
        /// </summary>
        /// <param name="e"></param>
        /// <remarks>
        /// This method will not fire if property AllowDefaultDragDrop=<c>false</c>. This is only a convenience method for the developer so
        /// they don't have to handle the normal OnDragDrop event during drag operations. Also, it will only fire if the user is 
        /// dragging nodes from within the control itself.  If you are expecting any outside dragging onto this control, you will have 
        /// to handle the normal OnDragDrop method.
        /// </remarks>
        protected virtual void OnItemDrop(TreeListViewItemDropEventArgs e)
        {
            if (this.ItemDrop != null)
            {
                this.ItemDrop(this, e);
            }
        }
        #endregion

        #region member varible and default property initialization
        private bool alwaysShowPM;
        private TreeListNode curNode;
        private int imageIndex;
        private int selectedImageIndex;
        private TreeListViewItemDragEventArgs dragArg;
        private bool fireItemDrag;
        private TreeListNode firstSelectedNode;
        private Hashtable imageRects = new Hashtable();
        private int indent = 19;
        private TreeListNode lastNodeHovered;
        private Bitmap minusBitMap;
        private Bitmap pusBitMap;
        private Hashtable nodeRowRects = new Hashtable();
        private TreeListNodeCollection nodes;
        private string pathDivider = "\\";
        private Hashtable plusMinusRects = new Hashtable();
        private int rendCount;
        private Color rootLineColor = SystemColors.ControlDark;
        private bool showRootLines = true;
        private bool showPlusMinus = true;
        private int totalRend;
        private TreeListNode virtualParent;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// TreeListView control constructor
        /// </summary>
        public TreeListView()
        {
            this.virtualParent = new TreeListNode(this);

            this.RowHeight = 16;
            this.GridLines = GridLineSelections.Column;

            this.nodes = this.virtualParent.Nodes;

            //Initialize the images
            this.minusBitMap = Properties.Resources.Minus;
            this.pusBitMap = Properties.Resources.Plus;
        }
        #endregion

        #region action methods
        /// <summary>
        /// Collapses every TreeListNode in the control.
        /// </summary>
        public void CollapseAll()
        {
            foreach (TreeListNode Node in this.nodes)
            {
                Node.CollapseAll();
            }

            this.Invalidate();
        }

        /// <summary>
        /// Expands every TreeListNode in the control.
        /// </summary>
        public void ExpandAll()
        {
            foreach (TreeListNode Node in this.nodes)
            {
                Node.ExpandAll();
            }

            this.Invalidate();
        }

        /// <summary>
        /// Retrieves the ContainerListViewObject at the specified position.
        /// </summary>
        /// <param name="Point">The Point the ContainerListViewObject is at.</param>
        /// <returns>A ContainerListViewObject; otherwise <c>null</c> if there is no ContainerListViewObject at the specified point.</returns>
        public override ContainerListViewObject GetItemAt(Point Point)
        {
            return GetNodeAt(Point);
        }

        /// <summary>
        /// Retrieves the TreeListNode at the specified position.
        /// </summary>
        /// <param name="Point">The Point the TreeListNode is at.</param>
        /// <returns>A TreeListNode; otherwise <c>null</c> if there is no TreeListNode at the specified point.</returns>
        public TreeListNode GetNodeAt(Point Point)
        {
            IEnumerator Keys = this.nodeRowRects.Keys.GetEnumerator();

            while (Keys.MoveNext())
            {
                Rectangle Rect = (Rectangle)Keys.Current;

                if (Point.X >= Rect.X && Point.X <= Rect.Right && Point.Y >= Rect.Y && Point.Y <= Rect.Bottom - 1)
                {
                    return (TreeListNode)this.nodeRowRects[Rect];
                }
            }

            return null;
        }

        /// <summary>
        /// Retrieves a TreeListNode based upon the specified Path (path must be fully qualified).
        /// </summary>
        /// <param name="NodePath">The Path of the Node to retrieve.</param>
        /// <returns>A TreeListNode object; otherwise <c>null</c> if the node cannot be located within the specified path.</returns>
        public TreeListNode GetNodeAt(string NodePath)
        {
            if (string.IsNullOrEmpty(NodePath))
            {
                return null;
            }

            string NewPath = NodePath.Trim().Replace(this.pathDivider, @"\");
            string[] Path = NewPath.Split(new char[] { '\\' });

            TreeListNode Node = null;
            if (Path != null)
            {
                Node = GetTheNode(this.nodes, Path[0]);

                if (Node != null)
                {
                    for (int i = 1; i <= Path.GetUpperBound(0); i++)
                    {
                        Node = GetTheNode(Node.Nodes, Path[i]);
                        if (Node == null)
                        {
                            return Node;
                        }
                    }
                }
            }

            return Node;
        }

        /// <summary>
        /// Returns the number of child tree nodes.
        /// </summary>
        /// <param name="IncludeSubTrees"><c>true</c> if the resulting count includes all nodes indirectly rooted at this node; otherwise <c>false</c>.</param>
        /// <returns>An integer representing the number of child nodes.</returns>
        public int GetNodeCount(bool IncludeSubTrees)
        {
            if (IncludeSubTrees)
            {
                return this.virtualParent.ChildrenCount;
            }

            return this.Nodes.Count;
        }

        /// <summary>
        /// Selects all the Nodes in the control.
        /// </summary>
        public override void SelectAll()
        {
            if (this.MultiSelect)
            {
                this.BeginUpdate();
                try
                {
                    foreach (TreeListNode Node in this.nodes)
                    {
                        this.SelectAll(Node);
                    }
                }
                finally
                {
                    this.EndUpdate();
                }
            }
        }
        #endregion

        #region internal methods
        /// <summary>
        /// Calls the OnAfterCollapse method.
        /// </summary>
        /// <param name="Node">The TreeListNode calling the method.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void TreeListViewAfterCollapse(TreeListNode Node)
        {
            if (Node != null)
            {
                this.OnAfterCollapse(new TreeListViewEventArgs(Node, TreeViewAction.Collapse));
            }
        }

        /// <summary>
        /// Calls the OnBeforeCollapse method.
        /// </summary>
        /// <param name="Node">The TreeListNode calling the method.</param>
        /// <returns><c>true</c> if the call to the 'OnAfter' equivalent method should be cancelled; othewise <c>false</c>.</returns>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal bool TreeListViewBeforeCollapse(TreeListNode Node)
        {
            if (Node != null)
            {
                TreeListViewCancelEventArgs Arg = new TreeListViewCancelEventArgs(Node, false, TreeViewAction.Collapse);
                this.OnBeforeCollapse(Arg);
                return Arg.Cancel;
            }

            return true;
        }

        /// <summary>
        ///  Calls the OnAfterExpand method.
        /// </summary>
        /// <param name="Node">The TreeListNode calling the method.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void TreeListViewAfterExpand(TreeListNode Node)
        {
            if (Node != null)
            {
                this.OnAfterExpand(new TreeListViewEventArgs(Node, TreeViewAction.Expand));
            }
        }

        /// <summary>
        /// Calls the OnBeforeExpand method.
        /// </summary>
        /// <param name="Node">The TreeListNode calling the method.</param>
        /// <returns><c>true</c> if the call to the 'OnAfter' equivalent method should be cancelled; othewise <c>false</c>.</returns>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal bool TreeListViewBeforeExpand(TreeListNode Node)
        {
            if (Node != null)
            {
                TreeListViewCancelEventArgs Arg = new TreeListViewCancelEventArgs(Node, false, TreeViewAction.Expand);
                this.OnBeforeExpand(Arg);
                return Arg.Cancel;
            }

            return true;
        }

        /// <summary>
        /// Calls after node was Collapsed to change selection if needed
        /// </summary>
        /// <param name="CollapsedNode">The TreeListNode calling the method.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void ChangeSelectionOnCollapse(TreeListNode CollapsedNode)
        {
            if (this.SelectedItems.Count == 0)
            {
                return;
            }

            if (this.SelectedItems.Count < 2)
            {
                //Single selection
                TreeListNode Node = this.curNode;

                while (!Node.IsRootNode)
                {
                    Node = Node.Parent;

                    if (Node == CollapsedNode)
                    {
                        this.curNode = CollapsedNode;

                        this.SelectedItems.Clear();
                        this.curNode.Selected = true;
                        this.curNode.Focused = true;

                        this.ShowSelectedItems();
                        return;
                    }
                }

                return;
            }

            //Multi selection
            int Selected = 0;
            foreach (var ChildNode in CollapsedNode.Branch.GetBranchNodes())
            {
                if (ChildNode.Selected)
                {
                    Selected++;
                }
            }

            if (Selected == this.SelectedItems.Count)
            {
                //All selected nodes are child nodes of CollapsedNode
                this.curNode = CollapsedNode;

                this.SelectedItems.Clear();
                this.curNode.Selected = true;
                this.curNode.Focused = true;

                this.ShowSelectedItems();
                return;
            }
        }

        /// <summary>
        /// Ensures that the Node is visible, expanding tree nodes and scrolling the TreeListView control as necessary.
        /// </summary>
        /// <param name="Node">The TreeListNode calling the method.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void EnsureNodeVisible(TreeListNode Node)
        {
            //Expand tree nodes
            TreeListNode node = Node;
            while (!node.IsRootNode)
            {
                node = node.Parent;
                node.Expand();
            }

            OnAdjustScrollBars();

            //Scroll the TreeListView
            Rectangle Rect = this.ClientRectangle;
            int Pos = Rect.Top + (this.RowHeight * Node.RowIndex) + this.HeaderBuffer - this.VScroll.Value;

            int Var1 = 0;
            if (this.HScroll.Visible)
            {
                Var1 = this.HScroll.Height;
            }

            try
            {
                if (Pos + (this.RowHeight * 2) + Var1 > Rect.Top + Rect.Height)
                {
                    this.VScroll.Value += Math.Abs(Rect.Top + Rect.Height - (Pos + (this.RowHeight * 2) + Var1));
                }
                else if (Pos < Rect.Top + this.HeaderBuffer + 2)
                {
                    this.VScroll.Value -= Math.Abs(Rect.Top + this.HeaderBuffer - Pos);
                }
            }
            catch (System.ArgumentOutOfRangeException)
            {
                if (this.VScroll.Value > this.VScroll.Maximum)
                {
                    this.VScroll.Value = this.VScroll.Maximum;
                }
                else if (this.VScroll.Value < this.VScroll.Minimum)
                {
                    this.VScroll.Value = this.VScroll.Minimum;
                }
            }
        }
        #endregion

        #region property getters/setters
        #region Behavior
        /// <summary>
        /// Gets or Sets a value that determines if Plus and Minus signs are always shown next to each node.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines if Plus and Minus signs are always shown next to each node."),
        DefaultValue(false)
        ]
        public bool AlwaysShowPlusMinus
        {
            get { return this.alwaysShowPM; }
            set
            {
                if (!this.alwaysShowPM.Equals(value))
                {
                    this.alwaysShowPM = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }
        #endregion

        #region Appearance
        /// <summary>
        /// Gets or Sets the foreground color used to display text and graphics in the control.
        /// </summary>
        [
        Description("The foreground color used to display text and graphics in the control."),
        Browsable(true), Category("Appearance"),
        DefaultValue(typeof(Color), "WindowText")
        ]
        public override Color ForeColor
        {
            get { return base.ForeColor; }
            set
            {
                if (!base.ForeColor.Equals(value))
                {
                    base.ForeColor = value;
                }
            }
        }
        
        /// <summary>
        /// Gets or Sets a value that determines the Color used for drawing Root lines of TreeListNodes.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The Color used for drawing Root lines of TreeListNodes."),
        DefaultValue(typeof(Color), "ControlDark")
        ]
        public Color RootLineColor
        {
            get { return this.rootLineColor; }
            set
            {
                if (!this.rootLineColor.Equals(value))
                {
                    this.rootLineColor = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets the default image index to use when creating nodes.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The default image index to use when creating nodes."),
        DefaultValue(0),
        TypeConverter(typeof(ImageIndexConverter)),
        Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor))
        ]
        public int ImageIndex
        {
            get { return this.imageIndex; }
            set
            {
                if (this.imageIndex != value)
                {
                    this.imageIndex = value;
                }
            }
        }

        /// <summary>
        /// Gets or Sets the default selected image index to use when creating nodes.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The default selected image index to use when creating nodes."),
        DefaultValue(0),
        TypeConverter(typeof(ImageIndexConverter)),
        Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor)),
        ]
        public int SelectedImageIndex
        {
            get { return this.selectedImageIndex; }
            set
            {
                if (!this.selectedImageIndex.Equals(value))
                {
                    this.selectedImageIndex = value;
                }
            }
        }

        /// <summary>
        /// Gets or Sets the RowHeight of the Items in the listview.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Sets the RowHeight of the Items in the listview."),
        DefaultValue(16)
        ]
        public new int RowHeight
        {
            get { return base.RowHeight; }
            set { base.RowHeight = value; }
        }

        /// <summary>
        /// Gets or Sets the Indent value of child nodes (in pixels)
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The Indent value of child nodes (in pixels)"),
        DefaultValue(19)
        ]
        public int IndentSize
        {
            get { return this.indent; }
            set
            {
                if (!this.indent.Equals(value))
                {
                    this.indent = Math.Abs(value);
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines if Lines are shown between Root nodes.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines if Lines are shown between Root nodes."),
        DefaultValue(true)
        ]
        public bool ShowRootLines
        {
            get { return this.showRootLines; }
            set
            {
                if (!this.showRootLines.Equals(value))
                {
                    this.showRootLines = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines whether plus/minus signs are shown next to parent nodes.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines whether plus/minus signs are shown next to parent nodes."),
        DefaultValue(true)
        ]
        public bool ShowPlusMinus
        {
            get { return this.showPlusMinus; }
            set
            {
                if (!this.showPlusMinus.Equals(value))
                {
                    this.showPlusMinus = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines which gridlines will be shown.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines which gridlines will be shown."),
        DefaultValue(typeof(GridLineSelections), "Column")
        ]
        public new GridLineSelections GridLines
        {
            get { return base.GridLines; }
            set { base.GridLines = value; }
        }
        #endregion

        #region Data
        /// <summary>
        /// Gets the collection of tree nodes that are assigned to the control.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("The collection of tree nodes that are assigned to the control."),
        MergableProperty(false), Localizable(true),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Content)
        ]
        public TreeListNodeCollection Nodes
        {
            get { return this.nodes; }
        }

        /// <summary>
        /// Gets the Nodes that are selected in the control.
        /// </summary>
        [Browsable(false)]
        public SelectedTreeListNodeCollection SelectedNodes
        {
            get { return new SelectedTreeListNodeCollection(base.SelectedItems); }
        }

        /// <summary>
        /// Gets the currently selected TreeListNode.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TreeListNode FocusedNode
        {
            get { return this.firstSelectedNode; }
            set
            {
                if (value != null)
                {
                    value.Focused = true;
                }
            }
        }

        /// <summary>
        /// Gets or Sets the string to use as the path separator when using the FullPath property on a TreeListNode.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("The string to use as the path separator when using the FullPath property on a TreeListNode."),
        DefaultValue(typeof(string), @"\"),
        ]
        public string PathSeparator
        {
            get { return this.pathDivider; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    this.pathDivider = value;
                }
            }
        }

        ///// <summary>
        ///// This property is not meaningful for this control.
        ///// </summary>
        //[Browsable(false), EditorBrowsable(EditorBrowsableState.Advanced)]
        //public override ContainerListViewItemCollection Items
        //{
        //    get { return null; }
        //}

        ///// <summary>
        ///// This property is not meaningful for this control.
        ///// </summary>
        //[Browsable(false), EditorBrowsable(EditorBrowsableState.Advanced)]
        //public new SelectedIndexCollection SelectedIndexes
        //{
        //    get { return null; }
        //}
        #endregion
        #endregion

        #region private member functions
        #region control overrides
        /// <summary>
        /// This member overrides <see cref="Control.OnFontChanged"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnFontChanged(EventArgs e)
        {
            base.OnFontChanged(e);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnDragDrop"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDragDrop(DragEventArgs e)
        {
            base.MultiSelectMode = ContainerListView.MultiSelectModes.Single;

            base.OnDragDrop(e);

            this.dragArg = null;
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnDragEnter"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDragEnter(DragEventArgs e)
        {
            base.OnDragEnter(e);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnDragLeave"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDragLeave(EventArgs e)
        {
            base.OnDragLeave(e);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnDragOver"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDragOver(DragEventArgs e)
        {
            Point Client = this.PointToClient(new Point(e.X, e.Y));

            //Fire the itemdrag event first here if this is the first time we have hit this on a new drag
            //and the mouse pointer has moved more than 4 pixels in any direction            
            if (this.fireItemDrag)
            {
                int X_Diff = Math.Abs((int)(this.dragArg.MousePosition.X - Client.X));
                int Y_Diff = Math.Abs((int)(this.dragArg.MousePosition.Y - Client.Y));

                if (X_Diff > 4 || Y_Diff > 4)
                {
                    this.fireItemDrag = false;
                    this.OnItemDrag(this.dragArg);

                    //If the drag was cancelled then call OnQuery... to cancel the drag
                    if (this.dragArg.Cancel)
                    {
                        this.OnQueryContinueDrag(new QueryContinueDragEventArgs(e.KeyState, true, DragAction.Cancel));
                        return;
                    }

                    return;
                }
            }
            else
            {
                this.fireItemDrag = false;
            }

            //Scroll if needed
            TreeListNode DropNode = (TreeListNode)this.GetItemAt(Client);

            if (DropNode != null)
            {
                int HScrollSize = 0;
                //Account for the HScroll if it is visible
                if (this.HScroll.Visible)
                {
                    HScrollSize = this.HScroll.Height;
                }

                //If we are near the bottom, scroll down
                if (DropNode.Bounds.Y > this.Height - 30 - HScrollSize)
                {
                    int Val1 = this.VScroll.Value + cDragScroll;
                    if (Val1 > this.VScroll.Maximum)
                    {
                        this.VScroll.Value = this.VScroll.Maximum;
                    }
                    else
                    {
                        this.VScroll.Value = Val1;
                    }
                }
                else if (DropNode.Bounds.Y < 30)
                {
                    int Val2 = this.VScroll.Value - cDragScroll;
                    if (Val2 < this.VScroll.Minimum)
                    {
                        this.VScroll.Value = this.VScroll.Minimum;
                    }
                    else
                    {
                        this.VScroll.Value = Val2;
                    }
                }
            }

            base.OnDragOver(e);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnGiveFeedback"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnGiveFeedback(GiveFeedbackEventArgs e)
        {
            base.OnGiveFeedback(e);
        }

        /// <summary>
        /// This member overrides <see cref="ContainerListView.OnKeyDown"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnKeyDown(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Space:
                    if (this.CheckBoxes)
                    {
                        this.OnSpaceBarKey(e);
                    }
                    return;
                case Keys.Left:
                case Keys.Right:
                    base.OnCheckShiftState(e);
                    this.OnLeftRightKeys(e);
                    return;
            }

            base.OnKeyDown(e);
        }

        /// <summary>
        /// This member overrides <see cref="ContainerListView.OnMouseDown"/>.
        /// </summary>
        /// <param name="e"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.MouseDownProcessRows = false;

            base.OnMouseDown(e);

            if (base.MouseDownProcessRows)
            {
                if (!this.RowsRectangle.Contains(e.X, e.Y))
                {
                    this.SelectedItems.Clear();
                }
                else if (e.Button == MouseButtons.Left || (this.RightMouseSelects && e.Button == MouseButtons.Right))
                {
                    object TestObj = null;
                    TreeListNode Node = null;

                    if (!this.NodeRowClicked(e, ref Node) && !this.ImageClicked(e, ref Node))
                    {
                        if (this.PlusMinusClicked(e, ref Node))
                        {
                            Node.Toggle();
                        }
                        else if (CheckBoxClicked(base.CheckBoxRects, e, ref TestObj) && e.Button == MouseButtons.Left &&
                            ((e.Clicks == 2 && (this.CheckBoxSelection == ItemActivation.Standard || this.CheckBoxSelection == ItemActivation.TwoClick)) ||
                             (e.Clicks == 1 && this.CheckBoxSelection == ItemActivation.OneClick)))
                        {
                            Node = (TreeListNode)TestObj;
                            if (Node.CheckBoxEnabled)
                            {
                                Node.Checked = !Node.Checked;
                            }
                        }
                    }
                    else
                    {
                        switch (base.MultiSelectMode)
                        {
                            case ContainerListView.MultiSelectModes.Single:
                                this.SelectedItems.Clear();
                                this.curNode = Node;
                                this.curNode.Focused = true;
                                this.curNode.Selected = true;

                                if (e.Clicks == 2)
                                {
                                    var Item = this.GetNodeAt(new Point(e.X, e.Y));
                                    if (Item != null)
                                    {
                                        var SubItem = Item.GetSubItemAt(new Point(e.X, e.Y));

                                        ContainerListViewItemEventArgs Arg = new ContainerListViewItemEventArgs(Item, SubItem);
                                        this.OnItemDoubleClick(Arg);

                                        if (Arg.Action == ContainerListViewItemAction.BeginEdit)
                                        {
                                            if (SubItem == null)
                                            {
                                                Item.BeginEdit();
                                            }
                                            else
                                            {
                                                Item.BeginEdit(SubItem);
                                            }
                                        }
                                        else if (Arg.Action == ContainerListViewItemAction.Default)
                                        {
                                            this.curNode.Toggle();
                                        }
                                    }
                                }

                                this.ShowSelectedItems();
                                break;
                            case ContainerListView.MultiSelectModes.Range:
                                this.SelectedItems.Clear();
                                this.curNode = Node;
                                this.ShowSelectedItems();

                                break;
                            case ContainerListView.MultiSelectModes.Selective:
                                if (!Node.Selected)
                                {
                                    Node.Focused = true;
                                    Node.Selected = true;
                                    this.curNode = Node;
                                    break;
                                }

                                Node.Focused = false;
                                Node.Selected = false;

                                break;
                        }

                        if ((!this.MultiSelect || (this.MultiSelect && this.AllowMultiSelectActivation)) &&
                            ((e.Clicks == 1 && this.ActivationType == ItemActivation.OneClick) ||
                             (e.Clicks == 2 && this.ActivationType == ItemActivation.TwoClick)))
                        {
                            this.OnItemActivate(EventArgs.Empty);
                        }
                    }
                }

                this.Invalidate();
            }
        }

        /// <summary>
        /// This member overrides <see cref="ContainerListView.OnMouseLeave"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);

            if (this.lastNodeHovered != null)
            {
                this.lastNodeHovered.Hovered = false;
                this.Invalidate();
            }
        }

        /// <summary>
        /// This member overrides <see cref="ContainerListView.OnMouseMove"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            TreeListNode Node = null;
            if (base.RowsRectangle.Contains(e.X, e.Y) && (this.NodeRowClicked(e, ref Node) || CheckBoxClicked(base.CheckBoxRects, e, ref Node) || this.ImageClicked(e, ref Node) || this.PlusMinusClicked(e, ref Node)))
            {
                if (this.lastNodeHovered != Node)
                {
                    if (this.lastNodeHovered != null)
                    {
                        this.lastNodeHovered.Hovered = false;
                    }

                    this.lastNodeHovered = Node;

                    if (Node != null)
                    {
                        Node.Hovered = true;
                    }
                }
            }
            else
            {
                if (this.lastNodeHovered != null)
                {
                    this.lastNodeHovered.Hovered = false;
                }

                this.lastNodeHovered = null;
            }

            this.Invalidate();
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnQueryContinueDrag"/>.
        /// </summary>
        /// <param name="qcdevent"></param>
        protected override void OnQueryContinueDrag(QueryContinueDragEventArgs qcdevent)
        {
            if (qcdevent.Action == DragAction.Cancel || qcdevent.EscapePressed)
            {
                this.dragArg = null;
                base.MultiSelectMode = ContainerListView.MultiSelectModes.Single;
            }

            base.OnQueryContinueDrag(qcdevent);
        }

        /// <summary>
        /// This member overrides <see cref="ContainerListView.OnResize"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            this.Invalidate();
        }

        /// <summary>
        /// This member overrides <see cref="ContainerListView.OnSpaceBarKey"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnSpaceBarKey(KeyEventArgs e)
        {
            if (e.Shift)
            {
                base.OnSpaceBarKey(e);
            }
            else
            {
                this.SelectedItems.Clear();
                this.firstSelectedNode.Selected = true;

                if (this.firstSelectedNode.CheckBoxVisible && this.firstSelectedNode.CheckBoxEnabled)
                {
                    this.firstSelectedNode.Checked = !this.firstSelectedNode.Checked;
                }

                e.Handled = true;

                this.Invalidate();
            }
        }

        /// <summary>
        /// This member overrides <see cref="ContainerListView.OnAfterSelect"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnAfterSelect(ContainerListViewEventArgs e)
        {
            this.OnAfterSelect(new TreeListViewEventArgs((TreeListNode)e.Item));
        }
        #endregion

        #region custom paint functions
        /// <summary>
        /// Draws the Rows of the control.
        /// </summary>
        /// <param name="g">A Graphics object to draw with.</param>
        /// <param name="bounds">A rectangle to draw in.</param>
        protected override void OnDrawRows(Graphics g, Rectangle bounds)
        {
            if (!this.InUpdateMode && this.nodes.Count > 0 && this.Columns.Count > 0)
            {
                int borderWidth = GetBorderWidth();
                bounds.Inflate(2 - borderWidth, 2 - borderWidth);

                int RenderedSoFar = 0;

                //Determine the total number of nodes that can be rendered in the client rectangle
                int MaxRend;
                if (this.HScroll.Visible)
                {
                    MaxRend = Convert.ToInt32((this.ClientRectangle.Height - this.HeaderBuffer - this.HScroll.Height) / this.RowHeight);
                }
                else
                {
                    MaxRend = Convert.ToInt32((this.ClientRectangle.Height - this.HeaderBuffer) / this.RowHeight);
                }

                //Get the first node to draw
                int Value = this.VScroll.Value;
                if (Value > this.VScroll.Maximum - this.VScroll.LargeChange)
                {
                    Value = this.VScroll.Maximum - this.VScroll.LargeChange;
                }

                TreeListNode NodeDraw = this.FindFirstNode(this.Nodes[0], Value);

                //Clear existing data
                this.totalRend = 0;
                this.nodeRowRects.Clear();
                this.plusMinusRects.Clear();
                base.CheckBoxRects.Clear();
                this.imageRects.Clear();

                //Start drawing the rows
                while (NodeDraw != null && MaxRend > RenderedSoFar)
                {
                    this.RenderNodeRows(NodeDraw, g, bounds, RenderedSoFar);
                    RenderedSoFar++;
                    this.totalRend++;
                    NodeDraw = GetNextNode(NodeDraw);
                }

                //Complete rows drawing to root level
                while (NodeDraw != null)
                {
                    this.RenderNodeRows(NodeDraw, g, bounds, RenderedSoFar);
                    RenderedSoFar++;
                    this.totalRend++;

                    if (NodeDraw.Parent == null)
                    {
                        break;
                    }

                    NodeDraw = GetNextNode(NodeDraw);
                }

                //Refresh the object in an edit state
                if (base.EditedObject != null)
                {
                    base.EditedObject.RefreshEditing();
                }

                //Render the column gridlines
                this.OnDrawColumnGridLines(g);

                this.OnAdjustScrollBars();
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void RenderNodeRows(TreeListNode Node, Graphics g, Rectangle bounds, int TotalRend)
        {
            int EdgeBuffer = 10;
            int HdrBuffer = this.HeaderBuffer;

            Pen LinePen = new Pen(this.RootLineColor, 1f);
            int NodeIndex = Node.Index;
            int NodeLevel = Node.Level;

            Rectangle NodeRect = this.GetCompleteItemBounds(Node);
            Rectangle ItemRect = this.GetItemBounds(Node);

            int LevelBuffer = this.IndentSize * NodeLevel;

            LinePen.DashStyle = DashStyle.Dot;

            this.rendCount++;

            int Count;
            if (Node.Parent == null)
            {
                Count = this.virtualParent.Nodes.Count;
            }
            else
            {
                Count = Node.Parent.Nodes.Count;
            }

            int ChildCount = 0;
            if (Node.PreviousSiblingNode != null)
            {
                ChildCount = Node.PreviousSiblingNode.VisibleChildren;
            }

            int CheckBuffer = 0;
            if (this.CheckBoxes && Node.CheckBoxVisible)
            {
                CheckBuffer = 18;
            }

            int IconBuffer = 0;
            int ImageIndex = 0;
            if (this.ImageList != null)
            {
                if (Node.IsExpanded)
                {
                    ImageIndex = Node.SelectedImageIndex;
                    if (ImageIndex == -1) //Default
                    {
                        ImageIndex = this.selectedImageIndex;
                    }
                }
                else
                {
                    ImageIndex = Node.ImageIndex;
                    if (ImageIndex == -1) //Default
                    {
                        ImageIndex = this.imageIndex;
                    }
                }

                if (ImageIndex >= 0 && ImageIndex < this.ImageList.Images.Count)
                {
                    IconBuffer = 18;
                }
            }

            //Add space for root lines and/or plus-minus icons
            if (this.ShowRootLines || this.ShowPlusMinus)
            {
                EdgeBuffer += 10;
            }

            int EdgeBuffer2 = EdgeBuffer / 2;

            //Add the rectangle to the hash table (for easy lookups later) and then set the clip to that rectangle only
            this.nodeRowRects.Add(NodeRect, Node);

            g.Clip = new Region(NodeRect);

            //Set the selected row rectangle
            Rectangle SelRowRect;
            if (!this.FullRowSelect)
            {
                SelRowRect = ItemRect;
            }
            else if (NodeRect.Width < bounds.Width - 4 || this.HScroll.Visible)
            {
                SelRowRect = NodeRect;
            }
            else
            {
                SelRowRect = new Rectangle(NodeRect.X, NodeRect.Y, bounds.Width - 4, NodeRect.Height);
            }

            //Render item background
            Color ItemBackColor = this.DetermineBackGroundColor(Node, null);

            g.FillRectangle(new SolidBrush(ItemBackColor), ItemRect);

            //Render selected item
            if (this.FullRowSelect && (Node.Selected || Node.Hovered))
            {
                g.FillRectangle(new SolidBrush(ItemBackColor), SelRowRect);
            }

            g.Clip = new Region(new Rectangle(bounds.Left + 2 - this.HScroll.Value, bounds.Top + HdrBuffer + 2, ItemRect.Right, bounds.Height - this.HeaderBuffer - 4));

            int X;
            int Y;
            int X2;
            //Render rootlines if visible
            if (bounds.Left + EdgeBuffer - this.HScroll.Value > bounds.Left && this.showRootLines && NodeLevel == 0)
            {
                bool HasMoreSiblings = Node.NextSiblingNode != null;
                X = bounds.Left + EdgeBuffer2 - this.HScroll.Value;
                X2 = bounds.Left - this.HScroll.Value;

                if (NodeIndex == 0)
                {
                    Y = bounds.Top + EdgeBuffer2 + HdrBuffer;
                    int Y2 = bounds.Top + HdrBuffer;

                    g.DrawLine(LinePen, X, Y, X2 + EdgeBuffer, Y2 + EdgeBuffer2);

                    if (HasMoreSiblings)
                    {
                        g.DrawLine(LinePen, X, Y, X2 + EdgeBuffer2, Y2 + EdgeBuffer);
                    }
                }
                else if (NodeIndex == Count - 1)
                {
                    Y = bounds.Top + HdrBuffer + (this.RowHeight * TotalRend);
                    g.DrawLine(LinePen, X, Y + EdgeBuffer2, X2 + EdgeBuffer, Y + EdgeBuffer2);
                    g.DrawLine(LinePen, X, Y, X2 + EdgeBuffer2, Y + EdgeBuffer2);
                }
                else
                {
                    Y = bounds.Top + EdgeBuffer + HdrBuffer;
                    g.DrawLine(LinePen, X, Y + (this.RowHeight * TotalRend) - EdgeBuffer2, X2 + EdgeBuffer, Y + (this.RowHeight * TotalRend) - EdgeBuffer2);

                    if (HasMoreSiblings)
                    {
                        g.DrawLine(LinePen, X, Y + (this.RowHeight * (TotalRend - 1)), X2 + EdgeBuffer2, Y + (this.RowHeight * TotalRend));
                    }
                }

                if (ChildCount > 0)
                {
                     g.DrawLine(LinePen, X, bounds.Top + HdrBuffer + (this.RowHeight * (TotalRend - ChildCount)), X2 + EdgeBuffer2, bounds.Top + HdrBuffer + (this.RowHeight * TotalRend) + 3);
                }
            }

            //Render child lines if visible
            if (bounds.Left + LevelBuffer + EdgeBuffer - this.HScroll.Value > bounds.Left && this.showRootLines && NodeLevel > 0)
            {
                X = bounds.Left + LevelBuffer + EdgeBuffer2 - this.HScroll.Value;
                X2 = bounds.Left + LevelBuffer - this.HScroll.Value;
                Y = bounds.Top + HdrBuffer + (this.RowHeight * TotalRend) + 2;

                if (NodeIndex == Count - 1)
                {
                    g.DrawLine(LinePen, X, Y - 2 + EdgeBuffer2, X2 + EdgeBuffer, Y - 2 + EdgeBuffer2);
                    g.DrawLine(LinePen, X, Y, X2 + EdgeBuffer2, Y + EdgeBuffer2);
                }
                else
                {
                    g.DrawLine(LinePen, X, Y - 2 + EdgeBuffer2, X2 + EdgeBuffer, Y - 2 + EdgeBuffer2);
                    g.DrawLine(LinePen, X, Y, X2 + EdgeBuffer2, Y + EdgeBuffer);
                }

                if (ChildCount > 0)
                {
                    g.DrawLine(LinePen, X, bounds.Top + HdrBuffer + (this.RowHeight * (TotalRend - ChildCount)), X2 + EdgeBuffer2, Y);
                }
            }

            //Render plus/minus signs if visible
            if (bounds.Left + LevelBuffer + EdgeBuffer2 + 5 - this.HScroll.Value > bounds.Left && this.showPlusMinus && (Node.Nodes.Count > 0 || this.alwaysShowPM))
            {
                X = bounds.Left + LevelBuffer + EdgeBuffer2 - 4 - this.HScroll.Value;
                if (NodeIndex == 0 && NodeLevel == 0)
                {
                    this.RenderPlusMinus(g, X, bounds.Top + HdrBuffer + EdgeBuffer2 - 4, 8, 8, Node);
                }
                else
                {
                    this.RenderPlusMinus(g, X, bounds.Top + HdrBuffer + (this.RowHeight * TotalRend) + EdgeBuffer2 - 4, 8, 8, Node);
                }
            }

            //Draw the checkbox if necessary
            if (CheckBuffer != 0)
            {
                X = bounds.Left + LevelBuffer + EdgeBuffer + 2 - this.HScroll.Value;
                Y = Convert.ToInt32(bounds.Top + HdrBuffer + (this.RowHeight * TotalRend) + (EdgeBuffer / 4) - 3);

                Rectangle CkBxRect = new Rectangle(X, Y, 16, 16);

                this.DrawObjectCheckBox(g, CkBxRect, Node);
                base.CheckBoxRects.Add(CkBxRect, Node);
            }

            //Draw the icon if available
            if (IconBuffer != 0)
            {
                X = bounds.Left + LevelBuffer + EdgeBuffer + CheckBuffer + 2 - this.HScroll.Value;
                Y = Convert.ToInt32(bounds.Top + HdrBuffer + (this.RowHeight * TotalRend) + (EdgeBuffer / 4) - 3);

                g.DrawImage(this.ImageList.Images[ImageIndex], X, Y, 16, 16);
                this.imageRects.Add(new Rectangle(X, Y, 16, 16), Node);
            }

            //Render text if visible
            string TruncText = TruncateString(Node.Text, Node.Font, this.Columns[0].Width - (LevelBuffer + EdgeBuffer + IconBuffer + 4), g);

            if (ItemBackColor.Equals(this.RowSelectColor))
            {
                g.DrawString(TruncText, Node.Font, new SolidBrush(Color.White), (float)(NodeRect.X - 1), (float)(NodeRect.Y + 1));
            }
            else
            {
                g.DrawString(TruncText, Node.Font, new SolidBrush(Node.ForeColor), (float)(NodeRect.X - 1), (float)(NodeRect.Y + 1));
            }

            //Render SubItems
            if (this.Columns.Count > 0)
            {
                for (int j = 0; j < Node.SubItems.Count; j++)
                {
                    if (j < this.Columns.Count - 1)
                    {
                        ContainerListViewObject.ContainerListViewSubItem SubItem = Node.SubItems[j];

                        SolidBrush Brush = new SolidBrush(this.DetermineBackGroundColor(Node, SubItem));
                        Rectangle SIRect = SubItem.Bounds;

                        g.Clip = new Region(SIRect);

                        //Set the offset
                        int Offset = 0;
                        if (this.GridLines == GridLineSelections.Both || this.GridLines == GridLineSelections.Row)
                        {
                            Offset = 1;
                        }

                        //Fill the rectangle
                        g.FillRectangle(Brush, SIRect.X, SIRect.Y, SIRect.Width, SIRect.Height - Offset);

                        if (Node.SubItems[j].Control != null)
                        {
                            Node.SubItems[j].Control.Location = new Point(SIRect.X + 1, SIRect.Y + 1);
                            Node.SubItems[j].Control.ClientSize = new Size(SIRect.Width - 3, SIRect.Height - 3);
                            Node.SubItems[j].Control.Parent = this;
                            Node.SubItems[j].Control.Visible = true;
                            Node.SubItems[j].Control.BringToFront();
                            Node.SubItems[j].Control.Refresh();
                        }
                        else
                        {
                            if (this.FullRowSelect && ItemBackColor.Equals(this.RowSelectColor))
                            {
                                Brush = new SolidBrush(Color.White);
                            }
                            else
                            {
                                Brush = new SolidBrush(SubItem.ForeColor);
                            }

                            Font SubItemFont = SubItem.Font;
                            HorizontalAlignment SubItemAlign = SubItem.TextAlign;

                            string TruncSubItemText = TruncateString(Node.SubItems[j].Text, SubItemFont, SIRect.Width - 9, g);
                            int MDSW = MeasureDisplayString(g, TruncSubItemText, this.Font).Width;

                            //Draw the text
                            if (SubItemAlign == HorizontalAlignment.Left)
                            {
                                int TempInt = 0;
                                if (SIRect.X <= 0)
                                {
                                    TempInt = 2;
                                }        

                                g.DrawString(TruncSubItemText, SubItemFont, Brush, (float)(SIRect.X + 1 + TempInt), (float)(SIRect.Y + 1));
                            }
                            else if (SubItemAlign == HorizontalAlignment.Right)
                            {
                                int OS = 0;
                                if (SubItemFont.Bold)
                                {
                                    OS = 8;
                                }
                                else
                                {
                                    OS = 4;
                                }

                                g.DrawString(TruncSubItemText, SubItemFont, Brush, (float)(SIRect.Right - MDSW - OS - 6), (float)(SIRect.Y + 1));
                            }
                            else
                            {
                                g.DrawString(TruncSubItemText, SubItemFont, Brush, (float)(SIRect.X + ((SIRect.Width - MDSW) / 2) - 1), (float)(SIRect.Y + 1));
                            }
                        }
                    }
                }
            }

            //Render the row gridline
            g.Clip = new Region(new Rectangle(2, NodeRect.Y, this.GetSumOfVisibleColumnWidths() - 1, NodeRect.Height));

            if (this.GridLines == GridLineSelections.Both || this.GridLines == GridLineSelections.Row)
            {
                Pen gridLinePen = new Pen(this.GridLineColor, 1.0f);
                g.DrawLine(gridLinePen, ItemRect.Right, NodeRect.Bottom - 1, NodeRect.Right, NodeRect.Bottom - 1);
            }

            //Render focus
            g.Clip = new Region(NodeRect);

            if (Node.Focused && this.SelectedItems.Count > 1 && this.IsFocused)
            {
                Rectangle FocusRect = this.FullRowSelect ? NodeRect : ItemRect;
                ControlPaint.DrawFocusRectangle(g, FocusRect, Node.ForeColor, Node.BackColor);
            }
        }

        private void RenderPlusMinus(Graphics g, int X, int Y, int Width, int Height, TreeListNode Node)
        {
            if (this.VisualStyles)
            {
                VisualStyleElement VSE;
                if (Node.IsExpanded)
                {
                    VSE = VisualStyleElement.TreeView.Glyph.Opened;
                }
                else
                {
                    VSE = VisualStyleElement.TreeView.Glyph.Closed;
                }

                if (VisualStyleRenderer.IsElementDefined(VSE))
                {
                    VisualStyleRenderer renderer = new VisualStyleRenderer(VSE);
                    Size size = renderer.GetPartSize(g, ThemeSizeType.True);

                    renderer.DrawBackground(g, new Rectangle(X, Y, size.Width, size.Height));

                    this.plusMinusRects.Add(new Rectangle(X, Y, size.Width, size.Height), Node);
                    return;
                }
            }

            if (Node.IsExpanded)
            {
                g.DrawImage(this.minusBitMap, X, Y);
            }
            else
            {
                g.DrawImage(this.pusBitMap, X, Y);
            }

            this.plusMinusRects.Add(new Rectangle(X, Y, Width, Height), Node);
        }
        #endregion

        #region protected methods
        /// <summary>
        /// Returns the bounding Rectangle of the TreeListNode and it's SubItems.
        /// </summary>
        /// <param name="Obj">The TreeListNode whose rectangle to return.</param>
        /// <returns>A bounds rectangle.</returns>
        protected internal override Rectangle GetCompleteItemBounds(ContainerListViewObject Obj)
        {
            if (Obj == null)
            {
                throw new ArgumentNullException("Obj");
            }

            TreeListNode TreeListNode = Obj as TreeListNode;
            if (TreeListNode == null)
            {
                throw new InvalidCastException("Obj must be a TreeListNode");
            }

            return this.GetNodeCompleteBounds(TreeListNode);
        }

        /// <summary>
        /// Returns the bounding Rectangle of the TreeListNode only.
        /// </summary>
        /// <param name="Obj">The TreeListNode whose rectangle to return.</param>
        /// <returns>A bounds rectangle.</returns>
        protected internal override Rectangle GetItemBounds(ContainerListViewObject Obj)
        {
            if (Obj == null)
            {
                throw new ArgumentNullException("Obj");
            }

            TreeListNode TreeListNode = Obj as TreeListNode;
            if (TreeListNode == null)
            {
                throw new InvalidCastException("Obj must be a TreeListNode");
            }

            return this.GetNodeBounds(TreeListNode);
        }

        /// <summary>
        /// Gets the Next node relative to the specified node.
        /// </summary>
        /// <param name="Node">The Node whose next node to retrieve.</param>
        /// <returns>A TreeListNode; otherwise <c>null</c> if no node can be found.</returns>
        protected internal static TreeListNode GetNextNode(TreeListNode Node)
        {
            if (Node == null)
            {
                return null;
            }

            if (Node.IsExpanded && Node.Nodes.Count > 0)
            {
                return Node.FirstChildNode;
            }

            if (Node.NextSiblingNode != null)
            {
                return Node.NextSiblingNode;
            }

            if (Node.NextSiblingNode != null)
            {
                return Node.RootNode.NextSiblingNode;
            }

            TreeListNode[] Nodes = Node.GetNodesInPath();
            if (Nodes != null)
            {
                for (int i = Nodes.GetUpperBound(0); i >= 0; i += -1)
                {
                    TreeListNode Nde = Nodes[i];
                    if (Nde != Node && Nde.NextSiblingNode != null)
                    {
                        return Nde.NextSiblingNode;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the Prior node relative to the specified node.
        /// </summary>
        /// <param name="Node">The Node whose prior node to retrieve.</param>
        /// <returns>A TreeListNode; otherwise <c>null</c> if no previous node can be found.</returns>
        protected internal static TreeListNode GetPreviousNode(TreeListNode Node)
        {
            if (Node == null)
            {
                return null;
            }

            if (Node.PreviousSiblingNode == null && Node.Parent != null)
            {
                return Node.Parent;
            }

            if (Node.PreviousSiblingNode != null)
            {
                TreeListNode TempNode = Node.PreviousSiblingNode;
                if (TempNode.Nodes.Count <= 0 || !TempNode.IsExpanded)
                {
                    return Node.PreviousSiblingNode;
                }

                do
                {
                    TempNode = TempNode.LastChildNode;
                    if (!TempNode.IsExpanded || (TempNode.Nodes.Count == 0))
                    {
                        return TempNode;
                    }
                }
                while (TempNode.Nodes.Count > 0 && TempNode.IsExpanded);
            }

            return null;
        }

        /// <summary>
        /// Occurs when the ScrollBars need to be setup and displayed by the control.
        /// </summary>
        protected internal override void OnAdjustScrollBars()
        {
            this.AdjustScrollBars();
        }

        /// <summary>
        /// Handles the Left or Right arrow KeyPress of the control which either expand or collapse the current node.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnLeftRightKeys(KeyEventArgs e)
        {
            if (this.nodes.Count > 0 && this.curNode != null)
            {
                switch (e.KeyCode)
                {
                    case Keys.Left:
                        if (this.curNode.Nodes.Count == 0 && this.curNode.IsExpanded)
                        {
                            this.curNode.Collapse();
                        }

                        if (!this.curNode.IsExpanded)
                        {
                            if (this.curNode.Parent != null)
                            {
                                this.curNode = this.curNode.Parent;
                            }
                            break;
                        }
                        this.curNode.Collapse();
                        break;
                    case Keys.Right:
                        if (this.curNode.Nodes.Count == 0)
                        {
                            break;
                        }

                        if (this.curNode.IsExpanded)
                        {
                            if (this.curNode.FirstChildNode != null)
                            {
                                this.curNode = this.curNode.FirstChildNode;
                            }
                            break;
                        }
                        this.curNode.Expand();
                        break;
                }

                if (base.MultiSelectMode != ContainerListView.MultiSelectModes.Range)
                {
                    this.SelectedItems.Clear();
                    this.curNode.Selected = true;
                    this.curNode.Focused = true;
                }

                this.ShowSelectedItems();

                e.Handled = true;

                this.AdjustScrollBars();
                this.Invalidate();
            }
        }

        /// <summary>
        /// Occurs when a TreeListNode in the collection has been added, removed, or changed.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnNodesChanged(TreeListViewEventArgs e)
        {
            this.AdjustScrollBars();
        }

        /// <summary>
        /// Occurs when the PageUp, PageDown, Home, or End Keys are pressed.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPageKeys(KeyEventArgs e)
        {
            TreeListNode Node = null;

            if (this.nodes.Count > 0)
            {
                switch (e.KeyCode)
                {
                    case Keys.Home:
                        Node = this.nodes[0];
                        break;
                    case Keys.End:
                        Node = this.nodes[this.nodes.Count - 1];
                        while (Node.IsExpanded)
                        {
                            Node = Node.Nodes[Node.Nodes.Count - 1];
                        }

                        break;
                    case Keys.PageUp:
                        Node = this.curNode;
                        
                        for (int i = 0; i < Convert.ToInt32((this.VScroll.LargeChange - this.VScroll.SmallChange) / this.RowHeight); i++)
			            {
                            var NewNode = GetPreviousNode(Node);
                            if (NewNode == null)
                            {
                                break;
                            }

                            Node = NewNode;
                        }
                        break;
                    case Keys.PageDown:
                        Node = this.curNode;
                        
                        for (int i = 0; i < Convert.ToInt32((this.VScroll.LargeChange - this.VScroll.SmallChange) / this.RowHeight); i++)
			            {
                            var NewNode = GetNextNode(Node);
                            if (NewNode == null)
                            {
                                break;
                            }

                            Node = NewNode;
                        }
                        break;
                }
            }

            if (Node != null && Node != this.curNode)
            {
                this.curNode = Node;

                if (base.MultiSelectMode != ContainerListView.MultiSelectModes.Range)
                {
                    this.SelectedItems.Clear();
                    this.curNode.Selected = true;
                    this.curNode.Focused = true;
                }

                this.ShowSelectedItems();
                this.Invalidate();
            }

            e.Handled = true;
        }

        /// <summary>
        /// Occurs on the MouseDown when the control is checking to see if a ColumnHeader was clicked.
        /// </summary>
        /// <param name="ColIndex">The index of the ColumnHeader that is currently being checked/processed.</param>
        /// <returns>Largest TextWidth (the largest string processed).</returns>
        protected override int GetAutoSizeColWidth(int ColIndex)
        {
            return GetAutoSizeColWidth(this.nodes, ColIndex);
        }

        /// <summary>
        /// Sets selection to the specified object.
        /// </summary>
        /// <param name="ClObj">The ContainerListViewObject to set selection to.</param>
        protected override void OnSetSelectedObject(ContainerListViewObject ClObj)
        {
            if (base.MultiSelectMode != ContainerListView.MultiSelectModes.Range)
            {
                this.curNode = (TreeListNode)ClObj;
            }
        }

        /// <summary>
        /// Sets focus to the selected TreeListNode.
        /// </summary>
        /// <param name="ClObj">The TreeListNode to set focus to.</param>
        protected override void OnSetFocusedObject(ContainerListViewObject ClObj)
        {
            if (this.firstSelectedNode != null)
            {
                this.firstSelectedNode.Focused = false;
            }

            this.firstSelectedNode = (TreeListNode)ClObj;
        }

        /// <summary>
        /// Occurs when the control needs to be sorted.
        /// </summary>
        /// <param name="Index">The zero-based index of the column to sort on.</param>
        protected override void OnSort(int Index)
        {
            this.nodes.Sort();
        }

        /// <summary>
        /// Occurs when the Up or Down Keys are pressed.
        /// </summary>
        /// <param name="e">A KeyEventArgs.</param>
        protected override void OnUpDownKeys(KeyEventArgs e)
        {
            TreeListNode Node = null;
            switch (e.KeyCode)
            {
                case Keys.Up:
                    Node = GetPreviousNode(this.curNode);
                    break;
                case Keys.Down:
                    Node = GetNextNode(this.curNode);
                    break;
            }

            if (Node != null && Node != this.curNode)
            {
                this.curNode = Node;

                if (base.MultiSelectMode != ContainerListView.MultiSelectModes.Range)
                {
                    this.SelectedItems.Clear();
                    this.curNode.Selected = true;
                    this.curNode.Focused = true;
                }

                this.ShowSelectedItems();
                this.Invalidate();

                e.Handled = true;
            }
        }

        /// <summary>
        /// Determines if Plus or Minus was clicked.
        /// </summary>
        /// <param name="e">The MouseEventArg containing the data.</param>
        /// <param name="Node">A Node (can be <c>null</c>) to assist in evaluation.</param>
        /// <returns><c>true</c> if a Plus or Minus was clicked; otherwise <c>false</c>.</returns>
        /// <remarks>
        /// Node will be set to the Node the plus or minus was clicked on.
        /// </remarks>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1045:DoNotPassTypesByReference", MessageId = "1#")]
        protected internal bool PlusMinusClicked(MouseEventArgs e, ref TreeListNode Node)
        {
            if (this.plusMinusRects != null)
            {
                Node = (TreeListNode)EvaluateObject(e, this.plusMinusRects.Keys.GetEnumerator(), this.plusMinusRects.Values.GetEnumerator());
                if (Node != null)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region custom functions
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void AdjustScrollBars()
        {
            if (this.nodes != null && (this.nodes.Count > 0 || (this.Columns.Count > 0 && !base.ColumnScaleMode)))
            {
                int ColsWidth = base.GetSumOfVisibleColumnWidths();
                Rectangle Rect = this.ClientRectangle;
                int borderWidth = GetBorderWidth();
                Rect.Inflate(-borderWidth, -borderWidth);

                int RowsHeight = this.RowHeight * this.virtualParent.VisibleChildren;

                //Set the VScrollBar
                this.VScroll.Left = Rect.Left + Rect.Width - this.VScroll.Width;
                this.VScroll.Top = Rect.Top;
                this.VScroll.SmallChange = this.RowHeight;
                this.VScroll.Maximum = RowsHeight;

                //Set the HScrollBar
                this.HScroll.Left = Rect.Left;
                this.HScroll.Top = Rect.Top + Rect.Height - this.HScroll.Height;
                try
                {
                    if (this.Columns.Count > 0)
                    {
                        this.HScroll.SmallChange = ColsWidth / this.Columns.Count;
                    }
                    else
                    {
                        this.HScroll.SmallChange = 0;
                    }
                }
                catch (System.ArgumentOutOfRangeException)
                {
                    this.HScroll.SmallChange = 0;
                }

                this.HScroll.Maximum = ColsWidth;

                bool ShowVert = this.Scrollable && RowsHeight > Rect.Height - this.HeaderBuffer;
                int HorizVal = Rect.Width - (ShowVert ? this.VScroll.Width : 0);
                bool ShowHoriz = this.Scrollable && ColsWidth > HorizVal;
                int VertVal = Rect.Height - this.HeaderBuffer - (ShowHoriz ? this.HScroll.Height : 0);
                ShowVert = this.Scrollable && RowsHeight > VertVal;
                HorizVal = Rect.Width - (ShowVert ? this.VScroll.Width : 0);

                //Set scroll specifics
                if (ShowVert && ShowHoriz)
                {
                    this.VScroll.Height = VertVal + this.HeaderBuffer;
                    if (VertVal > 0)
                    {
                        this.VScroll.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.VScroll.LargeChange = 0;
                    }

                    this.HScroll.Width = HorizVal;

                    if (HorizVal > 0)
                    {
                        this.HScroll.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.HScroll.LargeChange = 0;
                    }

                    if (this.Scrollable)
                    {
                        this.VScroll.Show();
                        this.HScroll.Show();
                    }
                }
                else if (ShowVert && !ShowHoriz)
                {
                    this.HScroll.Hide();
                    this.HScroll.Value = 0;

                    if (HorizVal > 0)
                    {
                        this.HScroll.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.HScroll.LargeChange = 0;
                    }

                    this.VScroll.Height = VertVal + this.HeaderBuffer;

                    if (VertVal > 0)
                    {
                        this.VScroll.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.VScroll.LargeChange = 0;
                    }

                    if (this.Scrollable)
                    {
                        this.VScroll.Show();
                    }
                }
                else if (ShowHoriz && !ShowVert)
                {
                    this.VScroll.Hide();
                    this.VScroll.Value = 0;

                    if (VertVal > 0)
                    {
                        this.VScroll.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.VScroll.LargeChange = 0;
                    }

                    this.HScroll.Width = HorizVal;

                    if (HorizVal > 0)
                    {
                        this.HScroll.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.HScroll.LargeChange = 0;
                    }

                    if (this.Scrollable)
                    {
                        this.HScroll.Show();
                    }
                }
                else
                {
                    this.VScroll.Hide();
                    this.VScroll.Value = 0;

                    if (VertVal > 0)
                    {
                        this.VScroll.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.VScroll.LargeChange = 0;
                    }

                    this.HScroll.Hide();
                    this.HScroll.Value = 0;

                    if (HorizVal > 0)
                    {
                        this.HScroll.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.HScroll.LargeChange = 0;
                    }
                }
            }
        }

        private static int GetAutoSizeColWidth(TreeListNodeCollection NodeColl, int ColIndex)
        {
            int AutoSizeWidth = 0;
            for (int i = 0; i <= NodeColl.Count - 1; i++)
            {
                TreeListNode Node = NodeColl[i];

                int TextWidth = 0;
                if (ColIndex == 0)
                {
                    TextWidth = MeasureDisplayString(Node.Text, Node.Font).Width + Node.Bounds.Left + 4;
                }
                else if (ColIndex > 0 && ColIndex <= Node.SubItems.Count)
                {
                    TextWidth = MeasureDisplayString(Node.SubItems[ColIndex - 1].Text, Node.SubItems[ColIndex - 1].Font).Width + 8;
                }

                if (TextWidth > AutoSizeWidth)
                {
                    AutoSizeWidth = TextWidth;
                }

                if (Node.IsExpanded && Node.Nodes.Count > 0)
                {
                    TextWidth = GetAutoSizeColWidth(Node.Nodes, ColIndex);

                    if (TextWidth > AutoSizeWidth)
                    {
                        AutoSizeWidth = TextWidth;
                    }
                }
            }

            return AutoSizeWidth;
        }

        private TreeListNode FindFirstNode(TreeListNode StartingNode, int StartingPoint)
        {
            int ChildrenCount = StartingNode.VisibleChildren;

            if (this.RowHeight * ChildrenCount < StartingPoint)
            {
                return this.FindFirstNode(StartingNode.NextSiblingNode, StartingPoint - ((ChildrenCount + 1) * 16));
            }

            TreeListNode Node = StartingNode;

            for (int i = 1; i <= (StartingPoint / this.RowHeight); i++)
            {
                Node = GetNextNode(Node);
            }

            return Node;
        }

        private Rectangle GetNodeBounds(TreeListNode Node)
        {
            if (!(this.Columns.Count > 0) || this.Columns[0].Hidden)
            {
                return Rectangle.Empty;
            }

            //See if we already have the rectangle
            foreach (Rectangle RT in this.nodeRowRects.Keys)
            {
                if (((TreeListNode)this.nodeRowRects[RT]) == Node)
                {
                    return new Rectangle(RT.X, RT.Y, this.Columns[0].Width - RT.X, RT.Height);
                }
            }
        
            int EdgeBuffer = 10;
            int LevelBuffer = this.indent * Node.Level;
            Rectangle Rect = this.ClientRectangle;

            if (this.showRootLines || this.showPlusMinus)
            {
                EdgeBuffer += 10;
            }

            int CheckBuffer = 0;
            if (this.CheckBoxes && Node.CheckBoxVisible)
            {
                CheckBuffer = 18;
            }

            int ImageIndex;
            if (Node.Selected || Node.Focused)
            {
                ImageIndex = Node.SelectedImageIndex;
                if (ImageIndex == -1) //Default
                {
                    ImageIndex = this.selectedImageIndex;
                }
            }
            else
            {
                ImageIndex = Node.ImageIndex;
                if (ImageIndex == -1) //Default
                {
                    ImageIndex = this.imageIndex;
                }
            }

            int IconBuffer = 0;
            if (this.ImageList != null && ImageIndex >= 0 && ImageIndex < this.ImageList.Images.Count)
            {
                IconBuffer = 18;
            }

            //Now calculate the coordinates and create the rectangle
            int Xpos = Rect.Left + LevelBuffer + CheckBuffer + IconBuffer + EdgeBuffer + 4 - this.HScroll.Value;
            int Ypos = Rect.Top + this.HeaderBuffer + (this.RowHeight * this.totalRend) + 2;

            return new Rectangle(Xpos, Ypos, this.Columns[0].Bounds.Width - Xpos, this.RowHeight);
         }

        private Rectangle GetNodeCompleteBounds(TreeListNode Node)
        {
            //See if we already have the rectangle
            foreach (Rectangle RT in this.nodeRowRects.Keys)
	        {
                if (((TreeListNode)this.nodeRowRects[RT]) == Node)
                {
        		    return RT;
                }
	        }

            int Sum = this.GetSumOfVisibleColumnWidths();
            if (Sum <= 0)
            {
                return Rectangle.Empty;
            }

            int EdgeBuffer = 10;
            int LevelBuffer = this.indent * Node.Level;
            Rectangle Rect = this.ClientRectangle;

            if (this.showRootLines || this.showPlusMinus)
            {
                EdgeBuffer += 10;
            }

            int CheckBuffer = 0;
            if (this.CheckBoxes && Node.CheckBoxVisible)
            {
                CheckBuffer = 18;
            }

            int ImageIndex;
            if (Node.Selected || Node.Focused)
            {
                ImageIndex = Node.SelectedImageIndex;
                if (ImageIndex == -1) //Default
                {
                    ImageIndex = this.selectedImageIndex;
                }
            }
            else
            {
                ImageIndex = Node.ImageIndex;
                if (ImageIndex == -1) //Default
                {
                    ImageIndex = this.imageIndex;
                }
            }

            int IconBuffer = 0;
            if (this.ImageList != null && ImageIndex >= 0 && ImageIndex < this.ImageList.Images.Count)
            {
                IconBuffer = 18;
            }

            //Now calculate the coordinates and create the rectangle
            int Xpos = Rect.Left + LevelBuffer + CheckBuffer + IconBuffer + EdgeBuffer + 4 - this.HScroll.Value;
            int Ypos = Rect.Top + this.HeaderBuffer + (this.RowHeight * this.totalRend) + 2;

            return new Rectangle(Xpos, Ypos, Sum - Xpos, this.RowHeight);
        }

        private static TreeListNode GetTheNode(TreeListNodeCollection Nodes, string Text)
        {
            foreach (TreeListNode Node in Nodes)
	        {
                if (string.Equals(Node.Text.Trim(), Text.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    return Node;
                }  		 
	        }

            return null;
        }

        private bool ImageClicked(MouseEventArgs e, ref TreeListNode Node)
        {
            if (this.imageRects == null)
            {
                return false;
            }

            Node = (TreeListNode)EvaluateObject(e, this.imageRects.Keys.GetEnumerator(), this.imageRects.Values.GetEnumerator());
            if (Node == null)
            {
                return false;
            }

            return true;
        }

        private void MakeSelectedVisible()
        {
            if (this.curNode == null || !this.Scrollable || !this.curNode.Selected)
            {
                return;
            }

            Rectangle Rect = this.ClientRectangle;
            int Pos = Rect.Top + (this.RowHeight * this.curNode.RowIndex) + this.HeaderBuffer - this.VScroll.Value;
            
            int Var1 = 0;
            if (this.HScroll.Visible)
            {
                Var1 = this.HScroll.Height;
            }

            try
            {
                if (Pos + (this.RowHeight * 2) + Var1 > Rect.Top + Rect.Height)
                {
                    this.VScroll.Value += Math.Abs(Rect.Top + Rect.Height - (Pos + (this.RowHeight * 2) + Var1));
                }
                else if (Pos < Rect.Top + this.HeaderBuffer + 2)
                {
                    this.VScroll.Value -= Math.Abs(Rect.Top + this.HeaderBuffer - Pos);
                }
            }
            catch (System.ArgumentOutOfRangeException)
            {
                if (this.VScroll.Value > this.VScroll.Maximum)
                {
                    this.VScroll.Value = this.VScroll.Maximum;
                }
                else if (this.VScroll.Value < this.VScroll.Minimum)
                {
                    this.VScroll.Value = this.VScroll.Minimum;
                }
            }
        }

        private bool NodeRowClicked(MouseEventArgs e, ref TreeListNode Node)
        {
            if (this.nodeRowRects == null)
            {
                return false;
            }

            Node = (TreeListNode)EvaluateObject(e, this.nodeRowRects.Keys.GetEnumerator(), this.nodeRowRects.Values.GetEnumerator());
            if (Node == null)
            {
                return false;
            }

            return true;
        }

        private static bool CheckBoxClicked(Hashtable HashTableToCheck, MouseEventArgs MouseArgs, ref TreeListNode Object)
        {
            object obj = Object;
            bool RetVal = CheckBoxClicked(HashTableToCheck, MouseArgs, ref obj);

            Object = (TreeListNode)obj;
            return RetVal;
        }

        private void RecursiveSort(TreeListNodeCollection NdeColl)
        {
            NdeColl.Sort();

            foreach (TreeListNode Node in NdeColl)
	        {
                this.RecursiveSort(Node.Nodes);
	        }
        }

        private void SelectAll(TreeListNode Node)
        {
            if (!Node.Selected)
            {
                Node.Selected = true;
            }

            if (Node.IsExpanded)
            {
                foreach (TreeListNode item in Node.Nodes)
	            {
		            this.SelectAll(item);
	            }
            }
        }

        private void ShowSelectedItems()
        {
            if (this.curNode == null)
            {
                return;
            }

            if (this.firstSelectedNode == this.curNode)
            {
                if (this.curNode.Selected)
                {
                    var ItemsToDeselect = new ArrayList(this.SelectedItems);

                    foreach (TreeListNode Node in ItemsToDeselect)
	                {
                        if (Node != this.curNode)
                        {
                            Node.Selected = false;
                        }
	                }
                }
                else
                {
                    this.curNode.Selected = true;
                }
            }
            else
            {
                TreeListNode TempNode = this.firstSelectedNode;

                this.SelectedItems.Clear();
                this.BeginUpdate();

                try 
	            {	        
                    this.firstSelectedNode.Selected = true;

                    if (this.firstSelectedNode.RowIndex < this.curNode.RowIndex)
                    {
                        while (TempNode != this.curNode)
                        {
                            TempNode = GetNextNode(TempNode);
                            if (TempNode == null)
                            {
                                break;
                            }

                            TempNode.Selected = true;
                        }
                    }
                    else
                    {
                        while (TempNode != this.curNode)
                        {
                            TempNode = GetPreviousNode(TempNode);
                            if (TempNode == null)
                            {
                                break;
                            }

                            TempNode.Selected = true;
                        }
                    }
	            }
	            finally
	            {
                    this.EndUpdate();
	            }
            }

            this.MakeSelectedVisible();
        }
        #endregion
        #endregion
    }

    #region Type converters
    #region TreeListNodeConverter class
    /// <summary>
    /// Provides a type converter to convert <see cref="TreeListNode"/> objects to and from various other representations.
    /// </summary>
    public class TreeListNodeConverter : TypeConverter
    {
        #region action methods
        /// <summary>
        /// Gets a value indicating whether this converter can convert an object to the given destination type using the context.
        /// </summary>
        /// <param name="context">An System.ComponentModel.ITypeDescriptorContext that provides a format context.</param>
        /// <param name="destinationType">A System.Type that represents the type you wish to convert to.</param>
        /// <returns>true if this converter can perform the conversion; otherwise, false.</returns>
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(InstanceDescriptor))
            {
                return true;
            }

            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// Converts the given object to another type.
        /// </summary>
        /// <param name="context">
        /// A formatter context. This object can be used to extract additional information
        /// about the environment this converter is being invoked from. This may be null,
        /// so you should always check. Also, properties on the context object may also
        /// return null.
        /// </param>
        /// <param name="culture">An optional culture info. If not supplied the current culture is assumed.</param>
        /// <param name="value">The object to convert.</param>
        /// <param name="destinationType">The type to convert the object to.</param>
        /// <returns>The converted object.</returns>
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == null)
            {
                throw new ArgumentNullException("destinationType");
            }

            var TlNode = value as TreeListNode;

            if (destinationType == typeof(InstanceDescriptor) && TlNode != null)
            {
                ContainerListViewObject.ContainerListViewSubItem[] SubItems = null;
                if (TlNode.SubItems.Count > 0)
                {
                    SubItems = new ContainerListViewObject.ContainerListViewSubItem[TlNode.SubItems.Count];
                    TlNode.SubItems.CopyTo(SubItems, 0);
                }

                object[] Params = null;
                ConstructorInfo info;
                if (TlNode.ImageIndex.Equals(-1) && TlNode.SelectedImageIndex.Equals(-1))
                {
                    if (SubItems == null)
                    {
                        info = TlNode.GetType().GetConstructor(new Type[] { typeof(string) });
                        if (info != null)
                        {
                            Params = new object[] { TlNode.Text };
                        }
                    }
                    else
                    {
                        info = TlNode.GetType().GetConstructor(new Type[] { typeof(string), typeof(ContainerListViewObject.ContainerListViewSubItem[]) });
                        if (info != null)
                        {
                            Params = new object[] { TlNode.Text, SubItems };
                        }
                    }
                }
                else
                {
                    if (SubItems == null)
                    {
                        info = TlNode.GetType().GetConstructor(new Type[] { typeof(string), typeof(int), typeof(int) });
                        if (info != null)
                        {
                            Params = new object[] { TlNode.Text, TlNode.ImageIndex, TlNode.SelectedImageIndex };
                        }
                    }
                    else
                    {
                        info = TlNode.GetType().GetConstructor(new Type[] { typeof(string), typeof(ContainerListViewObject.ContainerListViewSubItem[]), typeof(int), typeof(int) });
                        if (info != null)
                        {
                            Params = new object[] { TlNode.Text, SubItems, TlNode.ImageIndex, TlNode.SelectedImageIndex };
                        }
                    }
                }

                return new InstanceDescriptor(info, Params, false);
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
        #endregion
    }
    #endregion
    #endregion
}

namespace IMP.SharedControls.Design
{
    #region TreeListNodeCollectionEditor class
    /// <summary>
    /// Collection editor class for TreeListNodeCollection
    /// </summary>
    internal class TreeListNodeCollectionEditor : CollectionEditor
    {
        public TreeListNodeCollectionEditor() : base(typeof(TreeListNodeCollection)) { }

        protected override CollectionEditor.CollectionForm CreateCollectionForm()
        {
            return new TreeListNodeCollectionForm(this);
        }

        protected override string HelpTopic
        {
            get { return "net.ComponentModel.TreeNodeCollectionEditor"; }
        }

        #region TreeListNodeCollectionForm class
        /// <summary>
        /// CollectionEditor Form for TreeListNodeCollection
        /// </summary>
        private class TreeListNodeCollectionForm : CollectionEditor.CollectionForm
        {
 		    #region member varible and default property initialization
            private Button btnAddChild;
            private Button btnAddRoot;
            private Button btnCancel;
            private Button btnDelete;
            private TreeNode curNode;
            private TreeListNodeCollectionEditor editor;
            private int intialNextNode;
            private Label label1;
            private Label label2;
            private Button moveDownButton;
            private Button moveUpButton;
            private TableLayoutPanel navigationButtonsTableLayoutPanel;
            private int nextNode;
            private static object NextNodeKey = new object();
            private TableLayoutPanel nodeControlPanel;
            private Button okButton;
            private TableLayoutPanel okCancelPanel;
            private TableLayoutPanel overarchingTableLayoutPanel;
            private VsPropertyGrid propertyGrid1;
            private TreeView treeView;
            #endregion

		    #region constructors and destructors
            public TreeListNodeCollectionForm(CollectionEditor editor)
                : base(editor)
            {
                this.editor = (TreeListNodeCollectionEditor)editor;
                this.InitializeComponent();
                this.HookEvents();
                this.intialNextNode = this.NextNode;
                this.SetButtonsState();
            }
            #endregion

            #region property getters/setters
            private TreeNode LastNode
            {
                get
                {
                    TreeNode node = this.treeView.Nodes[this.treeView.Nodes.Count - 1];
                    while (node.Nodes.Count > 0)
                    {
                        node = node.Nodes[node.Nodes.Count - 1];
                    }

                    return node;
                }
            }

            private int NextNode
            {
                get
                {
                    if (this.TreeListView != null && this.TreeListView.Site != null)
                    {
                        IDictionaryService service = (IDictionaryService)this.TreeListView.Site.GetService(typeof(IDictionaryService));
                        if (service != null)
                        {
                            object obj2 = service.GetValue(NextNodeKey);
                            if (obj2 != null)
                            {
                                this.nextNode = (int)obj2;
                            }
                            else
                            {
                                this.nextNode = 0;
                                service.SetValue(NextNodeKey, 0);
                            }
                        }
                    }

                    return this.nextNode;
                }
                set
                {
                    this.nextNode = value;
                    if (this.TreeListView != null && this.TreeListView.Site != null)
                    {
                        IDictionaryService service = (IDictionaryService)this.TreeListView.Site.GetService(typeof(IDictionaryService));
                        if (service != null)
                        {
                            service.SetValue(NextNodeKey, this.nextNode);
                        }
                    }
                }
            }

            private TreeListView TreeListView
            {
                get
                {
                    if (base.Context != null && base.Context.Instance is TreeListView)
                    {
                        return (TreeListView)base.Context.Instance;
                    }
                    return null;
                }
            }
            #endregion

		    #region private member functions
            #region design methods
            private void InitializeComponent()
            {
                ComponentResourceManager manager = new ComponentResourceManager(typeof(TreeListNodeCollectionEditor));
                this.okCancelPanel = new TableLayoutPanel();
                this.okButton = new Button();
                this.btnCancel = new Button();
                this.nodeControlPanel = new TableLayoutPanel();
                this.btnAddRoot = new Button();
                this.btnAddChild = new Button();
                this.btnDelete = new Button();
                this.moveDownButton = new Button();
                this.moveUpButton = new Button();
                this.propertyGrid1 = new VsPropertyGrid(base.Context);
                this.label2 = new Label();
                this.treeView = new TreeView();
                this.label1 = new Label();
                this.overarchingTableLayoutPanel = new TableLayoutPanel();
                this.navigationButtonsTableLayoutPanel = new TableLayoutPanel();
                this.okCancelPanel.SuspendLayout();
                this.nodeControlPanel.SuspendLayout();
                this.overarchingTableLayoutPanel.SuspendLayout();
                this.navigationButtonsTableLayoutPanel.SuspendLayout();
                base.SuspendLayout();
                manager.ApplyResources(this.okCancelPanel, "okCancelPanel");
                this.okCancelPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
                this.okCancelPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
                this.okCancelPanel.Controls.Add(this.okButton, 0, 0);
                this.okCancelPanel.Controls.Add(this.btnCancel, 1, 0);
                this.okCancelPanel.Margin = new Padding(3, 3, 0, 0);
                this.okCancelPanel.Name = "okCancelPanel";
                this.okCancelPanel.RowStyles.Add(new RowStyle());
                manager.ApplyResources(this.okButton, "okButton");
                this.okButton.DialogResult = DialogResult.OK;
                this.okButton.Margin = new Padding(0, 0, 3, 0);
                this.okButton.Name = "okButton";
                manager.ApplyResources(this.btnCancel, "btnCancel");
                this.btnCancel.DialogResult = DialogResult.Cancel;
                this.btnCancel.Margin = new Padding(3, 0, 0, 0);
                this.btnCancel.Name = "btnCancel";
                manager.ApplyResources(this.nodeControlPanel, "nodeControlPanel");
                this.nodeControlPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
                this.nodeControlPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
                this.nodeControlPanel.Controls.Add(this.btnAddRoot, 0, 0);
                this.nodeControlPanel.Controls.Add(this.btnAddChild, 1, 0);
                this.nodeControlPanel.Margin = new Padding(0, 3, 3, 3);
                this.nodeControlPanel.Name = "nodeControlPanel";
                this.nodeControlPanel.RowStyles.Add(new RowStyle());
                manager.ApplyResources(this.btnAddRoot, "btnAddRoot");
                this.btnAddRoot.Margin = new Padding(0, 0, 3, 0);
                this.btnAddRoot.Name = "btnAddRoot";
                manager.ApplyResources(this.btnAddChild, "btnAddChild");
                this.btnAddChild.Margin = new Padding(3, 0, 0, 0);
                this.btnAddChild.Name = "btnAddChild";
                manager.ApplyResources(this.btnDelete, "btnDelete");
                this.btnDelete.Margin = new Padding(0, 3, 0, 0);
                this.btnDelete.Name = "btnDelete";
                manager.ApplyResources(this.moveDownButton, "moveDownButton");
                this.moveDownButton.Margin = new Padding(0, 1, 0, 3);
                this.moveDownButton.Name = "moveDownButton";
                manager.ApplyResources(this.moveUpButton, "moveUpButton");
                this.moveUpButton.Margin = new Padding(0, 0, 0, 1);
                this.moveUpButton.Name = "moveUpButton";
                manager.ApplyResources(this.propertyGrid1, "propertyGrid1");
                this.propertyGrid1.LineColor = SystemColors.ScrollBar;
                this.propertyGrid1.Margin = new Padding(3, 3, 0, 3);
                this.propertyGrid1.Name = "propertyGrid1";
                this.overarchingTableLayoutPanel.SetRowSpan(this.propertyGrid1, 2);
                manager.ApplyResources(this.label2, "label2");
                this.label2.Margin = new Padding(3, 1, 0, 0);
                this.label2.Name = "label2";
                this.treeView.AllowDrop = true;
                manager.ApplyResources(this.treeView, "treeView");
                this.treeView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
                this.treeView.HideSelection = false;
                this.treeView.Margin = new Padding(0, 3, 3, 3);
                this.treeView.Name = "treeView";
                manager.ApplyResources(this.label1, "label1");
                this.label1.Margin = new Padding(0, 1, 3, 0);
                this.label1.Name = "label1";
                manager.ApplyResources(this.overarchingTableLayoutPanel, "overarchingTableLayoutPanel");
                this.overarchingTableLayoutPanel.ColumnStyles.Add(new ColumnStyle());
                this.overarchingTableLayoutPanel.ColumnStyles.Add(new ColumnStyle());
                this.overarchingTableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
                this.overarchingTableLayoutPanel.Controls.Add(this.navigationButtonsTableLayoutPanel, 1, 1);
                this.overarchingTableLayoutPanel.Controls.Add(this.label2, 2, 0);
                this.overarchingTableLayoutPanel.Controls.Add(this.propertyGrid1, 2, 1);
                this.overarchingTableLayoutPanel.Controls.Add(this.treeView, 0, 1);
                this.overarchingTableLayoutPanel.Controls.Add(this.label1, 0, 0);
                this.overarchingTableLayoutPanel.Controls.Add(this.nodeControlPanel, 0, 2);
                this.overarchingTableLayoutPanel.Controls.Add(this.okCancelPanel, 2, 3);
                this.overarchingTableLayoutPanel.Name = "overarchingTableLayoutPanel";
                this.overarchingTableLayoutPanel.RowStyles.Add(new RowStyle());
                this.overarchingTableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                this.overarchingTableLayoutPanel.RowStyles.Add(new RowStyle());
                this.overarchingTableLayoutPanel.RowStyles.Add(new RowStyle());
                manager.ApplyResources(this.navigationButtonsTableLayoutPanel, "navigationButtonsTableLayoutPanel");
                this.navigationButtonsTableLayoutPanel.ColumnStyles.Add(new ColumnStyle());
                this.navigationButtonsTableLayoutPanel.Controls.Add(this.moveUpButton, 0, 0);
                this.navigationButtonsTableLayoutPanel.Controls.Add(this.btnDelete, 0, 2);
                this.navigationButtonsTableLayoutPanel.Controls.Add(this.moveDownButton, 0, 1);
                this.navigationButtonsTableLayoutPanel.Margin = new Padding(3, 3, 0x12, 3);
                this.navigationButtonsTableLayoutPanel.Name = "navigationButtonsTableLayoutPanel";
                this.navigationButtonsTableLayoutPanel.RowStyles.Add(new RowStyle());
                this.navigationButtonsTableLayoutPanel.RowStyles.Add(new RowStyle());
                this.navigationButtonsTableLayoutPanel.RowStyles.Add(new RowStyle());
                base.AcceptButton = this.okButton;
                manager.ApplyResources(this, "$this");
                base.AutoScaleMode = AutoScaleMode.Font;
                base.CancelButton = this.btnCancel;
                base.Controls.Add(this.overarchingTableLayoutPanel);
                base.HelpButton = true;
                base.MaximizeBox = false;
                base.MinimizeBox = false;
                base.Name = "TreeNodeCollectionEditor";
                base.ShowIcon = false;
                base.ShowInTaskbar = false;
                base.SizeGripStyle = SizeGripStyle.Show;
                this.okCancelPanel.ResumeLayout(false);
                this.okCancelPanel.PerformLayout();
                this.nodeControlPanel.ResumeLayout(false);
                this.nodeControlPanel.PerformLayout();
                this.overarchingTableLayoutPanel.ResumeLayout(false);
                this.overarchingTableLayoutPanel.PerformLayout();
                this.navigationButtonsTableLayoutPanel.ResumeLayout(false);
                base.ResumeLayout(false);
            }

            private void HookEvents()
            {
                this.okButton.Click += new EventHandler(this.BtnOK_Click);
                this.btnCancel.Click += new EventHandler(this.BtnCancel_Click);
                this.btnAddChild.Click += new EventHandler(this.BtnAddChild_Click);
                this.btnAddRoot.Click += new EventHandler(this.BtnAddRoot_Click);
                this.moveUpButton.Click += new EventHandler(this.moveUpButton_Click);
                this.moveDownButton.Click += new EventHandler(this.moveDownButton_Click);
                this.btnDelete.Click += new EventHandler(this.BtnDelete_Click);
                base.HelpButtonClicked += new CancelEventHandler(this.TreeListNodeCollectionEditor_HelpButtonClicked);
                this.propertyGrid1.PropertyValueChanged += new PropertyValueChangedEventHandler(this.PropertyGrid_propertyValueChanged);

                this.treeView.AfterSelect += new TreeViewEventHandler(treeView_AfterSelect);
                this.treeView.DragEnter += new DragEventHandler(this.treeView_DragEnter);
                this.treeView.ItemDrag += new ItemDragEventHandler(this.treeView_ItemDrag);
                this.treeView.DragDrop += new DragEventHandler(this.treeView_DragDrop);
                this.treeView.DragOver += new DragEventHandler(this.treeView_DragOver);
            }
            #endregion

		    #region controls methods
            private void BtnOK_Click(object sender, EventArgs e)
            {
                SetTreeListNodesValue();

                this.treeView.Dispose();
                this.treeView = null;
            }

            private void BtnCancel_Click(object sender, EventArgs e)
            {
                if (this.NextNode != this.intialNextNode)
                {
                    this.NextNode = this.intialNextNode;
                }
            }

            private void BtnAddChild_Click(object sender, EventArgs e)
            {
                this.Add(this.curNode);
                this.SetButtonsState();
            }

            private void BtnAddRoot_Click(object sender, EventArgs e)
            {
                this.Add(null);
                this.SetButtonsState();
            }

            private void BtnDelete_Click(object sender, EventArgs e)
            {
                ((TreeListNode)this.curNode.Tag).Remove();
                this.curNode.Remove();
                if (this.treeView.Nodes.Count == 0)
                {
                    this.curNode = null;
                    this.SetNodeProps(null);
                }
                this.SetButtonsState();
            }

            private void moveUpButton_Click(object sender, EventArgs e)
            {
                TreeNode curentNode = this.curNode;
                TreeNode parent = this.curNode.Parent;
                if (parent == null)
                {
                    ((TreeListNode)curentNode.Tag).Remove();
                    this.treeView.Nodes.RemoveAt(curentNode.Index);
                    ((TreeListNode)this.treeView.Nodes[curentNode.Index - 1].Tag).Nodes.Add((TreeListNode)curentNode.Tag);
                    this.treeView.Nodes[curentNode.Index - 1].Nodes.Add(curentNode);
                }
                else
                {
                    ((TreeListNode)curentNode.Tag).Remove();
                    parent.Nodes.RemoveAt(curentNode.Index);

                    if (curentNode.Index == 0)
                    {
                        if (parent.Parent == null)
                        {
                            this.treeView.Nodes.Insert(parent.Index, curentNode);
                        }
                        else
                        {
                            ((TreeListNode)parent.Parent.Tag).Nodes.Insert(parent.Index, (TreeListNode)curentNode.Tag);
                            parent.Parent.Nodes.Insert(parent.Index, curentNode);
                        }
                    }
                    else
                    {
                        ((TreeListNode)parent.Nodes[curentNode.Index - 1].Tag).Nodes.Add((TreeListNode)curentNode.Tag);
                        parent.Nodes[curentNode.Index - 1].Nodes.Add(curentNode);
                    }
                }

                this.treeView.SelectedNode = curentNode;
                this.curNode = curentNode;
            }

            private void moveDownButton_Click(object sender, EventArgs e)
            {
                TreeNode curentNode = this.curNode;
                TreeNode parent = this.curNode.Parent;
                if (parent == null)
                {
                    ((TreeListNode)curentNode.Tag).Remove();
                    this.treeView.Nodes.RemoveAt(curentNode.Index);
                    ((TreeListNode)this.treeView.Nodes[curentNode.Index].Tag).Nodes.Insert(0, (TreeListNode)curentNode.Tag);
                    this.treeView.Nodes[curentNode.Index].Nodes.Insert(0, curentNode);
                }
                else
                {
                    ((TreeListNode)curentNode.Tag).Remove();
                    parent.Nodes.RemoveAt(curentNode.Index);

                    if (curentNode.Index < parent.Nodes.Count)
                    {
                        ((TreeListNode)parent.Nodes[curentNode.Index].Tag).Nodes.Insert(0, (TreeListNode)curentNode.Tag);
                        parent.Nodes[curentNode.Index].Nodes.Insert(0, curentNode);
                    }
                    else if (parent.Parent == null)
                    {
                        this.treeView.Nodes.Insert(parent.Index + 1, curentNode);
                    }
                    else
                    {
                        ((TreeListNode)parent.Parent.Tag).Nodes.Insert(parent.Index + 1, (TreeListNode)curentNode.Tag);
                        parent.Parent.Nodes.Insert(parent.Index + 1, curentNode);
                    }
                }

                this.treeView.SelectedNode = curentNode;
                this.curNode = curentNode;
            }

            private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
            {
                this.curNode = e.Node;
                this.SetNodeProps(this.curNode);
                this.SetButtonsState();
            }

            private void treeView_DragDrop(object sender, DragEventArgs e)
            {
                TreeNode data = (TreeNode)e.Data.GetData(typeof(TreeNode));
                Point p = this.treeView.PointToClient(new Point(e.X, e.Y));

                TreeNode nodeAt = this.treeView.GetNodeAt(p);
                if (data != nodeAt)
                {
                    ((TreeListNode)data.Tag).Remove();
                    this.treeView.Nodes.Remove(data);

                    if (nodeAt != null && !CheckParent(nodeAt, data))
                    {
                        ((TreeListNode)nodeAt.Tag).Nodes.Add((TreeListNode)data.Tag);
                        nodeAt.Nodes.Add(data);
                    }
                    else
                    {
                        this.treeView.Nodes.Add(data);
                    }
                }
            }

            private void treeView_DragEnter(object sender, DragEventArgs e)
            {
                if (e.Data.GetDataPresent(typeof(TreeNode)))
                {
                    e.Effect = DragDropEffects.Move;
                }
                else
                {
                    e.Effect = DragDropEffects.None;
                }
            }

            private void treeView_DragOver(object sender, DragEventArgs e)
            {
                Point p = this.treeView.PointToClient(new Point(e.X, e.Y));

                TreeNode nodeAt = this.treeView.GetNodeAt(p);
                this.treeView.SelectedNode = nodeAt;
            }

            private void treeView_ItemDrag(object sender, ItemDragEventArgs e)
            {
                TreeNode item = (TreeNode)e.Item;
                base.DoDragDrop(item, DragDropEffects.Move);
            }

            private void TreeListNodeCollectionEditor_HelpButtonClicked(object sender, CancelEventArgs e)
            {
                e.Cancel = true;
                this.editor.ShowHelp();
            }

            private void PropertyGrid_propertyValueChanged(object sender, PropertyValueChangedEventArgs e)
            {
                TreeListNode TreeListNode = (TreeListNode)this.treeView.SelectedNode.Tag;

                this.treeView.SelectedNode.Name = TreeListNode.Name;
                this.treeView.SelectedNode.Checked = TreeListNode.Checked;
                this.treeView.SelectedNode.ImageIndex = TreeListNode.ImageIndex;
                this.treeView.SelectedNode.SelectedImageIndex = TreeListNode.SelectedImageIndex;
                this.treeView.SelectedNode.Text = TreeListNode.Text;

                this.label2.Text = string.Format(CultureInfo.CurrentCulture, "{0} &properties:", new object[] { this.treeView.SelectedNode.Text });
            }
		    #endregion

            #region custom methods
            private TreeNode[] CreateNodes(TreeListView treeListView)
            {
                //Create clones of TreeListNodes
                TreeListNode[] cloneNodes = new TreeListNode[treeListView.Nodes.Count];
                for (int i = 0; i < treeListView.Nodes.Count; i++)
                {
                    cloneNodes[i] = (TreeListNode)treeListView.Nodes[i].Clone();
                    cloneNodes[i].SetParent(treeListView);
                }

                //Cteate TreeNodes for TreeView
                TreeNode[] nodes = new TreeNode[cloneNodes.Length];
                for (int i = 0; i < cloneNodes.Length; i++)
                {
                    nodes[i] = CreateNode(cloneNodes[i]);
                }

                return nodes;
            }

            private TreeNode CreateNode(TreeListNode TreeListNode)
            {
                TreeNode Node = new TreeNode();

                Node.Name = TreeListNode.Name;
                Node.Checked = TreeListNode.Checked;
                Node.ImageIndex = TreeListNode.ImageIndex;
                Node.SelectedImageIndex = TreeListNode.SelectedImageIndex;
                Node.Text = TreeListNode.Text;
                Node.Tag = TreeListNode;

                //Child Nodes
                foreach (TreeListNode childTreeListNode in TreeListNode.Nodes)
                {
                    Node.Nodes.Add(CreateNode(childTreeListNode));
                }

                return Node;
            }

            private void SetTreeListNodesValue()
            {
                object[] objArray = new object[this.treeView.Nodes.Count];
                for (int i = 0; i < this.treeView.Nodes.Count; i++)
                {
                    objArray[i] = ((TreeListNode)this.treeView.Nodes[i].Tag).Clone();
                }

                base.Items = objArray;
            }

            private void Add(TreeNode parent)
            {
                TreeNode node = null;
                string str = "Node";
                if (parent == null)
                {
                    int num;
                    this.NextNode = (num = this.NextNode) + 1;

                    TreeListNode TreeListNode = new TreeListNode(str + num.ToString(CultureInfo.InvariantCulture));
                    TreeListNode.SetParent(this.TreeListView);
                    TreeListNode.Name = TreeListNode.Text;

                    node = this.treeView.Nodes.Add(str + num.ToString(CultureInfo.InvariantCulture));
                    node.Name = node.Text;
                    node.Tag = TreeListNode;
                }
                else
                {
                    int num3;
                    this.NextNode = (num3 = this.NextNode) + 1;

                    TreeListNode TreeListNode = ((TreeListNode)parent.Tag).Nodes.Add(str + num3.ToString(CultureInfo.InvariantCulture));
                    TreeListNode.Name = TreeListNode.Text;

                    node = parent.Nodes.Add(str + num3.ToString(CultureInfo.InvariantCulture));
                    node.Name = node.Text;
                    node.Tag = TreeListNode;

                    parent.Expand();
                }

                if (parent != null)
                {
                    this.treeView.SelectedNode = parent;
                }
                else
                {
                    this.treeView.SelectedNode = node;
                    this.SetNodeProps(node);
                }
            }

            private static bool CheckParent(TreeNode child, TreeNode parent)
            {
                while (child != null)
                {
                    if (parent == child.Parent)
                    {
                        return true;
                    }

                    child = child.Parent;
                }

                return false;
            }

            private void SetNodeProps(TreeNode node)
            {
                if (node != null)
                {
                    this.label2.Text = string.Format(CultureInfo.CurrentCulture, "{0} &properties:", new object[] { node.Name.ToString() });
                }
                else
                {
                    this.label2.Text = "&Properties:";
                }

                this.propertyGrid1.SelectedObject = (TreeListNode)node.Tag;
            }

            private void SetButtonsState()
            {
                bool flag = this.treeView.Nodes.Count > 0;
                this.btnAddChild.Enabled = flag;
                this.btnDelete.Enabled = flag;
                this.moveDownButton.Enabled = (flag && ((this.curNode != this.LastNode) || (this.curNode.Level > 0))) && (this.curNode != this.treeView.Nodes[this.treeView.Nodes.Count - 1]);
                this.moveUpButton.Enabled = flag && (this.curNode != this.treeView.Nodes[0]);
            }

            protected override void OnEditValueChanged()
            {
                if (base.EditValue != null)
                {
                    object[] items = base.Items;

                    this.propertyGrid1.Site = new PropertyGridSite(base.Context, this.propertyGrid1);

                    TreeListView treeListView = this.TreeListView;
                    if (treeListView != null)
                    {
                        TreeNode[] nodes = CreateNodes(treeListView);

                        this.treeView.Nodes.Clear();
                        this.treeView.Nodes.AddRange(nodes);

                        this.curNode = null;
                        this.btnAddChild.Enabled = false;
                        this.btnDelete.Enabled = false;

                        if (treeListView.ImageList != null)
                        {
                            this.treeView.ImageList = treeListView.ImageList;
                            this.treeView.ImageIndex = treeListView.ImageIndex;
                            this.treeView.SelectedImageIndex = treeListView.SelectedImageIndex;
                        }
                        else
                        {
                            this.treeView.ImageList = null;
                            this.treeView.ImageIndex = -1;
                            this.treeView.SelectedImageIndex = -1;
                        }

                        if (items.Length > 0 && nodes[0] != null)
                        {
                            this.treeView.SelectedNode = nodes[0];
                        }
                    }
                }
            }
            #endregion
            #endregion

		    #region action methods
            internal class PropertyGridSite : ISite, IServiceProvider
            {
		        #region member varible and default property initialization
                private IComponent comp;
                private bool inGetService;
                private IServiceProvider sp;
                #endregion

        		#region constructors and destructors
                public PropertyGridSite(IServiceProvider sp, IComponent comp)
                {
                    this.sp = sp;
                    this.comp = comp;
                }
                #endregion

		        #region action methods
                public object GetService(Type t)
                {
                    if (!this.inGetService && (this.sp != null))
                    {
                        try
                        {
                            this.inGetService = true;
                            return this.sp.GetService(t);
                        }
                        finally
                        {
                            this.inGetService = false;
                        }
                    }
                    return null;
                }
                #endregion

		        #region property getters/setters
                public IComponent Component
                {
                    get { return this.comp; }
                }

                public IContainer Container
                {
                    get { return null; }
                }

                public bool DesignMode
                {
                    get { return false; }
                }

                public string Name
                {
                    get { return null; }
                    set { }
                }
                #endregion
            }
		    #endregion
        }
        #endregion

        #region VsPropertyGrid class
        internal class VsPropertyGrid : PropertyGrid
        {
		    #region constructors and destructors
            public VsPropertyGrid(IServiceProvider serviceProvider)
            {
                if (serviceProvider != null)
                {
                    IUIService service = serviceProvider.GetService(typeof(IUIService)) as IUIService;
                    if (service != null)
                    {
                        base.ToolStripRenderer = (ToolStripProfessionalRenderer)service.Styles["VsToolWindowRenderer"];
                    }
                }
            }
            #endregion
        }
		#endregion
    }
    #endregion

    #region TreeListViewDesigner class
    /// <summary>
    /// ControlDesigner pro TreeListView control
    /// </summary>
    internal class TreeListViewDesigner : IMP.SharedControls.Design.ContainerListViewDesigner
    {
        #region member varible and default property initialization
        private System.ComponentModel.Design.DesignerVerbCollection m_Verbs;
        private DesignerActionListCollection m_ActionLists;
        #endregion

        #region constructors and destructors
        public TreeListViewDesigner() : base()
        {
            m_Verbs = new DesignerVerbCollection();
            m_Verbs.AddRange(new DesignerVerb[] { new DesignerVerb("Edit Nodes", new EventHandler(OnEditNodes)) });
            m_Verbs.AddRange(new DesignerVerb[] { new DesignerVerb("Edit Columns", new EventHandler(OnEditColumns)) });
        }
        #endregion

        #region ControlDesigner overrides
        /// <summary>
        /// Adjusts the set of properties the component exposes through a TypeDescriptor.
        /// </summary>
        /// <param name="properties">An IDictionary containing the properties for the class of the component.</param>
        protected override void PreFilterProperties(System.Collections.IDictionary properties)
        {
            base.PreFilterProperties(properties);
            properties.Remove("Items");
            properties.Remove("SelectedIndexes");
        }

        /// <summary>
        /// Creates a method signature in the source code file for the default event on the component and navigates the user's cursor to that location.
        /// </summary>
        public override void DoDefaultAction()
        {
            TreeListView control = (TreeListView)base.Component; 
            
            Point Point = this.Control.PointToClient(Control.MousePosition);

            TreeListNode ItemAt = (TreeListNode)control.GetItemAt(Point);
            if (ItemAt != null)
            {
                ItemAt.Toggle();
            }
        }

        /// <summary>
        /// Indicates whether a mouse click at the specified point should be handled by the control.
        /// </summary>
        /// <param name="point">A Point indicating the position at which the mouse was clicked, in screen coordinates.</param>
        /// <returns><c>true</c> if a click at the specified point is to be handled by the control; otherwise, <c>false</c>.</returns>
        /// <remarks>
        /// The GetHitTest method determines whether a click at the specified point should be passed to the control, while the control is in design mode. 
        /// You can override and implement this method to enable your control to receive clicks in the design-time environment.
        /// </remarks>
        protected override bool GetHitTest(Point point)
        {
            if (base.GetHitTest(point))
            {
                return true;
            }

            TreeListView control = (TreeListView)base.Component;

            Point ClientPoint = this.Control.PointToClient(point);
            MouseEventArgs e = new MouseEventArgs(MouseButtons.Left, 1, ClientPoint.X, ClientPoint.Y, 0);

            TreeListNode Node = null;
            if (control.PlusMinusClicked(e, ref Node))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the design-time verbs supported by the component that is associated with the ContainerListView.
        /// </summary>
        public override System.ComponentModel.Design.DesignerVerbCollection Verbs
        {
            get { return m_Verbs; }
        }

        /// <summary>
        /// Gets the design-time action lists supported by the component associated with the designer.
        /// </summary>
        public override DesignerActionListCollection ActionLists
        {
            get
            {
                // Use pull model to populate smart tag menu.
                if (m_ActionLists == null)
                {
                    m_ActionLists = new DesignerActionListCollection();
                    m_ActionLists.Add(new TreeListViewActionList(this));
                }

                return m_ActionLists;
            }
        }
        #endregion

        #region private member functions
        private void OnEditNodes(object sender, EventArgs e)
        {
            EditorServiceContext.EditValue(this, base.Component, "Nodes");
        }

        private void OnEditColumns(object sender, EventArgs e)
        {
            EditorServiceContext.EditValue(this, base.Component, "Columns");
        }
        #endregion
    }
    #endregion

    #region TreeListViewActionList class
    /// <summary>
    /// TreeListViewActionList class represents a list of smart tag items for TreeListView control
    /// </summary>
    internal class TreeListViewActionList : System.ComponentModel.Design.DesignerActionList
    {
        #region member varible and default property initialization
        private TreeListViewDesigner Designer;
        private TreeListView Control;
        #endregion

        #region constructors and destructors
        public TreeListViewActionList(TreeListViewDesigner Designer)
            : base(Designer.Component)
        {
            this.Designer = (TreeListViewDesigner)Designer;
            this.Control = (TreeListView)Designer.Control;
        }
        #endregion

        #region DesignerActionList overrides
        /// <summary>
        /// This is the method that returns which smart tag items are displayed at any given time.
        /// </summary>
        /// <remarks>
        /// If this method is not overriden, all properties and methods on the class will be returned
        /// in a collection and the sorting will be based on the order items are returned from reflection.
        /// </remarks>
        /// <returns>DesignerActionItemCollection</returns>
        public override DesignerActionItemCollection GetSortedActionItems()
        {
            DesignerActionItemCollection items = new DesignerActionItemCollection();

            items.Add(new DesignerActionMethodItem(this, "InvokeNodesDialog", "Edit Nodes", "Actions", "Opens the Nodes collection editor"));
            items.Add(new DesignerActionMethodItem(this, "InvokeColumnsDialog", "Edit Columns", "Actions", "Opens the Columns collection editor"));

            items.Add(new DesignerActionPropertyItem("ImageList", "ImageList", "Properties", "The ImageList used for displaying images in the control."));
            items.Add(new DesignerActionPropertyItem("CheckBoxes", "CheckBoxes", "Properties", "Determines if CheckBoxes will be displayed next to TreeListNodes in the TreeListView control."));
            
            return items;
        }
        #endregion

        #region action methods
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public void InvokeNodesDialog()
        {
            EditorServiceContext.EditValue(Designer, base.Component, "Nodes");
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public void InvokeColumnsDialog()
        {
            EditorServiceContext.EditValue(Designer, base.Component, "Columns");
        }
        #endregion

        #region property getters/setters
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public ImageList ImageList
        {
            get { return Control.ImageList; }
            set
            {
                GetPropertyByName("ImageList").SetValue(base.Component, value);
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public bool CheckBoxes
        {
            get { return Control.CheckBoxes; }
            set
            {
                GetPropertyByName("CheckBoxes").SetValue(base.Component, value);
            }
        }
        #endregion

        #region private member functions
        /// <summary>
        /// Helper method to retrieve control properties. Use of 
        /// GetProperties enables undo and menu updates to work properly.
        /// </summary>
        /// <param name="PropertyName">Property name</param>
        /// <returns>PropertyDescriptor of Property</returns>
        /// <exception cref="ArgumentException">Matching control property not found!</exception>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private PropertyDescriptor GetPropertyByName(string PropertyName)
        {
            PropertyDescriptor Property = TypeDescriptor.GetProperties(Control)[PropertyName];

            if (Property == null)
            {
                throw new ArgumentException("Matching control property not found!", PropertyName);
            }
            else
            {
                return Property;
            }
        }
        #endregion
    }
    #endregion
}