using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security;

namespace IMP.WinVersionInfo
{
    #region Public types
    /// <summary>
    /// Identifies platform of windows operating system
    /// </summary>
    [Serializable]
    internal enum OSWindowsID
    {
        /// <summary>
        /// Unknown OS
        /// </summary>
        Unknown = 0,
        /// <summary>
        /// Windows 95
        /// </summary>
        Windows95 = 1,
        /// <summary>
        /// Windows 98
        /// </summary>
        Windows98 = 2,
        /// <summary>
        /// Windows Millennium Edition
        /// </summary>
        WindowsMe = 3,
        /// <summary>
        /// Windows NT 4.0
        /// </summary>
        WindowsNT40 = 4,
        /// <summary>
        /// Windows 2000
        /// </summary>
        Windows2K = 5,
        /// <summary>
        /// Windows XP
        /// </summary>
        WindowsXP = 6,
        /// <summary>
        /// Windows Server 2003
        /// </summary>
        Windows2K3 = 7,
        /// <summary>
        /// Windows Vista
        /// </summary>
        WindowsVista = 8,
        /// <summary>
        /// Windows Server 2008
        /// </summary>
        Windows2K8 = 9,
        /// <summary>
        /// Windows 7, Windows Server 2008 R2
        /// </summary>
        Windows7 = 10,
        /// <summary>
        /// Windows 8, Windows Server 2012
        /// </summary>
        Windows8 = 11
    }

    /// <summary>
    /// Identifies the product type of operating system.
    /// </summary>
    [Serializable]
    internal enum ProductTypeID
    {
        /// <summary>
        /// Workstation (Client) operating system
        /// </summary>
        Workstation = 0,
        /// <summary>
        /// Server operating system
        /// </summary>
        Server = 1
    }

    /// <summary>
    /// Identifies operating system edition
    /// </summary>
    [Serializable]
    internal enum OSWindowsEdition
    {
        /// <summary>
        /// Standard server operating system or Professional / Business workstation operating system edition
        /// or operating system has no editions
        /// </summary>
        StandardOrProfessionalOrBusiness = 0,
        /// <summary>
        /// Home or Personal operating system edition
        /// </summary>
        Home = 1,
        /// <summary>
        /// Enterprise or Advanced server operating system edition
        /// </summary>
        Enterprise = 2,
        /// <summary>
        /// Datacenter server operating system edition
        /// </summary>
        Datacenter = 3,
        /// <summary>
        /// Web server operating system edition 
        /// </summary>
        Web = 4,
        /// <summary>
        /// Ultimate edition of workstation operating system
        /// </summary>
        Ultimate = 5
    }

    /// <summary>
    /// Identifies operating system architecture version.
    /// </summary>
    [Serializable]
    internal enum OSWindowsArchitecture
    {
        /// <summary>
        /// 32Bit version of operating system.
        /// </summary>
        x86 = 0,
        /// <summary>
        /// 64Bit version of operating system.
        /// </summary>
        x64 = 1
    }

    /// <summary>
    /// Identifies operating system special edition info like Media Center Edition or Windows Server R2 version.
    /// </summary>
    [Serializable]
    [Flags]
    internal enum OSWindowsSpecialEdition
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,
        /// <summary>
        /// Operating system is the Windows XP Tablet PC edition
        /// </summary>
        TabletPC = 1,
        /// <summary>
        /// Operating system is the Windows XP, Media Center Edition
        /// </summary>
        MediaCenter = 2,
        /// <summary>
        /// Operating system is Windows Server 2003 R2 version
        /// </summary>
        R2 = 4,
        /// <summary>
        ///  Operating system is the Windows XP Starter Edition or Windows Vista Starter Edition
        /// </summary>
        Starter = 6
    }

    /// <summary>
    /// Identifies system's processor architecture.
    /// </summary>
    [Serializable]
    internal enum ProcessorArchitectureID
    {
        /// <summary>
        /// Unknown processor
        /// </summary>
        Unknown = -1,
        /// <summary>
        /// x86 (32-bit) processor (Intel 386, 486, Pentium/Celeron Family, AMD K6/Athlon/Duron Family)
        /// </summary>
        Intel = 0,
        /// <summary>
        /// MIPS processor (for Windows NT 3.51)
        /// </summary>
        MIPS = 1,
        /// <summary>
        /// Alpha processor (for Windows NT 4.0 and earlier)
        /// </summary>
        Alpha = 2,
        /// <summary>
        /// PPC processor (for Windows NT 4.0 and earlier)
        /// </summary>
        PPC = 3,
        /// <summary>
        /// SHX
        /// </summary>
        SHX = 4,
        /// <summary>
        /// ARM
        /// </summary>
        ARM = 5,
        /// <summary>
        /// 64-bit Intel Itanium processor Family (IPF)
        /// </summary>
        IA64 = 6,
        /// <summary>
        /// Alpha 64-bit processor
        /// </summary>
        Alpha64 = 7,
        /// <summary>
        /// MSIL
        /// </summary>
        MSIL = 8,
        /// <summary>
        /// x64 (64-bit) processor (AMD Opteron, AMD Athlon64, Intel Xeon with Intel EM64T support, Intel Pentium 4 with Intel EM64T support)
        /// </summary>
        AMD64 = 9,
        /// <summary>
        /// IA32 on 64-bit
        /// </summary>
        IA32OnWIN64 = 10
    }

    /// <summary>
    /// Processor feature flags
    /// </summary>
    [Serializable]
    [Flags]
    internal enum ProcessorFeature
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,
        /// <summary>
        /// The MMX instruction set is available.
        /// </summary>
        MMX = 1,
        /// <summary>
        /// The 3D-Now instruction set is available.
        /// </summary>
        AMD3DNow = 2,
        /// <summary>
        /// The SSE instruction set is available.
        /// </summary>
        SSE = 4,
        /// <summary>
        /// The SSE2 instruction set is available.
        /// </summary>
        SSE2 = 8,
        /// <summary>
        /// The SSE3 instruction set is available.
        /// </summary>
        SSE3 = 16
    }
    #endregion

    /// <summary>
    /// T��da na��taj�c� informace o platform�, edici, verzi opera�n�ho syst�mu nainstalovan�m na po��ta�i,
    /// procesoru po��ta�e a vrac� textovou informaci s popisem opera�n�ho syst�mu.
    /// 
    /// Class gets information about platform, edition, version of operating system that are currently installed,
    /// system's processor and gets concatenated string with description of operating system.
    /// </summary>
    /// <remarks>
    /// Version Information:
    /// .NET Framework 2.0
    /// </remarks>
    /// <histories>
    /// <history date="13.07.2006" author="Jan Holan">Vytvo�en� nov� verze t��dy</history>
    /// <history date="17.11.2006" author="Jan Holan">Roz���en� pro Windows Vista</history>
    /// <history date="22.05.2007" author="Jan Holan">Roz���en� pro Windows Server 2008</history>
    /// <history date="12.01.2009" author="Jan Holan">Roz���en� pro Windows 7, Zm�na vlastnosti FrameworkVersion, Roz���en� enumu OSWindowsEdition</history>
    /// <history date="17.05.2009" author="Jan Holan">Roz���en� pro Windows Server 2008 R2</history>
    /// <history date="05.02.2010" author="Jan Holan">P�id�n� metody GetOSWindowsVersion</history>
    /// <history date="16.09.2011" author="Jan Holan">Roz���en� pro Windows Small Business Server 2011, Windows 8</history>
    /// </histories>
    internal class WinVersionInfo
    {
        #region Win32 API classes
        #region OSVERSIONINFOEX struct
        /// <summary>
        /// Struktura OSVERSIONINFO obsahuje informace o opera�n�m syst�mu. 
        /// Informace ur�uj� ��slo verze (major a minor), a ��slo sestaven� (build), 
        /// identifik�tor platformy, popisn� text o opera�n�m syst�mu, informaci
        /// o produktov� �ad� a posledn�m instalovan�m service packu.
        /// Tato structura je pou��v�na funkc� <c>GetVersionEx</c>.
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct OSVERSIONINFOEX
        {
            /// <summary>
            /// dwOSVersionInfoSize
            /// </summary>
            public int dwOSVersionInfoSize;
            /// <summary>
            /// dwMajorVersion
            /// </summary>
            public int dwMajorVersion;
            /// <summary>
            /// dwMinorVersion
            /// </summary>
            public int dwMinorVersion;
            /// <summary>
            /// dwBuildNumber
            /// </summary>
            public int dwBuildNumber;
            /// <summary>
            /// dwPlatformId
            /// </summary>
            public int dwPlatformId;
            /// <summary>
            /// szCSDVersion
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public String szCSDVersion;
            /// <summary>
            /// wServicePackMajor
            /// </summary>
            public short wServicePackMajor;
            /// <summary>
            /// wServicePackMinor
            /// </summary>
            public short wServicePackMinor;
            /// <summary>
            /// wSuiteMask
            /// </summary>
            public ushort wSuiteMask;
            /// <summary>
            /// wProductType
            /// </summary>
            public byte wProductType;
            /// <summary>
            /// wReserved
            /// </summary>
            public byte wReserved;
        }
        #endregion

        #region OSVERSIONINFO struct
        /// <summary>
        /// Struktura OSVERSIONINFO obsahuje informace o opera�n�m syst�mu. 
        /// Informace ur�uj� ��slo verze (major a minor), a ��slo sestaven� (build), 
        /// identifik�tor platformy a popisn� text o opera�n�m syst�mu. 
        /// Tato structura je pou��v�na funkc� <c>GetVersionEx</c>.
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct OSVERSIONINFO
        {
            /// <summary>
            /// dwOSVersionInfoSize
            /// </summary>
            public int dwOSVersionInfoSize;
            /// <summary>
            /// dwMajorVersion
            /// </summary>
            public int dwMajorVersion;
            /// <summary>
            /// dwMinorVersion
            /// </summary>
            public int dwMinorVersion;
            /// <summary>
            /// dwBuildNumber
            /// </summary>
            public int dwBuildNumber;
            /// <summary>
            /// dwPlatformId
            /// </summary>
            public int dwPlatformId;
            /// <summary>
            /// szCSDVersion
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public String szCSDVersion;
        }
        #endregion

        #region SYSTEM_INFO struct
        /// <summary>
        /// Struktura SYSTEM_INFO obsahuje informace o syst�mu. 
        /// Tato structura je pou��v�na funkc� <c>GetSystemInfo</c> a <c>GetNativeSystemInfo</c>.
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        private struct SYSTEM_INFO
        {
            /// <summary>
            /// System's processor architecture. This value can be one of the following values:
            /// PROCESSOR_ARCHITECTURE_UNKNOWN, PROCESSOR_ARCHITECTURE_INTEL, PROCESSOR_ARCHITECTURE_IA64, PROCESSOR_ARCHITECTURE_AMD64
            /// </summary>
            public short wProcessorArchitecture;
            /// <summary>
            /// Reserved for future use.
            /// </summary>
            public short wReserved;
            /// <summary>
            /// Page size and the granularity of page protection and commitment (VirtualAlloc).
            /// </summary>
            public int dwPageSize;
            /// <summary>
            /// Pointer to the lowest memory address accessible to applications and dynamic-link libraries (DLLs).
            /// </summary>
            public IntPtr lpMinimumApplicationAddress;
            /// <summary>
            /// Pointer to the highest memory address accessible to applications and DLLs.
            /// </summary>
            public IntPtr lpMaximumApplicationAddress;
            /// <summary>
            /// Mask representing the set of processors configured into the system. Bit 0 is processor 0; bit 31 is processor 31.
            /// </summary>
            public IntPtr dwActiveProcessorMask;
            /// <summary>
            /// Number of processors in the system
            /// </summary>
            public int dwNumberOfProcessors;
            /// <summary>
            /// An obsolete member that is retained for compatibility with Windows NT 3.5 and Windows Me/98/95.
            /// Use the wProcessorArchitecture, wProcessorLevel, and wProcessorRevision members to determine the type of processor.
            /// Specifies the type of processor in the system: 386, 486, 586
            /// </summary>
            public int dwProcessorType;
            /// <summary>
            /// Granularity for the starting address at which virtual memory can be allocated. For example, a VirtualAlloc request to allocate 1 byte will reserve an address space of dwAllocationGranularity bytes.
            /// </summary>
            public int dwAllocationGranularity;
            /// <summary>
            /// System's architecture-dependent processor level. It should be used only for display purposes.
            /// </summary>
            /// <remarks>
            /// If wProcessorArchitecture is PROCESSOR_ARCHITECTURE_INTEL
            ///     wProcessorLevel is defined by the CPU vendor
            ///     (following values: 3 - Intel 80386, 4 - Intel 80486, 5 - Intel Pentium, 6 - Intel Pentium Pro, Pentium II or Pentium III, 15 - Pentium 4)
            /// 
            /// If wProcessorArchitecture is PROCESSOR_ARCHITECTURE_IA64
            ///     wProcessorLevel is set to 1.
            /// 
            /// If wProcessorArchitecture is PROCESSOR_ARCHITECTURE_MIPS or PROCESSOR_ARCHITECTURE_ALPHA or PROCESSOR_ARCHITECTURE_PPC
            ///     wProcessorLevel is processor version number
            /// 
            /// </remarks>
            public short wProcessorLevel;
            /// <summary>
            /// Architecture-dependent processor revision
            /// </summary>
            /// <remarks>
            /// The following table shows how the revision value is assembled for each type of processor architecture.
            /// 
            /// Processor                | Value 
            /// ----------------------------------------------------------------------------------------------
            /// Intel Pentium, Cyrix, or | The high byte is the model and the low byte is the stepping. For example,
            /// NextGen 586              | if the value is xxyy, the model number and stepping can be displayed
            ///                          } as follows: Model xx, Stepping yy
            /// ----------------------------------------------------------------------------------------------
            /// Intel 80386 or 80486     | A value of the form xxyz.
            ///                          | If xx is equal to 0xFF, y - 0xA is the model number, and z is the stepping
            ///                          | identifier. For example, an Intel 80486-D0 system returns 0xFFD0
            ///                          |
            ///                          | If xx is not equal to 0xFF, xx + 'A' is the stepping letter and yz is the
            ///                          | minor stepping.
            /// ----------------------------------------------------------------------------------------------
            /// </remarks>
            public ushort wProcessorRevision;
        }
        #endregion

        #region constants
        //dwPlatformId of OSVERSIONINFOEX struct consts
        private const int VER_PLATFORM_WIN32s = 0;
        private const int VER_PLATFORM_WIN32_WINDOWS = 1;
        private const int VER_PLATFORM_WIN32_NT = 2;

        //wSuiteMask of OSVERSIONINFOEX struct consts
        private const ushort VER_SUITE_SMALLBUSINESS = 0x0001;   //Microsoft Small Business Server was once installed on the system, but may have been upgraded to another version of Windows. Refer to the Remarks section for more information about this bit flag.
        private const ushort VER_SUITE_ENTERPRISE = 0x0002;      //Windows Server 2008 Enterprise, Windows Server 2003, Enterprise Edition, or Windows 2000 Advanced Server is installed. Refer to the Remarks section for more information about this bit flag.
        private const ushort VER_SUITE_BACKOFFICE = 0x0004;      //Microsoft BackOffice components are installed.
        private const ushort VER_SUITE_TERMINAL = 0x0010;        //Terminal Services is installed. This value is always set.
        private const ushort VER_SUITE_SMALLBUSINESS_RESTRICTED = 0x0020;    //Microsoft Small Business Server is installed with the restrictive client license in force. Refer to the Remarks section for more information about this bit flag.
        private const ushort VER_SUITE_EMBEDDEDNT = 0x0040;      //Windows XP Embedded is installed.
        private const ushort VER_SUITE_DATACENTER = 0x0080;      //Windows Server 2008 Datacenter, Windows Server 2003, Datacenter Edition, or Windows 2000 Datacenter Server is installed.
        private const ushort VER_SUITE_SINGLEUSERTS = 0x0100;    //Remote Desktop is supported, but only one interactive session is supported. This value is set unless the system is running in application server mode.
        private const ushort VER_SUITE_PERSONAL = 0x0200;        //Windows Vista Home Premium, Windows Vista Home Basic, or Windows XP Home Edition is installed.
        private const ushort VER_SUITE_BLADE = 0x0400;           //Windows Server 2003, Web Edition is installed
        private const ushort VER_SUITE_STORAGE_SERVER = 0x2000;  //Windows Storage Server 2003 R2 or Windows Storage Server 2003is installed.
        private const ushort VER_SUITE_COMPUTE_SERVER = 0x4000;  //Windows Server 2003, Compute Cluster Edition is installed.
        private const ushort VER_SUITE_WH_SERVER = 0x8000;       //Windows Home Server is installed.

        //wProductType of OSVERSIONINFOEX struct consts
        private const byte VER_NT_WORKSTATION = 1;
        private const byte VER_NT_DOMAIN_CONTROLLER = 2;
        private const byte VER_NT_SERVER = 3;

        //GetProductInfo ReturnedProductType consts
        private const uint PRODUCT_UNDEFINED = 0x00000000;              //An unknown product
        private const uint PRODUCT_ULTIMATE = 0x00000001;               //Ultimate Edition
        private const uint PRODUCT_HOME_BASIC = 0x00000002;             //Home Basic Edition
        private const uint PRODUCT_HOME_PREMIUM = 0x00000003;           //Home Premium Edition
        private const uint PRODUCT_ENTERPRISE = 0x00000004;             //Enterprise Edition
        private const uint PRODUCT_HOME_BASIC_N = 0x00000005;           //Home Basic Edition
        private const uint PRODUCT_BUSINESS = 0x00000006;               //Business Edition
        private const uint PRODUCT_STANDARD_SERVER = 0x00000007;        //Server Standard Edition (full installation)
        private const uint PRODUCT_DATACENTER_SERVER = 0x00000008;      //Server Datacenter Edition (full installation)
        private const uint PRODUCT_SMALLBUSINESS_SERVER = 0x00000009;   //Small Business Server
        private const uint PRODUCT_ENTERPRISE_SERVER = 0x0000000A;      //Server Enterprise Edition (full installation)
        private const uint PRODUCT_STARTER = 0x0000000B;                //Starter Edition
        private const uint PRODUCT_DATACENTER_SERVER_CORE = 0x0000000C; //Server Datacenter Edition (core installation)
        private const uint PRODUCT_STANDARD_SERVER_CORE = 0x0000000D;   //Server Standard Edition (core installation)
        private const uint PRODUCT_ENTERPRISE_SERVER_CORE = 0x0000000E; //Server Enterprise Edition (core installation)
        private const uint PRODUCT_ENTERPRISE_SERVER_IA64 = 0x0000000F; //Server Enterprise Edition for Itanium-based Systems
        private const uint PRODUCT_BUSINESS_N = 0x00000010;             //Business Edition
        private const uint PRODUCT_WEB_SERVER = 0x00000011;             //Web Server Edition (full installation)
        private const uint PRODUCT_CLUSTER_SERVER = 0x00000012;         //Cluster Server Edition
        private const uint PRODUCT_HOME_SERVER = 0x00000013;            //Home Server Edition
        private const uint PRODUCT_STORAGE_EXPRESS_SERVER = 0x00000014;         //Storage Server Express Edition
        private const uint PRODUCT_STORAGE_STANDARD_SERVER = 0x00000015;        //Storage Server Standard Edition
        private const uint PRODUCT_STORAGE_WORKGROUP_SERVER = 0x00000016;       //Storage Server Workgroup Edition
        private const uint PRODUCT_STORAGE_ENTERPRISE_SERVER = 0x00000017;      //Storage Server Enterprise Edition
        private const uint PRODUCT_SERVER_FOR_SMALLBUSINESS = 0x00000018;       //Server for Small Business Edition
        private const uint PRODUCT_SMALLBUSINESS_SERVER_PREMIUM = 0x00000019;   //Small Business Server Premium Edition
        private const uint PRODUCT_HOME_PREMIUM_N = 0x0000001A;                 //Home Premium Edition
        private const uint PRODUCT_ENTERPRISE_N = 0x0000001B;                   //Enterprise Edition
        private const uint PRODUCT_ULTIMATE_N = 0x0000001C;                     //Ultimate Edition
        private const uint PRODUCT_WEB_SERVER_CORE = 0x0000001D;                //Web Server Edition (core installation)
        private const uint PRODUCT_MEDIUMBUSINESS_SERVER_MANAGEMENT = 0x0000001E;   //Windows Essential Business Server Management Server
        private const uint PRODUCT_MEDIUMBUSINESS_SERVER_SECURITY = 0x0000001F;     //Windows Essential Business Server Security Server
        private const uint PRODUCT_MEDIUMBUSINESS_SERVER_MESSAGING = 0x00000020;    //Windows Essential Business Server Messaging Server
        private const uint PRODUCT_SERVER_FOUNDATION = 0x00000021;              //Server Foundation
        private const uint PRODUCT_HOME_PREMIUM_SERVER = 0x00000022;            //Windows Home Server 2011
        private const uint PRODUCT_SERVER_FOR_SMALLBUSINESS_V = 0x00000023;     //Windows Server 2008 without Hyper-V for Windows Essential Server Solutions
        private const uint PRODUCT_STANDARD_SERVER_V = 0x00000024;          //Server Standard Edition without Hyper-V (full installation)
        private const uint PRODUCT_DATACENTER_SERVER_V = 0x00000025;        //Server Datacenter Edition without Hyper-V (full installation)
        private const uint PRODUCT_ENTERPRISE_SERVER_V = 0x00000026;        //Server Enterprise Edition without Hyper-V (full installation)
        private const uint PRODUCT_DATACENTER_SERVER_CORE_V = 0x00000027;   //Server Datacenter Edition without Hyper-V (core installation)
        private const uint PRODUCT_STANDARD_SERVER_CORE_V = 0x00000028;     //Server Standard Edition without Hyper-V (core installation)
        private const uint PRODUCT_ENTERPRISE_SERVER_CORE_V = 0x00000029;   //Server Enterprise Edition without Hyper-V (core installation)
        private const uint PRODUCT_HYPERV = 0x0000002A;                     //Microsoft Hyper-V Server
        private const uint PRODUCT_STORAGE_EXPRESS_SERVER_CORE = 0x0000002B;     //Storage Server Express (core installation)
        private const uint PRODUCT_STORAGE_STANDARD_SERVER_CORE = 0x0000002C;    //Storage Server Standard (core installation)
        private const uint PRODUCT_STORAGE_WORKGROUP_SERVER_CORE = 0x0000002D;   //Storage Server Workgroup (core installation)
        private const uint PRODUCT_STORAGE_ENTERPRISE_SERVER_CORE = 0x0000002E;  //Storage Server Enterprise (core installation)
        private const uint PRODUCT_STARTER_N = 0x0000002F;                  //Starter N
        private const uint PRODUCT_PROFESSIONAL = 0x00000030;               //Professional
        private const uint PRODUCT_PROFESSIONAL_N = 0x00000031;             //Professional N
        private const uint PRODUCT_SB_SOLUTION_SERVER = 0x00000032;         //Windows Small Business Server 2011 Essentials
        private const uint PRODUCT_SERVER_FOR_SB_SOLUTIONS = 0x00000033;        //Server For SB Solutions
        private const uint PRODUCT_STANDARD_SERVER_SOLUTIONS = 0x00000034;      //Server Solutions Premium 
        private const uint PRODUCT_STANDARD_SERVER_SOLUTIONS_CORE = 0x00000035; //Server Solutions Premium (core installation)
        private const uint PRODUCT_SB_SOLUTION_SERVER_EM = 0x00000036;          //Server For SB Solutions EM
        private const uint PRODUCT_SERVER_FOR_SB_SOLUTIONS_EM = 0x00000037;     //Server For SB Solutions EM
        private const uint PRODUCT_SOLUTION_EMBEDDEDSERVER = 0x00000038;    //Windows MultiPoint Server
        private const uint PRODUCT_ESSENTIALBUSINESS_SERVER_MGMT = 0x0000003B;      //Windows Essential Server Solution Management
        private const uint PRODUCT_ESSENTIALBUSINESS_SERVER_ADDL = 0x0000003C;      //Windows Essential Server Solution Additional
        private const uint PRODUCT_ESSENTIALBUSINESS_SERVER_MGMTSVC = 0x0000003D;   //Windows Essential Server Solution Management SVC
        private const uint PRODUCT_ESSENTIALBUSINESS_SERVER_ADDLSVC = 0x0000003E;   //Windows Essential Server Solution Additional SVC
        private const uint PRODUCT_SMALLBUSINESS_SERVER_PREMIUM_CORE = 0x0000003F;  //Small Business Server Premium (core installation)
        private const uint PRODUCT_CLUSTER_SERVER_V = 0x00000040;           //Server Hyper Core V
        private const uint PRODUCT_STARTER_E = 0x00000042;                  //Starter E
        private const uint PRODUCT_HOME_BASIC_E = 0x00000043;               //Home Basic E
        private const uint PRODUCT_HOME_PREMIUM_E = 0x00000044;             //Home Premium E
        private const uint PRODUCT_PROFESSIONAL_E = 0x00000045;             //Professional E
        private const uint PRODUCT_ENTERPRISE_E = 0x00000046;               //Enterprise E
        private const uint PRODUCT_ULTIMATE_E = 0x00000047;                 //Ultimate E
        private const uint PRODUCT_ENTERPRISE_EVALUATION = 0x00000048;          //Server Enterprise (evaluation installation)
        private const uint PRODUCT_DEVELOPER_PREVIEW = 0x0000004A;              //Windows 8 Developer Preview
        private const uint PRODUCT_MULTIPOINT_STANDARD_SERVER = 0x0000004C;     //Windows MultiPoint Server Standard (full installation)
        private const uint PRODUCT_MULTIPOINT_PREMIUM_SERVER = 0x0000004D;      //Windows MultiPoint Server Premium (full installation)
        private const uint PRODUCT_STANDARD_EVALUATION_SERVER = 0x0000004F;     //Server Standard (evaluation installation)
        private const uint PRODUCT_DATACENTER_EVALUATION_SERVER = 0x00000050;   //Server Datacenter (evaluation installation)
        private const uint PRODUCT_ENTERPRISE_N_EVALUATION = 0x00000054;        //Enterprise N (evaluation installation)
        private const uint PRODUCT_STORAGE_WORKGROUP_EVALUATION_SERVER = 0x0000005F;    //Storage Server Workgroup (evaluation installation)
        private const uint PRODUCT_STORAGE_STANDARD_EVALUATION_SERVER = 0x00000060;     //Storage Server Standard (evaluation installation)
        private const uint PRODUCT_CORE_N = 0x00000062;                     //Windows 8 N
        private const uint PRODUCT_CORE_COUNTRYSPECIFIC = 0x00000063;       //Windows 8 China
        private const uint PRODUCT_CORE_SINGLELANGUAGE = 0x00000064;        //Windows 8 Single Language
        private const uint PRODUCT_CORE = 0x00000065;                       //Windows 8
        private const uint PRODUCT_PROFESSIONAL_WMC = 0x00000067;           //Professional with Media Center
        private const uint PRODUCT_UNLICENSED = 0xABCDABCD; //Product has not been activated and is no longer in the grace period

        //GetSystemMetrics SO SpecialEdition info consts
        private const int SM_TABLETPC = 86;         //Windows XP Tablet PC edition
        private const int SM_MEDIACENTER = 87;      //Windows XP, Media Center Edition
        private const int SM_STARTER = 88;          //Windows Server 2003 R2 version
        private const int SM_SERVERR2 = 89;         //Windows XP Starter Edition or Windows Vista Starter Edition

        // ProcessorArchitecture of SYSTEM_INFO struct consts
        private const short PROCESSOR_ARCHITECTURE_UNKNOWN = -1;
        private const short PROCESSOR_ARCHITECTURE_INTEL = 0;
        private const short PROCESSOR_ARCHITECTURE_MIPS = 1;
        private const short PROCESSOR_ARCHITECTURE_ALPHA = 2;
        private const short PROCESSOR_ARCHITECTURE_PPC = 3;
        private const short PROCESSOR_ARCHITECTURE_IA64 = 6;
        private const short PROCESSOR_ARCHITECTURE_IA32_ON_WIN64 = 10;
        private const short PROCESSOR_ARCHITECTURE_AMD64 = 9;
        private const short PROCESSOR_ARCHITECTURE_SHX = 4;
        private const short PROCESSOR_ARCHITECTURE_ARM = 5;
        private const short PROCESSOR_ARCHITECTURE_ALPHA64 = 7;
        private const short PROCESSOR_ARCHITECTURE_MSIL = 8;

        // IsProcessorFeaturePresent const
        private const int PF_FLOATING_POINT_PRECISION_ERRATA = 0;
        private const int PF_FLOATING_POINT_EMULATED = 1;
        private const int PF_COMPARE_EXCHANGE_DOUBLE = 2;
        private const int PF_MMX_INSTRUCTIONS_AVAILABLE = 3;    // MMX
        private const int PF_XMMI_INSTRUCTIONS_AVAILABLE = 6;   // SSE
        private const int PF_3DNOW_INSTRUCTIONS_AVAILABLE = 7;  // 3DNOW
        private const int PF_RDTSC_INSTRUCTION_AVAILABLE = 8;
        private const int PF_PAE_ENABLED = 9;
        private const int PF_XMMI64_INSTRUCTIONS_AVAILABLE = 10; // SSE2
        private const int PF_SSE_DAZ_MODE_AVAILABLE = 11;
        private const int PF_NX_ENABLED = 12;
        private const int PF_SSE3_INSTRUCTIONS_AVAILABLE = 13;  // SSE3
        private const int PF_COMPARE_EXCHANGE128 = 14;
        private const int PF_COMPARE64_EXCHANGE128 = 15;
        private const int PF_CHANNELS_ENABLED = 16;
        #endregion

        #region SafeNativeMethods class
        /// <summary>
        /// T��da obsahuj�c� popis funkce API Win32
        /// </summary>
        /// <histories>
        /// <history date="24.06.2006" author="Jan Holan">Vytvo�en� t��dy</history>
        /// </histories>
        [SuppressUnmanagedCodeSecurityAttribute()]
        private static class SafeNativeMethods
        {
            [DllImport("kernel32", CharSet = CharSet.Auto)]
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2205:UseManagedEquivalentsOfWin32Api")]
            internal static extern int GetVersionEx(ref OSVERSIONINFOEX osVersionInfo);

            [DllImport("user32.dll", EntryPoint = ("GetSystemMetrics"))]
            internal static extern int GetSystemMetrics(int nIndex);

            [DllImport("kernel32.dll", BestFitMapping = false, ThrowOnUnmappableChar = true, SetLastError = true)]
            internal static extern IntPtr GetModuleHandle([MarshalAs(UnmanagedType.LPStr)] string lpModuleName);

            [DllImport("kernel32.dll", BestFitMapping = false, ThrowOnUnmappableChar = true)]
            internal static extern IntPtr GetProcAddress(IntPtr hModule, [MarshalAs(UnmanagedType.LPStr)] string lpProcName);

            [DllImport("kernel32.dll", EntryPoint = "GetSystemInfo")]
            internal static extern void GetSystemInfo(ref SYSTEM_INFO sysinfo);

            [DllImport("Kernel32.dll")]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern bool GetProductInfo(int dwOSMajorVersion, int dwOSMinorVersion, int dwSpMajorVersion, int dwSpMinorVersion, out uint pdwReturnedProductType);

            [DllImport("kernel32.dll", EntryPoint = "GetNativeSystemInfo")]
            internal static extern void GetNativeSystemInfo(ref SYSTEM_INFO sysinfo);

            [DllImport("kernel32.dll", EntryPoint = "IsProcessorFeaturePresent")]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern bool IsProcessorFeaturePresent(int ProcessorFeature);

            [DllImport("kernel32.dll", EntryPoint = "GetCurrentProcess")]
            internal static extern IntPtr GetCurrentProcess();

            [DllImport("kernel32.dll", EntryPoint = "IsWow64Process")]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern bool IsWow64Process(IntPtr hProcess, [MarshalAs(UnmanagedType.Bool)] ref bool Wow64Process);
        }
        #endregion
        #endregion

        #region member varible and default property initialization
        /// <summary>
        /// .NET t��da obsahuj�c� z�kladn� informace o opera�n�m syst�mu.
        /// </summary>
        private OperatingSystem m_OS;

        /// <summary>
        /// Win32 API struktura pro z�sk�n� detailn�ch informac� o hostuj�c�m opera�n�m syst�mu.
        /// </summary>
        private OSVERSIONINFOEX m_OSVersionInfo;

        /// <summary>
        /// Na�tena roz���en� Win32 API struktura OSVERSIONINFOEX
        /// </summary>
        private bool m_OsVersionInfoEx;

        /// <summary>
        /// Na�tena hodnota ProductType funkc� ProductInfo
        /// </summary>
        private uint m_ProductInfoProductType;

        /// <summary>
        /// Win32 API struktura obsahuj�c� informace o syst�mu.
        /// </summary>
        private SYSTEM_INFO m_SystemInfo;

        /// <summary>
        /// Gets the string representation of the platform and edition of operating system that are currently installed.
        /// member varible of <c>OSFullName</c> property
        /// </summary>
        private string m_OSFullName;

        /// <summary>
        /// Gets the string representation of the platform of operating system that are currently installed.
        /// member varible of <c>WindowsName</c> property
        /// </summary>
        private string m_OSName;

        /// <summary>
        /// Gets the platform identifier of windows operating system that are currently installed.
        /// member varible of <c>OSWindows</c> property
        /// </summary>
        private OSWindowsID m_OSWindows = OSWindowsID.Unknown;

        /// <summary>
        /// Gets the operating system edition.
        /// member varible of <c>Edition</c> property
        /// </summary>
        private OSWindowsEdition m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;

        /// <summary>
        /// Service pack that are currently installed on the operating system.
        /// member varible of <c>ServicePack</c> property
        /// </summary>
        private string m_ServicePack;

        /// <summary>
        /// Service pack CSDBuildNumber on the operating system.
        /// member varible of <c>CSDBuildNumber</c> property
        /// </summary>
        private int m_CSDBuildNumber;

        /// <summary>
        /// Operating system special edition info like Media Center Edition or Windows Server R2 version.
        /// member varible of <c>SpecialEdition</c> property
        /// </summary>
        private OSWindowsSpecialEdition m_SpecialEdition = OSWindowsSpecialEdition.None;

        /// <summary>
        /// System's processor manufacturer vendor identifier.
        /// e.g.: "GenuineIntel" or "AuthenticAMD"
        /// member varible of <c>VendorIdentifier</c> property
        /// </summary>
        private string m_VendorIdentifier;

        /// <summary>
        /// System's processor model number.
        /// member varible of <c>ProcessorModel</c> property
        /// </summary>
        private short m_ProcessorModel;

        /// <summary>
        /// System's processor stepping number.
        /// member varible of <c>ProcessorStepping</c> property
        /// </summary>
        private short m_ProcessorStepping;

        /// <summary>
        /// System's processor display name.
        /// member varible of <c>ProcessorName</c> property
        /// </summary>
        private string m_ProcessorName;

        /// <summary>
        /// System's processor description like platform, family and model number
        /// e.g.: "x86 Family 6 Model 8 Stepping 0".
        /// member varible of <c>ProcessorDescription</c> property
        /// </summary>
        private string m_ProcessorDescription;

        /// <summary>
        /// System's processor speed in MHz.
        /// member varible of <c>CPUSpeed</c> property
        /// </summary>
        private int m_CPUSpeed;

        /// <summary>
        /// System's processor features.
        /// member varible of <c>ProcessorFeaturePresent</c> property
        /// </summary>
        private ProcessorFeature m_ProcessorFeaturePresent = ProcessorFeature.None;

        /// <summary>
        /// Gets whether current process is running under WOW64 (x86 emulator that allows 32-bit applications to run on 64-bit).
        /// member varible of <c>IsWow64Process</c> property
        /// </summary>
        private bool m_IsWow64Process;

        private Version m_CLRVersion = System.Environment.Version;
        private string m_FrameworkVersion;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Constructors na��t� informace o opera�n�ho syst�mu s dopl�uj�c�mi informacemi.
        /// V p��pad�, �e se nepoda�� na��st, generuje v�jimku <c>NotSupportedException</c>.
        /// </summary>
        /// <exception cref="NotSupportedException">V p��pad�, �e se nepoda�� na��st info s verzi opera�n�ho syst�mu.</exception>
        public WinVersionInfo()
        {
            m_OS = Environment.OSVersion;

            //Na�ten� struktury OSVERSIONINFOEX
            m_OSVersionInfo = GetOSVersionInfo(out m_OsVersionInfoEx);

            //Na�ten� struktury SYSTEM_INFO
            m_SystemInfo = GetSystemInfo();

            SetSpecialEdition();

            SetWindowsVersionInformation();
            SetServicePackString();

            //Nastaven� informac� o procesoru VendorIdentifier, ProcessorModel, ProcessorName, ProcessorDescription
            SetProcessorInformation();
        }
        #endregion

        #region action methods
        /// <summary>
        /// Gets the concatenated string representation of the platform with edition, service pack and build number of operating system that are currently installed.
        /// </summary>
        /// <returns>concatenated string representation of the platform with edition, service pack and build number of operating system that are currently installed</returns>
        public override string ToString()
        {
            return this.VersionString;
        }

        /// <summary>
        /// Gets the WinVersionInfo object.
        /// </summary>
        /// <returns>WinVersionInfo object</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static WinVersionInfo VersionInfo()
        {
            return new WinVersionInfo();
        }

        /// <summary>
        /// Gets the concatenated string representation of the platform with edition, service pack and build number of operating system that are currently installed.
        /// </summary>
        /// <returns>concatenated string representation of the platform with edition, service pack and build number of operating system that are currently installed</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static string WindowsVersion()
        {
            return new WinVersionInfo().ToString();
        }

        /// <summary>
        /// Gets Version for windows operating system identifies by <paramref name="OSWindowsID"/> value.
        /// </summary>
        /// <param name="OSWindowsID">Identifies platform of windows operating system</param>
        /// <returns>Version for windows operating system identifies by <paramref name="OSWindowsID"/> value.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Version GetOSWindowsVersion(OSWindowsID OSWindowsID)
        {
            switch (OSWindowsID)
            {
                case OSWindowsID.Windows95:
                    return new Version(4, 0);
                case OSWindowsID.Windows98:
                    return new Version(4, 10);
                case OSWindowsID.WindowsMe:
                    return new Version(4, 90);
                case OSWindowsID.WindowsNT40:
                    return new Version(4, 0);
                case OSWindowsID.Windows2K:
                    return new Version(5, 0);
                case OSWindowsID.WindowsXP:
                    return new Version(5, 1);
                case OSWindowsID.Windows2K3:
                    return new Version(5, 2);
                case OSWindowsID.WindowsVista:
                    return new Version(6, 0);
                case OSWindowsID.Windows2K8:
                    return new Version(6, 0);
                case OSWindowsID.Windows7:
                    return new Version(6, 1);
                case OSWindowsID.Windows8:
                    return new Version(6, 2);
            }

            return null;
        }
        #endregion

        #region property getters/setters
        #region OS Information
        /// <summary>
        /// Operating system or platform currently installed.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public PlatformID Platform
        {
            get { return m_OS.Platform; }
        }

        /// <summary>
        /// Gets the string representation of the platform with edition of operating system that are currently installed.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string OSFullName
        {
            get { return m_OSFullName; }
        }

        /// <summary>
        /// Gets the string representation of the platform of operating system that are currently installed.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string OSName
        {
            get { return m_OSName; }
        }

        /// <summary>
        /// Gets the platform identifier of windows operating system that are currently installed.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public OSWindowsID OSWindows
        {
            get { return m_OSWindows; }
        }

        /// <summary>
        /// Version of operating system that are currently installed.
        /// </summary>
        /// <remarks>
        /// Revision number of version is not set, use only major, minor a build numbers
        /// </remarks>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Version OSVersion
        {
            get
            {
                return new Version(m_OS.Version.Major, m_OS.Version.Minor, m_OS.Version.Build, 0);
            }
        }

        /// <summary>
        /// Build number of operating system that are currently installed.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public int OSBuild
        {
            get { return m_OS.Version.Build; }
        }

        /// <summary>
        /// Product type of operating system that are currently installed.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public ProductTypeID ProductType
        {
            get
            {
                if (m_OSVersionInfo.wProductType == VER_NT_SERVER ||
                    m_OSVersionInfo.wProductType == VER_NT_DOMAIN_CONTROLLER)
                {
                    return ProductTypeID.Server;
                }

                return ProductTypeID.Workstation;
            }
        }

        /// <summary>
        /// Gets the operating system edition.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public OSWindowsEdition Edition
        {
            get { return m_Edition; }
        }

        /// <summary>
        /// Operating system architecture version.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public OSWindowsArchitecture WindowsArchitecture
        {
            get
            {
                if (m_SystemInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_IA64)
                {
                    return OSWindowsArchitecture.x64;
                }
                else if (m_SystemInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)
                {
                    return OSWindowsArchitecture.x64;
                }

                return OSWindowsArchitecture.x86;
            }
        }

        /// <summary>
        /// Service pack that are currently installed on the operating system.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string ServicePack
        {
            get { return m_ServicePack; }
        }

        /// <summary>
        /// Version of service pack that are currently installed on the operating system.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Version ServicePackVersion
        {
            get
            {
                return new Version(m_OSVersionInfo.wServicePackMajor, m_OSVersionInfo.wServicePackMinor);
            }
        }

        /// <summary>
        /// Service pack CSDBuildNumber on the operating system.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public int CSDBuildNumber
        {
            get { return m_CSDBuildNumber; }
        }

        /// <summary>
        /// BuildLab version string of operating system that are currently installed.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string BuildLab
        {
            get
            {
                if (m_OS.Platform != System.PlatformID.Win32NT)
                {
                    return "";
                }

                if (Microsoft.Win32.Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion") == null)
                {
                    return "";
                }

                string BuildLab = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                            "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion").GetValue("BuildLabEx") as string;

                if (BuildLab == null)
                {
                    BuildLab = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                                "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion").GetValue("BuildLab") as string;
                }

                if (BuildLab == null)
                {
                    return "";
                }

                return BuildLab;
            }
        }

        /// <summary>
        /// Gets the concatenated string representation of the platform with edition, service pack and build number of operating system that are currently installed
        /// </summary>
        public string VersionString
        {
            get
            {
                switch (m_OS.Platform)
                {
                    case System.PlatformID.Win32Windows:
                        //Windows 98, Windows 98 Second Edition or Windows Me
                        return m_OSFullName;
                    case System.PlatformID.Win32NT:
                        //Windows NT 4.0, Windows 2000, Windows XP or Windows Vista
                        return m_OSFullName + " " + m_ServicePack + (m_ServicePack.Length == 0 ? "" : " ") + "(Build " + m_OSVersionInfo.dwBuildNumber.ToString(System.Globalization.CultureInfo.CurrentCulture) + ")";
                    default:
                        return m_OS.Platform.ToString();
                }
            }
        }

        /// <summary>
        /// Operating system special edition info like Media Center Edition or Windows Server R2 version.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public OSWindowsSpecialEdition SpecialEdition
        {
            get { return m_SpecialEdition; }
        }

        /// <summary>
        /// Core installation of Windows Server 2008 or later operating system 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public bool CoreInstallation
        {
            get
            {
                switch (m_ProductInfoProductType)
                {
                    case PRODUCT_WEB_SERVER_CORE:
                    case PRODUCT_STANDARD_SERVER_CORE:
                    case PRODUCT_DATACENTER_SERVER_CORE:
                    case PRODUCT_ENTERPRISE_SERVER_CORE:
                    case PRODUCT_STANDARD_SERVER_CORE_V:
                    case PRODUCT_DATACENTER_SERVER_CORE_V:
                    case PRODUCT_ENTERPRISE_SERVER_CORE_V:
                    case PRODUCT_HYPERV:
                    case PRODUCT_STORAGE_EXPRESS_SERVER_CORE:
                    case PRODUCT_STORAGE_STANDARD_SERVER_CORE:
                    case PRODUCT_STORAGE_WORKGROUP_SERVER_CORE:
                    case PRODUCT_STORAGE_ENTERPRISE_SERVER_CORE:
                    case PRODUCT_STANDARD_SERVER_SOLUTIONS_CORE:
                    case PRODUCT_SMALLBUSINESS_SERVER_PREMIUM_CORE:
                        return true;
                }

                return false;
            }
        }

        /// <summary>
        /// N Editions of Windows Vista or later operating system (Editions without Windows Media Player)
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public bool NEdition
        {
            get
            {
                switch (m_ProductInfoProductType)
                {
                    case PRODUCT_STARTER_N:
                    case PRODUCT_HOME_BASIC_N:
                    case PRODUCT_HOME_PREMIUM_N:
                    case PRODUCT_BUSINESS_N:
                    case PRODUCT_PROFESSIONAL_N:
                    case PRODUCT_ENTERPRISE_N:
                    case PRODUCT_ENTERPRISE_N_EVALUATION:
                    case PRODUCT_ULTIMATE_N:
                        return true;
                }

                return false;
            }
        }

        /// <summary>
        /// E Editions of Windows 7 or later operating system (Editions without Internet Explorer)
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public bool EEdition
        {
            get
            {
                switch (m_ProductInfoProductType)
                {
                    case PRODUCT_STARTER_E:
                    case PRODUCT_HOME_BASIC_E:
                    case PRODUCT_HOME_PREMIUM_E:
                    case PRODUCT_PROFESSIONAL_E:
                    case PRODUCT_ENTERPRISE_E:
                    case PRODUCT_ULTIMATE_E:
                        return true;
                }

                return false;
            }
        }
        #endregion

        #region Processor information
        /// <summary>
        /// System's processor architecture.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public ProcessorArchitectureID ProcessorArchitecture
        {
            get { return (ProcessorArchitectureID)m_SystemInfo.wProcessorArchitecture; }
        }

        /// <summary>
        /// System's number of processors.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public int NumberOfProcessors
        {
            get { return (int)m_SystemInfo.dwNumberOfProcessors; }
        }

        /// <summary>
        /// Mask representing the set of processors configured into the system. Bit 0 is processor 0; bit 31 is processor 31.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public int ActiveProcessorMask
        {
            get { return (int)m_SystemInfo.dwActiveProcessorMask; }
        }

        /// <summary>
        /// System's processor manufacturer vendor identifier
        /// e.g.: "GenuineIntel" or "AuthenticAMD".
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string VendorIdentifier
        {
            get { return m_VendorIdentifier; }
        }

        /// <summary>
        /// System's processor family number.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public short ProcessorFamily
        {
            get { return m_SystemInfo.wProcessorLevel; }
        }

        /// <summary>
        /// System's processor model number.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public short ProcessorModel
        {
            get { return m_ProcessorModel; }
        }

        /// <summary>
        /// System's processor stepping number.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public short ProcessorStepping
        {
            get { return m_ProcessorStepping; }
        }

        /// <summary>
        /// System's processor display name.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string ProcessorName
        {
            get { return m_ProcessorName; }
        }

        /// <summary>
        /// System's processor description like platform, family and model number
        /// e.g.: "x86 Family 6 Model 8 Stepping 0".
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string ProcessorDescription
        {
            get { return m_ProcessorDescription; }
        }

        /// <summary>
        /// System's processor speed in MHz.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public int CPUSpeed
        {
            get { return m_CPUSpeed; }
        }

        /// <summary>
        /// System's processor features.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public ProcessorFeature ProcessorFeaturePresent
        {
            get { return m_ProcessorFeaturePresent; }
        }

        /// <summary>
        /// Gets whether current process is running under WOW64 (x86 emulator that allows 32-bit applications to run on 64-bit).
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public bool IsWow64Process
        {
            get { return m_IsWow64Process; }
        }
        #endregion

        #region Others information
        /// <summary>
        /// Version (the major, minor, build, and revision numbers) of the common language runtime.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Version CLRVersion
        {
            get { return m_CLRVersion; }
        }

        /// <summary>
        /// Version of .NET framework that are currently installed, e.g.: "3.5 SP1".
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public string FrameworkVersion
        {
            get
            {
                if (m_FrameworkVersion == null)
                {
                    m_FrameworkVersion = GetFrameworkVersion();
                }

                return m_FrameworkVersion;
            }
        }
        #endregion
        #endregion

        #region private member functions
        #region Windows API calls function
        /// <summary>
        /// Vrac� napln�nou strukturu OSVERSIONINFOEX
        /// </summary>
        /// <param name="OsVersionInfoEx">Vrac� <c>true</c> pokud byla na�tena roz���en� struktura</param>
        /// <returns>Napln�n� struktura GetOSVersionInfo</returns>
        /// <exception cref="NotSupportedException">V p��pad�, �e se nepoda�� na��st ani z�kladn� strukturu OSVERSIONINFO.</exception>
        private static OSVERSIONINFOEX GetOSVersionInfo(out bool OsVersionInfoEx)
        {
            OSVERSIONINFOEX OSVersionInfo = new OSVERSIONINFOEX();

            //Pokus se z�skat roz���enou strukturu z Win32 API
            OSVersionInfo.dwOSVersionInfoSize = Marshal.SizeOf(new OSVERSIONINFOEX());

            int Result = SafeNativeMethods.GetVersionEx(ref OSVersionInfo);
            OsVersionInfoEx = Result != 0;

            if (Result == 0)
            {
                //Jestli�e nelze z�skat roz���enou, z�skej z�kladn�
                OSVersionInfo.dwOSVersionInfoSize = Marshal.SizeOf(new OSVERSIONINFO());
                Result = SafeNativeMethods.GetVersionEx(ref OSVersionInfo);

                if (Result == 0)
                {
                    //Nepoda�ilo se z�skat informace o syst�mu.
                    throw new NotSupportedException();
                }
            }

            return OSVersionInfo;
        }

        /// <summary>
        /// Vrac� napln�nou strukturu SYSTEM_INFO
        /// </summary>
        /// <returns>Napln�n� struktura SYSTEM_INFO</returns>
        private static SYSTEM_INFO GetSystemInfo()
        {
            SYSTEM_INFO si = new SYSTEM_INFO();

            if (Environment.OSVersion.Platform == PlatformID.Win32Windows ||
                (Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.OSVersion.Version.Major > 3))
            {
                if (SafeNativeMethods.GetProcAddress(SafeNativeMethods.GetModuleHandle("KERNEL32.dll"), "GetNativeSystemInfo") != (IntPtr)0)
                {
                    //On Windows XP or later
                    SafeNativeMethods.GetNativeSystemInfo(ref si);
                    return si;
                }

                SafeNativeMethods.GetSystemInfo(ref si);
            }

            return si;
        }

        /// <summary>
        /// Vrac� zda procesor podporuje zadanou funkcionalitu
        /// </summary>
        /// <returns><c>true</c> pokud procesor podporuje zadanou funkcionalitu</returns>
        private static bool GetIsProcessorFeaturePresent(int ProcessorFeature)
        {
            if (Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.OSVersion.Version.Major > 3)
            {
                if (SafeNativeMethods.GetProcAddress(SafeNativeMethods.GetModuleHandle("KERNEL32.dll"), "IsProcessorFeaturePresent") != (IntPtr)0)
                {
                    return SafeNativeMethods.IsProcessorFeaturePresent(ProcessorFeature);
                }
            }

            return false;
        }

        /// <summary>
        /// Vrac� zda aktu�ln� proces b�� jako WOW64 (x86 emulator that allows 32-bit applications to run on 64-bit)
        /// </summary>
        /// <returns></returns>
        private static bool GetIsWow64Process()
        {
            if (Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.OSVersion.Version >= new Version(5, 1))
            {
                bool Wow64Process = false;

                if (SafeNativeMethods.IsWow64Process(SafeNativeMethods.GetCurrentProcess(), ref Wow64Process))
                {
                    return Wow64Process;
                }
            }

            return false;
        }
        #endregion

        #region Set Windows Version Information
        /// <summary>
        /// Nastaven� informac� o platform� a verzi OS, �et�zec s popisem opera�n�ho syst�mu
        /// </summary>
        /// <remarks>
        /// Nastavuje:
        /// m_OSFullName, m_OSName, m_OSWindows, m_Edition
        /// </remarks>
        private void SetWindowsVersionInformation()
        {
            switch (m_OS.Platform)
            {
                case System.PlatformID.Win32Windows:
                    //Windows 98, Windows 98 Second Edition or Windows Me
                    m_OSFullName = "Windows 9x";
                    m_OSName = "Windows 9x";
                    SetWin32PlatformInformation();
                    break;
                case System.PlatformID.Win32NT:
                    //Windows NT 4.0, Windows 2000, Windows XP or Windows Vista
                    m_OSFullName = "Windows";
                    m_OSName = "Windows";
                    SetWin32NTPlatformInformation();
                    break;
                case System.PlatformID.WinCE:    //Specifies the Windows CE OS.
                    m_OSFullName = "Windows CE";
                    m_OSName = "Windows CE";
                    break;
                default:
                    m_OSFullName = m_OS.Platform.ToString();
                    m_OSName = m_OS.Platform.ToString();
                    break;
            }
        }

        #region Windows Platform medhods
        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu platformy Win32
        /// </summary>
        private void SetWin32PlatformInformation()
        {
            switch (m_OS.Version.Minor)
            {
                case 0:
                    m_OSFullName = "Windows 95";

                    if (m_OSVersionInfo.dwBuildNumber > 950 && m_OSVersionInfo.dwBuildNumber <= 1080)
                    {
                        m_OSFullName += " SP1";
                    }
                    else if (m_OSVersionInfo.dwBuildNumber > 1080)
                    {
                        m_OSFullName += " OSR2";
                    }

                    m_OSName = "Windows 95";
                    m_OSWindows = OSWindowsID.Windows95;
                    break;
                case 10:
                    m_OSFullName = "Windows 98";

                    if (m_OSVersionInfo.dwBuildNumber > 1998 && m_OSVersionInfo.dwBuildNumber < 2183)
                    {
                        m_OSFullName += " SP1";
                    }
                    else if (m_OSVersionInfo.dwBuildNumber >= 2183)
                    {
                        m_OSFullName += " SE";
                    }

                    m_OSName = "Windows 98";
                    m_OSWindows = OSWindowsID.Windows98;
                    break;
                case 90:
                    m_OSFullName = "Windows Millennium Edition";
                    m_OSName = "Windows Me";
                    m_OSWindows = OSWindowsID.WindowsMe;
                    break;
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu platformy WinNT
        /// </summary>
        private void SetWin32NTPlatformInformation()
        {
            switch (m_OS.Version.Major)
            {
                case 3:
                    m_OSFullName = "Windows NT 3.51";
                    m_OSName = "Windows NT 3.51";
                    m_OSWindows = OSWindowsID.Unknown;
                    break;
                case 4:
                    SetWinNT4Information(); //Windows NT 4.0
                    break;
                case 5:
                    if (m_OS.Version.Minor == 0)
                    {
                        SetWin2KInformation(); //Windows 2000
                    }
                    else if (m_OS.Version.Minor == 1)
                    {
                        SetWinXPInformation(); //Windows XP
                    }
                    else
                    {
                        SetWin2K3Information(); //Windows Server 2003 nebo Windows XP Professional x64 Edition
                    }
                    break;
                case 6:
                    if (m_OS.Version.Minor == 0)
                    {
                        SetWinVistaWin2K8Information();  //Windows Vista nebo Windows Server 2008
                    }
                    else if (m_OS.Version.Minor == 1)
                    {
                        SetWin7Win2K8R2Information();  //Windows 7 nebo Windows Server 2008 R2
                    }
                    else
                    {
                        SetWin8Win2012Information();  //Windows 8, Windows Server 2012
                    }
                    break;
                case 7:
                    SetWin8Win2012Information();  //Windows 8, Windows Server 2012
                    break;
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows NT 4.0
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1302:DoNotHardcodeLocaleSpecificStrings", MessageId = "WINNT")]
        private void SetWinNT4Information()
        {
            m_OSFullName = "Windows NT 4.0";
            m_OSName = "Windows NT 4.0";
            m_OSWindows = OSWindowsID.WindowsNT40;

            if (m_OsVersionInfoEx)    //Use information from GetVersionEx
            {
                //Windows NT 4.0 SP6 and later
                if (m_OSVersionInfo.wProductType == VER_NT_WORKSTATION)
                {
                    m_OSFullName += " Workstation";
                }
                else if (m_OSVersionInfo.wProductType == VER_NT_SERVER ||
                         m_OSVersionInfo.wProductType == VER_NT_DOMAIN_CONTROLLER)
                {
                    if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
                    {
                        m_OSFullName += " Server Enterprise Edition";
                        m_Edition = OSWindowsEdition.Enterprise;
                    }
                    else
                    {
                        m_OSFullName += " Server";
                    }
                }
            }
            else
            {
                //Windows NT 4.0 SP5 and earlier
                //Test for product type
                string productType = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                                    "SYSTEM\\CurrentControlSet\\Control\\ProductOptions").GetValue("ProductType") as string;

                if (productType.Equals("WINNT", StringComparison.OrdinalIgnoreCase))
                {
                    m_OSFullName += " Workstation";
                }
                else if (productType.Equals("LANMANNT", StringComparison.OrdinalIgnoreCase))
                {
                    m_OSFullName += " Server";
                }
                else if (productType.Equals("SERVERNT", StringComparison.OrdinalIgnoreCase))
                {
                    m_OSFullName += " Advanced Server";
                    m_Edition = OSWindowsEdition.Enterprise;
                }
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows 2000
        /// </summary>
        private void SetWin2KInformation()
        {
            m_OSFullName = "Windows 2000";
            m_OSName = "Windows 2000";
            m_OSWindows = OSWindowsID.Windows2K;

            if (m_OSVersionInfo.wProductType == VER_NT_WORKSTATION)
            {
                if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_PERSONAL) == VER_SUITE_PERSONAL)
                {
                    m_OSFullName += " Personal";
                    m_Edition = OSWindowsEdition.Home;
                }
                else
                {
                    m_OSFullName += " Professional";
                }
            }
            else if (m_OSVersionInfo.wProductType == VER_NT_SERVER ||
                     m_OSVersionInfo.wProductType == VER_NT_DOMAIN_CONTROLLER)
            {
                if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
                {
                    m_OSFullName += " Datacenter Server";
                    m_Edition = OSWindowsEdition.Datacenter;
                }
                else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
                {
                    m_OSFullName += " Advanced Server";
                    m_Edition = OSWindowsEdition.Enterprise;
                }
                else if (((m_OSVersionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS) == VER_SUITE_SMALLBUSINESS) ||
                        ((m_OSVersionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS_RESTRICTED) == VER_SUITE_SMALLBUSINESS_RESTRICTED))
                {
                    m_OSFullName += " Small Business Server";
                }
                else
                {
                    m_OSFullName += " Server";
                }
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows XP (32-bit)
        /// </summary>
        private void SetWinXPInformation()
        {
            m_OSFullName = "Windows XP";
            m_OSName = "Windows XP";
            m_OSWindows = OSWindowsID.WindowsXP;

            if ((m_SpecialEdition & OSWindowsSpecialEdition.MediaCenter) == OSWindowsSpecialEdition.MediaCenter)
            {
                m_OSFullName += " Media Center Edition";
            }
            else if ((m_SpecialEdition & OSWindowsSpecialEdition.Starter) == OSWindowsSpecialEdition.Starter)
            {
                m_OSFullName += " Starter Edition";
            }
            else if ((m_SpecialEdition & OSWindowsSpecialEdition.TabletPC) == OSWindowsSpecialEdition.TabletPC)
            {
                m_OSFullName += " Tablet PC Edition";
            }
            if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_PERSONAL) == VER_SUITE_PERSONAL)
            {
                m_OSFullName += " Home Edition";
                m_Edition = OSWindowsEdition.Home;
            }
            else
            {
                m_OSFullName += " Professional";
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows Server 2003 nebo Windows XP Professional x64 Edition
        /// </summary>
        private void SetWin2K3Information()
        {
            if (m_OS.Version.Build > 3716)
            {
                if ((m_SpecialEdition & OSWindowsSpecialEdition.R2) == OSWindowsSpecialEdition.R2)
                {
                    m_OSFullName = "Windows Server 2003 R2";
                    m_OSName = "Windows Server 2003";
                    m_OSWindows = OSWindowsID.Windows2K3;
                }
                else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_STORAGE_SERVER) == VER_SUITE_STORAGE_SERVER)
                {
                    m_OSFullName = "Windows Storage Server 2003";
                    m_OSName = "Windows Storage Server 2003";
                    m_OSWindows = OSWindowsID.Windows2K3;
                }
                else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_WH_SERVER) == VER_SUITE_WH_SERVER)
                {
                    m_OSFullName = "Windows Home Server";
                    m_OSName = "Windows Home Server";
                    m_OSWindows = OSWindowsID.Windows2K3;
                    m_Edition = OSWindowsEdition.Home;
                }
                else if (m_OSVersionInfo.wProductType == VER_NT_WORKSTATION && m_SystemInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)
                {
                    m_OSFullName = "Windows XP Professional x64 Edition";
                    m_OSName = "Windows XP x64";
                    m_OSWindows = OSWindowsID.WindowsXP;
                }
                else
                {
                    m_OSFullName = "Windows Server 2003";
                    m_OSName = "Windows Server 2003";
                    m_OSWindows = OSWindowsID.Windows2K3;
                }

                if ((m_OSVersionInfo.wProductType == VER_NT_SERVER ||
                    m_OSVersionInfo.wProductType == VER_NT_DOMAIN_CONTROLLER) &&
                    (m_OSVersionInfo.wSuiteMask & VER_SUITE_WH_SERVER) != VER_SUITE_WH_SERVER)
                {
                    if (m_SystemInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_IA64)
                    {
                        if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
                        {
                            m_OSFullName += " Datacenter Edition for Itanium-based Systems";
                            m_Edition = OSWindowsEdition.Datacenter;
                        }
                        else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
                        {
                            m_OSFullName += " Enterprise Edition for Itanium-based Systems";
                            m_Edition = OSWindowsEdition.Enterprise;
                        }
                    }
                    else if (m_SystemInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)
                    {
                        if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
                        {
                            m_OSFullName += " Datacenter x64 Edition";
                            m_Edition = OSWindowsEdition.Datacenter;
                        }
                        else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
                        {
                            m_OSFullName += " Enterprise x64 Edition";
                            m_Edition = OSWindowsEdition.Enterprise;
                        }
                        else
                        {
                            m_OSFullName += " Standard x64 Edition";
                        }
                    }
                    else
                    {
                        if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_COMPUTE_SERVER) == VER_SUITE_COMPUTE_SERVER)
                        {
                            m_OSFullName += " Compute Cluster Edition";
                        }
                        else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
                        {
                            m_OSFullName += " Datacenter Edition";
                            m_Edition = OSWindowsEdition.Datacenter;
                        }
                        else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
                        {
                            m_OSFullName += " Enterprise Edition";
                            m_Edition = OSWindowsEdition.Enterprise;
                        }
                        else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_BLADE) == VER_SUITE_BLADE)
                        {
                            m_OSFullName += " Web Edition";
                            m_Edition = OSWindowsEdition.Web;
                        }
                        else if (((m_OSVersionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS) == VER_SUITE_SMALLBUSINESS) ||
                                ((m_OSVersionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS_RESTRICTED) == VER_SUITE_SMALLBUSINESS_RESTRICTED))
                        {
                            m_OSFullName += " for Small Business Server";
                        }
                        else
                        {
                            m_OSFullName += " Standard Edition";
                        }
                    }
                }
            }
            else
            {
                m_OSFullName = "Windows .NET";
                m_OSName = "Windows .NET Server";
                m_OSWindows = OSWindowsID.Windows2K3;

                if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
                {
                    m_OSFullName += " Datacenter Server";
                    m_Edition = OSWindowsEdition.Datacenter;
                }
                else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
                {
                    m_OSFullName += " Enterprise Server";
                    m_Edition = OSWindowsEdition.Enterprise;
                }
                else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_BLADE) == VER_SUITE_BLADE)
                {
                    m_OSFullName += " Web Server";
                    m_Edition = OSWindowsEdition.Web;
                }
                else
                {
                    m_OSFullName += " Server";
                }
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows Vista nebo Windows Server 2008
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void SetWinVistaWin2K8Information()
        {
            //GetProductInfo
            uint dwType = 0;
            if (SafeNativeMethods.GetProductInfo(6, 0, 0, 0, out dwType))
            {
                m_ProductInfoProductType = dwType;
            }

            if (m_OSVersionInfo.wProductType == VER_NT_WORKSTATION)
            {
                SetWinVistaInformation();
            }
            else
            {
                SetWin2K8Information();
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows Vista
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void SetWinVistaInformation()
        {
            m_OSWindows = OSWindowsID.WindowsVista;
            m_OSFullName = "Windows Vista";
            m_OSName = "Windows Vista";

            #region ProductInfoProductType switch
            switch (m_ProductInfoProductType)
            {
                case PRODUCT_HOME_BASIC:
                    m_OSFullName += " Home Basic";
                    m_Edition = OSWindowsEdition.Home;
                    return;
                case PRODUCT_HOME_BASIC_N:
                    m_OSFullName += " Home Basic N";
                    m_Edition = OSWindowsEdition.Home;
                    return;
                case PRODUCT_HOME_PREMIUM:
                    m_OSFullName += " Home Premium";
                    m_Edition = OSWindowsEdition.Home;
                    return;
                case PRODUCT_HOME_PREMIUM_N:
                    m_OSFullName += " Home Premium N";
                    m_Edition = OSWindowsEdition.Home;
                    return;
                case PRODUCT_STARTER:
                    m_OSFullName += " Starter";
                    return;
                case PRODUCT_STARTER_N:
                    m_OSFullName += " Starter N";
                    return;
                case PRODUCT_STARTER_E:
                    m_OSFullName += " Starter E";
                    return;
                case PRODUCT_ENTERPRISE:
                    m_OSFullName += " Enterprise";
                    m_Edition = OSWindowsEdition.Enterprise;
                    return;
                case PRODUCT_ENTERPRISE_N:
                    m_OSFullName += " Enterprise N";
                    m_Edition = OSWindowsEdition.Enterprise;
                    return;
                case PRODUCT_BUSINESS:
                    m_OSFullName += " Business";
                    m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                    return;
                case PRODUCT_BUSINESS_N:
                    m_OSFullName += " Business N";
                    m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                    return;
                case PRODUCT_ULTIMATE:
                    m_OSFullName += " Ultimate";
                    m_Edition = OSWindowsEdition.Ultimate;
                    return;
                case PRODUCT_ULTIMATE_N:
                    m_OSFullName += " Ultimate N";
                    m_Edition = OSWindowsEdition.Ultimate;
                    return;
            }
            #endregion

            //V�choz� zji�t�n� pro unlicensed nebo unknown
            if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_PERSONAL) == VER_SUITE_PERSONAL)
            {
                //Windows Vista Home Premium or Windows Vista Home Basic
                if ((m_SpecialEdition & OSWindowsSpecialEdition.MediaCenter) == OSWindowsSpecialEdition.MediaCenter)
                {
                    m_OSFullName += " Home Premium";
                }
                else
                {
                    m_OSFullName += " Home Basic";
                }

                m_Edition = OSWindowsEdition.Home;
            }
            else
            {
                if ((m_SpecialEdition & OSWindowsSpecialEdition.Starter) == OSWindowsSpecialEdition.Starter)
                {
                    m_OSFullName += " Starter";
                }
                else
                {
                    if ((m_SpecialEdition & OSWindowsSpecialEdition.MediaCenter) == OSWindowsSpecialEdition.MediaCenter)
                    {
                        m_OSFullName += " Ultimate";
                        m_Edition = OSWindowsEdition.Ultimate;
                    }
                    else
                    {
                        //Windows Vista Business or Windows Vista Enterprise
                        if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
                        {
                            m_OSFullName += " Enterprise";
                            m_Edition = OSWindowsEdition.Enterprise;
                        }
                        else
                        {
                            m_OSFullName += " Business";
                            m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows Server 2008
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void SetWin2K8Information()
        {
            m_OSWindows = OSWindowsID.Windows2K8;
            m_OSName = "Windows Server 2008";
            m_OSFullName = "Windows Server 2008";

            if (m_SystemInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_IA64)
            {
                m_OSFullName = "Windows Server 2008 for Itanium-based Systems";
                return;
            }

            #region ProductInfoProductType switch
            switch (m_ProductInfoProductType)
            {
                case PRODUCT_STANDARD_SERVER:
                    m_OSFullName = "Windows Server 2008 Standard";
                    return;
                case PRODUCT_STANDARD_SERVER_CORE:
                    m_OSFullName = "Windows Server 2008 Standard (core installation)";
                    return;
                case PRODUCT_STANDARD_SERVER_V:
                    m_OSFullName = "Windows Server 2008 Standard without Hyper-V";
                    return;
                case PRODUCT_STANDARD_SERVER_CORE_V:
                    m_OSFullName = "Windows Server 2008 Standard without Hyper-V (core installation)";
                    return;
                case PRODUCT_ENTERPRISE:
                case PRODUCT_ENTERPRISE_N:
                case PRODUCT_ENTERPRISE_SERVER:
                    m_OSFullName = "Windows Server 2008 Enterprise";
                    m_Edition = OSWindowsEdition.Enterprise;
                    return;
                case PRODUCT_ENTERPRISE_SERVER_CORE:
                    m_OSFullName = "Windows Server 2008 Enterprise (core installation)";
                    m_Edition = OSWindowsEdition.Enterprise;
                    return;
                case PRODUCT_ENTERPRISE_SERVER_V:
                    m_OSFullName = "Windows Server 2008 Enterprise without Hyper-V";
                    m_Edition = OSWindowsEdition.Enterprise;
                    return;
                case PRODUCT_ENTERPRISE_SERVER_CORE_V:
                    m_OSFullName = "Windows Server 2008 Enterprise without Hyper-V (core installation)";
                    m_Edition = OSWindowsEdition.Enterprise;
                    return;
                case PRODUCT_DATACENTER_SERVER:
                    m_OSFullName = "Windows Server 2008 Datacenter";
                    m_Edition = OSWindowsEdition.Datacenter;
                    return;
                case PRODUCT_DATACENTER_SERVER_CORE:
                    m_OSFullName = "Windows Server 2008 Datacenter (core installation)";
                    m_Edition = OSWindowsEdition.Datacenter;
                    return;
                case PRODUCT_DATACENTER_SERVER_V:
                    m_OSFullName = "Windows Server 2008 Datacenter without Hyper-V";
                    m_Edition = OSWindowsEdition.Datacenter;
                    return;
                case PRODUCT_DATACENTER_SERVER_CORE_V:
                    m_OSFullName = "Windows Server 2008 Datacenter without Hyper-V (core installation)";
                    m_Edition = OSWindowsEdition.Datacenter;
                    return;
                case PRODUCT_WEB_SERVER:
                    m_OSFullName = "Windows Web Server 2008";
                    m_OSName = "Windows Web Server 2008";
                    m_Edition = OSWindowsEdition.Web;
                    return;
                case PRODUCT_WEB_SERVER_CORE:
                    m_OSFullName = "Windows Web Server 2008 (core installation)";
                    m_OSName = "Windows Web Server 2008";
                    m_Edition = OSWindowsEdition.Web;
                    return;
                case PRODUCT_ENTERPRISE_SERVER_IA64:
                    m_OSFullName = "Windows Server 2008 for Itanium-based Systems";
                    return;
                case PRODUCT_SMALLBUSINESS_SERVER:
                case PRODUCT_SERVER_FOR_SMALLBUSINESS:
                    m_OSFullName = "Windows Small Business Server 2008";
                    m_OSName = "Windows Small Business Server 2008";
                    return;
                case PRODUCT_SERVER_FOR_SMALLBUSINESS_V:
                    m_OSFullName = "Windows Small Business Server 2008 without Hyper-V";
                    m_OSName = "Windows Small Business Server 2008";
                    return;
                case PRODUCT_SMALLBUSINESS_SERVER_PREMIUM:
                    m_OSFullName = "Windows Small Business Server 2008 Premium";
                    m_OSName = "Windows Small Business Server 2008";
                    return;
                case PRODUCT_MEDIUMBUSINESS_SERVER_MANAGEMENT:
                case PRODUCT_MEDIUMBUSINESS_SERVER_SECURITY:
                case PRODUCT_MEDIUMBUSINESS_SERVER_MESSAGING:
                    m_OSFullName = "Windows Essential Business Server 2008";
                    m_OSName = "Windows Essential Business Server 2008";
                    return;
                case PRODUCT_STARTER:
                case PRODUCT_STARTER_N:
                case PRODUCT_STARTER_E:
                    m_OSFullName = "Windows Server 2008 Starter Edition";
                    return;
                case PRODUCT_CLUSTER_SERVER:
                    m_OSFullName = "Windows HPC Server 2008";
                    return;
                case PRODUCT_HOME_SERVER:
                    m_OSFullName = "Windows Home Server";
                    m_OSName = "Windows Home Server";
                    m_Edition = OSWindowsEdition.Home;
                    return;
                case PRODUCT_STORAGE_EXPRESS_SERVER:
                    m_OSFullName = "Windows Storage Server 2008 Express";
                    m_OSName = "Windows Storage Server 2008";
                    return;
                case PRODUCT_STORAGE_STANDARD_SERVER:
                    m_OSFullName = "Windows Storage Server 2008";
                    m_OSName = "Windows Storage Server 2008";
                    return;
                case PRODUCT_STORAGE_WORKGROUP_SERVER:
                    m_OSFullName = "Windows Storage Server 2008 Workgroup";
                    m_OSName = "Windows Storage Server 2008";
                    return;
                case PRODUCT_STORAGE_ENTERPRISE_SERVER:
                    m_OSFullName = "Windows Storage Server 2008 Enterprise";
                    m_OSName = "Windows Storage Server 2008";
                    m_Edition = OSWindowsEdition.Enterprise;
                    return;
                case PRODUCT_HYPERV:
                    m_OSFullName = "Microsoft Hyper-V Server 2008";
                    m_OSName = "Hyper-V Server 2008";
                    return;
            }
            #endregion

            //V�choz� zji�t�n� pro unlicensed nebo unknown
            if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_COMPUTE_SERVER) == VER_SUITE_COMPUTE_SERVER)
            {
                m_OSFullName = "Windows HPC Server 2008";
            }
            else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_STORAGE_SERVER) == VER_SUITE_STORAGE_SERVER)
            {
                m_OSFullName = "Windows Storage Server 2008";
                m_OSName = "Windows Storage Server 2008";
            }
            else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_WH_SERVER) == VER_SUITE_WH_SERVER)
            {
                m_OSFullName = "Windows Home Server";
                m_OSName = "Windows Home Server";
                m_Edition = OSWindowsEdition.Home;
            }
            else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
            {
                m_OSFullName = "Windows Server 2008 Datacenter";
                m_Edition = OSWindowsEdition.Datacenter;
            }
            else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
            {
                m_OSFullName = "Windows Server 2008 Enterprise";
                m_Edition = OSWindowsEdition.Enterprise;
            }
            else if ((m_OSVersionInfo.wSuiteMask & VER_SUITE_BLADE) == VER_SUITE_BLADE)
            {
                m_OSFullName = "Windows Web Server 2008";
                m_OSName = "Windows Web Server 2008";
                m_Edition = OSWindowsEdition.Web;
            }
            else if (((m_OSVersionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS) == VER_SUITE_SMALLBUSINESS) ||
                    ((m_OSVersionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS_RESTRICTED) == VER_SUITE_SMALLBUSINESS_RESTRICTED))
            {
                m_OSFullName = "Windows Small Business Server 2008";
            }
            else
            {
                m_OSFullName = "Windows Server 2008 Standard";
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows 7 nebo Windows Server 2008 R2 nebo Windows Small Business Server 2011
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void SetWin7Win2K8R2Information()
        {
            //GetProductInfo
            uint dwType = 0;
            if (SafeNativeMethods.GetProductInfo(6, 1, 0, 0, out dwType))
            {
                m_ProductInfoProductType = dwType;
            }

            m_OSWindows = OSWindowsID.Windows7;

            if (m_OSVersionInfo.wProductType == VER_NT_WORKSTATION)
            {
                m_OSFullName = "Windows 7";
                m_OSName = "Windows 7";

                #region ProductInfoProductType switch
                switch (m_ProductInfoProductType)
                {
                    case PRODUCT_HOME_BASIC:
                        m_OSFullName += " Home Basic";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_HOME_BASIC_N:
                        m_OSFullName += " Home Basic N";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_HOME_BASIC_E:
                        m_OSFullName += " Home Basic E";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_HOME_PREMIUM:
                        m_OSFullName += " Home Premium";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_HOME_PREMIUM_N:
                        m_OSFullName += " Home Premium N";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_HOME_PREMIUM_E:
                        m_OSFullName += " Home Premium E";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_STARTER:
                        m_OSFullName += " Starter Edition";
                        return;
                    case PRODUCT_STARTER_N:
                        m_OSFullName += " Starter N Edition";
                        return;
                    case PRODUCT_STARTER_E:
                        m_OSFullName += " Starter E Edition";
                        return;
                    case PRODUCT_ENTERPRISE:
                        m_OSFullName += " Enterprise";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_ENTERPRISE_N:
                        m_OSFullName += " Enterprise N";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_ENTERPRISE_E:
                        m_OSFullName += " Enterprise E";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_BUSINESS:
                    case PRODUCT_PROFESSIONAL:
                        m_OSFullName += " Professional";
                        m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                        return;
                    case PRODUCT_BUSINESS_N:
                    case PRODUCT_PROFESSIONAL_N:
                        m_OSFullName += " Professional N";
                        m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                        return;
                    case PRODUCT_PROFESSIONAL_E:
                        m_OSFullName += " Professional E";
                        m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                        return;
                    case PRODUCT_ULTIMATE:
                        m_OSFullName += " Ultimate";
                        m_Edition = OSWindowsEdition.Ultimate;
                        return;
                    case PRODUCT_ULTIMATE_N:
                        m_OSFullName += " Ultimate N";
                        m_Edition = OSWindowsEdition.Ultimate;
                        return;
                    case PRODUCT_ULTIMATE_E:
                        m_OSFullName += " Ultimate E";
                        m_Edition = OSWindowsEdition.Ultimate;
                        return;
                }
                #endregion
            }
            else
            {
                m_OSName = "Windows Server 2008 R2";
                m_OSFullName = "Windows Server 2008 R2";

                if (m_SystemInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_IA64)
                {
                    m_OSFullName = "Windows Server 2008 R2 for Itanium-based Systems";
                    return;
                }

                #region ProductInfoProductType switch
                switch (m_ProductInfoProductType)
                {
                    case PRODUCT_STANDARD_SERVER:
                        m_OSFullName = "Windows Server 2008 R2 Standard";
                        return;
                    case PRODUCT_STANDARD_SERVER_CORE:
                        m_OSFullName = "Windows Server 2008 R2 Standard (core installation)";
                        return;
                    case PRODUCT_STANDARD_SERVER_V:
                        m_OSFullName = "Windows Server 2008 R2 Standard without Hyper-V";
                        return;
                    case PRODUCT_STANDARD_SERVER_CORE_V:
                        m_OSFullName = "Windows Server 2008 R2 Standard without Hyper-V (core installation)";
                        return;
                    case PRODUCT_ENTERPRISE:
                    case PRODUCT_ENTERPRISE_N:
                    case PRODUCT_ENTERPRISE_SERVER:
                        m_OSFullName = "Windows Server 2008 R2 Enterprise";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_ENTERPRISE_SERVER_CORE:
                        m_OSFullName = "Windows Server 2008 R2 Enterprise (core installation)";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_ENTERPRISE_SERVER_V:
                        m_OSFullName = "Windows Server 2008 R2 Enterprise without Hyper-V";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_ENTERPRISE_SERVER_CORE_V:
                        m_OSFullName = "Windows Server 2008 R2 Enterprise without Hyper-V (core installation)";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_DATACENTER_SERVER:
                        m_OSFullName = "Windows Server 2008 R2 Datacenter";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_DATACENTER_SERVER_CORE:
                        m_OSFullName = "Windows Server 2008 R2 Datacenter (core installation)";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_DATACENTER_SERVER_V:
                        m_OSFullName = "Windows Server 2008 R2 Datacenter without Hyper-V";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_DATACENTER_SERVER_CORE_V:
                        m_OSFullName = "Windows Server 2008 R2 Datacenter without Hyper-V (core installation)";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_WEB_SERVER:
                        m_OSFullName = "Windows Web Server 2008 R2";
                        m_OSName = "Windows Web Server 2008 R2";
                        m_Edition = OSWindowsEdition.Web;
                        return;
                    case PRODUCT_WEB_SERVER_CORE:
                        m_OSFullName = "Windows Web Server 2008 R2 (core installation)";
                        m_OSName = "Windows Web Server 2008 R2";
                        m_Edition = OSWindowsEdition.Web;
                        return;
                    case PRODUCT_ENTERPRISE_SERVER_IA64:
                        m_OSFullName = "Windows Server 2008 R2 for Itanium-based Systems";
                        return;
                    case PRODUCT_SMALLBUSINESS_SERVER:
                    case PRODUCT_SERVER_FOR_SMALLBUSINESS:
                    case PRODUCT_SERVER_FOR_SMALLBUSINESS_V:
                        m_OSFullName = "Windows Small Business Server 2011 Standard";
                        m_OSName = "Windows Small Business Server 2011";
                        return;
                    case PRODUCT_SB_SOLUTION_SERVER:
                        m_OSFullName = "Windows Small Business Server 2011 Essentials";
                        m_OSName = "Windows Small Business Server 2011";
                        return;
                    case PRODUCT_SMALLBUSINESS_SERVER_PREMIUM:
                        m_OSFullName = "Windows Small Business Server 2011 Premium";
                        m_OSName = "Windows Small Business Server 2011";
                        return;
                    case PRODUCT_MEDIUMBUSINESS_SERVER_MANAGEMENT:
                    case PRODUCT_MEDIUMBUSINESS_SERVER_SECURITY:
                    case PRODUCT_MEDIUMBUSINESS_SERVER_MESSAGING:
                        m_OSFullName = "Windows Essential Business Server 2008 R2";
                        m_OSName = "Windows Essential Business Server 2008 R2";
                        return;
                    case PRODUCT_STARTER:
                    case PRODUCT_STARTER_N:
                    case PRODUCT_STARTER_E:
                        m_OSFullName = "Windows Server 2008 R2 Starter Edition";
                        return;
                    case PRODUCT_CLUSTER_SERVER:
                        m_OSFullName = "Windows HPC Server 2008 R2";
                        return;
                    case PRODUCT_HOME_SERVER:
                        m_OSFullName = "Windows Storage Server 2008 R2 Essentials";
                        m_OSName = "Windows Storage Server 2008 R2 Essentials";
                        return;
                    case PRODUCT_HOME_PREMIUM_SERVER:
                        m_OSFullName = "Windows Home Server 2011";
                        m_OSName = "Windows Home Server 2011";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_STORAGE_EXPRESS_SERVER:
                        m_OSFullName = "Windows Storage Server 2008 R2 Express";
                        m_OSName = "Windows Storage Server 2008 R2";
                        return;
                    case PRODUCT_STORAGE_STANDARD_SERVER:
                        m_OSFullName = "Windows Storage Server 2008 R2";
                        m_OSName = "Windows Storage Server 2008 R2";
                        return;
                    case PRODUCT_STORAGE_WORKGROUP_SERVER:
                        m_OSFullName = "Windows Storage Server 2008 R2 Workgroup";
                        m_OSName = "Windows Storage Server 2008 R2";
                        return;
                    case PRODUCT_STORAGE_ENTERPRISE_SERVER:
                        m_OSFullName = "Windows Storage Server 2008 R2 Enterprise";
                        m_OSName = "Windows Storage Server 2008 R2";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_HYPERV:
                        m_OSFullName = "Microsoft Hyper-V Server 2008 R2";
                        m_OSName = "Hyper-V Server 2008 R2";
                        return;
                    case PRODUCT_SOLUTION_EMBEDDEDSERVER:
                        m_OSFullName = "Windows MultiPoint Server 2011";
                        m_OSName = "Windows MultiPoint Server 2011";
                        return;
                }
                #endregion
            }
        }

        /// <summary>
        /// Z�sk�v� informace o verzi opera�n�ho syst�mu Windows 8 nebo Windows Server 2012
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void SetWin8Win2012Information()
        {
            //GetProductInfo
            uint dwType = 0;
            if (SafeNativeMethods.GetProductInfo(6, 2, 0, 0, out dwType))
            {
                m_ProductInfoProductType = dwType;
            }

            m_OSWindows = OSWindowsID.Windows8;

            if (m_OSVersionInfo.wProductType == VER_NT_WORKSTATION)
            {
                m_OSFullName = "Windows 8";
                m_OSName = "Windows 8";

                #region ProductInfoProductType switch
                switch (m_ProductInfoProductType)
                {
                    case PRODUCT_DEVELOPER_PREVIEW:
                        m_OSFullName += " Developer Preview";
                        return;
                    case PRODUCT_CORE_COUNTRYSPECIFIC:
                    case PRODUCT_CORE_SINGLELANGUAGE:
                    case PRODUCT_CORE:
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_CORE_N:
                        m_OSFullName += " N";
                        m_Edition = OSWindowsEdition.Home;
                        return;
                    case PRODUCT_BUSINESS:
                    case PRODUCT_PROFESSIONAL:
                    case PRODUCT_PROFESSIONAL_WMC:
                        m_OSFullName += " Pro";
                        m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                        return;
                    case PRODUCT_BUSINESS_N:
                    case PRODUCT_PROFESSIONAL_N:
                        m_OSFullName += " Pro N";
                        m_Edition = OSWindowsEdition.StandardOrProfessionalOrBusiness;
                        return;
                    case PRODUCT_ENTERPRISE:
                    case PRODUCT_ENTERPRISE_EVALUATION:
                    case PRODUCT_ULTIMATE:
                        m_OSFullName += " Enterprise";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                    case PRODUCT_ENTERPRISE_N:
                    case PRODUCT_ENTERPRISE_N_EVALUATION:
                    case PRODUCT_ULTIMATE_N:
                        m_OSFullName += " Enterprise N";
                        m_Edition = OSWindowsEdition.Enterprise;
                        return;
                }
                #endregion
            }
            else
            {
                m_OSName = "Windows Server 2012";
                m_OSFullName = "Windows Server 2012";

                #region ProductInfoProductType switch
                switch (m_ProductInfoProductType)
                {
                    case PRODUCT_DEVELOPER_PREVIEW:
                        m_OSFullName += " Developer Preview";
                        return;
                    case PRODUCT_STANDARD_SERVER:
                    case PRODUCT_STANDARD_EVALUATION_SERVER:
                        m_OSFullName += " Standard";
                        return;
                    case PRODUCT_STANDARD_SERVER_CORE:
                        m_OSFullName += " Standard (core installation)";
                        return;
                    case PRODUCT_STANDARD_SERVER_V:
                        m_OSFullName += " Standard without Hyper-V";
                        return;
                    case PRODUCT_STANDARD_SERVER_CORE_V:
                        m_OSFullName += " Standard without Hyper-V (core installation)";
                        return;
                    case PRODUCT_DATACENTER_SERVER:
                    case PRODUCT_DATACENTER_EVALUATION_SERVER:
                        m_OSFullName += " Datacenter";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_DATACENTER_SERVER_CORE:
                        m_OSFullName += " Datacenter (core installation)";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_DATACENTER_SERVER_V:
                        m_OSFullName += " Datacenter without Hyper-V";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_DATACENTER_SERVER_CORE_V:
                        m_OSFullName += " Datacenter without Hyper-V (core installation)";
                        m_Edition = OSWindowsEdition.Datacenter;
                        return;
                    case PRODUCT_SB_SOLUTION_SERVER:
                    case PRODUCT_MEDIUMBUSINESS_SERVER_MANAGEMENT:
                    case PRODUCT_MEDIUMBUSINESS_SERVER_SECURITY:
                    case PRODUCT_MEDIUMBUSINESS_SERVER_MESSAGING:
                    case PRODUCT_ESSENTIALBUSINESS_SERVER_MGMT:
                    case PRODUCT_ESSENTIALBUSINESS_SERVER_ADDL:
                    case PRODUCT_ESSENTIALBUSINESS_SERVER_MGMTSVC:
                    case PRODUCT_ESSENTIALBUSINESS_SERVER_ADDLSVC:
                        m_OSFullName += " Essentials";
                        m_OSName += " Essentials";
                        return;
                    case PRODUCT_SERVER_FOUNDATION:
                        m_OSFullName += " Foundation";
                        m_OSName += " Foundation";
                        return;
                    case PRODUCT_STORAGE_EXPRESS_SERVER:
                    case PRODUCT_STORAGE_STANDARD_SERVER:
                    case PRODUCT_STORAGE_STANDARD_EVALUATION_SERVER:
                        m_OSFullName = "Windows Storage Server 2012 Standard";
                        m_OSName = "Windows Storage Server 2012";
                        return;
                    case PRODUCT_STORAGE_WORKGROUP_SERVER:
                    case PRODUCT_STORAGE_WORKGROUP_EVALUATION_SERVER:
                        m_OSFullName = "Windows Storage Server 2012 Workgroup";
                        m_OSName = "Windows Storage Server 2012";
                        return;
                    case PRODUCT_STORAGE_EXPRESS_SERVER_CORE:
                    case PRODUCT_STORAGE_STANDARD_SERVER_CORE:
                        m_OSFullName = "Windows Storage Server 2012 Standard (core installation)";
                        m_OSName = "Windows Storage Server 2012";
                        return;
                    case PRODUCT_STORAGE_WORKGROUP_SERVER_CORE:
                        m_OSFullName = "Windows Storage Server 2012 Workgroup (core installation)";
                        m_OSName = "Windows Storage Server 2012";
                        return;
                    case PRODUCT_HYPERV:
                        m_OSFullName = "Hyper-V Server 2012";
                        m_OSName = "Hyper-V Server 2012";
                        return;
                }
                #endregion
            }
        }
        #endregion

        /// <summary>
        /// Nastaven� informace o Service Packu.
        /// </summary>
        /// <remarks>
        /// Nastavuje m_ServicePack a m_CSDBuildNumber
        /// </remarks>
        private void SetServicePackString()
        {
            m_ServicePack = "";
            m_CSDBuildNumber = 0;

            if (m_OS.Platform == System.PlatformID.Win32NT)
            {
                string ServicePack = m_OSVersionInfo.szCSDVersion.Trim();

                //O�et�en� pro Windows Vista Build 5456 kde v szCSDVersion je "Service Pack 0 v. "
                if (ServicePack.Length > 0 && ServicePack.Substring(ServicePack.Length - 3) == " v.")
                {
                    ServicePack = ServicePack.Substring(0, ServicePack.Length - 3);
                }

                if (m_OSVersionInfo.dwMajorVersion == 4 &&
                    ServicePack == "Service Pack 6")
                {
                    if (Microsoft.Win32.Registry.LocalMachine.OpenSubKey("SYSTEM\\Microsoft\\Windows NT\\CurrentVersion\\Hotfix\\Q246009") != null)
                    {
                        string SP6a = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("SYSTEM\\Microsoft\\Windows NT\\CurrentVersion\\Hotfix\\Q246009").GetValue("Installed") as string;

                        if (SP6a == "1")
                        {
                            ServicePack = "Service Pack 6a";
                        }
                    }
                }

                m_ServicePack = ServicePack;

                if (Microsoft.Win32.Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion") != null)
                {
                    string CSDBuildNumberStr = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                                "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion").GetValue("CSDBuildNumber") as string;

                    if (!Int32.TryParse(CSDBuildNumberStr, out m_CSDBuildNumber))
                    {
                        m_CSDBuildNumber = 0;
                    }
                }
            }
        }

        /// <summary>
        /// Nastaven� SpecialEdition info
        /// </summary>
        /// <remarks>
        /// Nastavuje m_SpecialEdition
        /// </remarks>
        private void SetSpecialEdition()
        {
            if (SafeNativeMethods.GetSystemMetrics(SM_TABLETPC) != 0)
            {
                m_SpecialEdition = m_SpecialEdition | OSWindowsSpecialEdition.TabletPC;
            }
            if (SafeNativeMethods.GetSystemMetrics(SM_MEDIACENTER) != 0)
            {
                m_SpecialEdition = m_SpecialEdition | OSWindowsSpecialEdition.MediaCenter;
            }
            if (SafeNativeMethods.GetSystemMetrics(SM_SERVERR2) != 0)
            {
                m_SpecialEdition = m_SpecialEdition | OSWindowsSpecialEdition.R2;
            }
            if (SafeNativeMethods.GetSystemMetrics(SM_STARTER) != 0)
            {
                m_SpecialEdition = m_SpecialEdition | OSWindowsSpecialEdition.Starter;
            }
        }

        /// <summary>
        /// Vrac� FrameworkVersion
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private string GetFrameworkVersion()
        {
            if (m_CLRVersion.Major == 4 && m_CLRVersion.Minor == 0)
            {
                //4.0.30319.237   - 4.0
                //4.0.30319.17020 - 4.5 (Microsoft .NET Framework 4.5 Developer Preview)
                //4.0.30319.17379 - 4.5 (Microsoft .NET Framework 4.5 Consumer Preview)
                //4.0.30319.17626 - 4.5 (Microsoft .NET Framework 4.5 RC)
                //4.0.30319.17929 - 4.5 (Microsoft .NET Framework 4.5 RTM)

                if (m_CLRVersion >= new Version(4, 0, 30319, 17020))
                {
                    return "4.5";
                }

                return "4.0";   //4.0.30319.237
            }
            else if (m_CLRVersion.Major == 2 && m_CLRVersion.Minor == 0)
            {
                #region FW 2.0, 3.0, 3.5, 3.5.1
                if (m_CLRVersion >= new Version(2, 0, 50727, 3521))     //3.5.1
                {
                    //2.0.50727.3521 - 3.5.1 in Windows 7 Beta 2
                    //2.0.50727.4016 - 3.5 SP1 in Windows Vista SP2 or Windows Server 2008 SP2
                    //2.0.50727.4918 - 3.5.1 in Windows 7 RC or Windows Server 2008 R2

                    try
                    {
                        System.Reflection.Assembly.Load("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089");

                        if (Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.OSVersion.Version.Major >= 6 && Environment.OSVersion.Version.Minor >= 1)
                        {
                            return "3.5.1";
                        }

                        return "3.5 SP1";
                    }
                    catch (FileNotFoundException) { }

                    return "2.0 SP2";
                }

                if (m_CLRVersion >= new Version(2, 0, 50727, 3053))
                {
                    return "3.5 SP1";
                }

                if (m_CLRVersion >= new Version(2, 0, 50727, 1433))
                {
                    //2.0 SP1 nebo 3.0 SP1 nebo 3.5
                    try
                    {
                        System.Reflection.Assembly.Load("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089");
                        return "3.5";
                    }
                    catch (FileNotFoundException) { }

                    try
                    {
                        System.Reflection.Assembly.Load("WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                        return "3.0 SP1";
                    }
                    catch (FileNotFoundException) { }

                    return "2.0 SP1";
                }

                if (m_CLRVersion == new Version(2, 0, 50727, 312))  //Vista RTM
                {
                    return "3.0";
                }

                //2.0.50727.42 RTM - 2.0 nebo 3.0
                try
                {
                    System.Reflection.Assembly.Load("WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                    return "3.0";
                }
                catch (FileNotFoundException) { }

                return "2.0";
                #endregion
            }

            return m_CLRVersion.Major.ToString(System.Globalization.CultureInfo.InvariantCulture) + "." + m_CLRVersion.Minor.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
        #endregion

        #region Set Processor Information
        /// <summary>
        /// Nataven� informac� o procesoru
        /// </summary>
        /// <remarks>
        /// Nastavuje:
        /// m_VendorIdentifier, m_ProcessorModel, m_ProcessorStepping, m_ProcessorName, m_ProcessorDescription
        /// m_CPUSpeed, m_ProcessorFeaturePresent, m_IsWow64Process
        /// </remarks>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void SetProcessorInformation()
        {
            //Na�ten� VendorIdentifier
            //Proto�e C# neumo��uje k na�ten� pou��t cpuid instrukce, pou�ije se alternativn� metoda na�ten� z registr�
            m_VendorIdentifier = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                        "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0").GetValue("VendorIdentifier") as string;

            if (m_VendorIdentifier == null)
            {
                m_VendorIdentifier = "";
            }

            m_ProcessorModel = 0;
            m_ProcessorStepping = 0;
            m_ProcessorName = "";
            m_ProcessorDescription = "";

            #region Processor Architecture switch
            switch (m_SystemInfo.wProcessorArchitecture)
            {
                case PROCESSOR_ARCHITECTURE_INTEL:
                    m_ProcessorDescription = "x86 Family";

                    if (m_VendorIdentifier.Equals("CyrixInstead", StringComparison.OrdinalIgnoreCase))
                    {
                        m_ProcessorName = "Cyrix";
                    }
                    else if (m_VendorIdentifier.Equals("CentaurHauls", StringComparison.OrdinalIgnoreCase))
                    {
                        m_ProcessorName = "Centaur";
                    }
                    else if (m_VendorIdentifier.Equals("NexGenDriven", StringComparison.OrdinalIgnoreCase))
                    {
                        m_ProcessorName = "NexGen";
                    }
                    else    //GenuineIntel, AuthenticAMD
                    {
                        m_ProcessorName = "Intel";

                        switch (m_SystemInfo.wProcessorLevel)   //Family number
                        {
                            case 0:
                                //Old system - wProcessorLevel not set, using dwProcessorType
                                switch (m_SystemInfo.dwProcessorType)
                                {
                                    case 386:
                                        m_ProcessorName = "Intel 80386";
                                        break;
                                    case 486:
                                        if (m_VendorIdentifier.Equals("AuthenticAMD", StringComparison.OrdinalIgnoreCase))
                                        {
                                            m_ProcessorName = "AMD 486";
                                        }
                                        else
                                        {
                                            m_ProcessorName = "Intel 80486";
                                        }
                                        break;
                                    default:    //586
                                        if (m_VendorIdentifier.Equals("AuthenticAMD", StringComparison.OrdinalIgnoreCase))
                                        {
                                            m_ProcessorName = "AMD K5 or K6";
                                        }
                                        else
                                        {
                                            m_ProcessorName = "Intel Pentium";
                                        }
                                        break;
                                }
                                break;
                            case 2:
                            case 3:
                                m_ProcessorName = "Intel 80386";
                                break;
                            case 4:
                                if (m_VendorIdentifier.Equals("AuthenticAMD", StringComparison.OrdinalIgnoreCase))
                                {
                                    m_ProcessorName = "AMD 486";
                                }
                                else
                                {
                                    m_ProcessorName = "Intel 80486";
                                }
                                break;
                            default:    //5, 6, 15
                                //x86 Procesory Intel nebo AMD Pentium nebo vy���
                                m_ProcessorModel = (short)(m_SystemInfo.wProcessorRevision >> 8);   //HIBYTE
                                m_ProcessorStepping = (short)(byte)(m_SystemInfo.wProcessorRevision);   //LOBYTE

                                m_ProcessorDescription = string.Format(System.Globalization.CultureInfo.CurrentCulture, "x86 Family {0} Model {1} Stepping {2}",
                                                            m_SystemInfo.wProcessorLevel.ToString(System.Globalization.CultureInfo.CurrentCulture), m_ProcessorModel, m_ProcessorStepping) +
                                                            (string.IsNullOrEmpty(m_VendorIdentifier) ? "" : " " + m_VendorIdentifier);

                                //Nastaven� jm�na procesoru
                                m_ProcessorName = GetProcessorIntelAMDName();
                                break;
                        }
                    }
                    break;
                case PROCESSOR_ARCHITECTURE_MIPS:
                    m_ProcessorName = "MIPS R4000";    //si.wProcessorLevel == 0004
                    break;
                case PROCESSOR_ARCHITECTURE_ALPHA:
                    m_ProcessorName = "Alpha " + m_SystemInfo.wProcessorLevel.ToString(System.Globalization.CultureInfo.CurrentCulture);  //21064, 21066, 21164
                    break;
                case PROCESSOR_ARCHITECTURE_PPC:
                    switch (m_SystemInfo.wProcessorLevel)
                    {
                        case 1:
                            m_ProcessorName = "PPC 601";
                            break;
                        case 3:
                            m_ProcessorName = "PPC 603";
                            break;
                        case 4:
                            m_ProcessorName = "PPC 604";
                            break;
                        case 6:
                            m_ProcessorName = "PPC 603+";
                            break;
                        case 9:
                            m_ProcessorName = "PPC 604+";
                            break;
                        default:    //20
                            m_ProcessorName = "PPC 620";
                            break;
                    }
                    break;
                case PROCESSOR_ARCHITECTURE_SHX:
                    m_ProcessorName = "SHX";
                    break;
                case PROCESSOR_ARCHITECTURE_ARM:
                    m_ProcessorName = "ARM";
                    break;
                case PROCESSOR_ARCHITECTURE_IA64:
                    m_ProcessorName = "Intel Itanium";
                    break;
                case PROCESSOR_ARCHITECTURE_ALPHA64:
                    m_ProcessorName = "Alpha 64-bit";
                    break;
                case PROCESSOR_ARCHITECTURE_MSIL:
                    m_ProcessorName = "MSIL";
                    break;
                case PROCESSOR_ARCHITECTURE_AMD64:
                    //x64 (64-bit) Procesory (AMD Opteron, AMD Athlon64, Intel Xeon with Intel EM64T support, Intel Pentium 4 with Intel EM64T support)
                    m_ProcessorModel = (short)(m_SystemInfo.wProcessorRevision >> 8);   //HIBYTE
                    m_ProcessorStepping = (short)(byte)(m_SystemInfo.wProcessorRevision);   //LOBYTE

                    m_ProcessorDescription = string.Format(System.Globalization.CultureInfo.CurrentCulture, "AMD64 Family {0} Model {1} Stepping {2}",
                                                m_SystemInfo.wProcessorLevel.ToString(System.Globalization.CultureInfo.CurrentCulture), m_ProcessorModel, m_ProcessorStepping) +
                                                (string.IsNullOrEmpty(m_VendorIdentifier) ? "" : " " + m_VendorIdentifier);

                    //Nastaven� jm�na procesoru
                    m_ProcessorName = GetProcessorIntelAMDName();
                    break;
                case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
                    m_ProcessorName = "IA32";
                    break;
            }
            #endregion

            //Nastaven� CPU Speed
            if (Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                        "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0").GetValue("~MHz") != null)
            {
                m_CPUSpeed = Convert.ToInt32(Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                                    "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0").GetValue("~MHz"), System.Globalization.CultureInfo.CurrentCulture);
            }

            //Nastaven� ProcessorFeaturePresent
            if (GetIsProcessorFeaturePresent(PF_MMX_INSTRUCTIONS_AVAILABLE))
            {
                m_ProcessorFeaturePresent = m_ProcessorFeaturePresent | ProcessorFeature.MMX;
            }
            if (GetIsProcessorFeaturePresent(PF_3DNOW_INSTRUCTIONS_AVAILABLE))
            {
                m_ProcessorFeaturePresent = m_ProcessorFeaturePresent | ProcessorFeature.AMD3DNow;
            }
            if (GetIsProcessorFeaturePresent(PF_XMMI_INSTRUCTIONS_AVAILABLE))
            {
                m_ProcessorFeaturePresent = m_ProcessorFeaturePresent | ProcessorFeature.SSE;
            }
            if (GetIsProcessorFeaturePresent(PF_XMMI64_INSTRUCTIONS_AVAILABLE))
            {
                m_ProcessorFeaturePresent = m_ProcessorFeaturePresent | ProcessorFeature.SSE2;
            }
            if (GetIsProcessorFeaturePresent(PF_SSE3_INSTRUCTIONS_AVAILABLE))
            {
                m_ProcessorFeaturePresent = m_ProcessorFeaturePresent | ProcessorFeature.SSE3;
            }

            m_IsWow64Process = GetIsWow64Process();
        }

        /// <summary>
        /// Vr�cen� jm�na procesoru pro x86 Pentium nebo x64 Procesory Intel nebo AMD
        /// </summary>
        private string GetProcessorIntelAMDName()
        {
            //Na�ten� jm�na z registr�
            string RegProcessorName = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                        "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0").GetValue("ProcessorNameString") as string;

            if (!string.IsNullOrEmpty(RegProcessorName))
            {
                return RegProcessorName.Trim();
            }

            //Vr�cen� jm�na procesoru podle VendorIdentifier, Family a Model number
            return GetProcessorIntelAMDNameDefName();
        }

        /// <summary>
        /// Vr�cen� jm�na procesoru pro x86 Pentium nebo x64 Procesory Intel nebo AMD
        /// podle VendorIdentifier, Family a Model number (pro star�� syst�my
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private string GetProcessorIntelAMDNameDefName()
        {
            if (m_VendorIdentifier.Equals("AuthenticAMD", StringComparison.OrdinalIgnoreCase))
            {
                switch (m_SystemInfo.wProcessorLevel)   //Family number
                {
                    case 5:     //AMD K5 or K6
                        switch (m_ProcessorModel)
                        {
                            case 0:
                                return "AMD K5 SSA5";
                            case 1:
                            case 2:
                            case 3:
                                return "AMD K5";
                            case 6:
                            case 7:
                                return "AMD K6";
                            case 8:
                                return "AMD K6-2";
                            case 9:
                                return "AMD K6-3";
                            case 13:
                                return "AMD K6-3+";
                        }

                        return "AMD K6";
                    case 6:     //AMD Athlon, Duron
                        switch (m_ProcessorModel)
                        {
                            case 0:
                            case 1:
                                return "AMD Athlon";    //(25um)
                            case 2:
                                return "AMD Athlon";    //(18um)
                            case 3:
                                return "AMD Duron";
                            case 4:
                                return "AMD Athlon Thunderbird";
                            case 6:
                                return "AMD Athlon Palamino";
                            case 7:
                                return "AMD Duron Morgan";
                            case 8:
                                return "AMD Athlon XP"; //Thoroughbred
                            case 10:
                                return "AMD Athlon XP Barton";
                        }

                        return "AMD Athlon XP";
                    default:    //15
                        return "AMD Athlon 64";
                }
            }
            else    //GenuineIntel
            {
                switch (m_SystemInfo.wProcessorLevel)   //Family number
                {
                    case 5:     //Intel Pentium
                        switch (m_ProcessorModel)
                        {
                            case 0:
                                return "Intel Pentium 60/66 A-step";
                            case 1:
                                return "Intel Pentium 60/66";
                            case 2:
                                return "Intel Pentium 75-200";
                            case 3:
                                return "Intel OverDrive PODP5V83";
                            case 4:
                                return "Intel Pentium MMX";
                            case 7:
                                return "Intel Mobile Pentium 75-200";
                            case 8:
                                return "Intel Mobile Pentium MMX";
                        }

                        return "Intel Pentium";
                    case 6:     //Intel Pentium Pro
                        switch (m_ProcessorModel)
                        {
                            case 1:
                                return "Intel Pentium Pro A-Step";
                            case 3:
                                return "Intel Pentium II";  //Klamath
                            case 5:
                                return "Intel Pentium II";  //Deschutes
                            case 6:
                                return "Intel Celeron";     //Mendocino
                            case 7:
                                return "Intel Pentium III"; //Katmai
                            case 8:
                                return "Intel Pentium III"; //Coppermine
                            case 9:
                                return "Intel Mobile Pentium III";
                            case 10:
                                return "Intel Pentium III Xeon";    //(0.18um)
                            case 11:
                                return "Intel Pentium III Xeon";    //(0.13um)
                        }

                        return "Intel Pentium Pro";
                    case 7:
                        return "Intel Itanium";
                    default:    //15, 16
                        return "Intel Pentium 4";
                }
            }
        }
        #endregion
        #endregion
    }
}
