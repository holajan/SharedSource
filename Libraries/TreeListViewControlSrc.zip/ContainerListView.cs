﻿using System;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;
using System.Drawing;
using System.Drawing.Design;
using System.Globalization;
using System.Reflection;
using System.Security.Permissions;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Runtime.InteropServices;

namespace IMP.SharedControls
{
    #region public enums declarations
    /// <summary>
    /// Enumerated values specifying the type of CheckBox to draw.
    /// </summary>
    public enum CheckBoxType
    {
        /// <summary>
        /// A CheckBox is specified.
        /// </summary>
        CheckBox,
        /// <summary>
        /// A RadioButton is specified.
        /// </summary>
        RadioButton
    }

    /// <summary>
    /// Enumerated type specifying what GridLines to show.
    /// </summary>
    public enum GridLineSelections
    {
        /// <summary>
        /// Do not show any gridlines.
        /// </summary>
        None,
        /// <summary>
        /// Show both Column and Row gridlines.
        /// </summary>
        Both,
        /// <summary>
        /// Show only Column gridlines.
        /// </summary>
        Column,
        /// <summary>
        /// Show only Row gridlines.
        /// </summary>
        Row
    }

    /// <summary>
    /// Enumerated values specifying Actions of a collection.
    /// </summary>
    public enum CollectionActions
    {
        /// <summary>
        /// Nothing has happened to an item. Default value.
        /// </summary>
        Nothing,
        /// <summary>
        /// An item has been Added.
        /// </summary>
        Added,
        /// <summary>
        /// An item has changed.
        /// </summary>
        Changed,
        /// <summary>
        /// The collection has been cleared.
        /// </summary>
        Cleared,
        /// <summary>
        /// The collection is about to be cleared (no items have been cleared yet).
        /// </summary>
        Clearing,
        /// <summary>
        /// An item has been removed.
        /// </summary>
        Removed
    }

    /// <summary>
    /// Specifies the action of ContainerListView item or SubItem.
    /// </summary>
    public enum ContainerListViewItemAction
    {
        /// <summary>
        /// Default action, toggle of node in TreeListView
        /// </summary>
        Default = 0,
        /// <summary>
        /// Begins editing the specified item or SubItem.
        /// </summary>
        BeginEdit = 1,
        /// <summary>
        /// Nothing happened
        /// </summary>
        None = 2
    }
    #endregion

    #region public delegates
    /// <summary>
    /// Delegate that handles events on the ContainerListView control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void ContainerListViewEventHandler(object sender, ContainerListViewEventArgs e);

    /// <summary>
    /// Delegate that handles the BeforeCheck and BeforeSelect events of a ContainerListView.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void ContainerListViewCancelEventHandler(object sender, ContainerListViewCancelEventArgs e);

    /// <summary>
    /// Delegate that handles events of item on the ContainerListView control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void ContainerListViewItemEventHandler(object sender, ContainerListViewItemEventArgs e);

    /// <summary>
    /// Delegate that handles ColumnHeader events.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void HeaderMenuEventHandler(object sender, ContainerColumnHeaderEventArgs e);

    /// <summary>
    /// Delegate that handles events on the ContextMenu.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void ContextMenuEventHandler(object sender, MouseEventArgs e);
	#endregion

    #region EventArgs types declarations
    #region ContainerListViewEventArgs class
    /// <summary>
    /// Provides data for the ContainerListViewEventHandler delegate
    /// </summary>
    public class ContainerListViewEventArgs : EventArgs
    {
		#region member varible and default property initialization
        private ContainerListViewObject item;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of ContainerListViewEventArgs.
        /// </summary>
        /// <param name="Item">The ContainerListViewObject that the event is responding to.</param>
        public ContainerListViewEventArgs(ContainerListViewObject Item)
        {
            this.item = Item;
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the ContainerListViewObject that has been selected.
        /// </summary>
        public ContainerListViewObject Item
        {
            get { return this.item; }
        }
        #endregion
    }
    #endregion

    #region ContainerListViewItemEventArgs class
    /// <summary>
    /// Provides data for the ContainerListViewItemEventHandler delegate
    /// </summary>
    public class ContainerListViewItemEventArgs : ContainerListViewEventArgs
    {
        #region member varible and default property initialization
        private ContainerListViewObject.ContainerListViewSubItem subItem;
        private ContainerListViewItemAction action = ContainerListViewItemAction.Default;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of TreeListViewCancelEventArgs.
        /// </summary>
        /// <param name="Item">The item that the event is responding to.</param>
        /// <param name="SubItem">The SubItem or null that the event is responding to.</param>
        public ContainerListViewItemEventArgs(ContainerListViewObject Item, ContainerListViewObject.ContainerListViewSubItem SubItem)
            : base(Item)
        {
            this.subItem = SubItem;
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the ContainerListViewObject.ContainerListViewSubItem or null that has been selected.
        /// </summary>
        public ContainerListViewObject.ContainerListViewSubItem SubItem
        {
            get { return this.subItem; }
        }

        /// <summary>
        /// Gets or sets the action do do on the item or SubItem.
        /// </summary>
        public ContainerListViewItemAction Action
        {
            get { return this.action; }
            set { this.action = value; }
        }
        #endregion
    }
    #endregion

    #region ContainerListViewCancelEventArgs class
    /// <summary>
    /// Provides data for the ContainerListViewCancelEventHandler delegate
    /// </summary>
    public class ContainerListViewCancelEventArgs : EventArgs
    {
		#region member varible and default property initialization
        private bool cancel = false;
        private ContainerListViewObject item;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of ContainerListViewCancelEventArgs.
        /// </summary>
        /// <param name="Item">The ContainerListViewObject that the event is responding to.</param>
        /// <param name="Cancel"><c>true</c> to cancel the event; otherwise, <c>false</c>.</param>
        public ContainerListViewCancelEventArgs(ContainerListViewObject Item, bool Cancel)
        {
            this.item = Item;
            this.cancel = Cancel;
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets or sets a value indicating whether the event should be canceled.
        /// </summary>
        public bool Cancel
        {
            get { return this.cancel; }
            set { this.cancel = value; }
        }

        /// <summary>
        /// Gets the ContainerListViewObject that has been checked or selected.
        /// </summary>
        public ContainerListViewObject Item
        {
            get { return this.item; }
        }
        #endregion
    }
	#endregion

    #region ContainerColumnHeaderEventArgs class
    /// <summary>
    /// Provides data for the HeaderMenuEventHandler delegate
    /// </summary>
    public class ContainerColumnHeaderEventArgs : EventArgs
    {
		#region member varible and default property initialization
        private ContainerColumnHeader column;
        private MouseEventArgs mouseEventArgs;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of ContainerColumnHeaderEventArgs.
        /// </summary>
        /// <param name="Column">The ContainerContainerColumnHeader to intialize the class with.</param>
        /// <param name="MouseArg">The MouseEventArgs to initialize the class with.</param>
        public ContainerColumnHeaderEventArgs(ContainerColumnHeader Column, MouseEventArgs MouseArg)
        {
            this.column = Column;
            this.mouseEventArgs = MouseArg;
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the Column that was clicked.
        /// </summary>
        public ContainerColumnHeader Column
        {
            get { return this.column; }
        }

        /// <summary>
        /// The MouseEventArg created when the Column was clicked.
        /// </summary>
        public MouseEventArgs MouseArg
        {
            get { return this.mouseEventArgs; }
        }
        #endregion
    }
    #endregion
    #endregion

    #region public types declarations
    #region ContainerListViewObject class
    /// <summary>
    /// ContainerListViewObject Class
    /// </summary>
    public abstract class ContainerListViewObject : ICloneable
    {
		#region public member types
        #region ContainerListViewSubItem Class
        /// <summary>
        /// Represents a SubItem of a ContainerListViewObject.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible")]
        [DesignTimeVisible(false), ToolboxItem(false), Serializable, DefaultProperty("Text"), TypeConverter(typeof(ContainerListViewSubItemConverter))]
        public class ContainerListViewSubItem : ICloneable
        {
		    #region member varible and default property initialization
            [NonSerialized]
            private Control childControl;

            /// <summary>
            /// Custom value of the BackColor of the item.
            /// </summary>
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
            protected Color backColorValue = Color.Transparent;

            /// <summary>
            /// Custom value of the foreground color of the the item's text.
            /// </summary>
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
            protected Color foreColorValue = Color.Empty;

            /// <summary>
            /// Custom value of the font of the text displayed by the item
            /// </summary>
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
            protected Font fontValue;

            private string text;
            private HorizontalAlignment textAlign = HorizontalAlignment.Left;
            private object userData;
            [NonSerialized]
            private ContainerListViewObject parent;
            [NonSerialized]
            private ContainerListView parentOwner;
            #endregion

            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of ContainerListViewSubItem.
            /// </summary>
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.ToString")]
            public ContainerListViewSubItem()
            {
                this.text = "SubItem " + this.Index.ToString();
            }

            /// <summary>
            /// Creates a new instance of ContainerListViewSubItem.
            /// </summary>
            /// <param name="Text">The Text to assign.</param>
            public ContainerListViewSubItem(string Text)
            {
                this.text = Text;
                this.ConstructControl(null);
            }

            /// <summary>
            /// Creates a new instance of ContainerListViewSubItem.
            /// </summary>
            /// <param name="Control"></param>
            public ContainerListViewSubItem(Control Control)
            {
                this.text = "SubItem " + this.Index.ToString(CultureInfo.InvariantCulture);
                this.ConstructControl(Control);
            }

            /// <summary>
            /// Creates a new instance of ContainerListViewSubItem.
            /// </summary>
            /// <param name="Text">The text to display for the item.</param>
            /// <param name="BackColor">The BackColor of the item.</param>
            /// <param name="ForeColor">The ForeColor of the item.</param>
            /// <param name="Font">The Font of the item.</param>
            public ContainerListViewSubItem(string Text, Color BackColor, Color ForeColor, Font Font)
                : this(Text, BackColor, ForeColor, Font, null) { }

            /// <summary>
            /// Creates a new instance of ContainerListViewSubItem.
            /// </summary>
            /// <param name="Text">The text to display for the item.</param>
            /// <param name="BackColor">The BackColor of the item.</param>
            /// <param name="ForeColor">The ForeColor of the item.</param>
            /// <param name="Font">The Font of the item.</param>
            /// <param name="Tag">Data associated with the subitem.</param>
            public ContainerListViewSubItem(string Text, Color BackColor, Color ForeColor, Font Font, object Tag)
            {
                this.text = Text;
                this.userData = Tag;
                this.backColorValue = BackColor;
                this.foreColorValue = ForeColor;
                this.fontValue = Font;
            }
		    #endregion

	        #region action methods
            /// <summary>
            /// Creates a new Object that is a copy of the current instance.
            /// </summary>
            /// <returns>An object that is a Clone of the current instance.</returns>
            public object Clone()
            {
                var item = new ContainerListViewSubItem();
                item.childControl = this.childControl;
                item.backColorValue = this.backColorValue;
                item.foreColorValue = this.foreColorValue;
                item.fontValue = this.fontValue;
                item.text = this.text;
                item.textAlign = this.textAlign;
                item.userData = this.userData;
                return item;
            }

            /// <summary>
            /// Removes the current ContainerListViewSubItem from the ContainerListViewItem.
            /// </summary>
            public void Remove()
            {
                if (this.Parent != null)
                {
                    this.Parent.SubItems.Remove(this);
                }
            }

            /// <summary>
            /// Overriden.  Returns a string representing the object in the SubItem.
            /// </summary>
            /// <remarks>
            /// If the Control is null then the Text property is returned. Otherwise, the string representation of the type of control displayed in the SubItem is returned.
            /// </remarks>
            /// <returns>A String object.</returns>
            public override string ToString()
            {
                if (this.Control == null)
                {
                    return this.Text;
                }

                return this.Control.ToString();
            }

            /// <summary>
            /// Assigns the parent ContainerListViewItem to the SubItem.
            /// </summary>
            /// <param name="Parent">The ContainerListViewItem that the SubItem belongs to.</param>
            [EditorBrowsable(EditorBrowsableState.Never)]
            internal void SetParent(ContainerListViewObject Parent)
            {
                this.parent = Parent;
            }

            /// <summary>
            /// Sets the Parent ContainerListView
            /// </summary>
            /// <param name="ContainerListView">A ContainerListView object.</param>
            [EditorBrowsable(EditorBrowsableState.Never)]
            internal void SetParentOwner(ContainerListView ContainerListView)
            {
                this.parentOwner = ContainerListView;
                if (this.childControl != null)
                {
                    if (ContainerListView != null)
                    {
                        this.childControl.Parent = ContainerListView;
                    }
                    else
                    {
                        this.childControl.Visible = false;
                    }
                }
            }
	        #endregion

    		#region property getters/setters
            /// <summary>
            /// Gets or Sets the Text contained in the control.
            /// </summary>
            [
            Browsable(true), Category("Appearance"),
            Description("The Text contained in the control."),
            Localizable(true),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)
            ]
            public string Text
            {
                get { return this.text; }
                set
                {
                    if (!this.text.Equals(value))
                    {
                        this.text = value;
                        this.InvalidateParent(false);
                    }
                }
            }

            /// <summary>
            /// Gets the zero-based position of the SubItem in the collection.
            /// </summary>
            [Browsable(false)]
            public int Index
            {
                get
                {
                    if (this.Parent != null)
                    {
                        return this.Parent.SubItems.IndexOf(this);
                    }

                    return -1;
                }
            }

            /// <summary>
            /// The Object to associate to the item.
            /// </summary>
            [
            Browsable(true), Category("Data"),
            Description("Data to associate with the item"),
            DefaultValue(typeof(object), null),
            Bindable(true), Localizable(true),
            DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
            TypeConverter(typeof(System.ComponentModel.StringConverter))
            ]
            public object Tag
            {
                get { return this.userData; }
                set { this.userData = value; }
            }

            /// <summary>
            /// Gets or Sets the BackColor of the SubItem.
            /// </summary>
            [
            Browsable(true), Category("Appearance"),
            Description("Determines the BackColor of the SubItem."),
            DefaultValue(typeof(Color), "Transparent")
            ]
            public Color BackColor
            {
                get { return this.backColorValue; }
                set
                {
                    if (!this.backColorValue.Equals(value))
                    {
                        this.backColorValue = value;
                        this.InvalidateParent(false);
                    }
                }
            }

            /// <summary>
            /// Gets or sets the foreground color of the SubItem's text.
            /// </summary>
            [
            Browsable(true), Category("Appearance"),
            Description("Determines the foreground color of the the SubItem's text."),
            ]
            public virtual Color ForeColor
            {
                get
                {
                    if (this.foreColorValue != Color.Empty)
                    {
                        return this.foreColorValue;
                    }

                    if (this.Parent != null && this.Parent.useItemStyleForSubItems)
                    {
                        return this.Parent.ForeColor;
                    }

                    if (this.Parent != null && this.Parent.ListView != null)
                    {
                        return this.Parent.ListView.ForeColor;
                    }

                    return SystemColors.WindowText;
                }
                set
                {
                    if (!this.foreColorValue.Equals(value))
                    {
                        this.foreColorValue = value;

                        this.InvalidateParent(false);
                    }
                }
            }

            /// <summary>
            /// This method is used by designers to enable resetting the property to its default value.
            /// </summary>
            protected virtual void ResetForeColor()
            {
                this.foreColorValue = Color.Empty;
            }

            /// <summary>
            /// This method indicates to designers whether the property value is different from the ambient value, in which case the designer should persist the value.
            /// </summary>
            protected virtual bool ShouldSerializeForeColor()
            {
                return !this.foreColorValue.IsEmpty;
            }

            /// <summary>
            /// Gets or sets the font of the text displayed by the SubItem.
            /// </summary>
            [
            Browsable(true), Category("Appearance"),
            Description("Determines the font of the text displayed by the SubItem."),
            AmbientValue((string)null),
            Localizable(true)
            ]
            public virtual Font Font
            {
                get
                {
                    if (this.fontValue != null)
                    {
                        return this.fontValue;
                    }

                    if (this.Parent != null && this.Parent.useItemStyleForSubItems)
                    {
                        return this.Parent.Font;
                    }

                    if (this.Parent != null && this.Parent.ListView != null)
                    {
                        return this.Parent.ListView.Font;
                    }

                    return SystemFonts.DefaultFont;
                }
                set
                {
                    if ((value == null && this.fontValue != null) || (value != null && !value.Equals(this.fontValue)))
                    {
                        this.fontValue = value;

                        this.InvalidateParent(false);
                    }
                }
            }

            /// <summary>
            /// This method is used by designers to enable resetting the property to its default value.
            /// </summary>
            protected virtual void ResetFont()
            {
                this.fontValue = null;
            }

            /// <summary>
            /// This method indicates to designers whether the property value is different from the ambient value, in which case the designer should persist the value.
            /// </summary>
            protected virtual bool ShouldSerializeFont()
            {
                return this.fontValue != null;
            }


            /// <summary>
            /// Gets or Sets the Alignment of the text within the ContainerListViewSubItem.
            /// </summary>
            [
            Browsable(true), Category("Appearance"),
            Description("The Alignment of the text within the ContainerListViewObject."),
            DefaultValue(typeof(HorizontalAlignment), "Left"), Localizable(true)
            ]
            public HorizontalAlignment TextAlign
            {
                get { return this.textAlign; }
                set
                {
                    if (!this.textAlign.Equals(value))
                    {
                        this.textAlign = value;
                        this.InvalidateParent(false);
                    }
                }
            }

            /// <summary>
            /// Gets the bounding rectangle of the ContainerListViewSubItem within it's Parent's bounding Rectangle.
            /// </summary>
            [Browsable(false)]
            public Rectangle Bounds
            {
                get { return this.RegenerateRectangle(); }
            }

            /// <summary>
            /// Gets or Sets the specifed control to the SubItem.
            /// </summary>
            [
            Browsable(true), Category("Appearance"),
            Description("Assignes the specifed control to the SubItem."),
            DefaultValue(typeof(Control), "null")
            ]
            public Control Control
            {
                get { return this.childControl; }
                set
                {
                    if (this.childControl != value)
                    {
                        this.childControl = this.ConstructControl(value);
                        this.InvalidateParent(false);
                    }
                }
            }

            /// <summary>
            /// Gets a value that determines if the ContainerListViewSubItem is currently being edited by the user.
            /// </summary>
            [Browsable(false)]
            public bool IsEditing
            {
                get
                {
                    return this.parentOwner != null && this.parentOwner.EditedObject != null && this.parentOwner.EditedObject.EditedSubItem == this;
                }
            }

            /// <summary>
            /// The owner of this SubItem.
            /// </summary>
            [Browsable(false)]
            public ContainerListViewObject Parent
            {
                get { return this.parent; }
            }
    		#endregion

		    #region private member functions
            private Control ConstructControl(Control Control)
            {
                if (this.childControl != null)
                {
                    this.childControl.Visible = false;

                    if (this.childControl.Parent != null)
                    {
                        this.childControl.Parent.Controls.Remove(this.childControl);
                    }

                    this.childControl.Click -= new EventHandler(this.childControl_Click);
                    this.childControl.Disposed -= new EventHandler(this.childControl_Disposed);
                }

                if (Control != null)
                {
                    Control.Visible = false;

                    if (Control.Parent != null)
                    {
                        Control.Parent.Controls.Remove(Control);
                    }

                    Control.Click += new EventHandler(this.childControl_Click);
                    Control.Disposed += new EventHandler(this.childControl_Disposed);
                }

                return Control;
            }

            private void childControl_Click(object sender, EventArgs e)
            {
                this.InvalidateParent(true);
            }

            private void childControl_Disposed(object sender, EventArgs e)
            {
                this.childControl.Visible = false;
                this.childControl.Click -= new EventHandler(this.childControl_Click);
                this.childControl = null;
                this.InvalidateParent(false);
            }

            private void InvalidateParent(bool SelectParent)
            {
                if (this.Parent != null && this.Parent.ListView != null)
                {
                    if (SelectParent)
                    {
                        this.Parent.ListView.SelectedItems.Clear();
                        this.Parent.Selected = true;
                        this.Parent.ListView.SetFocusedObject(this.Parent);
                    }

                    this.Parent.ListView.Invalidate();
                }
            }

            private Rectangle RegenerateRectangle()
            {
                Rectangle Rect = Rectangle.Empty;

                if (this.Parent != null)
                {
                    Rectangle PrntRect = Rectangle.Empty;
                    if (this.parentOwner != null && this.parentOwner.Columns.Count > (this.Index + 1))
                    {
                        Rectangle ColRect = this.parent.ListView.Columns[this.Index + 1].Bounds;
                        PrntRect = this.parent.CompleteBounds;
                        Rect = new Rectangle(ColRect.X - 1, PrntRect.Y, ColRect.Width + 1, PrntRect.Height);
                    }
                }

                return Rect;
            }
		    #endregion
        }
		#endregion

        #region ContainerListViewSubItemCollection class
        /// <summary>
        /// Strongly typed collection of ContainerListViewSubItem objects. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1058:TypesShouldNotExtendCertainBaseTypes"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1039:ListsAreStronglyTyped"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
        public class ContainerListViewSubItemCollection : CollectionBase
        {
            #region member varible and default property initialization
            private ContainerListViewObject parent;
            #endregion

            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of ContainerListViewSubItemCollection.
            /// </summary>
            public ContainerListViewSubItemCollection() { }

            /// <summary>
            /// Creates a new instance of ContainerListViewSubItemCollection.
            /// </summary>
            /// <param name="Parent">The Parent this collection belongs to.</param>
            protected internal ContainerListViewSubItemCollection(ContainerListViewObject Parent)
            {
                if (Parent == null)
                {
                    throw new ArgumentNullException("Parent");
                }

                this.parent = Parent;
            }
            #endregion

            #region action methods
            /// <summary>
            /// Adds a SubItem to the collection.
            /// </summary>
            /// <param name="SubItem">The SubItem to Add.</param>
            /// <returns>An integer representing the zero-based index within the collection.</returns>
            public int Add(ContainerListViewObject.ContainerListViewSubItem SubItem)
            {
                return this.List.Add(SubItem);
            }

            /// <summary>
            /// Adds a SubItem to the collection.
            /// </summary>
            /// <param name="Text">The Text to create a new SubItem for.</param>
            /// <returns>A newly created ContainerListViewSubItem.</returns>
            public ContainerListViewObject.ContainerListViewSubItem Add(string Text)
            {
                var item = new ContainerListViewObject.ContainerListViewSubItem(Text);

                lock (this.List.SyncRoot)
                {
                    this.List.Add(item);
                }

                return item;
            }

            /// <summary>
            /// Adds a SubItem to the collection.
            /// </summary>
            /// <param name="Control">The control to create a new SubItem for.</param>
            /// <returns>A newly created ContainerListViewSubItem.</returns>
            public ContainerListViewObject.ContainerListViewSubItem Add(Control Control)
            {
                var item = new ContainerListViewObject.ContainerListViewSubItem(Control);

                lock (this.List.SyncRoot)
                {
                    this.List.Add(item);
                }

                return item;
            }

            /// <summary>
            /// Adds an array of Items.
            /// </summary>
            /// <param name="Items">The Items to add.</param>
            public void AddRange(ContainerListViewObject.ContainerListViewSubItem[] Items)
            {
                if (Items != null)
                {
                    lock (this.List.SyncRoot)
                    {
                        for (int i = 0; i <= Items.GetUpperBound(0); i++)
                        {
                            this.List.Add(Items[i]);
                        }
                    }
                }
            }

            /// <summary>
            /// Determines if an item is in the collection.
            /// </summary>
            /// <param name="SubItem">The item to search for.</param>
            /// <returns><c>true</c> if the item is in the collection; otherwise <c>false</c>.</returns>
            public bool Contains(ContainerListViewObject.ContainerListViewSubItem SubItem)
            {
                return this.List.Contains(SubItem);
            }

            /// <summary>
            /// Copies the contents of the collection to an array at the specified index.
            /// </summary>
            /// <param name="Array">The array to copy the Items of the collection to.</param>
            /// <param name="Index">The index to start the copying at.</param>
            public void CopyTo(Array Array, int Index)
            {
                base.List.CopyTo(Array, Index);
            }

            /// <summary>
            /// Returns the index of the specified item in the collection.
            /// </summary>
            /// <param name="SubItem">The item to search for.</param>
            /// <returns>An integer.</returns>
            public int IndexOf(ContainerListViewObject.ContainerListViewSubItem SubItem)
            {
                return this.List.IndexOf(SubItem);
            }

            /// <summary>
            /// Inserts an item at the specified position.
            /// </summary>
            /// <param name="SubItem">The ContainerListViewSubItem to insert.</param>
            /// <param name="Index">The zero-based index at which the item should be inserted.</param>
            public void Insert(ContainerListViewObject.ContainerListViewSubItem SubItem, int Index)
            {
                base.List.Insert(Index, SubItem);
            }

            /// <summary>
            /// Removes an item from the collection.
            /// </summary>
            /// <param name="SubItem">The item to remove.</param>
            public void Remove(ContainerListViewObject.ContainerListViewSubItem SubItem)
            {
                this.List.Remove(SubItem);
            }

            /// <summary>
            /// Does pre-processing of items in the list before removing them.
            /// </summary>
            protected override void OnClear()
            {
                foreach (ContainerListViewObject.ContainerListViewSubItem item in this.List)
                {
                    RemoveProcessing(item);
                }
            }

            /// <summary>
            /// Raises the ClearComplete event.
            /// </summary>
            protected override void OnClearComplete()
            {
                base.OnClearComplete();
            }

            /// <summary>
            /// Does post-processing after an item has been added.
            /// </summary>
            /// <param name="index">The index of the item that was added.</param>
            /// <param name="value">The value of the item.</param>
            protected override void OnInsertComplete(int index, object value)
            {
                base.OnInsertComplete(index, value);

                this.AddProcessing((ContainerListViewObject.ContainerListViewSubItem)value);
            }

            /// <summary>
            /// Does post-processing after an item has been removed.
            /// </summary>
            /// <param name="index">The index of the item that was removed.</param>
            /// <param name="value">The value of the item.</param>
            protected override void OnRemoveComplete(int index, object value)
            {
                base.OnRemoveComplete(index, value);

                RemoveProcessing((ContainerListViewObject.ContainerListViewSubItem)value);
            }

            /// <summary>
            /// Does post-processing after an item's value has been changed.
            /// </summary>
            /// <param name="index">The index of the item changed.</param>
            /// <param name="oldValue">The old value of the item.</param>
            /// <param name="newValue">The new value of the item.</param>
            protected override void OnSetComplete(int index, object oldValue, object newValue)
            {
                base.OnSetComplete(index, oldValue, newValue);

                RemoveProcessing((ContainerListViewObject.ContainerListViewSubItem)oldValue);
                this.AddProcessing((ContainerListViewObject.ContainerListViewSubItem)newValue);
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets or Sets the SubItem in the Collection.
            /// </summary>
            /// <param name="Index">The index of the item to get or set.</param>
            public ContainerListViewObject.ContainerListViewSubItem this[int Index]
            {
                get { return (ContainerListViewObject.ContainerListViewSubItem)this.List[Index]; }
                set { this.List[Index] = value; }
            }
            #endregion

            #region private member functions
            private void AddProcessing(ContainerListViewObject.ContainerListViewSubItem SubItem)
            {
                if (SubItem.Parent == null)
                {
                    if (this.parent != null)
                    {
                        SubItem.SetParent(this.parent);
                        SubItem.SetParentOwner(this.parent.ListView);
                    }
                }
                else
                {
                    this.Remove(SubItem);
                    throw new ArgumentException("Cannot add or insert the ContainerListViewSubItem '" + SubItem.Text + "' in more than one ContainerListViewSubItemCollection. You must first remove it from its current collection or clone it.", "SubItem", null);
                }
            }

            private static void RemoveProcessing(ContainerListViewObject.ContainerListViewSubItem SubItem)
            {
                SubItem.SetParent(null);
                SubItem.SetParentOwner(null);
            }
            #endregion
        }
        #endregion
		#endregion

        #region member varible and default property initialization
        private bool allowSelect = true;

        /// <summary>
        /// Custom value of the BackColor of the item.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected Color backColorValue = Color.Transparent;

        /// <summary>
        /// Custom value of the foreground color of the the item's text.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected Color foreColorValue = Color.Empty;

        /// <summary>
        /// Custom value of the font of the text displayed by the item
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected Font fontValue;

        private string text = string.Empty;
        private HorizontalAlignment textAlign = HorizontalAlignment.Left;
        private object userData;
        private int imgIndex = -1;
        private ContainerListViewSubItemCollection subItems;
        private bool isChecked;
        private bool isCheckEnabled = true;
        private bool isCheckVisible = true;
        private bool focused;
        private bool hovered;
        private ContainerListViewSubItem editedItem;
        private Rectangle editedRect;
        private bool useItemStyleForSubItems = true;
        private ContainerListView containerListView;
        #endregion

		#region constructors and destructors
        /// <summary>
        /// Creates a new instance of ContainerListViewObject.
        /// </summary>
        protected ContainerListViewObject()
        {
            this.subItems = new ContainerListViewSubItemCollection(this);
        }

        /// <summary>
        /// Creates a new instance of ContainerListViewObject.
        /// </summary>
        /// <param name="ItemText">The text to display for the item.</param>
        protected ContainerListViewObject(string ItemText) : this()
        {
            this.text = ItemText;
        }
		#endregion

        #region abstract methods
        /// <summary>
        /// Creates a new Object that is a copy of the current instance.
        /// </summary>
        /// <returns>An object that is a Clone of the current instance.</returns>
        public abstract object Clone();

        /// <summary>
        /// Gets a value that determines if the ContainerListViewObject has a parent.
        /// </summary>
        public abstract bool HasParent { get; }

        /// <summary>
        /// Gets the zero-based position of the ContainerListViewObject within the collection.
        /// </summary>
        public abstract int Index { get; }

        /// <summary>
        /// Gets or Sets a value that determines if the ContainerListViewObject is in a selected state.
        /// </summary>
        [DefaultValue(false)]
        public abstract bool Selected { get; set; }
 
        /// <summary>
        /// Assigns the ListView that the item belongs to.
        /// </summary>
        /// <param name="ContainerListView">The ContainerListView that owns the item.</param>
        internal abstract void SetParent(ContainerListView ContainerListView);
		#endregion

		#region action methods
        /// <summary>
        /// Begins editing of the ContainerListViewObject.
        /// </summary>
        /// <remarks>
        /// Editing only occurs if the ContainerListViewObject belongs to a ContainerListView.
        /// </remarks>
        public void BeginEdit()
        {
            if (this.containerListView != null && !this.IsEditing && !this.containerListView.ContainerListViewBeforeEdit(this))
            {
                this.BeginEditInternal(this.containerListView.GetItemBounds(this), this.Text, this.Font, this.ForeColor);
            }
        }

        /// <summary>
        /// Begins editing the specified SubItem.
        /// </summary>
        /// <param name="SubItem">The SubItem to begin editing on.</param>
        public void BeginEdit(ContainerListViewSubItem SubItem)
        {
            //Make sure that the subitem belongs to the parent who started the editing, that the subitem is not already in an edit 
            //state, and that the subitem is not displaying a control.
            if (!this.subItems.Contains(SubItem))
            {
                throw new ArgumentException("SubItem is not a member of this ContainerListViewObject's subitem collection.");
            }

            if (this.containerListView != null && !SubItem.IsEditing && SubItem.Control == null)
            {
                this.editedItem = SubItem;

                //Raise the 'before' event to see if we should continue...
                if (!this.containerListView.ContainerListViewBeforeEdit(this))
                {
                    this.BeginEditInternal(SubItem.Bounds, SubItem.Text, SubItem.Font, SubItem.ForeColor);
                }
                else
                {
                    this.editedItem = null;
                }
            }
        }

        /// <summary>
        /// Begins editing the specified SubItem.
        /// </summary>
        /// <param name="SubItemIndex"></param>
        public void BeginEdit(int SubItemIndex)
        {
            this.BeginEdit(this.subItems[SubItemIndex]);
        }

        /// <summary>
        /// Ends all editing on this ContainerListViewObject and any of it's SubItems.
        /// </summary>
        public void EndEdit()
        {
            EndEdit(false);
        }

        /// <summary>
        /// Ends all editing on this ContainerListViewObject and any of it's SubItems.
        /// </summary>
        /// <param name="CancelChanges"><c>true</c> to cancel any changes; otherwise <c>false</c> to keep them.</param>
        public void EndEdit(bool CancelChanges)
        {
            EndEdit(CancelChanges, false);
        }

        /// <summary>
        /// Ends all editing on this ContainerListViewObject and any of it's SubItems.
        /// </summary>
        /// <param name="CancelChanges"><c>true</c> to cancel any changes; otherwise <c>false</c> to keep them.</param>
        /// <param name="LostFocus">Call from LostFocus</param>
        public void EndEdit(bool CancelChanges, bool LostFocus)
        {
            if (this.IsEditing || this.editedItem != null)
            {
                var editBox = this.containerListView.EditBox;
                string edittext = editBox.Text;

                //Hide and reset the editcontrol
                editBox.KeyUp -= new KeyEventHandler(this.EditBox_KeyUp);
                editBox.LostFocus -= new EventHandler(this.EditBox_LostFocus);
                editBox.Hide();
                editBox.Text = string.Empty;

                if (!LostFocus)
                {
                    this.containerListView.Focus();
                }

                //Set the text for the proper edited item and then raise the 'after' event on the containerlistview
                if (!CancelChanges)
                {
                    if (this.IsEditing)
                    {
                        this.Text = edittext;
                    }
                    else
                    {
                        this.editedItem.Text = edittext;
                    }

                    this.containerListView.ContainerListViewAfterEdit(this);
                }

                //If it was a subitem, set it to null.
                this.editedRect = Rectangle.Empty;
                this.containerListView.SetEditedObject(null);

                if (this.editedItem != null)
                {
                    this.editedItem = null;
                }
            }
        }

        /// <summary>
        /// Returns a SubItem at the specified point.
        /// </summary>
        /// <param name="Point">The point at which to check for a SubItem.</param>
        /// <returns>A ContainerListViewSubItem object</returns>
        public ContainerListViewSubItem GetSubItemAt(Point Point)
        {
            foreach (ContainerListViewSubItem item in this.subItems)
            {
                if (item.Bounds.Contains(Point))
                {
                    return item;
                }
            }

            return null;
        }

        /// <summary>
        /// Returns a SubItem at the specified point.
        /// </summary>
        /// <param name="X">The X coordinate.</param>
        /// <param name="Y">The Y coordinate.</param>
        /// <returns>A ContainerListViewSubItem object.</returns>
        public ContainerListViewSubItem GetSubItemAt(int X, int Y)
        {
            return this.GetSubItemAt(new Point(X, Y));
        }

        /// <summary>
        /// Overriden.  Returns a String that represents the current Object.
        /// </summary>
        /// <returns>A String that represents the current Object.</returns>
        public override string ToString()
        {
            return this.text;
        }
 
        /// <summary>
        /// Refreshes the editing control if the ContainerListViewObject or any of it's subitems are in an edit state.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void RefreshEditing()
        {
            this.containerListView.EditBox.Location = new Point(this.editedRect.X, this.editedRect.Y);
            this.containerListView.EditBox.Size = new Size(this.editedRect.Width, this.editedRect.Height);
        }
		#endregion

		#region property getters/setters
        /// <summary>
        /// Gets or sets the text of the item.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The text of the item."),
        Localizable(true),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)
        ]
        public string Text
        {
            get { return this.text; }
            set
            {
                if (!this.text.Equals(value))
                {
                    this.text = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the item is checked.
        /// </summary>
        [
        Browsable(false),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), EditorBrowsable(EditorBrowsableState.Never)
        ]
        public bool Checked
        {
            get { return this.isChecked; }
            set
            {
                if (this.isCheckEnabled && this.isChecked != value)
                {
                    bool Cancel = false;
                    bool InvalidView = this.ListView == null;

                    if (!InvalidView)
                    {
                        Cancel = this.ListView.ContainerListViewBeforeCheckStateChanged(this);
                    }

                    if (!Cancel)
                    {
                        if (!this.isChecked)
                        {
                            this.isChecked = true;
                            if (!InvalidView)
                            {
                                this.ListView.CheckedItems.Add(this);
                            }
                        }
                        else
                        {
                            if (!InvalidView)
                            {
                                this.ListView.CheckedItems.Remove(this);
                            }
                            this.isChecked = false;
                        }

                        this.ListView.ContainerListViewAfterCheckStateChanged(this);

                        if (!InvalidView)
                        {
                            this.ListView.Invalidate();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets an object that contains data to associate with the item.
        /// </summary>
        [
        Browsable(true), Category("Data"),
        Description("Data to associate with the item"),
        DefaultValue(typeof(object), null),
        Bindable(true), Localizable(true),
        TypeConverter(typeof(System.ComponentModel.StringConverter))
        ]
        public object Tag
        {
            get { return this.userData; }
            set { this.userData = value; }
        }

        /// <summary>
        /// Gets the collection of SubItems of the current item.
        /// </summary>
        [
        Browsable(true), Category("Data"),
        Description("The collection of SubItems of the current item."),
        Editor(typeof(System.ComponentModel.Design.CollectionEditor), typeof(UITypeEditor)),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)
        ]
        public ContainerListViewSubItemCollection SubItems
        {
            get { return this.subItems; }
        }

        /// <summary>
        /// Gets or Sets a value that Determines whether the ContainerListViewObject can be selected.
        /// </summary>
        /// <remarks>
        /// In the case of TreeListNodes, AllowSelection is convenient if you want a user to be able to expand and collapse TreeListNodes 
        /// but not allow them to be selected (thereby not being added to the SelectedItems/SelectedIndexes collections).  For example, 
        /// if you have a parent node that represents a collection and the childnodes of that parentnode represent the items of that 
        /// collection, you can allow the user to select as many childnodes (or not) as they wish. So if there is processing on the 
        /// SelectedItems collection you can be guaranteed that the parentnode will not be part of that collection.
        /// AllowSelection may not hold such importance on ContainerListViewItems but it is supported if needed.
        /// </remarks>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether the ContainerListViewObject can be selected."),
        DefaultValue(true)
        ]
        public bool AllowSelection
        {
            get { return this.allowSelect; }
            set
            {
                if (!this.allowSelect.Equals(value))
                {
                    if (!value)
                    {
                        this.Selected = false;
                    }

                    this.allowSelect = value;
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines if the checkbox is enabled or disabled.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines if the checkbox is enabled or disabled."),
        DefaultValue(true)
        ]
        public virtual bool CheckBoxEnabled
        {
            get { return this.isCheckEnabled; }
            set
            {
                if (!this.isCheckEnabled.Equals(value))
                {
                    this.isCheckEnabled = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines whether the CheckBox is visible for the ContainerListViewObject.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether the CheckBox is visible for the ContainerListViewObject."),
        DefaultValue(true)
        ]
        public virtual bool CheckBoxVisible
        {
            get { return this.isCheckVisible; }
            set
            {
                if (!this.isCheckVisible.Equals(value))
                {
                    this.isCheckVisible = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or Sets the BackColor of the item.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines the BackColor of the item."),
        DefaultValue(typeof(Color), "Transparent"),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)
        ]
        public Color BackColor
        {
            get { return this.backColorValue; }
            set
            {
                if (!this.backColorValue.Equals(value))
                {
                    this.backColorValue = value;

                    if (this.containerListView != null)
                    {
                        this.containerListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the foreground color of the item's text.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines the foreground color of the the item's text."),
        ]
        public Color ForeColor
        {
            get
            {
                if (this.foreColorValue != Color.Empty)
                {
                    return this.foreColorValue;
                }

                if (this.containerListView != null)
                {
                    return this.containerListView.ForeColor;
                }

                return SystemColors.WindowText;
            }
            set
            {
                if (!this.foreColorValue.Equals(value))
                {
                    this.foreColorValue = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// This method is used by designers to enable resetting the property to its default value.
        /// </summary>
        protected void ResetForeColor()
        {
            this.foreColorValue = Color.Empty;
        }

        /// <summary>
        /// This method indicates to designers whether the property value is different from the ambient value, in which case the designer should persist the value.
        /// </summary>
        protected bool ShouldSerializeForeColor()
        {
            return !this.foreColorValue.IsEmpty;
        }

        /// <summary>
        /// Gets or sets the font of the text displayed by the item.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines the font of the text displayed by the item."),
        AmbientValue((string)null),
        Localizable(true)
        ]
        public Font Font
        {
            get
            {
                if (this.fontValue != null)
                {
                    return this.fontValue;
                }

                if (this.containerListView != null)
                {
                    return this.containerListView.Font;
                }

                return SystemFonts.DefaultFont;
            }
            set
            {
                if ((value == null && this.fontValue != null) || (value != null && !value.Equals(this.fontValue)))
                {
                    this.fontValue = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// This method is used by designers to enable resetting the property to its default value.
        /// </summary>
        protected void ResetFont()
        {
            this.fontValue = null;
        }

        /// <summary>
        /// This method indicates to designers whether the property value is different from the ambient value, in which case the designer should persist the value.
        /// </summary>
        protected bool ShouldSerializeFont()
        {
            return this.fontValue != null;
        }

        /// <summary>
        /// Gets or Sets the Alignment of the text within the ContainerListViewObject.
        /// </summary>
        /// <remarks>
        /// Note:  Setting this property on a TreeListNode has no effect on the TextAlignment of the text on the Node itself.  
        /// It will only be used for the Node's subitems instead.
        /// </remarks>
        [
        Browsable(true), Category("Appearance"),
        Description("The Alignment of the text within the ContainerListViewObject."),
        DefaultValue(typeof(HorizontalAlignment), "Left"), Localizable(true)
        ]
        public HorizontalAlignment TextAlign
        {
            get { return this.textAlign; }
            set
            {
                if (!this.textAlign.Equals(value))
                {
                    this.textAlign = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the TextAlign, Font, ForeColor, and BackColor properties for the item are used for all its subitems.
        /// </summary>
        /// <remarks>
        /// If you do not want to have a uniform background color, foreground color, textalign, and font used for all items and subitems 
        /// in your ContainerListView control, you can set this property to false. When this property is set to true, any changes made to 
        /// the subitem's ContainerListViewSubItem.Font, ContainerListViewSubItem.ForeColor, and ContainerListViewSubItem.BackColor,  
        /// ContainerListViewSubItem.TextAlign properties are ignored, and the values of the item are used instead. You can use this 
        /// property if you need to specify a different text alignment, text color, background color, or font to be used for a subitem to 
        /// highlight the item when subitems are displayed in the ContainerListView control.
        /// </remarks>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether the TextAlign, Font, ForeColor, and BackColor properties for the item are used for all its subitems."),
        DefaultValue(true)
        ]
        public virtual bool UseItemStyleForSubItems
        {
            get { return this.useItemStyleForSubItems; }
            set
            {
                if (!this.useItemStyleForSubItems.Equals(value))
                {
                    this.useItemStyleForSubItems = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the index of the image that is displayed for the item.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The index of the image that is displayed for the item."),
        DefaultValue(-1),
        Localizable(true),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor)),
        TypeConverter(typeof(TreeViewImageIndexConverter))
        ]
        public int ImageIndex
        {
            get { return this.imgIndex; }
            set
            {
                if (!this.imgIndex.Equals(value))
                {
                    this.imgIndex = value;

                    if (this.ListView != null)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets the ImageList associated with the ContainerListViewObject.
        /// </summary>
        [Browsable(false)]
        public ImageList ImageList
        {
            get
            {
                if (this.ListView != null)
                {
                    return this.ListView.ImageList;
                }

                return null;
            }
        }

        /// <summary>
        /// Gets a value that determines if the ContainerListViewObject is currently being edited by the user.
        /// </summary>
        /// <remarks>
        /// This does not include any SubItems that may be in an editing state.
        /// </remarks>
        [Browsable(false)]
        public bool IsEditing
        {
            get
            {
                return this.containerListView != null && this.containerListView.EditedObject != null && this.containerListView.EditedObject.EditedSubItem == null && this.containerListView.EditedObject == this;
            }
        }

        /// <summary>
        /// Gets the ContainerListViewSubItem being edited.
        /// </summary>
        [Browsable(false)]
        public ContainerListViewSubItem EditedSubItem
        {
            get { return this.editedItem; }
        }

        /// <summary>
        /// Gets the ContainerListView control that contains the item.
        /// </summary>
        [Browsable(false)]
        public ContainerListView ListView
        {
            get { return this.containerListView; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the item has focus within the list view control.
        /// </summary>
        [
        Browsable(false),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), EditorBrowsable(EditorBrowsableState.Never)
        ]
        internal bool Focused
        {
            get { return this.focused; }
            set
            {
                if (!this.focused.Equals(value))
                {
                    this.focused = value;

                    if (this.ListView != null && this.focused)
                    {
                        this.ListView.SetFocusedObject(this);
                    }
                }
            }
        }

        /// <summary>
        /// Gets or Sets that determines if the ContainerListViewObject is currently hovered by the Mouse pointer.
        /// </summary>
        [
        Browsable(false),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        DefaultValue(false)
        ]
        protected internal bool Hovered
        {
            get { return this.hovered; }
            set
            {
                if (!this.hovered.Equals(value))
                {
                    this.hovered = value;
                }
            }
        }

        /// <summary>
        /// Gets the bounding rectangle of just the ContainerListViewObject.
        /// </summary>
        [Browsable(false)]
        public Rectangle Bounds
        {
            get
            {
                if (this.containerListView != null)
                {
                    return this.containerListView.GetItemBounds(this);
                }

                return Rectangle.Empty;
            }
        }

        /// <summary>
        /// Gets the bounding rectangle of the ContainerListViewObject, including it's SubItems.
        /// </summary>
        [Browsable(false)]
        public Rectangle CompleteBounds
        {
            get
            {
                if (this.ListView != null)
                {
                    return this.ListView.GetCompleteItemBounds(this);
                }

                return Rectangle.Empty;
            }
        }

        /// <summary>
        /// The ContainerListView that owns the ContainerListViewObject.
        /// </summary>
        protected ContainerListView OwnerListView
        {
            get { return this.containerListView; }
            set { this.containerListView = value; }
        }
		#endregion

		#region private member functions
        private void BeginEditInternal(Rectangle Rect, string Text, Font Font, Color ForeColor)
        {
            //Let's end the edit of anything that is already in an edit state
            if (this.containerListView.EditedObject != null)
            {
                this.containerListView.EditedObject.EndEdit(false);
            }

            //Save the edit rectangle
            if (Rect.X == 0)
            {
                this.editedRect = new Rectangle(Rect.X + 2, Rect.Y, Rect.Width - 3, Rect.Height - 1);
            }
            else
            {
                this.editedRect = new Rectangle(Rect.X, Rect.Y, Rect.Width - 1, Rect.Height - 1);
            }

            var editBox = this.containerListView.EditBox;

            //Set the dynamic fields
            editBox.BackColor = this.containerListView.EditBackColor;
            editBox.ForeColor = ForeColor;
            editBox.Font = Font;
            editBox.Location = new Point(Rect.X, Rect.Y);
            editBox.Size = new Size(this.editedRect.Width, this.editedRect.Height);
            editBox.Text = Text;

            containerListView.SetEditedObject(this);
            editBox.Show();
            editBox.Focus();
            editBox.Select(0, editBox.Text.Length);
            editBox.KeyUp += new KeyEventHandler(this.EditBox_KeyUp);
            editBox.LostFocus += new EventHandler(this.EditBox_LostFocus);
        }

        private void EditBox_KeyUp(object sender, KeyEventArgs e)
        {
            //ESC means cancel any changes and end the editing session
            //return/enter means end the editing session but persist the changes
            switch (e.KeyCode)
            {
                case Keys.Return:
                    this.EndEdit(false);
                    break;
                case Keys.Escape:
                    this.EndEdit(true);
                    break;
            }
        }

        private void EditBox_LostFocus(object sender, EventArgs e)
        {
            this.EndEdit(false, true);
        }
		#endregion
    }
    #endregion

    #region ContainerListViewObjectCollection class
    /// <summary>
    /// ContainerListViewObjectCollection Class.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1058:TypesShouldNotExtendCertainBaseTypes"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
    public abstract class ContainerListViewObjectCollection : CollectionBase
    {
        #region member varible and default property initialization
        /// <summary>
        /// Variable that stores the ContainerListView that is the parent of this collection.
        /// </summary>
        private ContainerListView parent;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of ContainerListViewObjectCollection.
        /// </summary>
        protected ContainerListViewObjectCollection() { }

        /// <summary>
        /// Creates a new instance of ContainerListViewObjectCollection.
        /// </summary>
        /// <param name="Parent">The Owner of the collection.</param>
        protected ContainerListViewObjectCollection(ContainerListView Parent)
        {
            if (Parent == null)
            {
                throw new ArgumentNullException("Parent");
            }

            this.parent = Parent;
        }
        #endregion

        #region action methods
        /// <summary>
        /// Determines if an item is in the collection.
        /// </summary>
        /// <param name="Item">The item to search for.</param>
        /// <returns><c>true</c> if the item is in the collection; otherwise <c>false</c>.</returns>
        public bool Contains(ContainerListViewObject Item)
        {
            return base.List.Contains(Item);
        }

        /// <summary>
        /// Copies the contents of the collection to an array at the specified index.
        /// </summary>
        /// <param name="Array">The array to copy the items of the collection to.</param>
        /// <param name="Index">The index to start the copying at.</param>
        public void CopyTo(Array Array, int Index)
        {
            base.List.CopyTo(Array, Index);
        }

        /// <summary>
        /// Returns the index of the specified item in the collection.
        /// </summary>
        /// <param name="Item">The item to search for.</param>
        /// <returns>An integer.</returns>
        public int IndexOf(ContainerListViewObject Item)
        {
            return this.List.IndexOf(Item);
        }

        /// <summary>
        /// Removes an item from the collection.
        /// </summary>
        /// <param name="Item">The item to remove.</param>
        public void Remove(ContainerListViewObject Item)
        {
            this.List.Remove(Item);
        }

        /// <summary>
        /// Sorts the elements in the entire Collection using the specified comparer.
        /// </summary>
        public virtual void Sort()
        {
            if (this.parent == null)
            {
                throw new InvalidOperationException("parent is null");
            }

            if (this.parent.SortComparer == null)
            {
                this.InnerList.Sort(this.parent.DefaultComparer);
            }
            else
            {
                this.InnerList.Sort(this.parent.SortComparer);
            }
        }

        /// <summary>
        /// Occurs after an add or insert to the collection.
        /// </summary>
        /// <param name="ClObj">The item that was added.</param>
        /// <param name="Index">The index where the item was added.</param>
        protected virtual void OnAddProcessing(ContainerListViewObject ClObj, int Index)
        {
            this.ValidateAdd(ClObj);
        }

        /// <summary>
        /// Performs additional custom processes when clearing the contents of the CollectionBase instance.
        /// </summary>
        protected override void OnClear()
        {
            base.OnClear();

            lock (this.List.SyncRoot)
            {
                if (this.parent != null)
                {
                    this.parent.BeginUpdate();
                }

                foreach (ContainerListViewObject item in this.List)
                {
                    this.OnRemoveProcessing(item);
                }

                if (this.parent != null)
                {
                    this.parent.EndUpdate();
                }
            }
        }

        /// <summary>
        /// Performs additional custom processes after clearing the contents of the CollectionBase instance.
        /// </summary>
        protected override void OnClearComplete()
        {
            base.OnClearComplete();

            if (this.parent != null && !this.parent.InUpdateMode)
            {
                this.parent.Invalidate();
            }
        }

        /// <summary>
        /// Performs additional custom processes after inserting a new element into the CollectionBase instance.
        /// </summary>
        /// <param name="index">The index of the item that was added.</param>
        /// <param name="value">The Value of the item.</param>
        protected override void OnInsertComplete(int index, object value)
        {
            base.OnInsertComplete(index, value);

            this.OnAddProcessing((ContainerListViewObject)value, index);

            if (this.parent != null && !this.parent.InUpdateMode)
            {
                this.parent.Invalidate();
            }
        }

        /// <summary>
        /// Performs additional custom processes after removing an element from the CollectionBase instance.
        /// </summary>
        /// <param name="index">The index of the item that was removed.</param>
        /// <param name="value">The Value of the item.</param>
        protected override void OnRemoveComplete(int index, object value)
        {
            base.OnRemoveComplete(index, value);

            this.OnRemoveProcessing((ContainerListViewObject)value);

            if (this.parent != null && !this.parent.InUpdateMode)
            {
                this.parent.Invalidate();
            }
        }

        /// <summary>
        /// Occurs after an item has been removed from the collection.
        /// </summary>
        /// <param name="CObj">The item that was removed from the collection.</param>
        protected virtual void OnRemoveProcessing(ContainerListViewObject CObj)
        {
            CObj.SetParent(null);

            foreach (ContainerListViewItem.ContainerListViewSubItem item in CObj.SubItems)
            {
                if (item.Control != null)
                {
                    item.Control.Parent.Controls.Remove(item.Control);
                    item.Control.Parent = null;
                    item.Control.Visible = false;
                }
            }
        }

        /// <summary>
        /// Performs additional custom processes after setting a value in the CollectionBase instance.
        /// </summary>
        /// <param name="index"></param>
        /// <param name="oldValue">The old value of the item.</param>
        /// <param name="newValue">The new value of the item.</param>
        protected override void OnSetComplete(int index, object oldValue, object newValue)
        {
            base.OnSetComplete(index, oldValue, newValue);

            this.OnRemoveProcessing((ContainerListViewObject)oldValue);
            this.OnAddProcessing((ContainerListViewObject)newValue, index);

            if (this.parent != null && !this.parent.InUpdateMode)
            {
                this.parent.Invalidate();
            }
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets a value indicating whether the collection is Read-only.
        /// </summary>
        public bool IsReadOnly
        {
            get { return base.List.IsReadOnly; }
        }

        /// <summary>
        /// The ContainerListView that owns the ContainerListViewObjectCollection.
        /// </summary>
        protected ContainerListView Parent
        {
            get { return this.parent; }
            set { this.parent = value; }
        }
        #endregion

        #region private member functions
        private void ValidateAdd(ContainerListViewObject ClObj)
        {
            if (ClObj.HasParent)
            {
                this.Remove(ClObj);
                throw new ArgumentException("Cannot add or insert the ContainerListViewObject '" + ClObj.Text + "' in more than one ContainerListViewObjectCollection. You must first remove it from its current collection or clone it.", "ClObj", null);
            }
        }
        #endregion
    }
    #endregion

    #region ContainerListViewReadOnlyCollection class
    /// <summary>
    /// Base typed for ContainerListView read only collections.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1058:TypesShouldNotExtendCertainBaseTypes"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
    public abstract class ContainerListViewReadOnlyCollection : ReadOnlyCollectionBase
    {
        #region action methods
        /// <summary>
        /// Copies the entire Collection to the compatible array starting at the specified index.
        /// </summary>
        /// <param name="Array">The Array to copy all Items of the collection to.</param>
        /// <param name="Index">The index to start copying at.</param>
        public void CopyTo(Array Array, int Index)
        {
            base.InnerList.CopyTo(Array, Index);
        }

        /// <summary>
        /// Determines if an item is in the collection.
        /// </summary>
        /// <param name="Item">The item to search for.</param>
        /// <returns><c>true</c> if the item is in the collection; otherwise <c>false</c>.</returns>
        public bool Contains(object Item)
        {
            return base.InnerList.Contains(Item);
        }

        /// <summary>
        /// Returns the index of the specified item in the collection.
        /// </summary>
        /// <param name="Item">The item to search for.</param>
        /// <returns>An integer.</returns>
        public int IndexOf(object Item)
        {
            return base.InnerList.IndexOf(Item);
        }

        /// <summary>
        /// Removes all items from the collection.
        /// </summary>
        internal virtual void Clear()
        {
            base.InnerList.Clear();
        }
        #endregion
    }
    #endregion

    #region ContainerListViewItem class
    /// <summary>
    /// Represents an item in a ContainerListView control.
    /// </summary>
    [DesignTimeVisible(false), ToolboxItem(false), Serializable, DefaultProperty("Text"), TypeConverter(typeof(ContainerListViewItemConverter))]
    public class ContainerListViewItem : ContainerListViewObject
    {
        #region member varible and default property initialization
        private bool selected;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Creates a new instance of ContainerListViewItem.
        /// </summary>
        public ContainerListViewItem() { }

        /// <summary>
        /// Creates a new instance of ContainerListViewItem.
        /// </summary>
        /// <param name="ItemText">The text to display for the item.</param>
        public ContainerListViewItem(string ItemText) : base(ItemText) { }

        /// <summary>
        /// Creates a new instance of ContainerListViewItem.
        /// </summary>
        /// <param name="ItemText">The text to display for the item.</param>
        /// <param name="ImageIndex">The zero-based index of the image within the ImageList associated with the ContainerListView control that contains the item.</param>
        public ContainerListViewItem(string ItemText, int ImageIndex)
            : base(ItemText)
        {
            this.ImageIndex = ImageIndex;
        }

        /// <summary>
        /// Creates a new instance of ContainerListViewItem.
        /// </summary>
        /// <param name="ItemText">The text to display for the item.</param>
        /// <param name="ImageIndex">The zero-based index of the image within the ImageList associated with the ContainerListView control that contains the item.</param>
        /// <param name="BackColor">The BackColor of the item.</param>
        /// <param name="ForeColor">The ForeColor of the item.</param>
        /// <param name="Font">The Font of the item.</param>
        public ContainerListViewItem(string ItemText, int ImageIndex, Color BackColor, Color ForeColor, Font Font)
            : base(ItemText)
        {
            this.ImageIndex = ImageIndex;
            this.BackColor = BackColor;
            this.ForeColor = ForeColor;
            this.Font = Font;
        }

        /// <summary>
        /// Creates a new instance of ContainerListViewItem.
        /// </summary>
        /// <param name="ItemText">The text to display for the item.</param>
        /// <param name="ImageIndex">The zero-based index of the image within the ImageList associated with the ContainerListView control that contains the item.</param>
        /// <param name="BackColor">The BackColor of the item.</param>
        /// <param name="ForeColor">The ForeColor of the item.</param>
        /// <param name="Font">The Font of the item.</param>
        /// <param name="SubItems">An array of Child subitems to add to the newly created ContainerListViewItem.</param>
        public ContainerListViewItem(string ItemText, int ImageIndex, Color BackColor, Color ForeColor, Font Font, ContainerListViewObject.ContainerListViewSubItem[] SubItems)
            : base(ItemText)
        {
            this.ImageIndex = ImageIndex;
            this.BackColor = BackColor;
            this.ForeColor = ForeColor;
            this.Font = Font;

            if (SubItems != null)
            {
                this.SubItems.AddRange(SubItems);
            }
        }
        #endregion

        #region action methods
        /// <summary>
        /// Creates a new Object that is a copy of the current instance.
        /// </summary>
        /// <returns>An object that is a Clone of the current instance.</returns>
        public override object Clone()
        {
            var item = new ContainerListViewItem();

            item.backColorValue = this.backColorValue;
            item.foreColorValue = this.foreColorValue;
            item.fontValue = this.fontValue;
            item.CheckBoxEnabled = this.CheckBoxEnabled;
            item.CheckBoxVisible = this.CheckBoxVisible;
            item.Checked = this.Checked;
            item.ImageIndex = this.ImageIndex;
            item.Tag = this.Tag;
            item.Text = this.Text;
            item.TextAlign = this.TextAlign;
            item.UseItemStyleForSubItems = this.UseItemStyleForSubItems;

            foreach (ContainerListViewSubItem subitem in this.SubItems)
            {
                item.SubItems.Add((ContainerListViewSubItem)subitem.Clone());
            }

            return item;
        }

        /// <summary>
        /// Removes the current ContainerListViewItem from the ContainerListView control.
        /// </summary>
        public void Remove()
        {
            if (this.ListView != null)
            {
                this.ListView.Items.Remove(this);
            }
        }

        /// <summary>
        /// Assigns the ListView that the item belongs to.
        /// </summary>
        /// <param name="ContainerListView">The ContainerListView that owns the item.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal override void SetParent(ContainerListView ContainerListView)
        {
            if (ContainerListView != base.OwnerListView)
            {
                if (base.OwnerListView != null)
                {
                    if (this.Checked)
                    {
                        base.OwnerListView.CheckedItems.Remove(this);
                    }

                    if (this.Selected)
                    {
                        base.OwnerListView.SelectedItems.Remove(this);
                        base.OwnerListView.SelectedIndexes.Remove(this.Index);
                    }
                }

                base.OwnerListView = ContainerListView;

                if (base.OwnerListView != null)
                {
                    if (this.Checked)
                    {
                        base.OwnerListView.CheckedItems.Add(this);
                    }

                    if (this.Selected)
                    {
                        base.OwnerListView.SelectedItems.Add(this);
                        base.OwnerListView.SelectedIndexes.Add(this.Index);
                    }
                }

                foreach (ContainerListViewSubItem item in this.SubItems)
                {
                    item.SetParentOwner(ContainerListView);
                }
            }
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the zero-based position of the ContainerListViewItem within the ContainerListViewItem collection.
        /// </summary>
        [Browsable(false)]
        public override int Index
        {
            get
            {
                if (this.ListView != null)
                {
                    return this.ListView.Items.IndexOf(this);
                }

                return -1;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the item is selected.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public override bool Selected
        {
            get { return this.selected; }
            set
            {
                if (this.AllowSelection && !this.selected.Equals(value))
                {
                    bool InvalidView = this.ListView == null;

                    if (!this.selected)
                    {
                        bool Cancel = false;
                        if (!InvalidView)
                        {
                            Cancel = this.ListView.ContainerListViewBeforeSelect(this);
                        }

                        if (!Cancel)
                        {
                            this.selected = true;

                            if (!InvalidView)
                            {
                                if (!this.ListView.MultiSelect)
                                {
                                    this.ListView.SelectedItems.Clear();
                                    this.ListView.SelectedIndexes.Clear();
                                    this.Focused = true;
                                }

                                this.ListView.SelectedItems.Add(this);
                                this.ListView.SelectedIndexes.Add(this.Index);
                                this.ListView.ContainerListViewAfterSelect(this);
                            }
                        }
                    }
                    else
                    {
                        if (!InvalidView)
                        {
                            this.ListView.SelectedItems.Remove(this);
                            this.ListView.SelectedIndexes.Remove(this.Index);
                        }

                        this.selected = false;
                    }

                    if (!InvalidView)
                    {
                        this.ListView.Invalidate();
                    }
                }
            }
        }

        /// <summary>
        /// Determines if the current TreeListNode has a parent node.
        /// </summary>
        [Browsable(false)]
        public override bool HasParent
        {
            get { return (this.ListView != null); }
        }
        #endregion
    }
    #endregion

    #region ContainerColumnHeader class
    /// <summary>
    /// Displays a single column header in a ContainerListView control.
    /// </summary>
    [
    ToolboxItem(false), DesignTimeVisible(false),
    DefaultProperty("Text"),
    TypeConverter(typeof(ContainerColumnHeaderConverter))
    ]
    public class ContainerColumnHeader : Component, ICloneable
    {
        #region member types definition
        #region ImageListIndexer class
        /// <summary>
        /// ImageList ContainerColumnHeader indexer class with Index and Key properties.
        /// </summary>
        internal class ColumnHeaderImageListIndexer
        {
            #region member varible and default property initialization
            private ContainerColumnHeader owner;
            private int index;
            private string key;
            #endregion

            #region constructors and destructors
            /// <summary>
            /// Initializes a new instance of the ContainerColumnHeader.ColumnHeaderImageListIndexer class.
            /// </summary>
            public ColumnHeaderImageListIndexer(ContainerColumnHeader ch)
            {
                this.owner = ch;
                this.key = string.Empty;
                this.index = -1;
            }
            #endregion

            #region property getters/setters
            public ImageList ImageList
            {
                get
                {
                    if (this.owner != null && this.owner.ListView != null)
                    {
                        return this.owner.ListView.ImageList;
                    }

                    return null;
                }
            }

            public int Index
            {
                get { return this.index; }
                set
                {
                    this.key = string.Empty;
                    this.index = value;
                }
            }

            public string Key
            {
                get { return this.key; }
                set
                {
                    this.index = -1;
                    this.key = (value == null) ? string.Empty : value;
                }
            }
            #endregion
        }
        #endregion
        #endregion

		#region member varible and default property initialization
        private ContainerListView containerListView;
        internal string name;
        internal string text;
        private HorizontalAlignment textAlign;
        private bool textAlignInitialized;
        private object userData;
        internal int width  = 60;
        private bool allowResize = true;
        private Font font;
        private Color foreColor = SystemColors.WindowText;
        private ColumnHeaderImageListIndexer imageIndexer;
        private bool hovered;
        private bool pressed;
        private bool hidden;
		#endregion

		#region constructors and destructors
        /// <summary>
        /// Initializes a new instance of the ContainerColumnHeader class.
        /// </summary>
        public ContainerColumnHeader()
        {
            this.imageIndexer = new ColumnHeaderImageListIndexer(this);
        }

        /// <summary>
        /// Initializes a new instance of the ContainerColumnHeader class with the image specified.
        /// </summary>
        /// <param name="imageIndex">The index of the image to display in the System.Windows.Forms.ColumnHeader.</param>
        public ContainerColumnHeader(int imageIndex) : this()
        {
            this.imageIndexer = new ColumnHeaderImageListIndexer(this);
            this.ImageIndex = imageIndex;
        }

        /// <summary>
        /// Initializes a new instance of the System.Windows.Forms.ColumnHeader class with the image specified.
        /// </summary>
        /// <param name="imageKey">The key of the image to display in the System.Windows.Forms.ColumnHeader.</param>
        public ContainerColumnHeader(string imageKey) : this()
        {
            this.imageIndexer = new ColumnHeaderImageListIndexer(this);
            this.ImageKey = imageKey;
        }

        /// <summary>
        /// Disposes of the resources (other than memory) used by the SContainerColumnHeader.
        /// </summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.containerListView != null))
            {
                int itemIndex = this.Index;
                if (itemIndex != -1)
                {
                    this.containerListView.Columns.RemoveAt(itemIndex);
                }
            }
            base.Dispose(disposing);
        }
		#endregion

		#region action methods
        /// <summary>
        /// Creates an identical copy of the current ContainerColumnHeader that is not attached to any list view control.
        /// </summary>
        /// <returns>An object representing a copy of this ContainerColumnHeader object.</returns>
        public object Clone()
        {
            Type type = base.GetType();

            ContainerColumnHeader column = null;
            if (type == typeof(ContainerColumnHeader))
            {
                column = new ContainerColumnHeader();
            }
            else
            {
                column = (ContainerColumnHeader)Activator.CreateInstance(type);
            }

            column.text = this.text;
            column.Width = this.width;
            column.textAlign = this.textAlign;
            column.allowResize = this.allowResize;
            column.font = this.font;
            column.foreColor = this.foreColor;
            column.hidden = this.hidden;
            column.userData = this.userData;
            column.imageIndexer = this.imageIndexer;

            return column;
        }

        /// <summary>
        /// Returns a string representation of this column header.
        /// </summary>
        /// <returns>A System.String containing the name of the System.ComponentModel.Component, if any, or null if the System.ComponentModel.Component is unnamed.</returns>
        public override string ToString()
        {
            return ("ColumnHeader: Text: " + this.Text);
        }

        /// <summary>
        /// Sort the Items in the ContainerListView by this column.
        /// </summary>
        public void Sort()
        {
            if (this.containerListView != null)
            {
                this.containerListView.Sort(this.Index);
            }
        }
		#endregion

		#region property getters/setters
        /// <summary>
        /// Gets or sets the text displayed in the column header.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The text displayed in the column header."),
        Localizable(true)
        ]
        public string Text
        {
            get
            {
                if (this.text == null)
                {
                    return "ColumnHeader";
                }

                return this.text;
            }
            set
            {
                if (value == null)
                {
                    this.text = "";
                }
                else
                {
                    this.text = value;
                }

                if (this.containerListView != null)
                {
                    this.containerListView.Invalidate(this.Bounds);
                }
            }
        }

        /// <summary>
        /// Gets or sets the name of the ContainerColumnHeader.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Name
        {
            get { return GetComponentName(this, this.name); }
            set
            {
                if (value == null)
                {
                    this.name = "";
                }
                else
                {
                    this.name = value;
                }

                if (this.Site != null)
                {
                    this.Site.Name = value;
                }
            }
        }

        /// <summary>
        /// Gets the location with the ContainerListView control's ContainerColumnHeaderCollection of this column.
        /// </summary>
        [Browsable(false)]
        public int Index
        {
            get
            {
                if (this.containerListView != null)
                {
                    return this.containerListView.Columns.IndexOf(this);
                }

                return -1;
            }
        }

        /// <summary>
        /// Gets or sets an object that contains data to associate with the ContainerColumnHeader.
        /// </summary>
        [
        Browsable(true), Category("Data"),
        Description("Object that contains data associate with the ContainerColumnHeader."),
        DefaultValue(""),
        Bindable(true), Localizable(true),
        TypeConverter(typeof(StringConverter))
        ]
        public object Tag
        {
            get { return this.userData; }
            set { this.userData = value; }
        }

        /// <summary>
        /// Gets or sets the horizontal alignment of the text displayed in the ContainerColumnHeader.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Horizontal alignment of the text displayed in the ContainerColumnHeader."),
        DefaultValue(typeof(HorizontalAlignment), "Left"), Localizable(true)
        ]
        public HorizontalAlignment TextAlign
        {
            get
            {
                if (!this.textAlignInitialized && this.containerListView != null)
                {
                    this.textAlignInitialized = true;

                    if (this.Index != 0 && this.containerListView.RightToLeft == RightToLeft.Yes && !this.containerListView.IsMirrored)
                    {
                        this.textAlign = HorizontalAlignment.Right;
                    }
                }

                return this.textAlign;
            }
            set
            {
                if (!IsEnumValid((int)value, 0, 2))
                {
                    throw new InvalidEnumArgumentException("value", (int)value, typeof(HorizontalAlignment));
                }

                this.textAlign = value;

                if (this.Index == 0 && this.textAlign != HorizontalAlignment.Left)
                {
                    this.textAlign = HorizontalAlignment.Left;
                }

                if (this.containerListView != null)
                {
                    this.containerListView.Invalidate();
                }
            }
        }
 
        /// <summary>
        /// Gets or sets the width of the column.
        /// </summary>
        [
        Browsable(true), Category("Layout"),
        Description("The width of the column."),
        DefaultValue(60),
        Localizable(true)
        ]
        public int Width
        {
            get { return this.width; }
            set
            {
                this.width = value;

                if (this.containerListView != null)
                {
                    this.containerListView.HeaderResized();
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines whether the ColumnHeader can be resized.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether the ColumnHeader can be resized."),
        DefaultValue(true)
        ]
        public bool AllowResize
        {
            get { return this.allowResize; }
            set { this.allowResize = value; }
        }

		#region image properties
        /// <summary>
        /// Gets or sets the index of the image displayed in the ContainerColumnHeader.
        /// </summary>
        /// <exception cref="System.ArgumentOutOfRangeException">ContainerColumnHeader.ImageIndex is less than -1.</exception>
        [
        Browsable(true), Category("Appearance"),
        Description("The index of the image displayed in the ContainerColumnHeader."),
        DefaultValue(-1),
        RefreshProperties(RefreshProperties.Repaint),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        TypeConverter(typeof(ImageIndexConverter)),
        Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor))
        ]
        public int ImageIndex
        {
            get
            {
                if (this.imageIndexer.Index != -1 && this.ImageList != null && this.imageIndexer.Index >= this.ImageList.Images.Count)
                {
                    return this.ImageList.Images.Count - 1;
                }

                return this.imageIndexer.Index;
            }
            set
            {
                if (value < -1)
                {
                    throw new ArgumentOutOfRangeException("value");
                }

                if (this.imageIndexer.Index != value)
                {
                    this.imageIndexer.Index = value;

                    if (this.containerListView != null)
                    {
                        this.containerListView.Invalidate(this.Bounds);
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the key of the image displayed in the ContainerColumnHeader.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The key of the image displayed in the ContainerColumnHeader."),
        DefaultValue(""),
        RefreshProperties(RefreshProperties.Repaint),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        TypeConverter(typeof(ImageIndexConverter)),
        Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor))
        ]
        public string ImageKey
        {
            get { return this.imageIndexer.Key; }
            set
            {
                if (value != this.imageIndexer.Key)
                {
                    this.imageIndexer.Key = value;

                    if (this.containerListView != null)
                    {
                        this.containerListView.Invalidate(this.Bounds);
                    }
                }
            }
        }

        /// <summary>
        /// Gets the image list associated with the ContainerColumnHeader.
        /// </summary>
        [Browsable(false)]
        public ImageList ImageList
        {
            get { return this.imageIndexer.ImageList; }
        }
        #endregion

        /// <summary>
        /// Gets or Sets a value that determines whether the Column is hidden or not.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether the Column is hidden or not."),
        DefaultValue(false),
        Localizable(true)
        ]
        public bool Hidden
        {
            get { return this.hidden; }
            set
            {
                if (!this.hidden.Equals(value))
                {
                    if (value)
                    {
                        if ((this.containerListView != null) && this.containerListView.AllowHiddenColumns)
                        {
                            this.hidden = value;
                            this.containerListView.HiddenColumns.Add(this);
                            this.containerListView.Invalidate();
                        }
                    }
                    else
                    {
                        this.hidden = value;
                        if ((this.containerListView != null) && this.containerListView.HiddenColumns.Contains(this))
                        {
                            this.containerListView.HiddenColumns.Remove(this);
                            this.containerListView.Invalidate();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the foreground color of the ColumnHeader's text
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines the ForeColor of the the ColumnHeader's text."),
        DefaultValue(typeof(Color), "WindowText")
        ]
        public Color ForeColor
        {
            get { return this.foreColor; }
            set
            {
                if (!this.foreColor.Equals(value))
                {
                    this.foreColor = value;

                    if (this.containerListView != null)
                    {
                        this.containerListView.Invalidate();
                    }

                }
            }
        }

        /// <summary>
        /// Gets or sets the font of the text displayed by the ColumnHeader.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines the font of the text displayed by the ColumnHeader."),
        AmbientValue((string)null),
        Localizable(true)
        ]
        public Font Font
        {
            get
            {
                if (this.font == null)
                {
                    return SystemFonts.DefaultFont;
                }

                return this.font;
            }
            set
            {
                if ((value == null && this.font != null) || (value != null && !value.Equals(this.font)))
                {
                    if (SystemFonts.DefaultFont.Equals(value))
                    {
                        this.font = null;
                    }
                    else
                    {
                        this.font = value;
                    }

                    if (this.containerListView != null)
                    {
                        this.containerListView.Invalidate();
                    }
                }
            }
        }

        private void ResetFont()
        {
            this.font = null;
        }

        private bool ShouldSerializeFont()
        {
            return (this.font != null);
        }

        /// <summary>
        /// Gets the ContainerListView control the ContainerColumnHeader is located in.
        /// </summary>
        [Browsable(false)]
        public ContainerListView ListView
        {
            get { return this.containerListView; }
        }

        /// <summary>
        /// Gets or Sets a value that determines if the column is Hovered.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal bool Hovered
        {
            get { return this.hovered; }
            set { this.hovered = value; }
        }

        /// <summary>
        /// Gets or Sets a value that determines if the Column is in a pressed state.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal bool Pressed
        {
            get { return this.pressed; }
            set { this.pressed = value; }
        }

        /// <summary>
        /// Gets the bounding rectangle of the ContainerColumnHeader.
        /// </summary>
        [Browsable(false)]
        public Rectangle Bounds
        {
            get { return this.RegenerateRectangle(); }
        }

        /// <summary>
        /// Gets the portion of the Column rectangle used for sizing.
        /// </summary>
        [Browsable(false)]
        protected internal Rectangle SizingBounds
        {
            get
            {
                Rectangle Rect = this.Bounds;

                if (!Rect.Equals(Rectangle.Empty))
                {
                    return new Rectangle(Rect.X + Rect.Width - 4, 2, 4, this.ListView.HeaderBuffer);
                }

                return Rectangle.Empty;
            }
        }

        /// <summary>
        /// The ContainerListView that owns the ContainerColumnHeader.
        /// </summary>
        internal ContainerListView OwnerListView
        {
            get { return this.containerListView; }
            set { this.containerListView = value; }
        }
		#endregion

		#region private member functions
        private static string GetComponentName(IComponent component, string defaultNameValue)
        {
            string name = string.Empty;

            if (string.IsNullOrEmpty(defaultNameValue))
            {
                if (component.Site != null)
                {
                    name = component.Site.Name;
                }
                if (name == null)
                {
                    name = string.Empty;
                }

                return name;
            }

            return defaultNameValue;
        }

        private static bool IsEnumValid(int value, int minValue, int maxValue)
        {
            return (value >= minValue && value <= maxValue);
        }

        private Rectangle RegenerateRectangle()
        {
            Rectangle Rect = Rectangle.Empty;
            int borderWidth = this.containerListView.GetBorderWidth();

            if (!this.hidden && this.containerListView != null)
            {
                int Xpos = borderWidth - this.ListView.HScroll.Value;

                for (int i = 0; i <= this.Index - 1; i++)
                {
                    if (!this.containerListView.Columns[i].Hidden)
                    {
                        Xpos += this.containerListView.Columns[i].Width;
                    }
                }

                Rect = new Rectangle(Xpos, borderWidth, this.Width, this.containerListView.HeaderBuffer);
            }

            return Rect;
        }
		#endregion
    }
    #endregion

    #region ContainerListViewComparer class
    /// <summary>
    /// ContainerListViewComparer Class. Helper class used to sort any ListView by a specific column. 
    /// </summary>
    public sealed class ContainerListViewComparer : IComparer
    {
		#region member varible and default property initialization
        private int col;
        private SortOrder order = SortOrder.Ascending;
        #endregion

		#region constructors and destructors
        /// <summary>
        /// Creates a new instance of ContainerListViewComparer.
        /// </summary>
        public ContainerListViewComparer() { }

        /// <summary>
        /// Creates a new instance of ContainerListViewComparer.
        /// </summary>
        /// <param name="Col">The index of the column clicked in the ListView.</param>
        /// <param name="SortOrder">The SortOrder.</param>
        public ContainerListViewComparer(int Col, SortOrder SortOrder)
        {
            if (SortOrder == SortOrder.None)
            {
                throw new InvalidEnumArgumentException("SortOrder", (int)SortOrder, typeof(SortOrder));
            }

            this.col = Math.Abs(Col);
            this.order = SortOrder;
        }
		#endregion

        #region action methods
        /// <summary>
        /// Compares two objects and returns a value indicating whether one is less than, equal to or greater than the other
        /// </summary>
        /// <param name="x">First object to compare.</param>
        /// <param name="y">Second object to compare.</param>
        /// <returns>A integer value indicating whether one is less than, equal to or greater than the other.</returns>
        public int Compare(object x, object y)
        {
            string XTextValue = string.Empty;
            string YTextValue = string.Empty;

            var ClvoX = x as ContainerListViewObject;
            var ClvoY = y as ContainerListViewObject;

            //If it's column zero then i know it's some type of ContainerListViewObject, otherwise it's a subitem
            if (this.col == 0)
            {
                if (ClvoX != null)
                {
                    XTextValue = ClvoX.Text.Trim();
                }

                if (ClvoY != null)
                {
                    YTextValue = ClvoY.Text.Trim();
                }
            }
            else
            {
                if (ClvoX != null)
                {
                    XTextValue = ClvoX.SubItems[this.col - 1].Text.Trim();
                }

                if (ClvoY != null)
                {
                    YTextValue = ClvoY.SubItems[this.col - 1].Text.Trim();
                }
            }

            //Compare
            int ReturnVal = -1;

            DateTime DateX;
            DateTime DateY;
            decimal DecimalX;
            decimal DecimalY;
            if (DateTime.TryParse(XTextValue, out DateX) && DateTime.TryParse(YTextValue, out DateY))
            {
                ReturnVal = DateTime.Compare(DateX, DateY);
            }
            else if (decimal.TryParse(XTextValue, out DecimalX) && decimal.TryParse(YTextValue, out DecimalY))
            {
                ReturnVal = decimal.Compare(DecimalX, DecimalY);
            }
            else
            {
                ReturnVal = string.Compare(XTextValue, YTextValue, StringComparison.OrdinalIgnoreCase);
            }

            if (this.order == SortOrder.Descending)
            {
                ReturnVal *= -1;
            }

            return ReturnVal;
        }
		#endregion

		#region property getters/setters
        /// <summary>
        /// Gets or Sets index of the ClickedColumn.
        /// </summary>
        public int ColumnIndex
        {
            get { return this.col; }
            set
            {
                if (value >= 0)
                {
                    this.col = value;
                }
            }
        }

        /// <summary>
        /// Gets or Sets the SortOrder.
        /// </summary>
        public SortOrder Order
        {
            get { return this.order; }
            set
            {
                if (value != SortOrder.None && this.order != value)
                {
                    this.order = value;
                }
            }
        }
		#endregion
    }
    #endregion
    #endregion

    /// <summary>
    /// Provides a ListView control in detail mode that provides containers for each cell in a row/column.
    /// </summary>
    /// <remarks>
    /// The container can hold almost any object that derives directly or indirectly from Control.
    /// </remarks>
    [
    ToolboxItem(false),
    DefaultProperty("Items"),
    DefaultEvent("AfterSelect"),
    Designer(typeof(IMP.SharedControls.Design.ContainerListViewDesigner))
    ]
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
    public class ContainerListView : Control
    {
		#region public member types
        #region SelectedContainerListViewObjectCollection class
        /// <summary>
        /// Strongly typed collection of ContainerListViewObject objects that are in a selected state. 
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
        public class SelectedContainerListViewObjectCollection : ContainerListViewReadOnlyCollection
        {
            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of SelectedContainerListViewObjectCollection.
            /// </summary>
            internal SelectedContainerListViewObjectCollection() { }
            #endregion

            #region action methods
            /// <summary>
            /// Removes all Items from the collection.
            /// </summary>
            public new void Clear()
            {
                for (int I = base.InnerList.Count - 1; I >= 0; I += -1)
                {
                    ((ContainerListViewObject)base.InnerList[I]).Selected = false;
                }

                base.InnerList.Clear();
            }

            /// <summary>
            /// Adds an item to the collection.
            /// </summary>
            /// <param name="ClObj">The ContainerListViewObject to add to the collection.</param>
            /// <returns>The index of the ContainerListViewObject in the collection; otherwise -1 if the ContainerListViewObject was not added.</returns>
            internal int Add(ContainerListViewObject ClObj)
            {
                if (ClObj != null && !this.Contains(ClObj))
                {
                    return this.InnerList.Add(ClObj);
                }

                return -1;
            }

            /// <summary>
            /// Removes an item from the collection.
            /// </summary>
            /// <param name="ClObj">The ContainerListViewObject to remove.</param>
            internal void Remove(ContainerListViewObject ClObj)
            {
                if (ClObj != null && this.Contains(ClObj))
                {
                    this.InnerList.Remove(ClObj);
                }
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets the item in the Collection.
            /// </summary>
            /// <param name="Index">The index of the item to get.</param>
            /// <returns>A ContainerListViewObject at the specified index</returns>
            public ContainerListViewObject this[int Index]
            {
                get { return (ContainerListViewObject)base.InnerList[Index]; }
            }
            #endregion
        }
        #endregion

        #region CheckedContainerListViewObjectCollection class
        /// <summary>
        /// Strongly typed collection of ContainerListViewItem objects that are in a checked state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers")]
        public class CheckedContainerListViewObjectCollection : ContainerListViewReadOnlyCollection
        {
            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of CheckedContainerListViewItemCollection.
            /// </summary>
            public CheckedContainerListViewObjectCollection() { }
            #endregion

            #region action methods
            /// <summary>
            /// Removes all Items from the collection.
            /// </summary>
            public new void Clear()
            {
                for (int I = base.InnerList.Count - 1; I >= 0; I += -1)
                {
                    ((ContainerListViewObject)base.InnerList[I]).Checked = false;
                }

                base.InnerList.Clear();
            }

            /// <summary>
            /// Adds an item to the collection.
            /// </summary>
            internal int Add(ContainerListViewObject ClObj)
            {
                if ((ClObj != null) && !this.Contains(ClObj))
                {
                    return this.InnerList.Add(ClObj);
                }

                return -1;
            }

            /// <summary>
            /// Removes an item from the collection.
            /// </summary>
            internal void Remove(ContainerListViewObject ClObj)
            {
                if ((ClObj != null) && this.Contains(ClObj))
                {
                    this.InnerList.Remove(ClObj);
                }
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets the item in the Collection.
            /// </summary>
            /// <param name="Index">The index of the item to get.</param>
            /// <returns>A ContainerListViewItem at the specified index</returns>
            public ContainerListViewObject this[int Index]
            {
                get { return (ContainerListViewItem)this.InnerList[Index]; }
            }
            #endregion
        }
        #endregion

        #region ContainerListViewItemCollection class
        /// <summary>
        /// Strongly typed collection of ContainerListViewItem objects.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1039:ListsAreStronglyTyped"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
        public class ContainerListViewItemCollection : ContainerListViewObjectCollection
        {
            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of ContainerListViewObjectCollection.
            /// </summary>
            public ContainerListViewItemCollection() { }

            /// <summary>
            /// Creates a new instance of ContainerListViewObjectCollection.
            /// </summary>
            /// <param name="Parent">The Owner of the collection.</param>
            internal ContainerListViewItemCollection(ContainerListView Parent) : base(Parent) { }
            #endregion

            #region action methods
            /// <summary>
            /// Adds a item to the collection.
            /// </summary>
            /// <param name="Item">The item to Add.</param>
            /// <returns>An integer representing the zero-based index within the collection.</returns>
            public int Add(ContainerListViewItem Item)
            {
                return this.List.Add(Item);
            }

            /// <summary>
            /// Adds a item to the collection.
            /// </summary>
            /// <param name="Text">The Text of the ContainerListViewItem.</param>
            /// <returns>The newly added item.</returns>
            public ContainerListViewItem Add(string Text)
            {
                ContainerListViewItem item = new ContainerListViewItem(Text);
                this.Add(item);

                return item;
            }

            /// <summary>
            /// Adds a Item to the collection.
            /// </summary>
            /// <param name="Text">The Text of the ContainerListViewItem.</param>
            /// <param name="ImageIndex">A index of the Image to display.</param>
            /// <returns>The newly added item.</returns>
            public ContainerListViewItem Add(string Text, int ImageIndex)
            {
                ContainerListViewItem item = new ContainerListViewItem(Text, ImageIndex);
                this.Add(item);

                return item;
            }

            /// <summary>
            /// Adds an array of Items.
            /// </summary>
            /// <param name="Items">The Items to add.</param>
            public void AddRange(ContainerListViewItem[] Items)
            {
                if (Items != null)
                {
                    lock (this.List.SyncRoot)
                    {
                        for (int i = 0; i <= Items.GetUpperBound(0); i++)
                        {
                            this.List.Add(Items[i]);
                        }
                    }
                }
            }

            /// <summary>
            /// Inserts an item at the specified position.
            /// </summary>
            /// <param name="Item">The ContainerListViewItem to insert.</param>
            /// <param name="Index">The zero-based index at which the item should be inserted.</param>
            public void Insert(ContainerListViewItem Item, int Index)
            {
                base.List.Insert(Index, Item);
            }

            /// <summary>
            /// Occurs after an add or insert to the collection.
            /// </summary>
            /// <param name="ClObj">The item that was added.</param>
            /// <param name="Index">The index where the item was added.</param>
            protected override void OnAddProcessing(ContainerListViewObject ClObj, int Index)
            {
                base.OnAddProcessing(ClObj, Index);

                ClObj.SetParent(base.Parent);

                foreach (ContainerListViewItem.ContainerListViewSubItem item in ClObj.SubItems)
                {
                    if (item.Control != null)
                    {
                        item.Control.Parent = base.Parent;
                        item.Control.Visible = true;
                    }
                }
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets or Sets the item in the Collection.
            /// </summary>
            /// <param name="Index">The index of the item to get or set.</param>
            /// <returns>Item in the Collection.</returns>
            public ContainerListViewItem this[int Index]
            {
                get { return (ContainerListViewItem)this.List[Index]; }
                set { this.List[Index] = value; }
            }
            #endregion
        }
        #endregion

        #region SelectedIndexCollection class
        /// <summary>
        /// Strongly typed collection of integers (representing Indexes) of ContainerListViewItem objects that are in a selected state.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
        public class SelectedIndexCollection : ContainerListViewReadOnlyCollection
        {
            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of SelectedIndexCollection.
            /// </summary>
            internal SelectedIndexCollection() { }
            #endregion

            #region action methods
            /// <summary>
            /// Adds an Item to the collection.
            /// </summary>
            /// <param name="Index">The index of the ContainerListViewItem to add to the collection.</param>
            /// <returns>The index of the ContainerListViewItem in the collection; otherwise -1 if the ContainerListViewItem was not added.</returns>
            internal int Add(int Index)
            {
                if (Index >= 0 && !this.Contains(Index))
                {
                    return this.InnerList.Add(Index);
                }

                return -1;
            }

            /// <summary>
            /// Removes an item from the collection.
            /// </summary>
            /// <param name="Index">The index of the ContainerListViewItem to remove.</param>
            internal void Remove(int Index)
            {
                if (Index >= 0 && this.Contains(Index))
                {
                    this.InnerList.Remove(Index);
                }
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets the item in the Collection.
            /// </summary>
            /// <param name="Index">The index of the item to get.</param>
            /// <returns>An integer representing the index of the SelectedItem.</returns>
            public int this[int Index]
            {
                get { return (int)this.InnerList[Index]; }
            }
            #endregion
        }
        #endregion

        #region ContainerColumnHeaderCollection class
        /// <summary>
        /// Represents the collection of column headers in a ContainerListView control.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface"), ListBindable(false)]
        public class ContainerColumnHeaderCollection : IList, ICollection, IEnumerable
        {
            #region member varible and default property initialization
            private ContainerListView owner;
            private int lastAccessedIndex = - 1;
            #endregion

            #region constructors and destructors
            /// <summary>
            /// Initializes a new instance of the ContainerColumnHeaderCollection class.
            /// </summary>
            public ContainerColumnHeaderCollection(ContainerListView owner)
            {
                this.owner = owner;
            }
            #endregion

            #region action methods
		    #region Add
            /// <summary>
            /// Adds an existing ContainerColumnHeader to the collection.
            /// </summary>
            /// <param name="value">The ContainerColumnHeader to add to the collection.</param>
            /// <returns>The zero-based index into the collection where the item was added.</returns>
            public virtual int Add(ContainerColumnHeader value)
            {
                int count = this.Count;
                this.owner.InsertColumn(count, value);
                return count;
            }

            /// <summary>
            /// Creates and adds a column with the specified text to the collection.
            /// </summary>
            /// <param name="text">The text to display in the column header.</param>
            /// <returns>The ContainerColumnHeader with the specified text that was added to the ContainerColumnHeaderCollection.</returns>
            public virtual ContainerColumnHeader Add(string text)
            {
                ContainerColumnHeader ch = new ContainerColumnHeader();
                ch.Text = text;
                return this.owner.InsertColumn(this.Count, ch);
            }

            /// <summary>
            /// Creates and adds a column with the specified text and width to the collection.
            /// </summary>
            /// <param name="text">The text of the ContainerColumnHeader to add to the collection.</param>
            /// <param name="width">The width of the ContainerColumnHeader to add to the collection.</param>
            /// <returns>The ContainerColumnHeader with the specified text and width that was added to the ContainerColumnHeaderCollection.</returns>
            public virtual ContainerColumnHeader Add(string text, int width)
            {
                ContainerColumnHeader ch = new ContainerColumnHeader();
                ch.Text = text;
                ch.Width = width;

                return this.owner.InsertColumn(this.Count, ch);
            }

            /// <summary>
            /// Creates and adds a column with the specified text and key to the collection.
            /// </summary>
            /// <param name="key">The key of the ContainerColumnHeader to add to the collection.</param>
            /// <param name="text">The text of the ContainerColumnHeader to add to the collection.</param>
            /// <returns> The ContainerColumnHeader with the specified key and text that was added to the ContainerColumnHeaderCollection.</returns>
            public virtual ContainerColumnHeader Add(string key, string text)
            {
                ContainerColumnHeader ch = new ContainerColumnHeader();
                ch.Name = key;
                ch.Text = text;

                return this.owner.InsertColumn(this.Count, ch);
            }

            /// <summary>
            /// Adds a column header to the collection with specified text, width, and alignment settings.
            /// </summary>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width of the column header.</param>
            /// <param name="textAlign">One of the HorizontalAlignment values.</param>
            /// <returns>The ContainerColumnHeader that was created and added to the collection.</returns>
            public virtual ContainerColumnHeader Add(string text, int width, HorizontalAlignment textAlign)
            {
                ContainerColumnHeader ch = new ContainerColumnHeader();
                ch.Text = text;
                ch.Width = width;
                ch.TextAlign = textAlign;

                return this.owner.InsertColumn(this.Count, ch);
            }

            /// <summary>
            /// Creates and adds a column with the specified text, key, and width to the collection.
            /// </summary>
            /// <param name="key">The key of the column header.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width of the ContainerColumnHeader.</param>
            /// <returns></returns>
            public virtual ContainerColumnHeader Add(string key, string text, int width)
            {
                ContainerColumnHeader ch = new ContainerColumnHeader();
                ch.Name = key;
                ch.Text = text;
                ch.Width = width;

                return this.owner.InsertColumn(this.Count, ch);
            }

            /// <summary>
            /// Creates and adds a column with the specified key, aligned text, width, and image index to the collection.
            /// </summary>
            /// <param name="key">The key of the column header.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width of the column header.</param>
            /// <param name="textAlign">One of the System.Windows.Forms.HorizontalAlignment values.</param>
            /// <param name="imageIndex">The index value of the image to display in the column.</param>
            /// <returns>The System.Windows.Forms.ColumnHeader with the specified key, aligned text, width, and image index that has been added to the collection.</returns>
            public virtual ContainerColumnHeader Add(string key, string text, int width, HorizontalAlignment textAlign, int imageIndex)
            {
                ContainerColumnHeader ch = new ContainerColumnHeader(imageIndex);
                ch.Name = key;
                ch.Text = text;
                ch.Width = width;
                ch.TextAlign = textAlign;

                return this.owner.InsertColumn(this.Count, ch);
            }

            /// <summary>
            /// Creates and adds a column with the specified key, aligned text, width, and image key to the collection.
            /// </summary>
            /// <param name="key">The key of the column header.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width of the column header.</param>
            /// <param name="textAlign">One of the System.Windows.Forms.HorizontalAlignment values.</param>
            /// <param name="imageKey">The key value of the image to display in the column header.</param>
            /// <returns>The System.Windows.Forms.ColumnHeader with the specified key, aligned text, width, and image key that has been added to the collection.</returns>
            public virtual ContainerColumnHeader Add(string key, string text, int width, HorizontalAlignment textAlign, string imageKey)
            {
                ContainerColumnHeader ch = new ContainerColumnHeader(imageKey);
                ch.Name = key;
                ch.Text = text;
                ch.Width = width;
                ch.TextAlign = textAlign;

                return this.owner.InsertColumn(this.Count, ch);
            }
            #endregion

            /// <summary>
            /// Adds an array of column headers to the collection.
            /// </summary>
            /// <param name="values">An array of System.Windows.Forms.ColumnHeader objects to add to the collection.</param>
            public virtual void AddRange(ContainerColumnHeader[] values)
            {
                if (values == null)
                {
                    throw new ArgumentNullException("values");
                }

                for (int i = 0; i < values.Length; i++)
                {
                    this.Add(values[i]);
                }
            }

            /// <summary>
            /// Removes all column headers from the collection.
            /// </summary>
            public virtual void Clear()
            {
                if (this.owner.columnHeaders != null)
                {
                    for (int i = this.owner.columnHeaders.Length - 1; i >= 0; i--)
                    {
                        this.owner.columnHeaders[i].OwnerListView = null;
                    }

                    this.owner.columnHeaders = null;
                }
            }

            /// <summary>
            /// Determines whether the specified column header is located in the collection.
            /// </summary>
            /// <param name="value">A ContainerColumnHeader representing the column header to locate in the collection.</param>
            /// <returns>true if the column header is contained in the collection; otherwise, false.</returns>
            public bool Contains(ContainerColumnHeader value)
            {
                return this.IndexOf(value) != -1;
            }

            /// <summary>
            /// Determines if a column with the specified key is contained in the collection.
            /// </summary>
            /// <param name="key">The name of the column to search for.</param>
            /// <returns>true if a column with the specified name is contained in the collection; otherwise, false.</returns>
            public virtual bool ContainsKey(string key)
            {
                return this.IsValidIndex(this.IndexOfKey(key));
            }

            /// <summary>
            /// Returns an enumerator to use to iterate through the column header collection.
            /// </summary>
            /// <returns>An System.Collections.IEnumerator that represents the column header collection.</returns>
            public IEnumerator GetEnumerator()
            {
                if (this.owner.columnHeaders != null)
                {
                    return this.owner.columnHeaders.GetEnumerator();
                }

                return new ColumnHeader[0].GetEnumerator();
            }

            /// <summary>
            /// Returns the index, within the collection, of the specified column header.
            /// </summary>
            /// <param name="value">A System.Windows.Forms.ColumnHeader representing the column header to locate in the collection.</param>
            /// <returns>The zero-based index of the column header's location in the collection. If the column header is not located in the collection, the return value is -1.</returns>
            public int IndexOf(ContainerColumnHeader value)
            {
                for (int i = 0; i < this.Count; i++)
                {
                    if (this[i] == value)
                    {
                        return i;
                    }
                }

                return -1;
            }

            /// <summary>
            /// Determines the index for a column with the specified key.
            /// </summary>
            /// <param name="key">The name of the column to retrieve the index for.</param>
            /// <returns>The zero-based index for the first occurrence of the column with the specified name, if found; otherwise, -1.</returns>
            public virtual int IndexOfKey(string key)
            {
                if (!string.IsNullOrEmpty(key))
                {
                    if (this.IsValidIndex(this.lastAccessedIndex) && SafeCompareStrings(this[this.lastAccessedIndex].Name, key, true))
                    {
                        return this.lastAccessedIndex;
                    }

                    for (int i = 0; i < this.Count; i++)
                    {
                        if (SafeCompareStrings(this[i].Name, key, true))
                        {
                            this.lastAccessedIndex = i;
                            return i;
                        }
                    }

                    this.lastAccessedIndex = -1;
                }

                return -1;
            }

            #region Insert
            /// <summary>
            /// Inserts an existing column header into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="value">The ContainerColumnHeader to insert into the collection.</param>
            /// <exception cref="System.ArgumentOutOfRangeException">index is less than 0 or greater than or equal to the value of the Count property of the ContainerColumnHeaderCollection.</exception>
            public void Insert(int index, ContainerColumnHeader value)
            {
                if (index < 0 || index > this.Count)
                {
                    throw new ArgumentOutOfRangeException("index", string.Format(CultureInfo.CurrentCulture, "Value of '{1}' is not valid for 'index'", index.ToString(CultureInfo.CurrentCulture)));
                }

                this.owner.InsertColumn(index, value);
            }

            /// <summary>
            /// Creates a new column header with the specified text, and inserts the header into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <exception cref="System.ArgumentOutOfRangeException">index is less than 0 or greater than or equal to the value of the Count property of the ContainerColumnHeaderCollection.</exception>
            public void Insert(int index, string text)
            {
                this.Insert(index, new ContainerColumnHeader(text));
            }

            /// <summary>
            /// Creates a new column header with the specified text and initial width, and inserts the header into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width, in pixels, of the column header.</param>
            public void Insert(int index, string text, int width)
            {
                ContainerColumnHeader header = new ContainerColumnHeader();
                header.Text = text;
                header.Width = width;

                this.Insert(index, header);
            }

            /// <summary>
            /// Creates a new column header with the specified text and key, and inserts the header into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="key">The name of the column header.</param>
            /// <param name="text">The text to display in the column header.</param>
            public void Insert(int index, string key, string text)
            {
                ContainerColumnHeader header = new ContainerColumnHeader();
                header.Name = key;
                header.Text = text;

                this.Insert(index, header);
            }

            /// <summary>
            /// Creates a new column header and inserts it into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width of the column header.</param>
            /// <param name="textAlign">One of the HorizontalAlignment values.</param>
            /// <exception cref="System.ArgumentOutOfRangeException">index is less than 0 or greater than or equal to the value of the Count property of the ContainerColumnHeaderCollection.</exception>
            public void Insert(int index, string text, int width, HorizontalAlignment textAlign)
            {
                ContainerColumnHeader header = new ContainerColumnHeader();
                header.Text = text;
                header.Width = width;
                header.TextAlign = textAlign;

                this.Insert(index, header);
            }

            /// <summary>
            /// Creates a new column header with the specified text, key, and width, and inserts the header into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="key">The name of the column header.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width, in pixels, of the column header.</param>
            public void Insert(int index, string key, string text, int width)
            {
                ContainerColumnHeader header = new ContainerColumnHeader();
                header.Name = key;
                header.Text = text;
                header.Width = width;

                this.Insert(index, header);
            }

            /// <summary>
            /// Creates a new column header with the specified aligned text, key, width, and image index, and inserts the header into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="key">The name of the column header.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width, in pixels, of the column header.</param>
            /// <param name="textAlign">One of the System.Windows.Forms.HorizontalAlignment values.</param>
            /// <param name="imageIndex">The index of the image to display in the column header.</param>
            public void Insert(int index, string key, string text, int width, HorizontalAlignment textAlign, int imageIndex)
            {
                ContainerColumnHeader header = new ContainerColumnHeader(imageIndex);
                header.Name = key;
                header.Text = text;
                header.Width = width;
                header.TextAlign = textAlign;

                this.Insert(index, header);
            }

            /// <summary>
            /// Creates a new column header with the specified aligned text, key, width, and image key, and inserts the header into the collection at the specified index.
            /// </summary>
            /// <param name="index">The zero-based index location where the column header is inserted.</param>
            /// <param name="key">The name of the column header.</param>
            /// <param name="text">The text to display in the column header.</param>
            /// <param name="width">The initial width, in pixels, of the column header.</param>
            /// <param name="textAlign">One of the System.Windows.Forms.HorizontalAlignment values.</param>
            /// <param name="imageKey">The key of the image to display in the column header.</param>
            public void Insert(int index, string key, string text, int width, HorizontalAlignment textAlign, string imageKey)
            {
                ContainerColumnHeader header = new ContainerColumnHeader(imageKey);
                header.Name = key;
                header.Text = text;
                header.Width = width;
                header.TextAlign = textAlign;

                this.Insert(index, header);
            }
            #endregion

            /// <summary>
            /// Removes the specified column header from the collection.
            /// </summary>
            /// <param name="column">A ContainerColumnHeader representing the column header to remove from the collection.</param>
            public virtual void Remove(ContainerColumnHeader column)
            {
                int index = this.IndexOf(column);
                if (index != -1)
                {
                    this.RemoveAt(index);
                }
            }

            /// <summary>
            /// Removes the column header at the specified index within the collection.
            /// </summary>
            /// <param name="index">The zero-based index of the column header to remove.</param>
            /// <exception cref="System.ArgumentOutOfRangeException">index is less than 0 or greater than or equal to the value of the Count property of the ContainerColumnHeaderCollection.</exception>
            public virtual void RemoveAt(int index)
            {
                if (index < 0 || index >= this.owner.columnHeaders.Length)
                {
                    throw new ArgumentOutOfRangeException("index", string.Format(CultureInfo.CurrentCulture, "Value of '{1}' is not valid for 'index'", index.ToString(CultureInfo.CurrentCulture)));
                }

                this.owner.columnHeaders[index].OwnerListView = null;

                int length = this.owner.columnHeaders.Length;
                if (length == 1)
                {
                    this.owner.columnHeaders = null;
                }
                else
                {
                    ContainerColumnHeader[] destinationArray = new ContainerColumnHeader[--length];
                    if (index > 0)
                    {
                        Array.Copy(this.owner.columnHeaders, 0, destinationArray, 0, index);
                    }

                    if (index < length)
                    {
                        Array.Copy(this.owner.columnHeaders, index + 1, destinationArray, index, length - index);
                    }

                    this.owner.columnHeaders = destinationArray;
                }

                this.owner.ColumnHeadersChanged();
            }

            /// <summary>
            /// Removes the column with the specified key from the collection.
            /// </summary>
            /// <param name="key">The name of the column to remove from the collection.</param>
            public virtual void RemoveByKey(string key)
            {
                int index = this.IndexOfKey(key);
                if (this.IsValidIndex(index))
                {
                    this.RemoveAt(index);
                }
            }

            /// <summary>
            /// Copies the entire collection into an existing array at a specified location within the array.
            /// </summary>
            /// <param name="dest">The destination array.</param>
            /// <param name="index">The index in the destination array at which storing begins.</param>
            public void CopyTo(ContainerColumnHeader[] dest, int index)
            {
                ((ICollection)this).CopyTo(dest, index);
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets the number of items in the collection.
            /// </summary>
            [Browsable(false)]
            public int Count
            {
                get
                {
                    if (this.owner.columnHeaders != null)
                    {
                        return this.owner.columnHeaders.Length;
                    }

                    return 0;
                }
            }

            /// <summary>
            /// Gets a value indicating whether the collection is read-only.
            /// </summary>
            public bool IsReadOnly
            {
                get { return false; }
            }

            /// <summary>
            /// Gets the column header at the specified index within the collection.
            /// </summary>
            /// <param name="index">The index of the column header to retrieve from the collection.</param>
            /// <returns>A ContainerColumnHeader representing the column header located at the specified index within the collection.</returns>
            public virtual ContainerColumnHeader this[int index]
            {
                get
                {
                    if (this.owner.columnHeaders == null || index < 0 || index >= this.owner.columnHeaders.Length)
                    {
                        throw new ArgumentOutOfRangeException("index", string.Format(CultureInfo.CurrentCulture, "Value of '{1}' is not valid for 'index'", index.ToString(CultureInfo.CurrentCulture)));
                    }

                    return this.owner.columnHeaders[index];
                }
            }

            /// <summary>
            /// Gets the column header with the specified key from the collection.
            /// </summary>
            /// <param name="key">The name of the column header to retrieve from the collection.</param>
            /// <returns>The ContainerColumnHeader with the specified key.</returns>
            public virtual ContainerColumnHeader this[string key]
            {
                get
                {
                    if (!string.IsNullOrEmpty(key))
                    {
                        int index = this.IndexOfKey(key);

                        if (this.IsValidIndex(index))
                        {
                            return this[index];
                        }
                    }

                    return null;
                }
            }
            #endregion

            #region private member functions
            private bool IsValidIndex(int index)
            {
                return (index >= 0 && index < this.Count);
            }

            private static bool SafeCompareStrings(string string1, string string2, bool ignoreCase)
            {
                if (string1 == null || string2 == null)
                {
                    return false;
                }

                if (string1.Length != string2.Length)
                {
                    return false;
                }

                return string.Equals(string1, string2, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
            }
            #endregion

            #region ICollection Members
            void ICollection.CopyTo(Array dest, int index)
            {
                if (this.Count > 0)
                {
                    Array.Copy(this.owner.columnHeaders, 0, dest, index, this.Count);
                }
            }

            bool ICollection.IsSynchronized
            {
                get { return this.IsSynchronized; }
            }

            /// <summary>
            /// ICollection.IsSynchronized property
            /// </summary>
            protected virtual bool IsSynchronized
            {
                get { return true; }
            }

            object ICollection.SyncRoot
            {
                get { return this; }
            }

            /// <summary>
            /// ICollection.SyncRoot property
            /// </summary>
            protected virtual object SyncRoot
            {
                get { return this; }
            }
            #endregion

            #region IList Members
            int IList.Add(object value)
            {
                ContainerColumnHeader column = value as ContainerColumnHeader;
                if (column == null)
                {
                    throw new ArgumentException("Value is not of type ContainerColumnHeader.");
                }

                return this.Add(column);
            }

            bool IList.Contains(object value)
            {
                ContainerColumnHeader column = value as ContainerColumnHeader;
                if (column != null)
                {
                    return this.Contains(column);
                }

                return false;
            }

            int IList.IndexOf(object value)
            {
                ContainerColumnHeader column = value as ContainerColumnHeader;
                if (column != null)
                {
                    return this.IndexOf(column);
                }

                return -1;
            }

            void IList.Insert(int index, object value)
            {
                ContainerColumnHeader column = value as ContainerColumnHeader;
                if (column != null)
                {
                    this.Insert(index, column);
                }
            }

            void IList.Remove(object value)
            {
                ContainerColumnHeader column = value as ContainerColumnHeader;
                if (column != null)
                {
                    this.Remove(column);
                }
            }

            bool IList.IsFixedSize
            {
                get { return this.IsFixedSize; }
            }

            /// <summary>
            /// IList.IsFixedSize property
            /// </summary>
            protected virtual bool IsFixedSize
            {
                get { return false; }
            }

            object IList.this[int index]
            {
                get { return this[index]; }
                set { throw new NotSupportedException(); }
            }
            #endregion
        }
        #endregion

        #region HiddenColumnsCollection class
        /// <summary>
        /// Strongly typed collection of HiddenColumnsCollection ContainerColumnHeaders.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
        public class HiddenColumnsCollection : ContainerListViewReadOnlyCollection
        {
            #region constructors and destructors
            /// <summary>
            /// Creates a new instance of HiddenColumnsCollection.
            /// </summary>
            internal HiddenColumnsCollection() { }
            #endregion

            #region action methods
            /// <summary>
            /// Adds an item to the collection.
            /// </summary>
            /// <param name="Item">The ContainerColumnHeader to add to the collection.</param>
            /// <returns>The index of the item in the collection; otherwise -1 if the item was not added.</returns>
            internal int Add(ContainerColumnHeader Item)
            {
                if (Item != null && !this.Contains(Item))
                {
                    return this.InnerList.Add(Item);
                }

                return -1;
            }

            /// <summary>
            /// Removes an item from the collection.
            /// </summary>
            /// <param name="Item">The ContainerColumnHeader to remove.</param>
            internal void Remove(ContainerColumnHeader Item)
            {
                if (Item != null && this.Contains(Item))
                {
                    this.InnerList.Remove(Item);
                }
            }
            #endregion

            #region property getters/setters
            /// <summary>
            /// Gets the item in the Collection.
            /// </summary>
            /// <param name="Index">The index of the item to get.</param>
            /// <returns>A ContainerColumnHeader at the specified index</returns>
            public ContainerColumnHeader this[int Index]
            {
                get { return (ContainerColumnHeader)this.InnerList[Index]; }
            }
            #endregion
        }
        #endregion
		#endregion

		#region constants
        /// <summary>
        /// WM_GETDLGCODE Windows message.
        /// </summary>
        private const int WM_GETDLGCODE = 0x87;

        /// <summary>
        /// The control wants arrow keys. (DialogCode from the WinAPI)
        /// </summary>
        private const int DLGC_WANTARROWS = 0x01;

        /// <summary>
        /// The control wants WM_CHAR messages. (DialogCode from the WinAPI)
        /// </summary>
        private const int DLGC_WANTCHARS = 0x80;
		#endregion

		#region public member types
        /// <summary>
        /// Enumerated values specifying possible Selection modes.
        /// </summary>
        protected enum MultiSelectModes
        {
            /// <summary>
            /// The control only allows Single row selection.
            /// </summary>
            Single,
            /// <summary>
            /// A range of rows can be selected by holding down the Shift key, selecting an individual row (with mouse) and then
            /// selecting another row (with mouse).  The rows inbetween the two initially selected rows will also be selected.            /// 
            /// </summary>
            Range,
            /// <summary>
            /// Multiple rows can be selected by holding down the Ctrl key and selecting the desired rows with the mouse.
            /// </summary>
            Selective
        }
		#endregion

        #region delegate and events
        /// <summary>
        /// Occurs after the ContainerListViewObject or one of it's SubItems has been edited by the user.
        /// </summary>
        public event ContainerListViewEventHandler AfterEdit;

        /// <summary>
        /// Occurs after the state of the CheckBox changes on a ContainerListViewObject.
        /// </summary>
        public event ContainerListViewEventHandler AfterCheckStateChanged;

        /// <summary>
        /// Occurs after the ContainerListViewObject is selected.
        /// </summary>
        public event ContainerListViewEventHandler AfterSelect;

        /// <summary>
        /// Occurs when the user starts editing the label of a ContainerListViewObject or one of it's SubItems.
        /// </summary>
        public event ContainerListViewCancelEventHandler BeforeEdit;

        /// <summary>
        /// Occurs before the state of the CheckBox changes on a ContainerListViewObject.
        /// </summary>
        public event ContainerListViewCancelEventHandler BeforeCheckStateChanged;

        /// <summary>
        /// Occurs before the ContainerListViewObject is selected.
        /// </summary>
        public event ContainerListViewCancelEventHandler BeforeSelect;

        /// <summary>
        /// Occurs when the item or SubItem is double-clicked.
        /// </summary>
        public event ContainerListViewItemEventHandler ItemDoubleClick;

        /// <summary>
        /// Occurs when a ColumnHeader is clicked.
        /// </summary>
        public event HeaderMenuEventHandler ColumnHeaderClicked;

        /// <summary>
        /// Occurs when the value of the ContextMenu property changes.
        /// </summary>
        public event EventHandler ColumnHeaderContextMenuChanged;

        /// <summary>
        /// Occurs right before the ContextMenu for the ContainerColumnHeaders is be displayed.
        /// </summary>
        public event ContextMenuEventHandler ColumnHeaderContextMenuRequested;

        /// <summary>
        /// Occurs right before the ContextMenu for the control is displayed.
        /// </summary>
        public event ContextMenuEventHandler ContextMenuRequested;

        /// <summary>
        /// Occurs when an item is activated.
        /// </summary>
        /// <remarks>
        /// The ItemActivate event occurs when the user activates one or more items in the ContainerListView control. 
        /// The user can activate an item with either a single-click or double-click, or, depending on the value of the 
        /// ActivationType property, with the keyboard (Standard). From within the event handler for the ItemActivate event, 
        /// you can reference the SelectedItems or SelectedIndexes properties to access the collection of items selected in the ContainerListView to determine which items are being activated.
        /// </remarks>
        public event EventHandler ItemActivate;
        #endregion

		#region events methods
        /// <summary>
        /// Raises the AfterCheckStateChanged event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnAfterCheckStateChanged(ContainerListViewEventArgs e)
        {
            if (this.AfterCheckStateChanged != null)
            {
                this.AfterCheckStateChanged(this, e);
            }
        }

        /// <summary>
        /// Raises the BeforeCheckStateChanged event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnBeforeCheckStateChanged(ContainerListViewCancelEventArgs e)
        {
            if (this.BeforeCheckStateChanged != null)
            {
                this.BeforeCheckStateChanged(this, e);
            }
        }

        /// <summary>
        /// Raises the AfterEditEvent event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnAfterEdit(ContainerListViewEventArgs e)
        {
            if (this.AfterEdit != null)
            {
                this.AfterEdit(this, e);
            }
        }

        /// <summary>
        /// Raises the BeforeEdit event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnBeforeEdit(ContainerListViewCancelEventArgs e)
        {
            if (this.BeforeEdit != null)
            {
                this.BeforeEdit(this, e);
            }
        }

        /// <summary>
        /// Raises the AfterSelect event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnAfterSelect(ContainerListViewEventArgs e)
        {
            if (this.AfterSelect != null)
            {
                this.AfterSelect(this, e);
            }
        }

        /// <summary>
        ///  Raises the BeforeSelect event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnBeforeSelect(ContainerListViewCancelEventArgs e)
        {
            if (this.BeforeSelect != null)
            {
                this.BeforeSelect(this, e);
            }
        }

        /// <summary>
        /// Raises the ItemDoubleClick event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnItemDoubleClick(ContainerListViewItemEventArgs e)
        {
            if (this.ItemDoubleClick != null)
            {
                this.ItemDoubleClick(this, e);
            }
        }

        /// <summary>
        /// Raises the ColumnHeaderClicked event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnColumnHeaderClicked(ContainerColumnHeaderEventArgs e)
        {
            if (this.ColumnHeaderClicked != null)
            {
                this.ColumnHeaderClicked(this, e);
            }

            if (this.sorting != SortOrder.None)
            {
                this.OnSort(e.Column.Index);
            }
        }

        /// <summary>
        /// Raises the ColumnHeaderContextMenuChanged event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnColumnHeaderContextMenuChanged(EventArgs e)
        {
            if (this.ColumnHeaderContextMenuChanged != null)
            {
                this.ColumnHeaderContextMenuChanged(this, e);
            }
        }

        /// <summary>
        /// Raises the ColumnHeaderContextMenuRequested event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnColumnHeaderContextMenuRequested(MouseEventArgs e)
        {
            if (this.ColumnHeaderContextMenuRequested != null)
            {
                this.ColumnHeaderContextMenuRequested(this, e);
            }
        }

        /// <summary>
        /// Raises the ContextMenuRequested event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnContextMenuRequested(MouseEventArgs e)
        {
            if (this.ContextMenuRequested != null)
            {
                this.ContextMenuRequested(this, e);
            }
        }

        /// <summary>
        /// Raises the ItemActivate event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnItemActivate(EventArgs e)
        {
            if (this.ItemActivate != null)
            {
                this.ItemActivate(this, e);
            }
        }
		#endregion

		#region member varible and default property initialization
        private ItemActivation activation = ItemActivation.Standard;
        private bool allowCheckBoxes;
        private bool allowMultiSelectActivation;
        private bool allowColumnResize = true;
        private BorderStyle borderStyle = BorderStyle.Fixed3D;
        private ItemActivation checkBoxSelection = ItemActivation.OneClick;
        private CheckBoxType checkBoxType = CheckBoxType.CheckBox;
        private CheckedContainerListViewObjectCollection checkedItems;
        private int colScalePos;
        private int colScaleWidth;
        private Color colSortColor = Color.FromArgb(247, 247, 247);
        private bool colSortEnabled;
        private Color colTrackColor = Color.WhiteSmoke;
        private ContainerColumnHeaderCollection columnHeaderCollection;
        private ContainerColumnHeader[] columnHeaders;
        private Color disabledColor = Color.Gainsboro;
        private bool doColTracking;
        private bool doRowTracking;
        private Color editBackColor = SystemColors.Info;
        private ContainerListViewObject editingObj;
        private int firstSelected = -1;
        private int focusedIndex = -1;
        private ContainerListViewItem focusedItem;
        private bool fullRowSelect = true;
        private Color gridLineColor = SystemColors.Control;
        private GridLineSelections gridLineType = GridLineSelections.Both;
        private ContextMenuStrip headerMenu;
        private Rectangle headerRect;
        private ColumnHeaderStyle headerStyle = ColumnHeaderStyle.Clickable;
        private int headerBuffer = 0;
        private bool allowHiddenColumns = true;
        private bool hideSelection;
        private HiddenColumnsCollection hiddenCols;
        private HScrollBar hscrollBar = new HScrollBar();
        private VScrollBar vscrollBar = new VScrollBar();
        private ImageList imageList;
        private bool isFocused;
        private ContainerListViewItemCollection items;
        private Point lastClickedPoint;
        private ContainerColumnHeader lastColPressed;
        private ContainerListViewItem lastRowHovered;
        private bool multiSelect;
        private bool rightMouseSelects = true;
        private int rowHeight = 17;
        private Color rowTrackColor = Color.WhiteSmoke;
        private Color rowSelectColor = SystemColors.Highlight;
        private Rectangle rowsRect;
        private int scaledCol = -1;
        private bool scrollable = true;
        private SelectedIndexCollection selectedIndexes;
        private SelectedContainerListViewObjectCollection selectedItems;
        private IComparer sortComparer;
        private SortOrder sorting = SortOrder.None;
        private bool updateTransactions;
        private ContainerListViewComparer defaultComparer = new ContainerListViewComparer();
        private bool visualStyles = true;
        private bool colScaleMode;
        private Hashtable checkBoxRects = new Hashtable();
        private ContainerColumnHeader lastColHovered;
        private int lastPaintedSortCol = -1;
        private MultiSelectModes multiSelectMode = MultiSelectModes.Single;
        private bool processRows = true;
        private ContainerColumnHeader selectedCol;
        private RichTextBox editBox;

        private static bool IsWindowsVistaOrLater = IMP.WinVersionInfo.WinVersionInfo.VersionInfo().OSVersion >= IMP.WinVersionInfo.WinVersionInfo.GetOSWindowsVersion(IMP.WinVersionInfo.OSWindowsID.WindowsVista);
		#endregion

		#region constructors and destructors
        /// <summary>
        /// ContainerListView control constructor
        /// </summary>
        internal ContainerListView()
        {
            this.items = new ContainerListViewItemCollection(this);
            this.columnHeaderCollection = new ContainerColumnHeaderCollection(this);
            this.selectedIndexes = new SelectedIndexCollection();
            this.selectedItems = new SelectedContainerListViewObjectCollection();

            this.SetStyle(ControlStyles.DoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserMouse | ControlStyles.Selectable |
                          ControlStyles.ResizeRedraw | ControlStyles.Opaque | ControlStyles.UserPaint, true);

            this.checkedItems = new CheckedContainerListViewObjectCollection();
            this.hiddenCols = new HiddenColumnsCollection();
            this.Size = new Size(200, 150);

            base.BackColor = SystemColors.Window;
            base.ForeColor = SystemColors.WindowText;

            this.visualStyles = ScrollBarRenderer.IsSupported && Application.RenderWithVisualStyles;
            this.headerBuffer = GetColumnHeaderHeight();

            //Set the HScrollBar
            this.hscrollBar.Parent = this;
            this.vscrollBar.TabStop = false;
            this.hscrollBar.Minimum = 0;
            this.hscrollBar.Maximum = 0;
            this.hscrollBar.SmallChange = 10;
            this.hscrollBar.Hide();

            //Set the VScrollBar
            this.vscrollBar.Parent = this;
            this.vscrollBar.TabStop = false;
            this.vscrollBar.Minimum = 0;
            this.vscrollBar.Maximum = 0;
            this.vscrollBar.SmallChange = this.rowHeight;
            this.vscrollBar.Hide();

            //Attach any handlers
            this.hscrollBar.ValueChanged += new EventHandler(this.OnScroll);
            this.vscrollBar.ValueChanged += new EventHandler(this.OnScroll);
            this.hscrollBar.GotFocus += new EventHandler(this.ScrollGotFocus);
            this.vscrollBar.GotFocus += new EventHandler(this.ScrollGotFocus);

            //Create the header
            this.GenerateHeaderRect();

            //Create the editing control
            this.editBox = new RichTextBox();
            this.editBox.Visible = false;
            this.editBox.TabStop = false;
            this.editBox.AcceptsTab = false;
            this.editBox.BorderStyle = BorderStyle.None;
            this.editBox.DetectUrls = false;
            this.editBox.Multiline = false;
            this.editBox.ScrollBars = RichTextBoxScrollBars.None;
            this.Controls.Add(this.editBox);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                editBox.Dispose();

                if (this.columnHeaders != null)
                {
                    for (int i = this.columnHeaders.Length - 1; i >= 0; i--)
                    {
                        this.columnHeaders[i].OwnerListView = null;
                        this.columnHeaders[i].Dispose();
                    }

                    this.columnHeaders = null;
                }

                //Detach handlers
                this.hscrollBar.ValueChanged -= new EventHandler(this.OnScroll);
                this.vscrollBar.ValueChanged -= new EventHandler(this.OnScroll);
                this.hscrollBar.GotFocus -= new EventHandler(this.ScrollGotFocus);
                this.vscrollBar.GotFocus -= new EventHandler(this.ScrollGotFocus);
            }

            base.Dispose(disposing);
        }
        #endregion

		#region action methods
        /// <summary>
        /// Prevents the control from drawing until the EndUpdate method is called.
        /// </summary>
        public void BeginUpdate()
        {
            this.updateTransactions = true;
        }

        /// <summary>
        /// Resumes drawing of the list view control after drawing is suspended by the BeginUpdate method.
        /// </summary>
        public void EndUpdate()
        {
            this.updateTransactions = false;
            this.GenerateHeaderRect();
            this.GenerateViewableRowsRectangle();
            this.Invalidate();
        }
 
        /// <summary>
        /// Returns a ContainerListViewObject at the specified point.
        /// </summary>
        /// <param name="Point">The point at which to check for a SubItem.</param>
        /// <returns>A ContainerListViewObject ojbect.</returns>
        public virtual ContainerListViewObject GetItemAt(Point Point)
        {
            foreach (ContainerListViewItem item in this.items)
	        {
                if (item.CompleteBounds.Contains(Point))
                {
                    return item;
                }        		 
	        }

            return null;
        }

        /// <summary>
        /// Returns a ContainerListViewObject at the specified point.
        /// </summary>
        /// <param name="X">The X coordinate.</param>
        /// <param name="Y">The Y coordinate.</param>
        /// <returns>A ContainerListViewObject ojbect.</returns>
        public ContainerListViewObject GetItemAt(int X, int Y)
        {
            return this.GetItemAt(new Point(X, Y));
        }

        /// <summary>
        /// Returns the Sum of all the Column widths in the control, including hidden columns.
        /// </summary>
        /// <returns>An integer representing the combined width of all the columns.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate")]
        public int GetSumOfAllColumnWidths()
        {
            int Width = 0;

            if (this.columnHeaders != null)
            {
                foreach (ContainerColumnHeader Col in this.columnHeaders)
                {
                    Width += Col.Width;
                }
            }

            return Width;
        }

        /// <summary>
        /// Returns the Sum of all the visible Column widths in the control.
        /// </summary>
        /// <returns>An integer representing the combined width of all the visible columns.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate")]
        public int GetSumOfVisibleColumnWidths()
        {
            int Width = 0;

            if (this.columnHeaders != null)
            {
                foreach (ContainerColumnHeader Col in this.columnHeaders)
                {
                    if (!Col.Hidden)
                    {
                        if (Width == 0)
                        {
                            Width = -1;
                        }

                        Width += Col.Width;
                    }
                }
            }

            return Width;
        }

        /// <summary>
        /// Selects all Items in the control.
        /// </summary>
        public virtual void SelectAll()
        {
            if (this.multiSelect)
            {
                this.BeginUpdate();
                try
                {
                    foreach (ContainerListViewItem item in this.items)
                    {
                        item.Selected = true;
                    }
                }
                finally
                {
                    this.EndUpdate();
                }
            }
        }

        /// <summary>
        /// Sort all of the Items in the control.
        /// </summary>
        public void Sort()
        {
            this.Sort(0);
        }

        /// <summary>
        /// Sort all of the Items in the control.
        /// </summary>
        /// <param name="Index">The zero-based column index to sort on.</param>
        public void Sort(int Index)
        {
            if (this.sorting != SortOrder.None && this.columnHeaders != null && this.columnHeaders.Length > 0 && Index < this.columnHeaders.Length)
            {
                this.BeginUpdate();
                try
                {
                    this.defaultComparer.ColumnIndex = Index;
                    this.defaultComparer.Order = this.sorting;
                    this.OnSort(Index);
                }
                finally
                {
                    this.EndUpdate();
                }
            }
        }
        #endregion

        #region internal methods
        /// <summary>
        /// Gets control border width
        /// </summary>
        /// <returns></returns>
        internal int GetBorderWidth()
        {
            return borderStyle == BorderStyle.Fixed3D ? 2 : borderStyle == BorderStyle.FixedSingle ? 1 : 0;
        }

        /// <summary>
        /// Notifies the control that one of it's ContainerColumnHeaders has been resized.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void HeaderResized()
        {
            this.GenerateHeaderRect();
            this.GenerateViewableRowsRectangle();
        }

        /// <summary>
        /// Calls the OnAfterEdit method.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void ContainerListViewAfterEdit(ContainerListViewObject Item)
        {
            if (Item != null)
            {
                this.OnAfterEdit(new ContainerListViewEventArgs(Item));
            }
        }

        /// <summary>
        /// Calls the OnBeforeEdit method.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal bool ContainerListViewBeforeEdit(ContainerListViewObject Item)
        {
            if (Item != null)
            {
                ContainerListViewCancelEventArgs Arg = new ContainerListViewCancelEventArgs(Item, false);
                this.OnBeforeEdit(Arg);
                return Arg.Cancel;
            }

            return true;
        }

        /// <summary>
        /// Calls the OnAfterSelect method.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void ContainerListViewAfterSelect(ContainerListViewObject Item)
        {
            if (Item != null)
            {
                this.OnAfterSelect(new ContainerListViewEventArgs(Item));
            }
        }

        /// <summary>
        /// Calls the OnBeforeSelect method.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal bool ContainerListViewBeforeSelect(ContainerListViewObject Item)
        {
            if (Item != null)
            {
                ContainerListViewCancelEventArgs Arg = new ContainerListViewCancelEventArgs(Item, false);
                this.OnBeforeSelect(Arg);
                return Arg.Cancel;
            }

            return true;
        }

        /// <summary>
        /// Calls the OnAfterCheckStateChanged method.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal void ContainerListViewAfterCheckStateChanged(ContainerListViewObject Item)
        {
            if (Item != null)
            {
                this.OnAfterCheckStateChanged(new ContainerListViewEventArgs(Item));
            }
        }

        /// <summary>
        /// Calls the OnBeforeCheckStateChanged method.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal bool ContainerListViewBeforeCheckStateChanged(ContainerListViewObject Item)
        {
            if (Item != null)
            {
                ContainerListViewCancelEventArgs Arg = new ContainerListViewCancelEventArgs(Item, false);
                this.OnBeforeCheckStateChanged(Arg);
                return Arg.Cancel;
            }

            return false;
        }
        #endregion

        #region property getters/setters
        #region Behavior
        /// <summary>
        /// Gets or Sets a value that specifies the action that activates an item.
        /// </summary>
        /// <remarks>
        /// The ActivationType property allows you to specify how the user will activate an item in the ContainerListView control. Activating an item in a ContainerListView 
        /// is different from simply selecting an item. When an item is selected, an action is typically performed in an event handler for the ItemActivate event. For example, 
        /// when an item is activated you might open a file or display a dialog box that allows the item to be edited. Typically, an item is double-clicked by the user to 
        /// activate it. If the Activation property is set to ItemActivation.OneClick, clicking the item once activates it. Setting the Activation property to 
        /// ItemActivation.TwoClick is different from the standard double-click because the two clicks can have any duration between them.  If the Activation property is set
        /// to ItemActivation.Standard, highlighting the Node and pressing Enter/Return will activate the item(s).  If AllowMultiSelectActivation property is set to <c>TRUE</c>, 
        /// the ItemActivate event will only fire if the ActivationType is set to ItemActivation.Standard.
        /// </remarks>
        [
        Browsable(true), Category("Behavior"),
        Description("Specifies the action that activates an item."),
        DefaultValue(typeof(ItemActivation), "Standard")
        ]
        public ItemActivation ActivationType
        {
            get { return this.activation; }
            set { this.activation = value; }
        }

        /// <summary>
        /// Gets or Sets a value that determines how many clicks the user must press before the CheckBox will be selected/deselected.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines how many clicks the user must press before the CheckBox will be selected/deselected."),
        DefaultValue(typeof(ItemActivation), "OneClick")
        ]
        public ItemActivation CheckBoxSelection
        {
            get { return this.checkBoxSelection; }
            set { this.checkBoxSelection = value; }
        }

        /// <summary>
        /// Gets or Sets a value that determines whether the control will allow multiple selections.
        /// </summary>
        /// <remarks>
        /// If MultiSelect is changed to <c>false</c> and multiple items are currently selected, then all selected items are 
        /// cleared except for the last item that was selected when MultiSelect was enabled.
        /// </remarks>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether the control will allow multiple selections."),
        DefaultValue(false)
        ]
        public bool MultiSelect
        {
            get { return this.multiSelect; }
            set
            {
                if (!this.multiSelect.Equals(value))
                {
                    this.multiSelect = value;
                    this.Invalidate(this.ClientRectangle);

                    if (!this.multiSelect && this.selectedItems.Count > 1)
                    {
                        ContainerListViewObject Item = this.selectedItems[this.selectedItems.Count - 1];

                        this.BeginUpdate();

                        this.selectedItems.Clear();
                        this.selectedIndexes.Clear();
                        Item.Selected = true;

                        this.EndUpdate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines if the ItemActivation event fires if a user is in MultiSelect mode and presses the Enter/Return key.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines if the ItemActivation event fires if a user is in MultiSelect mode and presses the Enter/Return key."),
        DefaultValue(false)
        ]
        public bool AllowMultiSelectActivation
        {
            get { return this.allowMultiSelectActivation; }
            set { this.allowMultiSelectActivation = value; }
        }

        /// <summary>
        /// Gets or Sets a value that determines whether to highlight the full row or just the label when selecting an item.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether to highlight the full row or just the label when selecting an item."),
        DefaultValue(true)
        ]
        public bool FullRowSelect
        {
            get { return this.fullRowSelect; }
            set
            {
                if (!this.fullRowSelect.Equals(value))
                {
                    this.fullRowSelect = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines whether to hide selected rows when the control loses focus.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether to hide selected rows when the control loses focus."),
        DefaultValue(false)
        ]
        public bool HideSelection
        {
            get { return this.hideSelection; }
            set
            {
                if (!this.hideSelection.Equals(value))
                {
                    this.hideSelection = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines whether Columns can be resized by the user.
        /// </summary>
        /// <remarks>
        /// This property enables/disables column resizing on all columns. Individual columns can be enabled/disabled
        /// on the ColumnHeader itself.
        /// </remarks>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines whether Columns can be resized by the user."),
        DefaultValue(true)
        ]
        public bool AllowColumnResize
        {
            get { return this.allowColumnResize; }
            set { this.allowColumnResize = value; }
        }

        /// <summary>
        /// Gets or Sets a value that determines if the control will Allow Columns to be Hidden.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines if the control will Allow Columns to be Hidden."),
        DefaultValue(true)
        ]
        public bool AllowHiddenColumns
        {
            get { return this.allowHiddenColumns; }
            set
            {
                if (!this.allowHiddenColumns.Equals(value))
                {
                    this.allowHiddenColumns = value;

                    if (!this.allowHiddenColumns)
                    {
                        this.BeginUpdate();

                        for (int i = this.HiddenColumns.Count - 1; i >= 0; i += -1)
                        {
                            this.HiddenColumns[i].Hidden = false;
                        }
                        this.EndUpdate();
                    }

                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines if the control Highlights a row when the Mouse hovers over it.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines if the control Highlights a row when the Mouse hovers over it."),
        DefaultValue(false)
        ]
        public bool RowTracking
        {
            get { return this.doRowTracking; }
            set
            {
                if (!this.doRowTracking.Equals(value))
                {
                    this.doRowTracking = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that highlights the Column when the Mouse hovers of the header.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Highlights the Column when the Mouse hovers of the header."),
        DefaultValue(false)
        ]
        public bool ColumnTracking
        {
            get { return this.doColTracking; }
            set
            {
                if (!this.doColTracking.Equals(value))
                {
                    this.doColTracking = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines if a Right mouse-click selects a ContainerListViewObject also.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Determines if a Right mouse-click selects a TreeListNode also."),
        DefaultValue(true)
        ]
        public bool RightMouseSelects
        {
            get { return this.rightMouseSelects; }
            set { this.rightMouseSelects = value; }
        }

        /// <summary>
        /// Gets or Sets the ContextMenuStrip displayed when a Header is right-clicked.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("The ContextMenuStrip displayed when a ColumnHeader is right-clicked."),
        DefaultValue(typeof(ContextMenuStrip), null)
        ]
        public ContextMenuStrip ColumnHeaderContextMenuStrip
        {
            get { return this.headerMenu; }
            set
            {
                if (value != this.headerMenu)
                {
                    this.headerMenu = value;
                    this.OnColumnHeaderContextMenuChanged(EventArgs.Empty);
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that specifies whether to enable drawing the selected Column the ColumnSortColor.
        /// </summary>
        /// <remarks>
        /// Setting this property is only effective if the ColumnHeaderStyles property is set to ColumnHeaderStyle.Clickable.
        /// </remarks>
        [
        Browsable(true), Category("Behavior"),
        Description("Specifies whether to enable drawing the selected Column the ColumnSortColor."),
        DefaultValue(false)
        ]
        public bool ColumnSortColorEnabled
        {
            get { return this.colSortEnabled; }
            set
            {
                if (this.headerStyle == ColumnHeaderStyle.Clickable && !this.colSortColor.Equals(value))
                {
                    this.colSortEnabled = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Indicates the manner in which items are to be sorted.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Indicates the manner in which items are to be sorted."),
        DefaultValue(typeof(SortOrder), "None")
        ]
        public SortOrder Sorting
        {
            get { return this.sorting; }
            set { this.sorting = value; }
        }

        /// <summary>
        /// Indicates whether the control will display scroll bars if it contains more items than can fit in the client area.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("Indicates whether the control will display scroll bars if it contains more items than can fit in the client area."),
        DefaultValue(true)
        ]
        public bool Scrollable
        {
            get { return this.scrollable; }
            set
            {
                if (!this.scrollable.Equals(value))
                {
                    this.scrollable = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }
        #endregion

        #region Appearance
        /// <summary>
        /// Gets or Sets a value that determines if CheckBoxes will be displayed next to TreeListNodes in the TreeListView control.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines if CheckBoxes will be displayed next to TreeListNodes in the TreeListView control."),
        DefaultValue(false)
        ]
        public bool CheckBoxes
        {
            get { return this.allowCheckBoxes; }
            set
            {
                if (!this.allowCheckBoxes.Equals(value))
                {
                    this.allowCheckBoxes = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets the type of CheckBox to display.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The type of CheckBox to display."),
        DefaultValue(typeof(CheckBoxType), "CheckBox")
        ]
        public CheckBoxType CheckBoxType
        {
            get { return this.checkBoxType; }
            set
            {
                if (!this.checkBoxType.Equals(value))
                {
                    this.checkBoxType = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets the RowHeight of the Items in the listview.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Sets the RowHeight of the Items in the listview."),
        DefaultValue(17)
        ]
        public int RowHeight
        {
            get { return this.rowHeight; }
            set
            {
                if (!this.rowHeight.Equals(value))
                {
                    this.rowHeight = Math.Abs(value);
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or sets the border style of the control.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The border style of the control."),
        DefaultValue(typeof(BorderStyle), "Fixed3D")
        ]
        public BorderStyle BorderStyle
        {
            get { return this.borderStyle; }
            set
            {
                if (!IsEnumValid((int)value, 0, 2))
                {
                    throw new InvalidEnumArgumentException("value", (int)value, typeof(BorderStyle));
                }

                if (this.borderStyle != value)
                {
                    this.borderStyle = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// The background color used to display text and graphics in the control.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The background color used to display text and graphics in the control."),
        DefaultValue(typeof(Color), "Window")
        ]
        public override Color BackColor
        {
            get { return base.BackColor; }
            set { base.BackColor = value; }
        }

        /// <summary>
        /// Gets or Sets the foreground color used to display text and graphics in the control.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The foreground color used to display text and graphics in the control."),
        DefaultValue(typeof(Color), "WindowText")
        ]
        public override Color ForeColor
        {
            get { return base.ForeColor; }
            set
            {
                if (!base.ForeColor.Equals(value))
                {
                    base.ForeColor = value;
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that specifies the color used for selected rows.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Specifies the color used for selected rows."),
        DefaultValue(typeof(Color), "Highlight")
        ]
        public Color RowSelectColor
        {
            get { return this.rowSelectColor; }
            set { this.rowSelectColor = value; }
        }

        /// <summary>
        /// Gets or Sets a value that specifies the Color used for row hot-tracking.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Specifies the Color used for row hot-tracking."),
        DefaultValue(typeof(Color), "WhiteSmoke")]
        public Color RowTrackingColor
        {
            get { return this.rowTrackColor; }
            set
            {
                this.rowTrackColor = value;
                this.Invalidate();
            }
        }

        /// <summary>
        /// Gets or Sets a value that specifies whether to show Column headers and whether they respond to Mouse clicks.
        /// </summary>
        /// <remarks>
        /// Setting this property to ColumnHeaderStyles.NonClickable or ColumnHeaderStyles.None will set the ColumnSortColorEnabled property to <c>false</c>.
        /// </remarks>
        [
        Browsable(true), Category("Appearance"),
        Description("Specifies whether to show Column headers and whether they respond to Mouse clicks."),
        DefaultValue(typeof(ColumnHeaderStyle), "Clickable")
        ]
        public ColumnHeaderStyle ColumnHeaderStyles
        {
            get { return this.headerStyle; }
            set
            {
                if (!this.headerStyle.Equals(value))
                {
                    this.headerStyle = value;

                    if (this.headerStyle == ColumnHeaderStyle.Nonclickable || this.headerStyle == ColumnHeaderStyle.None)
                    {
                        this.colSortEnabled = false;
                    }

                    this.headerBuffer = GetColumnHeaderHeight();
                    HeaderResized();

                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that specifies the Color used for the currently selected sorting column.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Specifies the Color used for the currently selected sorting column."),
        DefaultValue(typeof(Color), "247, 247, 247")
        ]
        public Color ColumnSortColor
        {
            get { return this.colSortColor; }
            set
            {
                if (!this.colSortColor.Equals(value))
                {
                    this.colSortColor = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or Sets the Color used for column hot-tracking
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The Color used for column hot-tracking"),
        DefaultValue(typeof(Color), "WhiteSmoke")
        ]
        public Color ColumnTrackingColor
        {
            get { return this.colTrackColor; }
            set
            {
                if (!this.colTrackColor.Equals(value))
                {
                    this.colTrackColor = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or sets the background color of the ContainerListViewObject when it is in an edit state.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("The background color of the ContainerListViewObject when it is in an edit state."),
        DefaultValue(typeof(Color), "Info")
        ]
        public Color EditBackColor
        {
            get { return this.editBackColor; }
            set
            {
                if (!this.editBackColor.Equals(value))
                {
                    this.editBackColor = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines the Color of the control when the Enabled property is False.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines the Color of the control when the Enabled property is False."),
        DefaultValue(typeof(Color), "Gainsboro")
        ]
        public Color DisabledColor
        {
            get { return this.disabledColor; }
            set
            {
                if (!this.disabledColor.Equals(value))
                {
                    this.disabledColor = value;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Gets or Sets a value that determines which gridlines will be shown.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Determines which gridlines will be shown."),
        DefaultValue(typeof(GridLineSelections), "Both")
        ]
        public GridLineSelections GridLines
        {
            get { return this.gridLineType; }
            set
            {
                if (!this.gridLineType.Equals(value))
                {
                    this.gridLineType = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets or Sets the Color used for Gridlines.
        /// </summary>
        [
        Browsable(true), Category("Appearance"),
        Description("Specifies the Color used for Gridlines."),
        DefaultValue(typeof(Color), "Control")
        ]
        public Color GridLineColor
        {
            get { return this.gridLineColor; }
            set
            {
                if (!this.gridLineColor.Equals(value))
                {
                    this.gridLineColor = value;
                    this.Invalidate(this.ClientRectangle);
                }
            }
        }

        /// <summary>
        /// Gets the current rectangle representing the area where the visible Rows are located.
        /// </summary>
        [Browsable(false)]
        protected Rectangle RowsRectangle
        {
            get { return this.rowsRect; }
        }

        /// <summary>
        /// Gets the size of the Header buffer for drawing purposes.
        /// </summary>
        [Browsable(false)]
        protected internal int HeaderBuffer
        {
            get { return this.headerBuffer; }
        }
        #endregion

		#region Data
        /// <summary>
        /// Gets or Sets the Text associated with the Control.
        /// </summary>
        [
        Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        EditorBrowsable(EditorBrowsableState.Advanced),
        DefaultValue(typeof(string), "")
        ]
        public override string Text
        {
            get { return base.Text; }
            set { base.Text = value; }
        }

        /// <summary>
        /// Gets a collection containing all items in the control.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal ContainerListViewItemCollection Items
        {
            get { return this.items; }
        }
        ///// <summary>
        ///// Gets a collection containing all items in the control.
        ///// </summary>
        //[
        //Browsable(true), Category("Behavior"),
        //Description("A collection containing all items in the control."),
        //MergableProperty(false), Localizable(true),
        //DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
        //Editor(typeof(System.ComponentModel.Design.CollectionEditor), typeof(UITypeEditor))
        //]
        //public virtual ContainerListViewItemCollection Items
        //{
        //    get { return this.items; }
        //}

        /// <summary>
        /// Gets the currently checked items in the control.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public CheckedContainerListViewObjectCollection CheckedItems
        {
            get { return this.checkedItems; }
        }

        /// <summary>
        /// Gets the indexes of the selected items in the control.
        /// </summary>
        [Browsable(false)]
        internal SelectedIndexCollection SelectedIndexes
        {
            get { return this.selectedIndexes; }
        }
        ///// <summary>
        ///// Gets the indexes of the selected items in the control.
        ///// </summary>
        //[Browsable(false)]
        //public SelectedIndexCollection SelectedIndexes
        //{
        //    get { return this.selectedIndexes; }
        //}

        /// <summary>
        /// Gets the items that are selected in the control.
        /// </summary>
        [Browsable(false)]
        internal SelectedContainerListViewObjectCollection SelectedItems
        {
            get { return this.selectedItems; }
        }
        ///// <summary>
        ///// Gets the items that are selected in the control.
        ///// </summary>
        //[Browsable(false)]
        //public SelectedContainerListViewObjectCollection SelectedItems
        //{
        //    get { return this.selectedItems; }
        //}

        /// <summary>
        /// Gets the collection of all column headers that appear in the control.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("The collection of all column headers that appear in the control."),
        MergableProperty(false), Localizable(true),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
        Editor(typeof(IMP.SharedControls.Design.ContainerColumnHeaderCollectionEditor), typeof(UITypeEditor))
        ]
        public ContainerColumnHeaderCollection Columns
        {
            get { return this.columnHeaderCollection; }
        }

        /// <summary>
        /// Gets the Columns that are Hidden in the control.
        /// </summary>
        [Browsable(false)]
        public HiddenColumnsCollection HiddenColumns
        {
            get { return this.hiddenCols; }
        }

        /// <summary>
        /// Gets or sets the ImageList used for displaying images in the control.
        /// </summary>
        [
        Browsable(true), Category("Behavior"),
        Description("The ImageList used for displaying images in the control."),
        DefaultValue(typeof(ImageList), null)
        ]
        public ImageList ImageList
        {
            get { return this.imageList; }
            set
            {
                this.imageList = value;
                this.Invalidate();
            }
        }
		#endregion

		#region Others
        /// <summary>
        /// Gets a value that determines if the control is currently being updated.
        /// </summary>
        [Browsable(false)]
        public bool InUpdateMode
        {
            get { return this.updateTransactions; }
        }


        /// <summary>
        /// Gets the current ContainerListViewObject that is itself being edited or has one of it's subitems being edited.
        /// </summary>
        [Browsable(false)]
        public ContainerListViewObject EditedObject
        {
            get { return this.editingObj; }
        }

        /// <summary>
        /// Gets the default IComparer to use when sorting ContainerListsViewObjects.
        /// </summary>
        [Browsable(false)]
        public IComparer DefaultComparer
        {
            get { return this.defaultComparer; }
        }

        /// <summary>
        /// Gets or Sets the sorting comparer for the control.
        /// </summary>
        [Browsable(false), DefaultValue(typeof(IComparer), null)]
        public IComparer SortComparer
        {
            get { return this.sortComparer; }
            set { this.sortComparer = value; }
        }

        /// <summary>
        /// Gets the Horizontal scroll bar used by the control.
        /// </summary>
        [Browsable(false)]
        public HScrollBar HScroll
        {
            get { return this.hscrollBar; }
        }

        /// <summary>
        /// Gets the Vertical scroll bar used by the control.
        /// </summary>
        [Browsable(false)]
        public VScrollBar VScroll
        {
            get { return this.vscrollBar; }
        }

        /// <summary>
        /// This property is not meaningful for this control.
        /// </summary>
        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public sealed override ContextMenu ContextMenu
        {
            get { return null; }
            set { }
        }

        /// <summary>
        /// Edit TextBox for SubItems editing
        /// </summary>
        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        internal RichTextBox EditBox
        {
            get { return this.editBox; }
        }

        /// <summary>
        /// Indicates whether the control is drawn using WindowsXP visual styles
        /// </summary>
        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        internal bool VisualStyles
        {
            get { return this.visualStyles; }
        }
        #endregion

        #region protected properties
        /// <summary>
        /// Gets a value that represents whether Column scaling is set.
        /// </summary>
        [Browsable(false)]
        protected bool ColumnScaleMode
        {
            get { return this.colScaleMode; }
        }

        /// <summary>
        /// Gets a value that specifies if the control has focus.
        /// </summary>
        [Browsable(false)]
        protected bool IsFocused
        {
            get { return this.isFocused; }
        }

        /// <summary>
        /// Gets a value that represents the HashTable used to hold the Rectangles of the CheckBoxes.
        /// </summary>
        protected Hashtable CheckBoxRects
        {
            get { return this.checkBoxRects; }
        }

        /// <summary>
        /// Gets a value that represents how, if enabled, a user is selecting multiple items.
        /// </summary>
        protected MultiSelectModes MultiSelectMode
        {
            get { return this.multiSelectMode; }
            set { this.multiSelectMode = value; }
        }

        /// <summary>
        /// Used by derived classes that override the OnMouseDown event.  This will prevent the base ContainerListView class from
        /// processing any row clicks that the derived classes need to handle.
        /// </summary>
        protected bool MouseDownProcessRows
        {
            get { return this.processRows; }
            set { this.processRows = value; }
        }
		#endregion
        #endregion

        #region private member functions
        #region control overrides
        /// <summary>
        /// This member overrides <see cref="Control.OnFontChanged"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnFontChanged(EventArgs e)
        {
            base.OnFontChanged(e);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnGotFocus"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);

            this.isFocused = true;
            this.Invalidate(this.ClientRectangle);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnKeyDown"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnKeyDown(KeyEventArgs e)
        {
            this.OnCheckShiftState(e);

            switch (e.KeyCode)
            {
                case Keys.Home:
                case Keys.End:
                case Keys.PageUp:
                case Keys.PageDown:
                    this.OnPageKeys(e);
                    return;
                case Keys.Up:
                case Keys.Down:
                    this.OnUpDownKeys(e);
                    return;
                case Keys.Return:
                    if (this.activation == ItemActivation.Standard && (!this.multiSelect || this.multiSelect && this.allowMultiSelectActivation))
                    {
                        this.OnItemActivate(EventArgs.Empty);
                    }
                    return;
                case Keys.Space:
                    this.OnSpaceBarKey(e);
                    return;
                case Keys.A:
                    if (e.Control)
                    {
                        this.SelectAll();
                    }
                    return;
            }

            base.OnKeyDown(e);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnKeyUp"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);

            if (!e.Shift)
            {
                this.multiSelectMode = MultiSelectModes.Single;
            }
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnLostFocus"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLostFocus(EventArgs e)
        {
            base.OnLostFocus(e);

            this.isFocused = false;
            this.Invalidate(this.ClientRectangle);
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnMouseDown"/>.
        /// </summary>
        /// <param name="e"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            this.lastClickedPoint = new Point(e.X, e.Y);

            this.EndEdit();

            //Determine if a header was pressed
            if (this.headerStyle != ColumnHeaderStyle.None && this.headerRect.Contains(e.X, e.Y))
            {
                if (this.columnHeaders != null)
                {
                    for (int i = 0; i <= this.columnHeaders.Length - 1; i++)
                    {
                        ContainerColumnHeader Col = this.Columns[i];
                        Col.Pressed = false;

                        if (Col.SizingBounds.Contains(e.X, e.Y) && e.Button == MouseButtons.Left)
                        {
                            if (this.allowColumnResize && Col.AllowResize)
                            {
                                TreeListView TreeListView = this as TreeListView;

                                if (e.Clicks == 2 && e.Button == MouseButtons.Left &&
                                    (this.items.Count > 0 || (TreeListView != null && TreeListView.Nodes.Count > 0)))
                                {
                                    //Autosize column
                                    //Process the items
                                    int AutoSizeWidth = this.GetAutoSizeColWidth(i);

                                    //Now we need to measure the column text and compare that
                                    int TextWidth = MeasureDisplayString(Col.Text, Col.Font).Width + 8;

                                    if (TextWidth > AutoSizeWidth)
                                    {
                                        AutoSizeWidth = TextWidth;
                                    }

                                    Col.Width = AutoSizeWidth;
                                }
                                else
                                {
                                    this.colScaleMode = true;
                                    this.colScaleWidth = Col.Bounds.Width;
                                    this.scaledCol = i;

                                    Cursor.Current = Cursors.VSplit;
                                }
                            }

                            break;
                        }
                        else if (Col.Bounds.Contains(e.X, e.Y) && !Col.SizingBounds.Contains(e.X, e.Y))
                        {
                            if (e.Button == MouseButtons.Left)
                            {
                                if (this.DesignMode)
                                {
                                    this.ProcessDesignModeColumnClick(e);
                                }

                                Col.Pressed = true;
                                this.lastColPressed = Col;
                            }

                            this.OnColumnHeaderClicked(new ContainerColumnHeaderEventArgs(Col, e));
                            break;
                        }
                    }
                }

                this.Invalidate();
                return;
            }

            if (this.processRows)
            {
                if (e.Button == MouseButtons.Left || (this.rightMouseSelects && e.Button == MouseButtons.Right))
                {
                    if (this.items.Count > 0 && this.rowsRect.Contains(e.X, e.Y))
                    {
                        object TestObj = null;

                        if (CheckBoxClicked(this.checkBoxRects, e, ref TestObj))
                        {
                            if (e.Button == MouseButtons.Left && ((e.Clicks == 2 && (this.checkBoxSelection == ItemActivation.Standard || this.checkBoxSelection == ItemActivation.TwoClick)) ||
                                                                  (e.Clicks == 1 && this.checkBoxSelection == ItemActivation.OneClick)))
                            {
                                ContainerListViewItem ClItem = (ContainerListViewItem)TestObj;

                                if (ClItem.CheckBoxEnabled)
                                {
                                    ClItem.Checked = !ClItem.Checked;
                                }
                            }
                        }
                        else if (this.GetSelectedRowIndex(e.Y) >= 0)
                        {
                            int SelIndex = this.GetSelectedRowIndex(e.Y);

                            switch (this.multiSelectMode)
                            {
                                case MultiSelectModes.Single:
                                    this.MoveToIndex(SelIndex);

                                    if (e.Clicks == 2)
                                    {
                                        var Item = this.GetItemAt(new Point(e.X, e.Y));
                                        if (Item != null)
                                        {
                                            var SubItem = Item.GetSubItemAt(new Point(e.X, e.Y));

                                            ContainerListViewItemEventArgs Arg = new ContainerListViewItemEventArgs(Item, SubItem);
                                            this.OnItemDoubleClick(Arg);

                                            if (Arg.Action == ContainerListViewItemAction.BeginEdit)
                                            {
                                                if (SubItem == null)
                                                {
                                                    Item.BeginEdit();
                                                }
                                                else
                                                {
                                                    Item.BeginEdit(SubItem);
                                                }
                                            }
                                        }
                                    }

                                    break;
                                case MultiSelectModes.Range:
                                    this.MoveToIndex(SelIndex);
                                    break;
                                case MultiSelectModes.Selective:
                                    this.SelectiveSelection(SelIndex);
                                    break;
                            }

                            //Activate the item(s) if permitted
                            if ((!this.multiSelect || (this.multiSelect && this.allowMultiSelectActivation)) &&
                                ((e.Clicks == 1 && this.activation == ItemActivation.OneClick) ||
                                 (e.Clicks == 2 && this.activation == ItemActivation.TwoClick)))
                            {
                                this.OnItemActivate(EventArgs.Empty);
                            }
                        }
                        else
                        {
                            this.SelectedItems.Clear();
                            this.Invalidate();
                        }
                    }
                    else
                    {
                        this.SelectedItems.Clear();
                        this.Invalidate();
                    }
                }
            }
            else
            {
                //If a column was pressed, then we never would have gotten to this point.
                //so now set it back to true so derived classes can process any row clicks
                this.processRows = true;
            }
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnMouseLeave"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);

            if (this.lastColHovered != null)
            {
                this.lastColHovered.Hovered = false;
                this.lastColHovered = null;

                this.Invalidate();
            }

            if (this.lastRowHovered != null)
            {
                this.lastRowHovered.Hovered = false;
                this.lastRowHovered = null;
            }
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnMouseMove"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (this.lastRowHovered != null)
            {
                this.lastRowHovered.Hovered = false;
                this.lastRowHovered = null;
            }

            //If the mousebutton is pressed down on a header column, moving will attempt to move the position of that column
            //allowColumnReorder not supported
            //if (this.lastColPressed != null && this.allowColumnReorder)
            //{
            //    if (Math.Abs((int)(e.X - this.lastClickedPoint.X)) <= 3)
            //    {
                    //ControlPaint.DrawReversibleFrame(new Rectangle(e.X, e.Y, Me._LastColPressed.Width, Me.RowHeight), Me.BackColor, FrameStyle.Thick)
                    //TODO: Not Supported.  NEED CODE HERE - SET THE RECTANGLE FOR DRAG POS
            //    }
            //}
            //else
            if (this.columnHeaders != null && this.colScaleMode && this.allowColumnResize && this.columnHeaders[this.scaledCol].AllowResize)
            {
                ContainerColumnHeader column = this.columnHeaders[this.scaledCol];

                this.lastColHovered = null;
                Cursor.Current = Cursors.VSplit;
                this.colScalePos = e.X - this.lastClickedPoint.X;

                if (this.colScalePos + this.colScaleWidth <= 0)
                {
                    if (column.Index == 0)
                    {
                        column.Width = 2;
                    }
                    else
                    {
                        column.Width = 1;
                    }
                }
                else
                {
                    column.Width = this.colScalePos + this.colScaleWidth;
                }
            }
            else
            {
                if (this.columnHeaders != null && this.columnHeaders.Length > 0 && this.headerStyle != ColumnHeaderStyle.None)
                {
                    Cursor.Current = Cursors.Default;
                    if (this.headerRect.Contains(e.X, e.Y))
                    {
                        for (int i = 0; i <= this.columnHeaders.Length - 1; i++)
                        {
                            ContainerColumnHeader Col = this.columnHeaders[i];

                            if (Col.Bounds.Contains(e.X, e.Y))
                            {
                                Col.Hovered = true;
                                this.lastColHovered = Col;
                            }
                            else
                            {
                                Col.Hovered = false;
                            }

                            if (this.allowColumnResize && Col.AllowResize && Col.SizingBounds.Contains(e.X, e.Y))
                            {
                                Cursor.Current = Cursors.VSplit;
                            }
                        }

                        this.Invalidate();
                        return;
                    }
                }

                if (this.lastColHovered != null)
                {
                    this.lastColHovered.Hovered = false;
                    this.lastColHovered = null;
                    this.Invalidate();
                }

                if (this.rowsRect.Contains(e.X, e.Y))
                {
                    int SelIndex = this.GetSelectedRowIndex(e.Y);

                    if (SelIndex != -1)
                    {
                        if (this.lastRowHovered != null)
                        {
                            this.lastRowHovered.Hovered = false;
                        }

                        this.lastRowHovered = this.items[SelIndex];
                        this.lastRowHovered.Hovered = true;
                    }

                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnMouseUp"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);

            this.lastClickedPoint = Point.Empty;

            if (this.colScaleMode)
            {
                this.columnHeaders[this.scaledCol].Hovered = false;

                this.colScaleMode = false;
                this.colScalePos = 0;
                this.scaledCol = -1;
                this.colScaleWidth = 0;

                this.OnAdjustScrollBars();
                this.Invalidate();
            }

            if (this.lastColPressed != null)
            {
                this.lastColPressed.Pressed = false;

                //If the LastColPressed is something and LastColHovered is null, then we have a problem.
                //Set the LastColHovered to the LastColPressed in this situation
                if (this.lastColHovered == null)
                {
                    this.lastColHovered = this.lastColPressed;
                }

                if (this.lastColHovered.Bounds.Contains(e.X, e.Y) && !this.lastColPressed.SizingBounds.Contains(e.X, e.Y) && e.Button == MouseButtons.Left)
                {
                    //Order is important here. Set the lastpainted column first
                    if (this.selectedCol != null)
                    {
                        if (this.lastPaintedSortCol == this.selectedCol.Index)
                        {
                            this.lastPaintedSortCol = -1;
                        }
                        else
                        {
                            this.lastPaintedSortCol = this.selectedCol.Index;
                        }
                    }

                    //Change the currently selected column.  
                    this.selectedCol = this.lastColPressed;
                }
            }

            this.lastColPressed = null;

            //Check for a context click and raise the appropriate contextmenu
            if (e.Button == MouseButtons.Right)
            {
                if (this.headerRect.Contains(e.X, e.Y))
                {
                    if (this.headerMenu != null)
                    {
                        this.OnColumnHeaderContextMenuRequested(e);
                        this.headerMenu.Show(this, new Point(e.X, e.Y));
                    }
                }
                else if (this.ContextMenuStrip != null)
                {
                    this.OnContextMenuRequested(e);
                    this.ContextMenuStrip.Show(this, new Point(e.X, e.Y));
                }
            }
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnMouseWheel"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            if (!this.scrollable)
            {
                return;
            }

            int HsDelta = this.hscrollBar.Value - this.hscrollBar.SmallChange * Convert.ToInt32(e.Delta / 100);
            int VsDelta = this.vscrollBar.Value - this.vscrollBar.SmallChange * Convert.ToInt32(e.Delta / 100);

            if (e.Delta > 0)
            {
                if (this.vscrollBar.Visible)
                {
                    if (VsDelta < 0)
                    {
                        this.vscrollBar.Value = 0;
                    }
                    else
                    {
                        this.vscrollBar.Value = VsDelta;
                    }
                }
                else if (this.hscrollBar.Visible)
                {
                    if (HsDelta < 0)
                    {
                        this.hscrollBar.Value = 0;
                    }
                    else
                    {
                        this.hscrollBar.Value = HsDelta;
                    }
                }
            }
            else if (e.Delta < 0)
            {
                int HsVal = this.hscrollBar.Maximum - this.hscrollBar.LargeChange;
                int VsVal = this.vscrollBar.Maximum - this.vscrollBar.LargeChange;

                if (this.vscrollBar.Visible)
                {
                    if (VsDelta > VsVal)
                    {
                        this.vscrollBar.Value = VsVal < 0 ? 0 : VsVal;
                    }
                    else
                    {
                        this.vscrollBar.Value = VsDelta;
                    }
                }
                else if (this.hscrollBar.Visible)
                {
                    if (HsDelta > HsVal)
                    {
                        this.hscrollBar.Value = HsVal < 0 ? 0 : HsVal;
                    }
                    else
                    {
                        this.hscrollBar.Value = HsDelta;
                    }
                }
            }
        }

        /// <summary>
        /// Occurs when the PageUp, PageDown, Home, or End Keys are pressed.
        /// </summary>
        /// <param name="e">A KeyEventArgs.</param>
        protected virtual void OnPageKeys(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Home:
                    if (this.vscrollBar.Visible)
                    {
                        this.vscrollBar.Value = 0;
                    }
                    if (this.hscrollBar.Visible)
                    {
                        this.hscrollBar.Value = 0;
                    }

                    this.MoveToIndex(0);
                    break;
                case Keys.End:
                    if (this.vscrollBar.Visible)
                    {
                        this.vscrollBar.Value = this.vscrollBar.Maximum - this.vscrollBar.LargeChange;
                    }

                    this.MoveToIndex(this.items.Count - 1);
                    break;
                case Keys.PageUp:
                    if (this.vscrollBar.Visible)
                    {
                        if (this.vscrollBar.LargeChange > this.vscrollBar.Value)
                        {
                            this.vscrollBar.Value = 0;
                        }
                        else
                        {
                            this.vscrollBar.Value = this.vscrollBar.LargeChange;
                        }

                        this.MoveToIndex(Convert.ToInt32(Math.Round((double)(this.VScroll.Value / this.RowHeight))));
                    }
                    else
                    {
                        this.MoveToIndex(0);
                    }
                    break;
                case Keys.PageDown:
                    if (this.vscrollBar.Visible)
                    {
                        int Diff = 0;

                        if (this.hscrollBar.Visible)
                        {
                            Diff = 2;
                        }
                        else
                        {
                            Diff = 3;
                        }

                        if ((this.vscrollBar.Value + this.vscrollBar.LargeChange) > (this.vscrollBar.Maximum - this.vscrollBar.LargeChange))
                        {
                            this.vscrollBar.Value = this.vscrollBar.Maximum - this.vscrollBar.LargeChange;
                        }
                        else
                        {
                            this.vscrollBar.Value += this.vscrollBar.LargeChange;
                        }

                        this.MoveToIndex(Convert.ToInt32(Math.Round((double)(this.VScroll.Value / this.RowHeight))) + Convert.ToInt32(Math.Round((double)(this.VScroll.LargeChange / this.RowHeight))) - Diff);
                    }
                    else
                    {
                        this.MoveToIndex(this.items.Count - 1);
                    }
                    break;
            }

            e.Handled = true;
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnResize"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            this.GenerateHeaderRect();
            this.GenerateViewableRowsRectangle();
        }

        /// <summary>
        /// This member overrides <see cref="Control.WndProc"/>.
        /// </summary>
        /// <param name="m"></param>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.UnmanagedCode)]
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);

            //This line makes arrow and tab key events cause onkeyxxx events to fire
            if (m.Msg == WM_GETDLGCODE)
            {
                m.Result = new IntPtr(DLGC_WANTCHARS | DLGC_WANTARROWS | m.Result.ToInt32());
            }
        }

        /// <summary>
        /// Paints the control.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            bool IsVisualStyles = ScrollBarRenderer.IsSupported && Application.RenderWithVisualStyles;

            if (this.visualStyles != IsVisualStyles)
            {
                this.visualStyles = IsVisualStyles;
                this.headerBuffer = GetColumnHeaderHeight();
                HeaderResized();
            }

            Graphics g = e.Graphics;
            Rectangle bounds = this.ClientRectangle;

            this.OnDrawBackGround(g, bounds);
            this.OnDrawRows(g, bounds);
            this.DrawColumnHeaders(g, bounds);
            this.DrawBorder(g, bounds);
            this.DrawExtra(g, bounds);

            this.OnAdjustScrollBars();
        }
        #endregion

        #region custom paint functions
        /// <summary>
        /// Draws the BackGround of the control.
        /// </summary>
        /// <param name="g">A graphics object to draw with.</param>
        /// <param name="bounds">A rectangle to draw in.</param>
        protected virtual void OnDrawBackGround(Graphics g, Rectangle bounds)
        {
            if (this.Enabled)
            {
                g.FillRectangle(new SolidBrush(this.BackColor), bounds);

                if (this.BackgroundImage != null)
                {
                    int HdrOffset = 0;
                    if (this.headerStyle != ColumnHeaderStyle.None)
                    {
                        HdrOffset = this.headerBuffer;
                    }

                    g.DrawImage(this.BackgroundImage, bounds.X, bounds.Y + HdrOffset, bounds.Width, bounds.Height - HdrOffset);
                }

                if (this.headerStyle == ColumnHeaderStyle.Clickable && this.selectedCol != null && !this.selectedCol.Hidden && this.colSortEnabled && this.lastPaintedSortCol != this.selectedCol.Index)
                {
                    Rectangle SelColRect = this.selectedCol.Bounds;
                    g.FillRectangle(new SolidBrush(this.ColumnSortColor), SelColRect.X, SelColRect.Y + this.headerBuffer, SelColRect.Width, (bounds.Height - this.headerBuffer) + 2);
                }

                if (this.lastColHovered != null && !this.lastColHovered.Hidden && this.doColTracking)
                {
                    Rectangle TrackRect = this.lastColHovered.Bounds;
                    g.FillRectangle(new SolidBrush(this.colTrackColor), TrackRect.X, TrackRect.Y + this.headerBuffer, TrackRect.Width, (bounds.Height - this.headerBuffer) + 2);
                }
            }
            else
            {
                g.FillRectangle(new SolidBrush(this.disabledColor), bounds);
            }
        }

        /// <summary>
        /// Draws the CheckBoxes (if visible) of any ContainerListViewObject.
        /// </summary>
        /// <param name="g">The graphics object used to paint the CheckBox.</param>
        /// <param name="bounds">The rectangle representing the area to paint the CheckBox in.</param>
        /// <param name="Obj">The ContainerListViewObject whose CheckBox is to be drawn.</param>
        protected void DrawObjectCheckBox(Graphics g, Rectangle bounds, ContainerListViewObject Obj)
        {
            Point MousePos = this.PointToClient(Control.MousePosition);

            CheckBoxState State;
            RadioButtonState RadioState;
            if (Obj.Checked)
            {
                if (!Obj.CheckBoxEnabled)
                {
                    State = CheckBoxState.CheckedDisabled;
                    RadioState = RadioButtonState.CheckedDisabled;
                }
                else if (bounds.Contains(MousePos.X, MousePos.Y))
                {
                    State = CheckBoxState.CheckedHot;
                    RadioState = RadioButtonState.CheckedHot;
                }
                else
                {
                    State = CheckBoxState.CheckedNormal;
                    RadioState = RadioButtonState.CheckedNormal;
                }
            }
            else
            {
                if (!Obj.CheckBoxEnabled)
                {
                    State = CheckBoxState.UncheckedDisabled;
                    RadioState = RadioButtonState.UncheckedDisabled;
                }
                else if (bounds.Contains(MousePos.X, MousePos.Y))
                {
                    State = CheckBoxState.UncheckedHot;
                    RadioState = RadioButtonState.UncheckedHot;

                }
                else
                {
                    State = CheckBoxState.UncheckedNormal;
                    RadioState = RadioButtonState.UncheckedNormal;
                }
            }

            if (this.checkBoxType == CheckBoxType.CheckBox)
            {
                CheckBoxRenderer.DrawCheckBox(g, new Point(bounds.Location.X + 1, bounds.Location.Y + 1), State);
            }
            else
            {
                RadioButtonRenderer.DrawRadioButton(g, new Point(bounds.Location.X + 1, bounds.Location.Y + 1), RadioState);
            }
        }

        /// <summary>
        /// Draws the Column GridLines of the control.
        /// </summary>
        /// <param name="g">A graphics object to draw with.</param>
        protected virtual void OnDrawColumnGridLines(Graphics g)
        {
            if (this.gridLineType == GridLineSelections.Both || this.gridLineType == GridLineSelections.Column)
            {
                Rectangle Rect = this.ClientRectangle;
                g.Clip = new Region(Rect);

                foreach (ContainerColumnHeader item in this.columnHeaders)
                {
                    Rectangle ColRect = item.Bounds;
                    Pen gridLinePen = new Pen(this.GridLineColor, 1.0f);
                    g.DrawLine(gridLinePen, ColRect.Right - 1, this.headerBuffer, ColRect.Right - 1, Rect.Height - 2);
                }
            }
        }

        /// <summary>
        /// Draws the Rows of the control.
        /// </summary>
        /// <param name="g">A graphics object to draw with.</param>
        /// <param name="bounds">A rectangle to draw in.</param>
        protected virtual void OnDrawRows(Graphics g, Rectangle bounds)
        {
            if (!this.updateTransactions && this.items.Count > 0 && this.Columns.Count > 0)
            {
                int borderWidth = GetBorderWidth();
                bounds.Inflate(2 - borderWidth, 2 - borderWidth);

                int TotalRend = 0;
                int Value = this.VScroll.Value;
                if (Value > this.VScroll.Maximum - this.VScroll.LargeChange)
                {
                    Value = this.VScroll.Maximum - this.VScroll.LargeChange;
                }

                int Prior = (int)Math.Round((double)(((double)Value) / ((double)this.RowHeight)));

                //Determine the total number of items that can be rendered in the client rectangle
                int MaxRend;
                if (this.hscrollBar.Visible)
                {
                    MaxRend = (int)Math.Round(Math.Ceiling((double)(((double)((bounds.Height - (this.headerBuffer + 2)) - this.hscrollBar.Height)) / ((double)this.RowHeight))));
                }
                else
                {
                    MaxRend = (int)Math.Round(Math.Ceiling((double)(((double)(bounds.Height - (this.headerBuffer + 2))) / ((double)this.RowHeight))));
                }

                //First item to draw
                ContainerListViewItem ClviDraw;
                if (Prior <= 0)
                {
                    ClviDraw = this.items[0];
                }
                else
                {
                    ClviDraw = this.items[Prior];
                }

                this.checkBoxRects.Clear();

                //Start drawing the rows
                while (ClviDraw != null && MaxRend > TotalRend)
                {
                    this.RenderItemRows(ClviDraw, g, bounds, TotalRend);

                    TotalRend++;

                    if ((ClviDraw.Index + 1) == this.items.Count)
                    {
                        ClviDraw = null;
                    }
                    else
                    {
                        ClviDraw = this.items[ClviDraw.Index + 1];
                    }
                }

                //Refresh the object in an edit state
                if (this.editingObj != null)
                {
                    this.editingObj.RefreshEditing();
                }

                //Render the column gridlines and adjust the scrollbars
                this.OnDrawColumnGridLines(g);
                this.OnAdjustScrollBars();
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private void RenderItemRows(ContainerListViewItem Item, Graphics g, Rectangle bounds, int TotalRend)
        {
            int TempVar = bounds.Top + (this.RowHeight * TotalRend);

            //Only render row if visible to user
            if (TempVar + this.RowHeight >= bounds.Top + 2 && TempVar < bounds.Top + bounds.Height)
            {
                int ChkBoxX = bounds.Left + 2 - this.hscrollBar.Value; //Left viewport position less scrollbar pos

                SolidBrush Brush = new SolidBrush(Item.ForeColor);
                Rectangle CompleteItemBounds = this.GetCompleteItemBounds(Item);
                Rectangle ItemBounds = this.GetItemBounds(Item);

                SolidBrush SBrush = new SolidBrush(this.DetermineBackGroundColorInternal(Item, null));

                int CheckBuffer;
                if (this.allowCheckBoxes && Item.CheckBoxVisible)
                {
                    CheckBuffer = 18;
                }
                else
                {
                    CheckBuffer = 0;
                }

                int IconBuffer = 0;
                if (this.imageList != null)
                {
                    if (Item.ImageIndex >= 0 && Item.ImageIndex < this.imageList.Images.Count)
                    {
                        IconBuffer = 18;
                    }
                    else
                    {
                        IconBuffer = 0;
                    }
                }

                g.Clip = new Region(CompleteItemBounds);
                string TempStr = TruncateString(Item.Text, Item.Font, ItemBounds.Width - 16, g);
                int StrWidth = MeasureDisplayString(g, TempStr, Item.Font).Width;

                Rectangle SelRowRect;
                if (!this.fullRowSelect)
                {
                    SelRowRect = ItemBounds;
                }
                else if ((CompleteItemBounds.Width < (bounds.Width - 4)) || this.hscrollBar.Visible)
                {
                    SelRowRect = CompleteItemBounds;
                }
                else
                {
                    SelRowRect = new Rectangle(CompleteItemBounds.X, CompleteItemBounds.Y, bounds.Width - 4, CompleteItemBounds.Height);
                }

                //Render item background
                g.FillRectangle(SBrush, ItemBounds);

                //Render selected item
                if (this.fullRowSelect && (Item.Selected || Item.Hovered))
                {
                    g.FillRectangle(SBrush, SelRowRect);
                }

                //Set the clip
                g.Clip = new Region(new Rectangle(CompleteItemBounds.X, CompleteItemBounds.Y, ItemBounds.Width - 1, CompleteItemBounds.Height));

                //Draw the CheckBox if necessary
                if (CheckBuffer != 0)
                {
                    Rectangle CkBxRect = Rectangle.Empty;
                    switch (Item.TextAlign)
                    {
                        case HorizontalAlignment.Left:
                            CkBxRect = new Rectangle(ChkBoxX + 1, CompleteItemBounds.Y, 16, CompleteItemBounds.Height - 1);
                            break;
                        case HorizontalAlignment.Right:
                            CkBxRect = new Rectangle(ChkBoxX + ItemBounds.Width - 1 - StrWidth - CheckBuffer - IconBuffer - 3, CompleteItemBounds.Y, 16, CompleteItemBounds.Height - 1);
                            break;
                        case HorizontalAlignment.Center:
                            CkBxRect = new Rectangle(ChkBoxX + ((ItemBounds.Width - 1 + CheckBuffer + IconBuffer) / 2) - (StrWidth / 2) - IconBuffer - CheckBuffer, CompleteItemBounds.Y, 16, CompleteItemBounds.Height - 1);
                            break;
                    }

                    this.DrawObjectCheckBox(g, CkBxRect, Item);
                    this.checkBoxRects.Add(CkBxRect, Item);
                }

                //Draw the icon if available
                if (IconBuffer != 0)
                {
                    switch (Item.TextAlign)
                    {
                        case HorizontalAlignment.Left:
                            int TmpInt;
                            if (!Item.CheckBoxVisible)
                            {
                                TmpInt = 2;
                            }
                            else
                            {
                                TmpInt = 1;
                            }

                            g.DrawImage(this.imageList.Images[Item.ImageIndex], ChkBoxX + TmpInt + CheckBuffer, CompleteItemBounds.Y, 16, CompleteItemBounds.Height - 1);
                            break;
                        case HorizontalAlignment.Right:
                            g.DrawImage(this.imageList.Images[Item.ImageIndex], ChkBoxX + ItemBounds.Width - 1 - StrWidth - IconBuffer - 3, CompleteItemBounds.Y, 16, CompleteItemBounds.Height - 1);
                            break;
                        case HorizontalAlignment.Center:
                            g.DrawImage(this.imageList.Images[Item.ImageIndex], ChkBoxX + ((ItemBounds.Width - 1 + CheckBuffer + IconBuffer) / 2) - (StrWidth / 2) - IconBuffer, CompleteItemBounds.Y, 16, CompleteItemBounds.Height - 1);
                            break;
                    }
                }

                //Render the text
                switch (Item.TextAlign)
                {
                    case HorizontalAlignment.Left:
                        g.DrawString(TempStr, Item.Font, Brush, (float)(ChkBoxX + CheckBuffer + IconBuffer), (float)CompleteItemBounds.Y);
                        break;
                    case HorizontalAlignment.Right:
                        g.DrawString(TempStr, Item.Font, Brush, (float)(ChkBoxX + ItemBounds.Width - 1 - StrWidth - 3), (float)CompleteItemBounds.Y);
                        break;
                    case HorizontalAlignment.Center:
                        g.DrawString(TempStr, Item.Font, Brush, (float)(ChkBoxX + ((ItemBounds.Width - 1 + CheckBuffer + IconBuffer) / 2) - (StrWidth / 2)), (float)CompleteItemBounds.Y);
                        break;
                }

                //Render SubItems
                if (this.columnHeaders != null && this.columnHeaders.Length > 0)
                {
                    for (int k = 0; k < Item.SubItems.Count && k < this.columnHeaders.Length - 1; k++)
                    {
                        ContainerListViewObject.ContainerListViewSubItem SubItem = Item.SubItems[k];
                        Rectangle SubItemRect = SubItem.Bounds;
                        SolidBrush SubItemBrush = new SolidBrush(this.DetermineBackGroundColorInternal(Item, SubItem));

                        int Offset = 0;
                        if (this.gridLineType == GridLineSelections.Both || this.gridLineType == GridLineSelections.Row)
                        {
                            Offset = 1;
                        }

                        //Set the clip
                        g.Clip = new Region(SubItemRect);
                        //Draw the background
                        g.FillRectangle(SubItemBrush, SubItemRect.X, SubItemRect.Y, SubItemRect.Width, SubItemRect.Height - Offset);

                        //Only render SubItem if visible
                        g.Clip = new Region(SubItemRect);
                        if (SubItem.Control != null)
                        {
                            SubItem.Control.Location = new Point((ChkBoxX + SubItemRect.X) + 2, SubItemRect.Y + 2);
                            SubItem.Control.ClientSize = new Size(SubItemRect.Width - 5, SubItemRect.Height - 3);
                            SubItem.Control.Parent = this;
                            SubItem.Control.Visible = true;
                            SubItem.Control.BringToFront();
                            SubItem.Control.Refresh();
                        }
                        else
                        {
                            SubItemBrush = new SolidBrush(SubItem.ForeColor);
                            HorizontalAlignment SubItemAlign = SubItem.TextAlign;
                            Font SubItemFont = SubItem.Font;

                            TempStr = TruncateString(SubItem.Text, SubItemFont, SubItemRect.Width - 12, g);
                            int DispWidth = MeasureDisplayString(g, TempStr, SubItemFont).Width;

                            switch (SubItemAlign)
                            {
                                case HorizontalAlignment.Left:
                                    {
                                        int TmpInt = 0;
                                        if (SubItemRect.X <= 0)
                                        {
                                            TmpInt = 2;
                                        }

                                        g.DrawString(TempStr, SubItemFont, SubItemBrush, (float)(SubItemRect.X + 1 + TmpInt), (float)SubItemRect.Y);
                                        break;
                                    }
                                case HorizontalAlignment.Right:
                                    int OS = 0;
                                    if (SubItemFont.Bold)
                                    {
                                        OS = 4;
                                    }
                                    else
                                    {
                                        OS = 2;
                                    }

                                    g.DrawString(TempStr, SubItemFont, SubItemBrush, (float)(SubItemRect.X + SubItemRect.Width - DispWidth - OS - 6), (float)SubItemRect.Y);
                                    break;
                                case HorizontalAlignment.Center:
                                    g.DrawString(TempStr, SubItemFont, SubItemBrush, (float)(SubItemRect.X + (((double)SubItemRect.Width) / 2.0) - (((double)DispWidth) / 2.0)), (float)SubItemRect.Y);
                                    break;
                            }
                        }
                    }
                }

                //Set the new clip
                g.Clip = new Region(CompleteItemBounds);

                //Render the row gridlines
                if (this.gridLineType == GridLineSelections.Both || this.gridLineType == GridLineSelections.Row)
                {
                    Pen gridLinePen = new Pen(this.GridLineColor, 1.0f);
                    g.DrawLine(gridLinePen, (int)(CompleteItemBounds.Left + 2), (int)(CompleteItemBounds.Bottom - 1), (int)(CompleteItemBounds.Right + 1), (int)(CompleteItemBounds.Bottom - 1));
                }

                //Draw the focus rectangle
                if (this.selectedItems.Count > 1 && this.isFocused && Item.Focused)
                {
                    Rectangle NewRect = new Rectangle(SelRowRect.Left + 2, SelRowRect.Y, SelRowRect.Width - 3, SelRowRect.Height);
                    ControlPaint.DrawFocusRectangle(g, NewRect, Item.ForeColor, Item.BackColor);
                }
            }
        }

        private void DrawBorder(Graphics g, Rectangle bounds)
        {
            Rectangle Rect = new Rectangle(0, 0, bounds.Width - 1, bounds.Height - 1);

            Region OldReg = g.Clip;
            g.Clip = new Region(bounds);

            if (this.borderStyle == BorderStyle.Fixed3D)
            {
                if (this.visualStyles)
                {
                    g.DrawRectangle(new Pen(GetVisualStylesBorderColor()), Rect);
                    Rect.Inflate(-1, -1);
                    g.DrawRectangle(SystemPens.Window, Rect);
                }
                else
                {
                    ControlPaint.DrawBorder3D(g, bounds, Border3DStyle.Sunken);
                }
            }
            else if (this.borderStyle == BorderStyle.FixedSingle)
            {
                g.DrawRectangle(new Pen(SystemColors.WindowFrame), Rect);
            }

            g.Clip = OldReg;
        }

        private void DrawExtra(Graphics g, Rectangle bounds)
        {
            if (this.hscrollBar.Visible && this.vscrollBar.Visible)
            {
                int borderWidth = borderStyle == BorderStyle.Fixed3D ? 2 : borderStyle == BorderStyle.FixedSingle ? 1 : 0;

                g.ResetClip();
                g.FillRectangle(SystemBrushes.Control, bounds.Width - this.vscrollBar.Width - borderWidth, bounds.Height - this.hscrollBar.Height - borderWidth, this.vscrollBar.Width, this.hscrollBar.Height);
            }
        }

        private void DrawColumnHeaders(Graphics g, Rectangle bounds)
        {
            int borderWidth = GetBorderWidth();
            bounds.Inflate(-borderWidth, -borderWidth);

            if (this.visualStyles)
            {
                this.DrawHeadersXPStyled(g, bounds);
                return;
            }

            if (this.headerStyle != ColumnHeaderStyle.None)
            {
                g.FillRectangle(new SolidBrush(SystemColors.Control), bounds.Left, bounds.Top, bounds.Width, this.headerBuffer);

                ContainerColumnHeader LastCol = null;

                if (this.columnHeaders != null)
                {
                    foreach (ContainerColumnHeader column in this.columnHeaders)
                    {
                        if (!column.Hidden)
                        {
                            Rectangle ColRect = column.Bounds;
                            LastCol = column;
                            g.Clip = new Region(ColRect);

                            if (ColRect.Left < bounds.Left + bounds.Width - 2)
                            {
                                int ImageSpacing = 0;
                                Brush TextBrush = new SolidBrush(column.ForeColor);

                                if (this.headerStyle == ColumnHeaderStyle.Clickable && column.Pressed)
                                {
                                    ControlPaint.DrawButton(g, ColRect, ButtonState.Flat);
                                }
                                else
                                {
                                    ControlPaint.DrawButton(g, ColRect, ButtonState.Normal);
                                }

                                if (column.ImageList != null && column.ImageIndex >= 0 && column.ImageIndex < column.ImageList.Images.Count)
                                {
                                    ImageSpacing = 18;
                                }

                                string TruncText = TruncateString(column.Text, column.Font, column.Width - (4 + ImageSpacing), g);
                                Size StrSize = MeasureDisplayString(g, TruncText, column.Font);

                                switch (column.TextAlign)
                                {
                                    case HorizontalAlignment.Left:
                                        if (ImageSpacing > 0)
                                        {
                                            g.DrawImage(this.imageList.Images[column.ImageIndex], ColRect.X + 2, ColRect.Top + 1, 16, 16);
                                        }

                                        g.DrawString(TruncText, column.Font, TextBrush, (float)(ColRect.X + 2 + ImageSpacing), bounds.Top + ((ColRect.Height - StrSize.Height) / 2f));
                                        break;
                                    case HorizontalAlignment.Right:
                                        int Var1 = ColRect.Right - 3 - ImageSpacing - StrSize.Width;

                                        if (ImageSpacing > 0)
                                        {
                                            g.DrawImage(this.imageList.Images[column.ImageIndex], Var1, ColRect.Top + 1 - 3, 16, 16);
                                        }

                                        g.DrawString(TruncText, column.Font, TextBrush, (float)(Var1 + ImageSpacing - 3), bounds.Top + ((ColRect.Height - StrSize.Height) / 2f));
                                        break;
                                    case HorizontalAlignment.Center:
                                        int Var2 = ColRect.X + ((ColRect.Width - ImageSpacing - StrSize.Width) / 2);

                                        if (ImageSpacing > 0)
                                        {
                                            g.DrawImage(this.imageList.Images[column.ImageIndex], Var2 + 2, ColRect.Top + 1, 16, 16);
                                        }

                                        g.DrawString(TruncText, column.Font, TextBrush, (float)(Var2 + ImageSpacing), bounds.Top + ((ColRect.Height - StrSize.Height) / 2f));
                                        break;
                                }
                            }
                        }
                    }
                }

                //Render only trailing column header if the end of the last column ends before the boundary of the ListView
                g.Clip = new Region(new Rectangle(bounds.Left, bounds.Top, bounds.Width, bounds.Top + this.headerBuffer));

                if (this.columnHeaders != null && this.columnHeaders.Length > 0 && LastCol != null)
                {
                    Rectangle LastColRect = LastCol.Bounds;

                    if (LastColRect.Right < bounds.Right)
                    {
                        ControlPaint.DrawButton(g, LastColRect.Right, bounds.Top, bounds.Right - LastColRect.Right + 2, this.headerBuffer, ButtonState.Normal);
                    }
                }
                else
                {
                    g.FillRectangle(new SolidBrush(this.BackColor), g.ClipBounds);
                }
            }
        }

        private void DrawHeadersXPStyled(Graphics g, Rectangle bounds)
        {
            if (this.headerStyle != ColumnHeaderStyle.None)
            {
                int Last = 2;
                int Lp = bounds.Left;
                int Tp = bounds.Top;
                int LpScr = Lp - this.HScroll.Value;
                int RectWidth = bounds.Left + bounds.Width;

                if (this.columnHeaders != null)
                {
                    for (int i = 0; i <= this.columnHeaders.Length - 1; i++)
                    {
                        int Var = LpScr + Last;
                        ContainerColumnHeader column = this.columnHeaders[i];

                        if (!column.Hidden)
                        {
                            int State;
                            Rectangle ColRect = column.Bounds;
                            Brush TextBrush = new SolidBrush(column.ForeColor);

                            //Set the current state of the column
                            if (this.headerStyle == ColumnHeaderStyle.Clickable && column.Pressed)
                            {
                                State = 3; //Pressed
                            }
                            else if (this.headerStyle != ColumnHeaderStyle.None && column.Hovered)
                            {
                                State = 2; //Hot
                            }
                            else
                            {
                                State = 1; //Normal
                            }

                            g.Clip = new Region(new Rectangle(Lp, Tp, bounds.Width, this.HeaderBuffer));

                            //Draw the header background
                            VisualStyleElement vse = VisualStyleElement.CreateElement("HEADER", 1, State);
                            VisualStyleRenderer renderer = new VisualStyleRenderer(vse);
                            renderer.DrawBackground(g, new Rectangle(ColRect.Left, ColRect.Top, ColRect.Width, ColRect.Height - 2),
                                                       new Rectangle(Lp, Tp, bounds.Width, this.HeaderBuffer));

                            //Set the new clip
                            int Width;
                            if (bounds.Left + Last + column.Width > RectWidth)
                            {
                                Width = bounds.Width - bounds.Left + Last;
                            }
                            else
                            {
                                Width = column.Width - 2;
                            }

                            g.Clip = new Region(new Rectangle(Var + 2, Tp, Width + this.hscrollBar.Value, bounds.Top + this.headerBuffer));

                            //Determine if we should draw an image
                            int ImageSpacing;
                            if (this.imageList != null && column.ImageIndex >= 0 && column.ImageIndex < this.imageList.Images.Count)
                            {
                                ImageSpacing = 16;
                            }
                            else
                            {
                                ImageSpacing = 0;
                            }

                            string TruncText = TruncateString(column.Text, column.Font, column.Width - (ImageSpacing + 8), g);
                            Size StrSize = MeasureDisplayString(g, TruncText, column.Font);
                            int TextY = ColRect.Top + ((ColRect.Height - StrSize.Height) / 2) - 1;

                            //Draw image and text
                            switch (column.TextAlign)
                            {
                                case HorizontalAlignment.Left:
                                    if (ImageSpacing > 0)
                                    {
                                        g.DrawImage(this.imageList.Images[column.ImageIndex], ColRect.X + 4, ColRect.Top, 14, 14);
                                    }

                                    g.DrawString(TruncText, column.Font, TextBrush, (float)(ColRect.X + ImageSpacing + 4), TextY);
                                    break;
                                case HorizontalAlignment.Right:
                                    int Var1 = ColRect.Right - 3 - ImageSpacing - StrSize.Width;

                                    if (ImageSpacing > 0)
                                    {
                                        g.DrawImage(this.imageList.Images[column.ImageIndex], Var1 - 5, ColRect.Top, 14, 14);
                                    }

                                    g.DrawString(TruncText, column.Font, TextBrush, (float)(Var1 + ImageSpacing - 5), TextY);
                                    break;
                                case HorizontalAlignment.Center:
                                    int Var2 = ColRect.X + ((ColRect.Width - ImageSpacing - StrSize.Width) / 2);

                                    if (ImageSpacing > 0)
                                    {
                                        g.DrawImage(this.imageList.Images[column.ImageIndex], Var2 + 2, ColRect.Top, 14, 14);
                                    }

                                    g.DrawString(TruncText, column.Font, TextBrush, (float)(Var2 + ImageSpacing), TextY);
                                    break;
                            }

                            Last = ColRect.Left + ColRect.Width;
                        }
                    }
                }

                g.Clip = new Region(new Rectangle(Lp, Tp, bounds.Width, this.HeaderBuffer));

                //Render the trailing column header only if the end of the last column ends before the boundary of the control
                if (bounds.Left + Last + 2 - this.hscrollBar.Value < bounds.Left + bounds.Width)
                {
                    VisualStyleElement vse = VisualStyleElement.CreateElement("HEADER", 1, 1);
                    VisualStyleRenderer renderer = new VisualStyleRenderer(vse);
                    renderer.DrawBackground(g, new Rectangle(Last, bounds.Top, bounds.Left + bounds.Width - Last + this.hscrollBar.Value + 2, this.headerBuffer - 2),
                                               new Rectangle(Lp, Tp, bounds.Width, this.HeaderBuffer));
                }
            }
        }
		#endregion

        #region protected methods
        /// <summary>
        /// Determines the background color of the <see cref="ContainerListViewObject"/>.
        /// </summary>
        /// <param name="Obj">The object whose background color to determine.</param>
        /// <param name="SubItem">A SubItem.</param>
        /// <returns>A Color based on the state of Obj.</returns>
        protected virtual Color DetermineBackGroundColor(ContainerListViewObject Obj, ContainerListViewObject.ContainerListViewSubItem SubItem)
        {
            return this.DetermineBackGroundColorInternal(Obj, SubItem);
        }

        /// <summary>
        /// Returns the bounding Rectangle of the ContainerListViewObject only.
        /// </summary>
        /// <param name="Obj">The ContainerListViewObject whose rectangle to return.</param>
        /// <returns>A bounds rectangle.</returns>
        protected internal virtual Rectangle GetItemBounds(ContainerListViewObject Obj)
        {
            if (Obj == null)
            {
                throw new ArgumentNullException("Obj");
            }

            return this.GetBounds(Obj);
        }

        /// <summary>
        /// Returns the bounding Rectangle of the ContainerListViewObject and it's SubItems.
        /// </summary>
        /// <param name="Obj">The ContainerListViewObject whose rectangle to return.</param>
        /// <returns>A bounds rectangle.</returns>
        protected internal virtual Rectangle GetCompleteItemBounds(ContainerListViewObject Obj)
        {
            if (Obj == null)
            {
                throw new ArgumentNullException("Obj");
            }

            return this.GetCompleteBounds(Obj);
        }

        /// <summary>
        /// Occurs when the ScrollBars need to be setup and displayed by the control.
        /// </summary>
        protected internal virtual void OnAdjustScrollBars()
        {
            this.AdjustScrollBars();
        }

        /// <summary>
        /// Determines if a CheckBox has been clicked on an Object.
        /// </summary>
        /// <param name="HashTableToCheck">The HashTable containing the Rectangles(Keys) associated to the Objects(Values).</param>
        /// <param name="MouseArgs">The MouseEventArg where the user clicked.</param>
        /// <param name="Object">The Object to set if a match was found in the HashTable.</param>
        /// <returns><c>true</c> if a match was found; otherwise <c>false</c>.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1007:UseGenericsWhereAppropriate"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1045:DoNotPassTypesByReference", MessageId = "2#")]
        protected static bool CheckBoxClicked(Hashtable HashTableToCheck, MouseEventArgs MouseArgs, ref object Object)
        {
            bool Result = false;
            if (HashTableToCheck != null)
            {
                Object = EvaluateObject(MouseArgs, HashTableToCheck.Keys.GetEnumerator(), HashTableToCheck.Values.GetEnumerator());
                Result = Object != null;
            }

            return Result;
        }

        /// <summary>
        /// Occurs whenever OnKeyDown is called.  Checks if any Shift or Control keys are also pressed.
        /// </summary>
        /// <param name="KeyArgs">A KeyEventArgs.</param>
        protected virtual void OnCheckShiftState(KeyEventArgs KeyArgs)
        {
            if (this.multiSelect)
            {
                if (KeyArgs.KeyCode == Keys.ControlKey)
                {
                    this.multiSelectMode = MultiSelectModes.Selective;
                }
                else if (KeyArgs.KeyCode == Keys.ShiftKey)
                {
                    this.multiSelectMode = MultiSelectModes.Range;
                }
            }
        }

        /// <summary>
        /// Occurs on the MouseDown when the control is checking to see if a ColumnHeader was clicked.
        /// </summary>
        /// <param name="ColIndex">The index of the ColumnHeader that is currently being checked/processed.</param>
        /// <returns>Largest TextWidth (the largest string processed).</returns>
        protected virtual int GetAutoSizeColWidth(int ColIndex)
        {
            int AutoSizeWidth = 0;
            for (int i = 0; i <= this.items.Count - 1; i++)
            {
                ContainerListViewItem Clvi = this.items[i];

                int TextWidth = 0;
                if (ColIndex == 0)
                {
                    TextWidth = MeasureDisplayString(Clvi.Text, Clvi.Font).Width + 8;
                }
                else if (ColIndex > 0 && ColIndex <= Clvi.SubItems.Count)
                {
                    TextWidth = MeasureDisplayString(Clvi.SubItems[ColIndex - 1].Text, Clvi.SubItems[ColIndex - 1].Font).Width + 8;
                }

                if (TextWidth > AutoSizeWidth)
                {
                    AutoSizeWidth = TextWidth;
                }
            }

            return AutoSizeWidth;
        }

        /// <summary>
        /// Occurs when the ScrollBars are scrolled.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">An eventArg.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2109:ReviewVisibleEventHandlers")]
        protected virtual void OnScroll(object sender, EventArgs e)
        {
            if (this.scrollable)
            {
                this.EndEdit();
                this.Invalidate();
            }
        }

        /// <summary>
        /// Sets selection to the specified object.
        /// </summary>
        /// <param name="ClObj">The ContainerListViewObject to set focus to.</param>
        protected virtual void OnSetSelectedObject(ContainerListViewObject ClObj) { }

        /// <summary>
        /// Sets focus to the specified object.
        /// </summary>
        /// <param name="ClObj">The ContainerListViewObject to set focus to.</param>
        protected virtual void OnSetFocusedObject(ContainerListViewObject ClObj)
        {
            ContainerListViewItem Clvi = (ContainerListViewItem)ClObj;

            if (this.focusedItem != null)
            {
                this.focusedItem.Focused = false;
                this.focusedIndex = -1;
            }

            this.focusedItem = Clvi;
            this.focusedIndex = Clvi.Index;
        }

        /// <summary>
        /// Occurs when the control needs to be sorted.
        /// </summary>
        /// <param name="Index">The zero-based index of the column to sort on.</param>
        protected virtual void OnSort(int Index)
        {
            this.items.Sort();
        }

        /// <summary>
        /// Handles the SpaceBar key which Checks/UnChecks checkboxes on the item.
        /// </summary>
        /// <param name="e">A keyEventArgs.</param>
        protected virtual void OnSpaceBarKey(KeyEventArgs e)
        {
            if (e.Shift)
            {
                foreach (ContainerListViewObject item in this.selectedItems)
                {
                    if (item.CheckBoxVisible && item.CheckBoxEnabled)
                    {
                        item.Checked = !item.Checked;
                    }
                }
            }
            else
            {
                this.selectedItems.Clear();
                this.focusedIndex = this.focusedItem.Index;
                this.firstSelected = this.focusedIndex;
                this.focusedItem.Selected = true;
                this.focusedItem.Checked = !this.focusedItem.Checked;
                this.ShowSelectedItems();
                this.MakeSelectedVisible();
            }

            e.Handled = true;
            this.Invalidate();
        }

        /// <summary>
        /// Occurs when the Up or Down Keys are pressed.
        /// </summary>
        /// <param name="e">A KeyEventArgs.</param>
        protected virtual void OnUpDownKeys(KeyEventArgs e)
        {
            if (this.focusedItem != null && this.items.Count > 0)
            {
                int Index = this.focusedIndex;

                switch (e.KeyCode)
                {
                    case Keys.Up:
                        Index--;
                        break;
                    case Keys.Down:
                        Index++;
                        break;
                }

                this.MoveToIndex(Index);
                e.Handled = true;
            }
        }

        /// <summary>
        /// Processes Column clicks if the control is in DesignMode.
        /// </summary>
        /// <param name="e">The MouseArg containing the data.</param>
        protected void ProcessDesignModeColumnClick(MouseEventArgs e)
        {
            if (this.DesignMode && this.columnHeaders != null)
            {
                foreach (ContainerColumnHeader column in this.columnHeaders)
                {
                    if (column.Bounds.Contains(e.X, e.Y))
                    {
                        ArrayList SelList = new ArrayList(1);
                        ISelectionService Svc = (ISelectionService)this.GetService(typeof(ISelectionService));

                        SelList.Add(column);
                        Svc.SetSelectedComponents(SelList, SelectionTypes.Auto);
                    }
                }
            }
        }

        /// <summary>
        /// Sets the ContainerListViewObject currently in edit mode.
        /// </summary>
        /// <param name="ClObj">The ContainerListViewObject to set.</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        protected internal void SetEditedObject(ContainerListViewObject ClObj)
        {
            this.editingObj = ClObj;
        }

        /// <summary>
        /// Sets the Selected item.
        /// </summary>
        /// <param name="ClObj">The ContainerListViewObject to set.</param>
        protected internal void SetSelectedObject(ContainerListViewObject ClObj)
        {
            this.OnSetSelectedObject(ClObj);
        }

        /// <summary>
        /// Sets the Focused item.
        /// </summary>
        /// <param name="ClObj">The ContainerListViewObject to set.</param>
        protected internal void SetFocusedObject(ContainerListViewObject ClObj)
        {
            this.OnSetFocusedObject(ClObj);
        }

        /// <summary>
        /// Ends all editing on ContainerListView control.
        /// </summary>
        protected internal void EndEdit()
        {
            if (this.editingObj != null)
            {
                this.editingObj.EndEdit();
            }
        }
        #endregion

        #region custom functions
        private int GetColumnHeaderHeight()
        {
            if (this.headerStyle == ColumnHeaderStyle.None)
            {
                return 0;
            }

            if (this.visualStyles)
            {
                //GetPartSize for VisualStyleElement returns 24 for Vista and 18 for XP
                return IsWindowsVistaOrLater ? 26 : 22;
            }

            return 17;
        }

        private static Color GetVisualStylesBorderColor()
        {
            if (IsWindowsVistaOrLater)
            {
                if (VisualStyleInformation.DisplayName.Equals("Aero style", StringComparison.OrdinalIgnoreCase) &&
                    VisualStyleInformation.ColorScheme.Equals("NormalColor", StringComparison.Ordinal))
                {
                    return Color.FromArgb(130, 135, 144);
                }
            }
            else
            {
                //XP
                if (VisualStyleInformation.DisplayName.Equals("Windows XP style", StringComparison.OrdinalIgnoreCase) &&
                    (VisualStyleInformation.ColorScheme.Equals("NormalColor", StringComparison.Ordinal) || //Default (Blue)
                     VisualStyleInformation.ColorScheme.Equals("Metallic", StringComparison.Ordinal)))      //Silver
                {
                    return Color.FromArgb(127, 157, 185);
                }
            }

            return VisualStyleInformation.TextControlBorder;
        }

        internal ContainerColumnHeader InsertColumn(int index, ContainerColumnHeader column)
        {
            return this.InsertColumn(index, column, true);
        }

        internal ContainerColumnHeader InsertColumn(int index, ContainerColumnHeader column, bool refreshSubItems)
        {
            if (column == null)
            {
                throw new ArgumentNullException("column");
            }

            if (column.OwnerListView != null)
            {
                throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, "Cannot add or insert the item '{0}' in more than one place. You must first remove it from its current location or clone it.", new object[] { column.Text }), "column");
            }

            int length = this.columnHeaders == null ? 0 : this.columnHeaders.Length;
            if (length > 0)
            {
                ContainerColumnHeader[] destinationArray = new ContainerColumnHeader[length + 1];
                if (length > 0)
                {
                    Array.Copy(this.columnHeaders, 0, destinationArray, 0, length);
                }

                this.columnHeaders = destinationArray;
            }
            else
            {
                this.columnHeaders = new ContainerColumnHeader[1];
            }

            if (index < length)
            {
                Array.Copy(this.columnHeaders, index, this.columnHeaders, index + 1, length - index);
            }

            this.columnHeaders[index] = column;
            column.OwnerListView = this;

            if (refreshSubItems)
            {
                this.ColumnHeadersChanged();
            }

            return column;
        }

        private void ColumnHeadersChanged()
        {
            if (!this.updateTransactions)
            {
                this.GenerateHeaderRect();
                this.GenerateViewableRowsRectangle();

                this.Invalidate();
            }
        }

        private void AdjustScrollBars()
        {
            if (this.items.Count > 0 || (this.Columns.Count > 0 && !this.colScaleMode))
            {
                int ColsWidth = this.GetSumOfVisibleColumnWidths();
                Rectangle Rect = this.ClientRectangle;
                int borderWidth = GetBorderWidth();
                Rect.Inflate(-borderWidth, -borderWidth);

                int RowsHeight = this.items.Count * this.RowHeight;

                //Set the VScrollBar
                this.vscrollBar.Left = Rect.Left + Rect.Width - this.vscrollBar.Width;
                this.vscrollBar.Top = Rect.Top;
                this.vscrollBar.SmallChange = this.RowHeight;
                this.vscrollBar.Maximum = RowsHeight;

                //Set the HScrollBar
                this.hscrollBar.Left = Rect.Left;
                this.hscrollBar.Top = Rect.Top + Rect.Height - this.hscrollBar.Height;

                try
                {
                    if (this.Columns.Count > 0)
                    {
                        this.hscrollBar.SmallChange = ColsWidth / this.Columns.Count;
                    }
                    else
                    {
                        this.hscrollBar.SmallChange = 0;
                    }
                }
                catch (System.ArgumentOutOfRangeException)
                {
                    this.hscrollBar.SmallChange = 0;
                }

                this.hscrollBar.Maximum = ColsWidth;

                bool ShowVert = this.Scrollable && RowsHeight > Rect.Height - this.HeaderBuffer;
                int HorizVal = Rect.Width - (ShowVert ? this.VScroll.Width : 0);
                bool ShowHoriz = this.Scrollable && ColsWidth > HorizVal;
                int VertVal = Rect.Height - this.HeaderBuffer - (ShowHoriz ? this.HScroll.Height : 0);
                ShowVert = this.Scrollable && RowsHeight > VertVal;
                HorizVal = Rect.Width - (ShowVert ? this.VScroll.Width : 0);

                if (ShowVert & ShowHoriz)
                {
                    this.vscrollBar.Height = VertVal + this.HeaderBuffer;
                    if (VertVal > 0)
                    {
                        this.vscrollBar.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.vscrollBar.LargeChange = 0;
                    }

                    this.hscrollBar.Width = HorizVal;
                    if (HorizVal > 0)
                    {
                        this.hscrollBar.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.hscrollBar.LargeChange = 0;
                    }

                    this.hscrollBar.Show();
                    this.vscrollBar.Show();
                }
                else if (ShowVert && !ShowHoriz)
                {
                    this.hscrollBar.Hide();

                    this.hscrollBar.Value = 0;
                    if (HorizVal > 0)
                    {
                        this.hscrollBar.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.hscrollBar.LargeChange = 0;
                    }

                    this.vscrollBar.Height = VertVal + this.HeaderBuffer;
                    if (VertVal > 0)
                    {
                        this.vscrollBar.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.vscrollBar.LargeChange = 0;
                    }

                    this.vscrollBar.Show();
                }
                else if (!ShowVert && ShowHoriz)
                {
                    this.vscrollBar.Hide();

                    this.vscrollBar.Value = 0;
                    if (VertVal > 0)
                    {
                        this.vscrollBar.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.vscrollBar.LargeChange = 0;
                    }

                    this.hscrollBar.Width = HorizVal;
                    if (HorizVal > 0)
                    {
                        this.hscrollBar.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.hscrollBar.LargeChange = 0;
                    }

                    this.HScroll.Show();
                }
                else
                {
                    this.vscrollBar.Hide();

                    this.vscrollBar.Value = 0;
                    if (VertVal > 0)
                    {
                        this.vscrollBar.LargeChange = VertVal - (VertVal % this.RowHeight);
                    }
                    else
                    {
                        this.vscrollBar.LargeChange = 0;
                    }

                    this.hscrollBar.Hide();

                    this.hscrollBar.Value = 0;
                    if (HorizVal > 0)
                    {
                        this.hscrollBar.LargeChange = HorizVal;
                    }
                    else
                    {
                        this.hscrollBar.LargeChange = 0;
                    }
                }
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        private Color DetermineBackGroundColorInternal(ContainerListViewObject Obj, ContainerListViewObject.ContainerListViewSubItem SubItem)
        {
            //Listed in order of precedence
            if (!this.Enabled)
            {
                return this.disabledColor;
            }

            if (this.doRowTracking & Obj.Hovered && !Obj.Selected)
            {
                if (SubItem == null || this.fullRowSelect)
                {
                    return this.rowTrackColor;
                }

                if (Obj.UseItemStyleForSubItems)
                {
                    return GetItemColor(Obj);
                }

                return GetItemColor(SubItem);
            }

            if (Obj.Selected && this.IsFocused)
            {
                if (SubItem == null || this.fullRowSelect)
                {
                    return this.rowSelectColor;
                }

                if (Obj.UseItemStyleForSubItems)
                {
                    return GetItemColor(Obj);
                }

                return GetItemColor(SubItem);
            }

            if (Obj.Selected && !this.IsFocused && !this.hideSelection)
            {
                if (SubItem == null || this.fullRowSelect)
                {
                    return SystemColors.Control;
                }

                if (Obj.UseItemStyleForSubItems)
                {
                    return GetItemColor(Obj);
                }

                return GetItemColor(SubItem);
            }

            if (this.doColTracking && this.lastColHovered != null)
            {
                if (SubItem == null)
                {
                    if (this.lastColHovered.Index == 0)
                    {
                        return Color.Transparent;
                    }
                    else
                    {
                        return GetItemColor(Obj);
                    }
                }

                if (SubItem.Index == this.lastColHovered.Index - 1)
                {
                    return this.colTrackColor;
                }

                if (Obj.UseItemStyleForSubItems)
                {
                    return GetItemColor(Obj);
                }

                return GetItemColor(SubItem);
            }

            if (this.colSortEnabled && this.selectedCol != null && this.lastPaintedSortCol != this.selectedCol.Index)
            {
                if (SubItem == null)
                {
                    return GetItemColor(Obj);
                }

                if (SubItem.Index == this.selectedCol.Index - 1)
                {
                    return this.colSortColor;
                }

                if (Obj.UseItemStyleForSubItems)
                {
                    return GetItemColor(Obj);
                }

                return GetItemColor(SubItem);
            }

            if (SubItem != null && !Obj.UseItemStyleForSubItems)
            {
                return GetItemColor(SubItem);
            }

            return GetItemColor(Obj);
        }

        private void GenerateHeaderRect()
        {
            Rectangle Rect = this.ClientRectangle;
            this.headerRect = new Rectangle(Rect.Left + 2, Rect.Top + 2, Rect.Width - 4, this.headerBuffer);
        }

        private void GenerateViewableRowsRectangle()
        {
            int ColWidths = this.GetSumOfVisibleColumnWidths();
            Rectangle Rect = this.ClientRectangle;

            int Width;
            if (ColWidths >= Rect.Width)
            {
                Width = Rect.Width - 4;
            }
            else
            {
                Width = ColWidths;
            }

            int Val = 2;
            if (this.headerStyle != ColumnHeaderStyle.None)
            {
                Val += this.headerBuffer;
            }

            this.rowsRect = new Rectangle(Rect.Left + 2, Rect.Top + Val, Width, Rect.Height - Val);
        }

        private Rectangle GetBounds(ContainerListViewObject Obj)
        {
            Rectangle Rect = Rectangle.Empty;

            if (this.columnHeaders != null && this.columnHeaders.Length > 0 && !this.columnHeaders[0].Hidden)
            {
                int Ypos = 2 + this.headerBuffer - this.vscrollBar.Value;
                Rect = new Rectangle(this.columnHeaders[0].Bounds.X, Ypos + (Obj.Index * this.rowHeight), this.columnHeaders[0].Width, this.rowHeight);
            }

            return Rect;
        }

        private Rectangle GetCompleteBounds(ContainerListViewObject Obj)
        {
            Rectangle Rect = Rectangle.Empty;
            int Sum = 0;
            if (this.columnHeaders != null)
            {
                Sum = this.GetSumOfVisibleColumnWidths() + this.columnHeaders.Length - 1;
            }

            if (Sum > 0)
            {
                int XPos = this.ClientRectangle.X;
                int YPos = 2 + this.headerBuffer - this.vscrollBar.Value;
                Rect = new Rectangle(XPos, YPos + (Obj.Index * this.rowHeight), Sum, this.rowHeight);
            }

            return Rect;
        }

        private static Color GetItemColor(ContainerListViewObject Obj)
        {
            Color RetVal = Obj.BackColor;

            if (!Obj.BackColor.Equals(Color.Transparent))
            {
                RetVal = Obj.BackColor;
            }

            return RetVal;
        }

        private static Color GetItemColor(ContainerListViewObject.ContainerListViewSubItem SubItem)
        {
            Color RetVal = SubItem.BackColor;

            if (!SubItem.BackColor.Equals(Color.Transparent))
            {
                RetVal = SubItem.BackColor;
            }

            return RetVal;
        }

        private int GetSelectedRowIndex(int YPos)
        {
            int Var = -(2 + this.headerBuffer - this.vscrollBar.Value) + YPos;
            int SelIndex = Convert.ToInt32(Var / this.RowHeight);

            if (SelIndex < this.items.Count && SelIndex >= 0)
            {
                return SelIndex;
            }

            return -1;
        }

        private void MakeSelectedVisible()
        {
            if (this.focusedIndex > -1 && this.scrollable)
            {
                ContainerListViewItem Clvi = this.items[this.focusedIndex];

                if (Clvi != null && Clvi.Focused && Clvi.Selected)
                {
                    Rectangle Rect = this.ClientRectangle;
                    int Pos = Rect.Top + (this.rowHeight * Clvi.Index) + this.headerBuffer + 2 - this.vscrollBar.Value;

                    try
                    {
                        if (Pos + (this.rowHeight * 2) > Rect.Top + Rect.Height)
                        {
                            this.vscrollBar.Value += Math.Abs(Rect.Top + Rect.Height - (Pos + (this.rowHeight * 2)));
                        }
                        else if (Pos < (Rect.Top + this.headerBuffer))
                        {
                            this.vscrollBar.Value -= Math.Abs(Rect.Top + this.headerBuffer - Pos);
                        }
                    }
                    catch (System.ArgumentOutOfRangeException)
                    {
                        if (this.vscrollBar.Value > this.vscrollBar.Maximum)
                        {
                            this.vscrollBar.Value = this.vscrollBar.Maximum;
                        }
                        else if (this.vscrollBar.Value < this.vscrollBar.Minimum)
                        {
                            this.vscrollBar.Value = this.vscrollBar.Minimum;
                        }
                    }
                }
            }
        }

        private void MoveToIndex(int Index)
        {
            if (Index >= 0 && Index < this.items.Count && Index != this.focusedIndex)
            {
                this.selectedItems.Clear();
                this.focusedIndex = Index;

                if (this.multiSelectMode == MultiSelectModes.Single || this.firstSelected == -1)
                {
                    this.firstSelected = this.focusedIndex;
                    this.items[this.focusedIndex].Focused = true;
                    this.focusedItem = this.items[this.focusedIndex];
                }

                this.ShowSelectedItems();
                this.MakeSelectedVisible();
                this.Invalidate();
            }
        }

        private void SelectiveSelection(int Index)
        {
            ContainerListViewItem Clvi = this.items[Index];

            if (this.focusedIndex >= 0 && this.focusedIndex < this.items.Count)
            {
                this.items[this.focusedIndex].Focused = false;
            }

            if (Clvi.Selected)
            {
                Clvi.Focused = false;
                Clvi.Selected = false;
                if (this.focusedItem == Clvi)
                {
                    this.focusedItem = null;
                }
            }
            else
            {
                Clvi.Focused = true;
                Clvi.Selected = true;
            }

            this.MakeSelectedVisible();
            this.Invalidate();
        }

        private void ShowSelectedItems()
        {
            if (this.firstSelected == this.focusedIndex)
            {
                this.items[this.firstSelected].Selected = true;
            }
            else if (this.firstSelected > this.focusedIndex)
            {
                for (int i = this.focusedIndex; i <= this.firstSelected; i++)
                {
                    this.items[i].Selected = true;
                }
            }
            else if (this.firstSelected < this.focusedIndex)
            {
                for (int i = this.firstSelected; i <= this.focusedIndex; i++)
                {
                    this.items[i].Selected = true;
                }
            }
        }

        private void ScrollGotFocus(object sender, EventArgs e)
        {
            this.Focus();
        }
		#endregion

        #region helper functions
        /// <summary>
        /// Gets if enum is valid
        /// </summary>
        protected static bool IsEnumValid(int value, int minValue, int maxValue)
        {
            return (value >= minValue && value <= maxValue);
        }

        /// <summary>
        /// Gets the width of a string using a graphics object.
        /// </summary>
        protected static Size MeasureDisplayString(string text, Font font)
        {
            const int cWidth = 45;

            Bitmap bitmap = new Bitmap(cWidth, 1);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                SizeF sz = g.MeasureString(text, font);

                if (string.IsNullOrEmpty(text))
                {
                    return new Size(0, Convert.ToInt32(sz.Height));
                }

                int StringWidth = Convert.ToInt32(sz.Width) + 15;

                //Correct the value (MeasureString returns bigger width value)
                g.Clear(Color.White);
                g.DrawString(text + "|", font, Brushes.Black, -(float)(StringWidth - cWidth), -((float)(font.Height / 2)));

                for (int i = cWidth - 1; i >= 0; i--)
                {
                    StringWidth--;
                    if (bitmap.GetPixel(i, 0).R != 255)
                    {
                        StringWidth--;
                        break;
                    }
                }

                return new Size(StringWidth, Convert.ToInt32(sz.Height));
            }
        }

        /// <summary>
        /// Gets the width of a string using a graphics object.
        /// </summary>
        protected static Size MeasureDisplayString(Graphics formatg, string text, Font font)
        {
            const int cWidth = 45;

            Bitmap bitmap = new Bitmap(cWidth, 1, formatg);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                SizeF sz = g.MeasureString(text, font);

                if (string.IsNullOrEmpty(text))
                {
                    return new Size(0, Convert.ToInt32(sz.Height));
                }

                int StringWidth = Convert.ToInt32(sz.Width) + 15;

                //Correct the value (MeasureString returns bigger Width value)
                g.Clear(Color.White);
                g.DrawString(text + "|", font, Brushes.Black, -(float)(StringWidth - cWidth), -((float)(font.Height / 2)));

                for (int i = cWidth - 1; i >= 0; i--)
                {
                    StringWidth--;
                    if (bitmap.GetPixel(i, 0).R != 255)
                    {
                        StringWidth--;
                        break;
                    }
                }

                return new Size(StringWidth, Convert.ToInt32(sz.Height));
            }
        }

        /// <summary>
        /// Truncates text.
        /// </summary>
        protected static string TruncateString(string text, Font font, int width, Graphics g)
        {
            if (string.IsNullOrEmpty(text))
            {
                return text;
            }

            int length = text.Length;

            int StringWidth = MeasureDisplayString(g, text, font).Width;
            while (StringWidth > width)
            {
                length--;
                if (length <= 0)
                {
                    break;
                }

                text = text.Substring(0, length) + "...";

                StringWidth = MeasureDisplayString(text, font).Width;
            }

            return text;
        }

        /// <summary>
        /// Determines if an object has been clicked.
        /// </summary>
        protected static object EvaluateObject(MouseEventArgs e, IEnumerator keysEnum, IEnumerator valsEnum)
        {
            while (keysEnum.MoveNext() && valsEnum.MoveNext())
            {
                Rectangle Rect = (Rectangle)keysEnum.Current;

                if (Rect.Left <= e.X && Rect.Left + Rect.Width >= e.X && Rect.Top <= e.Y && Rect.Top + Rect.Height >= e.Y)
                {
                    return valsEnum.Current;
                }
            }

            return null;
        }
		#endregion
        #endregion
    }

    #region Type converters
    #region ContainerListViewSubItemConverter class
    /// <summary>
    /// Provides a type converter to convert <see cref="ContainerListViewObject.ContainerListViewSubItem"/> objects to and from various other representations.
    /// </summary>
    public class ContainerListViewSubItemConverter : TypeConverter
    {
        #region action methods
        /// <summary>
        /// Gets a value indicating whether this converter can convert an object to the given destination type using the context.
        /// </summary>
        /// <param name="context">An System.ComponentModel.ITypeDescriptorContext that provides a format context.</param>
        /// <param name="destinationType">A System.Type that represents the type you wish to convert to.</param>
        /// <returns>true if this converter can perform the conversion; otherwise, false.</returns>
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(InstanceDescriptor))
            {
                return true;
            }

            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// Converts the given object to another type.
        /// </summary>
        /// <param name="context">
        /// A formatter context. This object can be used to extract additional information
        /// about the environment this converter is being invoked from. This may be null,
        /// so you should always check. Also, properties on the context object may also
        /// return null.
        /// </param>
        /// <param name="culture">An optional culture info. If not supplied the current culture is assumed.</param>
        /// <param name="value">The object to convert.</param>
        /// <param name="destinationType">The type to convert the object to.</param>
        /// <returns>The converted object.</returns>
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == null)
            {
                throw new ArgumentNullException("destinationType");
            }

            var Clvi = value as ContainerListViewObject.ContainerListViewSubItem;

            if (destinationType == typeof(InstanceDescriptor) && Clvi != null)
            {
                ConstructorInfo info = Clvi.GetType().GetConstructor(new Type[] { typeof(string)});
                if (info != null)
                {
                    return new InstanceDescriptor(info, new object[] { Clvi.Text }, false);
                }
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
        #endregion
    }
    #endregion

    #region ContainerListViewItemConverter class
    /// <summary>
    /// Provides a type converter to convert <see cref="ContainerListViewItem"/> objects to and from various other representations.
    /// </summary>
    public class ContainerListViewItemConverter : TypeConverter
    {
        #region action methods
        /// <summary>
        /// Gets a value indicating whether this converter can convert an object to the given destination type using the context.
        /// </summary>
        /// <param name="context">An System.ComponentModel.ITypeDescriptorContext that provides a format context.</param>
        /// <param name="destinationType">A System.Type that represents the type you wish to convert to.</param>
        /// <returns>true if this converter can perform the conversion; otherwise, false.</returns>
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(InstanceDescriptor))
            {
                return true;
            }

            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// Converts the given object to another type.
        /// </summary>
        /// <param name="context">
        /// A formatter context. This object can be used to extract additional information
        /// about the environment this converter is being invoked from. This may be null,
        /// so you should always check. Also, properties on the context object may also
        /// return null.
        /// </param>
        /// <param name="culture">An optional culture info. If not supplied the current culture is assumed.</param>
        /// <param name="value">The object to convert.</param>
        /// <param name="destinationType">The type to convert the object to.</param>
        /// <returns>The converted object.</returns>
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == null)
            {
                throw new ArgumentNullException("destinationType");
            }

            var Clvi = value as ContainerListViewItem;

            if (destinationType == typeof(InstanceDescriptor) && Clvi != null)
            {
                ContainerListViewObject.ContainerListViewSubItem[] SubItems = null;
                if (Clvi.SubItems.Count > 0)
                {
                    SubItems = new ContainerListViewObject.ContainerListViewSubItem[Clvi.SubItems.Count];
                    Clvi.SubItems.CopyTo(SubItems, 0);
                }

                ConstructorInfo info = Clvi.GetType().GetConstructor(new Type[] { typeof(string), typeof(int), typeof(Color), typeof(Color), typeof(Font), typeof(ContainerListViewObject.ContainerListViewSubItem[]) });
                if (info != null)
                {
                    return new InstanceDescriptor(info, new object[] { Clvi.Text, Clvi.ImageIndex, Clvi.BackColor, Clvi.ForeColor, Clvi.Font, SubItems }, false);
                }
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
        #endregion
    }
    #endregion

    #region ContainerColumnHeaderConverter class
    /// <summary>
    /// Provides a type converter to convert <see cref="ContainerColumnHeader"/> objects to and from various other representations.
    /// </summary>
    public class ContainerColumnHeaderConverter : TypeConverter
    {
        #region action methods
        /// <summary>
        /// Gets a value indicating whether this converter can convert an object to the given destination type using the context.
        /// </summary>
        /// <param name="context">An System.ComponentModel.ITypeDescriptorContext that provides a format context.</param>
        /// <param name="destinationType">A System.Type that represents the type you wish to convert to.</param>
        /// <returns>true if this converter can perform the conversion; otherwise, false.</returns>
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(InstanceDescriptor))
            {
                return true;
            }

            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// Converts the given object to another type.
        /// </summary>
        /// <param name="context">
        /// A formatter context. This object can be used to extract additional information
        /// about the environment this converter is being invoked from. This may be null,
        /// so you should always check. Also, properties on the context object may also
        /// return null.
        /// </param>
        /// <param name="culture">An optional culture info. If not supplied the current culture is assumed.</param>
        /// <param name="value">The object to convert.</param>
        /// <param name="destinationType">The type to convert the object to.</param>
        /// <returns>The converted object.</returns>
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == null)
            {
                throw new ArgumentNullException("destinationType");
            }

            var CH = value as ContainerColumnHeader;

            if (destinationType == typeof(InstanceDescriptor) && CH != null)
            {
                ConstructorInfo info = CH.GetType().GetConstructor(Type.EmptyTypes);
                if (info != null)
                {
                    return new InstanceDescriptor(info, null, false);
                }
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
        #endregion
    }
	#endregion
    #endregion
}

namespace IMP.SharedControls.Design
{
    #region ContainerColumnHeaderCollectionEditor class
    /// <summary>
    /// Collection editor class for ContainerListView.ContainerColumnHeaderCollection
    /// </summary>
    internal class ContainerColumnHeaderCollectionEditor : CollectionEditor
    {
        public ContainerColumnHeaderCollectionEditor(Type type) : base(type) { }

        protected override object SetItems(object editValue, object[] value)
        {
            if (editValue != null)
            {
                ContainerListView.ContainerColumnHeaderCollection headers = editValue as ContainerListView.ContainerColumnHeaderCollection;
                if (editValue != null)
                {
                    headers.Clear();
                    ContainerColumnHeader[] destinationArray = new ContainerColumnHeader[value.Length];
                    Array.Copy(value, 0, destinationArray, 0, value.Length);
                    headers.AddRange(destinationArray);
                }
            }

            return editValue;
        }

        protected override string HelpTopic
        {
            get { return "net.ComponentModel.ColumnHeaderCollectionEditor"; }
        }
    }
    #endregion

    #region ContainerListViewDesigner class
    /// <summary>
    /// ControlDesigner pro ContainerListView control
    /// </summary>
    internal class ContainerListViewDesigner : System.Windows.Forms.Design.ControlDesigner
    {
        #region member varible and default property initialization
        private ContainerColumnHeader m_SelectionColumn;
        #endregion

        #region constructors and destructors
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                ISelectionService selectionService = (ISelectionService)this.GetService(typeof(ISelectionService));
                if (selectionService != null)
                {
                    selectionService.SelectionChanged -= new EventHandler(this.OnSelectionChanged);
                }

                IComponentChangeService ChangeService = (IComponentChangeService)this.GetService(typeof(IComponentChangeService));
                if (ChangeService != null)
                {
                    ChangeService.ComponentRemoving -= new ComponentEventHandler(this.OnComponentRemoving);
                }
            }

            base.Dispose(disposing);
        }
        #endregion

        #region ControlDesigner overrides
        /// <summary>
        /// Initializes the designer with the specified component.
        /// </summary>
        /// <param name="component">The IComponent to associate the designer with. This component must always be an instance of, or derive from, Control.</param>
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);

            ContainerListView control = (ContainerListView)base.Component;

            ISelectionService selectionService = (ISelectionService)this.GetService(typeof(ISelectionService));
            if (selectionService != null)
            {
                selectionService.SelectionChanged += new EventHandler(this.OnSelectionChanged);
            }

            IComponentChangeService ChangeService = (IComponentChangeService)this.GetService(typeof(IComponentChangeService));
            if (ChangeService != null)
            {
                ChangeService.ComponentRemoving += new ComponentEventHandler(this.OnComponentRemoving);
            }

            control.ColumnSortColorEnabled = false;
            control.ColumnTracking = false;
        }

        /// <summary>
        /// Adjusts the set of properties the component exposes through a TypeDescriptor.
        /// </summary>
        /// <param name="properties">An IDictionary containing the properties for the class of the component.</param>
        protected override void PreFilterProperties(System.Collections.IDictionary properties)
        {
            base.PreFilterProperties(properties);
            properties.Remove("DockPadding");
            properties.Remove("Padding");
            properties.Remove("ContextMenu");

            //Replace selected properties with our shadowed ones
            properties["ColumnSortColorEnabled"] = TypeDescriptor.CreateProperty(typeof(ContainerListViewDesigner), (PropertyDescriptor)properties["ColumnSortColorEnabled"], null);
            properties["ColumnTracking"] = TypeDescriptor.CreateProperty(typeof(ContainerListViewDesigner), (PropertyDescriptor)properties["ColumnTracking"], null);
        }

        /// <summary>
        /// Indicates whether a mouse click at the specified point should be handled by the control.
        /// </summary>
        /// <param name="point">A Point indicating the position at which the mouse was clicked, in screen coordinates.</param>
        /// <returns><c>true</c> if a click at the specified point is to be handled by the control; otherwise, <c>false</c>.</returns>
        /// <remarks>
        /// The GetHitTest method determines whether a click at the specified point should be passed to the control, while the control is in design mode. 
        /// You can override and implement this method to enable your control to receive clicks in the design-time environment.
        /// </remarks>
        protected override bool GetHitTest(Point point)
        {
            ContainerListView control = (ContainerListView)base.Component;

            Point ClientPoint = control.PointToClient(point);
            MouseEventArgs e = new MouseEventArgs(MouseButtons.Left, 1, ClientPoint.X, ClientPoint.Y, 0);

            //Check for columns
            foreach (ContainerColumnHeader Col in  control.Columns)
	        {
                if (Col.Bounds.Contains(e.X, e.Y) || Col.SizingBounds.Contains(e.X, e.Y))
                {
                    return true;
                }        		 
	        }

            bool ColHovered = false;
            foreach (ContainerColumnHeader Col in control.Columns)
            {
                if (Col.Hovered)
                {
                    Col.Hovered = false;
                    ColHovered = true;
                }
            }

            if (ColHovered)
            {
                control.Invalidate();
            }

            //Check for HScroll
            Rectangle HRect = new Rectangle(control.HScroll.Location.X, control.HScroll.Location.Y, control.HScroll.Width, control.HScroll.Height);
            if (HRect.Contains(e.X, e.Y))
            {
                return true;
            }

            //Check for VScroll
            Rectangle VRect = new Rectangle(control.VScroll.Location.X, control.VScroll.Location.Y, control.VScroll.Width, control.VScroll.Height);
            if (VRect.Contains(e.X, e.Y))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Called when the control that the designer is managing has painted its surface so the designer can paint any additional adornments on top of the control.
        /// </summary>
        /// <param name="pe">A PaintEventArgs the designer can use to draw on the control.</param>
        protected override void OnPaintAdornments(PaintEventArgs pe)
        {
            base.OnPaintAdornments(pe);

            ISelectionService selectionService = (ISelectionService)this.GetService(typeof(ISelectionService));

            if (selectionService != null)
            {
                if (selectionService.PrimarySelection == m_SelectionColumn)
                {
                    ContainerColumnHeader ActiveCol;
                    if (m_SelectionColumn != null)
                    {
                        ActiveCol = this.m_SelectionColumn;
                    }
                    else
                    {
                        ActiveCol = (ContainerColumnHeader)selectionService.PrimarySelection;
                    }

                    if (ActiveCol != null)
                    {
                        Color BckClr = Color.White;
                        if (ActiveCol.ListView != null && !ActiveCol.ListView.VisualStyles)
                        {
                            BckClr = SystemColors.Control;
                        }

                        //Draw the focus rectangle
                        Rectangle bounds = ActiveCol.Bounds;
                        Rectangle Rect = new Rectangle(bounds.X, bounds.Y, bounds.Width, bounds.Height - 4);

                        ControlPaint.DrawFocusRectangle(pe.Graphics, Rect, m_SelectionColumn.ForeColor, BckClr);
                    }
                }
            }
        }

        /// <summary>
        /// Gets the collection of components associated with the component managed by the designer.
        /// </summary>
        public override ICollection AssociatedComponents
        {
            get
            {
                ContainerListView control = (ContainerListView)base.Component;
                if (control != null)
                {
                    return control.Columns;
                }

                return base.AssociatedComponents;
            }
        }
        #endregion

        #region property getters/setters
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Convert.ToBoolean(System.Object)")]
        public bool ColumnSortColorEnabled
        {
            get { return Convert.ToBoolean(this.ShadowProperties["ColumnSortColorEnabled"]); }
            set { this.ShadowProperties["ColumnSortColorEnabled"] = value; }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Convert.ToBoolean(System.Object)")]
        public bool ColumnTracking
        {
            get { return Convert.ToBoolean(this.ShadowProperties["ColumnTracking"]); }
            set { this.ShadowProperties["ColumnTracking"] = value; }
        }
        #endregion

        #region private member functions
        private void OnSelectionChanged(object sender, EventArgs e)
        {
            ISelectionService selectionService = (ISelectionService)this.GetService(typeof(ISelectionService));

            if (selectionService != null)
            {
                ContainerListView control = (ContainerListView)base.Component;

                //See if the primary selection is one of the columns
                ContainerColumnHeader NewSelCol = null;
                foreach (ContainerColumnHeader Col in control.Columns)
                {
                    if (selectionService.PrimarySelection == Col)
                    {
                        NewSelCol = Col;
                    }
                }

                //Apply if necessary
                if (m_SelectionColumn != NewSelCol)
                {
                    m_SelectionColumn = NewSelCol;
                    control.Invalidate();
                }
            }
        }

        private void OnComponentRemoving(object sender, ComponentEventArgs e)
        {
            IComponentChangeService changeService = (IComponentChangeService)this.GetService(typeof(IComponentChangeService));
            IDesignerHost designerHost = (IDesignerHost)this.GetService(typeof(IDesignerHost));

            if (changeService != null && designerHost != null)
            {
                ContainerListView control = (ContainerListView)base.Component;

                ContainerColumnHeader column = e.Component as ContainerColumnHeader;
                if (column != null)
                {
                    if (control.Columns.Contains(column))
                    {
                        changeService.OnComponentChanging(control, null);
                        control.Columns.Remove(column);
                        changeService.OnComponentChanged(control, null, null, null);
                    }
                }
            }
        }
        #endregion
    }
    #endregion
}