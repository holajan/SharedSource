using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Design;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using System.Runtime.InteropServices;
using System.Security;

namespace IMP.SharedControls.Design
{
    #region EditorServiceContext class
    /// <summary>
    /// Provides an implementation of IWindowsFormsEditorService ITypeDescriptorContext and IServiceProvider.
    /// </summary>
    internal class EditorServiceContext : IWindowsFormsEditorService, ITypeDescriptorContext, IServiceProvider
    {
        #region member varible and default property initialization
        private ComponentDesigner m_Designer;
        private PropertyDescriptor m_TargetProperty;
        private IComponentChangeService m_ComponentChangeService;
        #endregion

        #region constructors and destructors
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal EditorServiceContext(ComponentDesigner designer)
        {
            m_Designer = designer;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal EditorServiceContext(ComponentDesigner designer, PropertyDescriptor prop)
        {
            m_Designer = designer;
            m_TargetProperty = prop;

            if (prop == null)
            {
                prop = TypeDescriptor.GetDefaultProperty(designer.Component);

                if ((prop != null) && typeof(ICollection).IsAssignableFrom(prop.PropertyType))
                {
                    m_TargetProperty = prop;
                }
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal EditorServiceContext(ComponentDesigner designer, PropertyDescriptor prop, string newVerbText)
            : this(designer, prop)
        {
            m_Designer.Verbs.Add(new DesignerVerb(newVerbText, new EventHandler(this.OnEditItems)));
        }
        #endregion

        #region action methods
        public static object EditValue(ComponentDesigner designer, object objectToChange, string propName)
        {
            PropertyDescriptor propertyDescriptor = TypeDescriptor.GetProperties(objectToChange)[propName];

            //Create a context
            EditorServiceContext editorServiceContext = new EditorServiceContext(designer, propertyDescriptor);

            UITypeEditor propertyEditor = propertyDescriptor.GetEditor(typeof(UITypeEditor)) as UITypeEditor;

            //Get value to edit
            object CurrentValue = propertyDescriptor.GetValue(objectToChange);

            //Invoke property editor
            object NewValue = propertyEditor.EditValue(editorServiceContext, editorServiceContext, CurrentValue);

            if (NewValue != CurrentValue)
            {
                try
                {
                    propertyDescriptor.SetValue(objectToChange, NewValue);
                }
                catch (CheckoutException) { }
            }

            return NewValue;
        }
        #endregion

        #region property getters/setters
        private IComponentChangeService ChangeService
        {
            get
            {
                if (m_ComponentChangeService == null)
                {
                    m_ComponentChangeService = (IComponentChangeService)((IServiceProvider)this).GetService(typeof(IComponentChangeService));
                }

                return m_ComponentChangeService;
            }
        }
        #endregion

        #region private member functions
        private void OnEditItems(object sender, EventArgs e)
        {
            object PropertyValue = m_TargetProperty.GetValue(m_Designer.Component);

            if (PropertyValue != null)
            {
                CollectionEditor collectionEditor = TypeDescriptor.GetEditor(PropertyValue, typeof(UITypeEditor)) as CollectionEditor;

                if (collectionEditor != null)
                {
                    collectionEditor.EditValue(this, this, PropertyValue);
                }
            }
        }
        #endregion

        #region IWindowsFormsEditorService Members
        void IWindowsFormsEditorService.CloseDropDown() { }

        void IWindowsFormsEditorService.DropDownControl(Control control) { }

        DialogResult IWindowsFormsEditorService.ShowDialog(Form dialog)
        {
            IUIService uiService = (IUIService)((IServiceProvider)this).GetService(typeof(IUIService));

            if (uiService != null)
            {
                return uiService.ShowDialog(dialog);
            }

            return dialog.ShowDialog(m_Designer.Component as IWin32Window);
        }
        #endregion

        #region ITypeDescriptorContext Members
        void ITypeDescriptorContext.OnComponentChanged()
        {
            this.ChangeService.OnComponentChanged(m_Designer.Component, m_TargetProperty, null, null);
        }

        bool ITypeDescriptorContext.OnComponentChanging()
        {
            try
            {
                this.ChangeService.OnComponentChanging(m_Designer.Component, m_TargetProperty);
            }
            catch (CheckoutException checkoutException)
            {
                if (checkoutException != CheckoutException.Canceled)
                {
                    throw;
                }

                return false;
            }

            return true;
        }

        IContainer ITypeDescriptorContext.Container
        {
            get
            {
                if (m_Designer.Component.Site != null)
                {
                    return m_Designer.Component.Site.Container;
                }

                return null;
            }
        }

        object ITypeDescriptorContext.Instance
        {
            get { return m_Designer.Component; }
        }

        PropertyDescriptor ITypeDescriptorContext.PropertyDescriptor
        {
            get { return m_TargetProperty; }
        }
        #endregion

        #region IServiceProvider Members
        object IServiceProvider.GetService(Type serviceType)
        {
            if ((serviceType == typeof(ITypeDescriptorContext)) || (serviceType == typeof(IWindowsFormsEditorService)))
            {
                return this;
            }

            if (m_Designer.Component.Site != null)
            {
                return m_Designer.Component.Site.GetService(serviceType);
            }

            return null;
        }
        #endregion
    }
    #endregion

    #region IEventHandlerService interface
    internal interface IEventHandlerService
    {
        event EventHandler EventHandlerChanged;

        object GetHandler(Type handlerType);
        void PopHandler(object handler);
        void PushHandler(object handler);

        Control FocusWindow { get; }
    }
    #endregion

    #region DesignerUtils class
    /// <summary>
    /// Designer Helper methods
    /// </summary>
    internal static class DesignerUtils
    {
		#region member varible and default property initialization
        public static readonly ContentAlignment anyTopAlignment = ContentAlignment.TopRight | ContentAlignment.TopCenter | ContentAlignment.TopLeft;
        public static readonly ContentAlignment anyMiddleAlignment = ContentAlignment.MiddleRight | ContentAlignment.MiddleCenter | ContentAlignment.MiddleLeft;
		#endregion

        #region NativeMethods member classes
        [SuppressUnmanagedCodeSecurity]
        private static class SafeNativeMethods
        {
            #region TEXTMETRIC class
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
            public class TEXTMETRIC
            {
                public int tmHeight;
                public int tmAscent;
                public int tmDescent;
                public int tmInternalLeading;
                public int tmExternalLeading;
                public int tmAveCharWidth;
                public int tmMaxCharWidth;
                public int tmWeight;
                public int tmOverhang;
                public int tmDigitizedAspectX;
                public int tmDigitizedAspectY;
                public char tmFirstChar;
                public char tmLastChar;
                public char tmDefaultChar;
                public char tmBreakChar;
                public byte tmItalic;
                public byte tmUnderlined;
                public byte tmStruckOut;
                public byte tmPitchAndFamily;
                public byte tmCharSet;
            }
            #endregion

            #region extern functions
            [DllImport("gdi32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
            public static extern IntPtr SelectObject(HandleRef hDC, HandleRef hObject);

            [DllImport("gdi32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool DeleteObject(HandleRef hObject);

            [DllImport("gdi32.dll", CharSet = CharSet.Auto)]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool GetTextMetrics(HandleRef hdc, TEXTMETRIC tm);
            #endregion
        }
        #endregion

		#region action methods
        public static int GetTextBaseline(Control ctrl, System.Drawing.ContentAlignment alignment)
        {
            Rectangle clientRectangle = ctrl.ClientRectangle;
            int num = 0;
            int tmHeight = 0;

            using (Graphics graphics = ctrl.CreateGraphics())
            {
                IntPtr hdc = graphics.GetHdc();
                IntPtr handle = ctrl.Font.ToHfont();
                try
                {
                    IntPtr ptr3 = SafeNativeMethods.SelectObject(new HandleRef(ctrl, hdc), new HandleRef(ctrl, handle));
                    SafeNativeMethods.TEXTMETRIC tm = new SafeNativeMethods.TEXTMETRIC();
                    SafeNativeMethods.GetTextMetrics(new HandleRef(ctrl, hdc), tm);
                    num = tm.tmAscent + 1;
                    tmHeight = tm.tmHeight;
                    SafeNativeMethods.SelectObject(new HandleRef(ctrl, hdc), new HandleRef(ctrl, ptr3));
                }
                finally
                {
                    SafeNativeMethods.DeleteObject(new HandleRef(ctrl.Font, handle));
                    graphics.ReleaseHdc(hdc);
                }
            }

            if ((alignment & anyTopAlignment) != ((ContentAlignment)0))
            {
                return (clientRectangle.Top + num);
            }

            if ((alignment & anyMiddleAlignment) != ((ContentAlignment)0))
            {
                return (((clientRectangle.Top + (clientRectangle.Height / 2)) - (tmHeight / 2)) + num);
            }

            return ((clientRectangle.Bottom - tmHeight) + num);
        }
        #endregion
    }
    #endregion
}
