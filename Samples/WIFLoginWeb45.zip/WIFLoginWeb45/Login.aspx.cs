﻿using System;
using System.Web.UI;

namespace WIFLoginWeb
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PageTitleLabel.Text = Page.Title;
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                var claimsPrincipal = AuthenticationManager.Authenticate(txtUsername.Text, txtPassword.Text);
                WIFAuthentication.SetAuthCookie(claimsPrincipal, chckRememberMe.Checked);

                Response.Redirect("~/");
            }
            catch (AuthenticationFailedException)
            {
                ErrorTextLabel.Text = "Chybné uživatelské jméno nebo heslo.";
                ErrorTextLabel.Visible = true;
            }
        }
    }
}