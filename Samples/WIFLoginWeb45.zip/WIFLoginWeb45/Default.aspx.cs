﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Claims;
using System.Security.Principal;

namespace WIFLoginWeb
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ShowName();

            var claimsIdentity = Page.User.Identity as ClaimsIdentity;
            if (claimsIdentity != null)
            {
                ShowClaimsIdentityAsIIdentity(claimsIdentity);
                ShowClaimsFromClaimsIdentity(claimsIdentity);
            }
        }

        protected void loginStatus_LoggingOut(object sender, LoginCancelEventArgs e)
        {
            WIFAuthentication.SignOutAndRefresh();
        }

        /// <summary>
        /// Displays a page that welcomes the user.
        /// </summary>
        private void ShowName()
        {
            if (Page.User.Identity.IsAuthenticated)
            {
                var claimsIdentity = Page.User.Identity as ClaimsIdentity;
                if (claimsIdentity != null)
                {
                    WelcomeMessage.Text = "Welcome: " + claimsIdentity.Name;
                    if (Page.User.IsInRole("Administrators"))
                    {
                        WelcomeMessage.Text = WelcomeMessage.Text + " (Administrator)";
                    }
                    return;
                }
            }

            WelcomeMessage.Text = "Please sign in.";
        }

        /// <summary>
        /// Build a table showing the name and authentication status of the current identity.
        /// </summary>
        /// <param name="ci">Current Identity</param>
        private void ShowClaimsIdentityAsIIdentity(IIdentity identity)
        {
            //Create the table and labels
            Table table = new Table();
            table.BorderWidth = 1;
            table.Font.Name = "Franklin Gothic Book";
            table.Font.Size = FontUnit.Point(10);
            table.CellPadding = 3;
            table.CellSpacing = 3;
            table.BorderColor = System.Drawing.Color.Chocolate;

            Label labelTitle = new Label();
            labelTitle.Text = "Values from IIdentity";
            this.Controls.Add(labelTitle);
            this.Controls.Add(table);

            //Build a row with the identity data
            TableCell tc1 = new TableCell();
            tc1.Text = "IsAuthenticated:" + identity.IsAuthenticated.ToString();
            tc1.BorderWidth = 1;

            TableCell tc2 = new TableCell();
            tc2.Text = "Name:" + identity.Name;
            tc2.BorderWidth = 1;

            TableRow tr = new TableRow();
            tr.Controls.Add(tc1);
            tr.Controls.Add(tc2);

            //Add the row to the table
            table.Controls.Add(tr);
        }

        /// <summary>
        /// Build a table listing the claims accepted about the identity.
        /// </summary>
        /// <param name="claimsIdentity">Given identity</param>
        private void ShowClaimsFromClaimsIdentity(ClaimsIdentity claimsIdentity)
        {
            //Build table and header row
            Table table = new Table();
            TableHeaderCell thc1 = new TableHeaderCell();
            thc1.Text = "Claim Type";

            TableHeaderCell thc2 = new TableHeaderCell();
            thc2.Text = "Claim Value";

            TableHeaderCell thc3 = new TableHeaderCell();
            thc3.Text = "Value Type";

            TableHeaderCell thc4 = new TableHeaderCell();
            thc4.Text = "Subject Name";

            TableHeaderCell thc5 = new TableHeaderCell();
            thc5.Text = "Issuer Name";

            TableHeaderRow th = new TableHeaderRow();
            th.Controls.Add(thc1);
            th.Controls.Add(thc2);
            th.Controls.Add(thc3);
            th.Controls.Add(thc4);
            th.Controls.Add(thc5);
            th.BorderWidth = 1;
            th.BorderColor = System.Drawing.Color.Chocolate;

            //Add a row for each claim
            table.Controls.Add(th);
            foreach (Claim claim in claimsIdentity.Claims)
            {
                WriteClaim(claim, table);
            }

            //Add the table to the returned page
            table.BorderWidth = 1;
            table.Font.Name = "Franklin Gothic Book";
            table.Font.Size = FontUnit.Point(10);
            table.CellPadding = 3;
            table.CellSpacing = 3;
            table.BorderColor = System.Drawing.Color.Chocolate;
            Label labelTitle = new Label();
            labelTitle.Text = "Claims from ClaimsIdentity";
            this.Controls.Add(labelTitle);
            this.Controls.Add(table);
        }

        /// <summary>
        /// Write a claim out in a row of the table.
        /// </summary>
        /// <param name="claim">claim value to write out </param>
        /// <param name="table">the table to write the row out to </param>
        private void WriteClaim(Claim claim, Table table)
        {
            TableCell tc1 = new TableCell();
            tc1.Text = claim.Type;

            TableCell tc2 = new TableCell();
            tc2.Text = claim.Value;

            TableCell tc3 = new TableCell();
            tc3.Text = claim.ValueType.Substring(claim.ValueType.IndexOf('#') + 1);

            TableCell tc4 = new TableCell();
            if ((claim.Subject) != null && (String.IsNullOrEmpty(claim.Subject.Name)) == false)
            {
                tc4.Text = claim.Subject.Name;
            }
            else
            {
                tc4.Text = "Null";
            }

            TableCell tc5 = new TableCell();
            if (!String.IsNullOrEmpty(claim.Issuer))
            {
                tc5.Text = claim.Issuer;
            }
            else
            {
                tc5.Text = "Null";
            }

            TableRow tr = new TableRow();

            tr.Controls.Add(tc1);
            tr.Controls.Add(tc2);
            tr.Controls.Add(tc3);
            tr.Controls.Add(tc4);
            tr.Controls.Add(tc5);

            tr.BorderColor = System.Drawing.Color.Chocolate;

            table.Controls.Add(tr);
        }
    }
}