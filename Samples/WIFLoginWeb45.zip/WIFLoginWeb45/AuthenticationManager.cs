﻿using System;
using System.IdentityModel.Services;
using System.IdentityModel.Tokens;
using System.Security.Claims;
using System.Security.Principal;

namespace WIFLoginWeb
{
    internal static class AuthenticationManager
    {
        #region action methods
        public static ClaimsPrincipal Authenticate(string userName, string password)
        {
            if (string.IsNullOrEmpty(userName))
            {
                throw new ArgumentNullException("userName");
            }

            if (userName == "admin" && password == "password")   //Custom claims
            {
                var outputIdentity = new ClaimsIdentity("Custom");
                outputIdentity.AddClaim(new Claim(ClaimTypes.Name, userName));
                outputIdentity.AddClaim(new Claim(ClaimTypes.Role, "Administrators"));
                outputIdentity.AddClaim(new Claim(ClaimTypes.Email, "admin@domain.com"));
                outputIdentity.AddClaim(new Claim(ClaimTypes.Gender, "Male"));
                outputIdentity.AddClaim(new Claim("UserId", "10", "int"));

                return new ClaimsPrincipal(outputIdentity);
            }

            return ValidateWindowsUser(userName, password);
        }
        #endregion

        #region private member functions
        private static WindowsPrincipal ValidateWindowsUser(string userName, string password)
        {
            try
            {
                SecurityToken securityToken = new UserNameSecurityToken(userName, password);
                var handlers = FederatedAuthentication.FederationConfiguration.IdentityConfiguration.SecurityTokenHandlers;

                //Uses default WindowsUserNameSecurityTokenHandler
                return new WindowsPrincipal((WindowsIdentity)handlers.ValidateToken(securityToken)[0]);
            }
            catch (SecurityTokenValidationException)
            {
                throw new AuthenticationFailedException();
            }
        }
        #endregion
    }

    [Serializable]
    public class AuthenticationFailedException : Exception
    {
        public AuthenticationFailedException() : base("Authentication failed.") { }

        public AuthenticationFailedException(Exception innerException) : base("Authentication failed.", innerException) { }
    }
}