﻿using System;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Pkcs;

namespace SignPDF
{
    class Program
    {
        static void Main(string[] args)
        {
            string pass = "tHuch5wr";

            string alias = null;
            ICipherParameters key;
            Org.BouncyCastle.X509.X509Certificate[] chain;
            using (var keyfs = new System.IO.FileStream(@"..\..\TestCert\TestCert.pfx", System.IO.FileMode.Open))
            {
                var ks = new Pkcs12Store(keyfs, pass.ToCharArray());

                foreach (string al in ks.Aliases)
                {
                    if (ks.IsKeyEntry(al) && ks.GetKey(al).Key.IsPrivate)
                    {
                        alias = al;
                        break;
                    }
                }

                key = ks.GetKey(alias).Key;

                var certificateChainEntry = ks.GetCertificateChain(alias);
                chain = new Org.BouncyCastle.X509.X509Certificate[certificateChainEntry.Length];
                for (int k = 0; k < certificateChainEntry.Length; ++k)
                {
                    chain[k] = certificateChainEntry[k].Certificate;
                }
            }

            var pdrReader = new PdfReader(@"Document.pdf");
            var fsOut = new System.IO.FileStream(@"Signed.pdf", System.IO.FileMode.Create);

            var stp = PdfStamper.CreateSignature(pdrReader, fsOut, '\0');

            var sap = stp.SignatureAppearance;
            sap.SetCrypto(key, chain, null, PdfSignatureAppearance.WINCER_SIGNED);
            //sap.Reason = "Reason";
            //sap.Location = "Location";

            //Remove next line to have an invisible signature
            sap.SetVisibleSignature(new iTextSharp.text.Rectangle(415, 100, 585, 40), 1, null);

            stp.Close();
        }
    }
}
