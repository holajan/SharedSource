﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace TestWindowsControls
{
    public class TestContentControl : Button
    {
        static TestContentControl()
        {
            FrameworkElement.DefaultStyleKeyProperty.OverrideMetadata(typeof(TestContentControl), new FrameworkPropertyMetadata(typeof(TestContentControl)));
        }
    }
}