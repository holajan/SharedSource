﻿using System;
using System.IdentityModel.Tokens;
using Microsoft.IdentityModel.Web;
using Microsoft.IdentityModel.Claims;

namespace FileAccessWeb
{
    internal static class AuthenticationManager
    {
        #region action methods
        public static IClaimsPrincipal Authenticate(string userName, string password)
        {
            if (string.IsNullOrEmpty(userName))
            {
                throw new ArgumentNullException("userName");
            }

            var principal = AuthenticateWindowsUser(userName, password);

            //Check if user is member of required groups
            if (!principal.IsInRole("Administrators") && !principal.IsInRole("Remote Desktop Users"))
            {
                throw new AuthenticationFailedException("Nemáte požadovaná oprávnění pro přihlášení.");
            }

            var inputIdentity = (IClaimsIdentity)principal.Identity;

            //Get Windows user DisplayName and add it to Claims
            var SID = ((System.Security.Principal.WindowsIdentity)inputIdentity).User;
            var user = new IMP.Security.ActiveDirectoryUser(SID);

            var outputIdentity = new ClaimsIdentity(inputIdentity.AuthenticationType);
            outputIdentity.Claims.Add(new Claim(ClaimTypes.Name, inputIdentity.Name));
            outputIdentity.Claims.Add(new Claim("DisplayName", user.DisplayName));

            return ClaimsPrincipal.CreateFromIdentity(outputIdentity);
        }
        #endregion

        #region private member functions
        private static WindowsClaimsPrincipal AuthenticateWindowsUser(string userName, string password)
        {
            try
            {
                SecurityToken securityToken = new UserNameSecurityToken(userName, password);
                var handlers = FederatedAuthentication.ServiceConfiguration.SecurityTokenHandlers;

                //Uses default WindowsUserNameSecurityTokenHandler
                var principal = ClaimsPrincipal.CreateFromIdentities(handlers.ValidateToken(securityToken));
                return (WindowsClaimsPrincipal)principal;
            }
            catch (SecurityTokenValidationException ex)
            {
                throw new AuthenticationFailedException("Chybné uživatelské jméno nebo heslo.", ex);
            }
        }
        #endregion
    }

    [Serializable]
    public class AuthenticationFailedException : Exception
    {
        public AuthenticationFailedException() : base("Authentication failed.") { }
        public AuthenticationFailedException(string message) : base(message) { }
        public AuthenticationFailedException(Exception innerException) : base("Authentication failed.", innerException) { }
        public AuthenticationFailedException(string message, Exception innerException) : base(message, innerException) { }

        protected AuthenticationFailedException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}