﻿using System;
using System.Web;
using Microsoft.IdentityModel.Web;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Tokens;

namespace FileAccessWeb
{
    internal static class WIFAuthentication
    {
        #region action methods
        public static void SetAuthCookie(IClaimsPrincipal claimsPrincipal, bool createPersistentCookie)
        {
            if (claimsPrincipal == null)
            {
                throw new ArgumentNullException("claimsPrincipal");
            }

            var sessionAuthenticationModule = FederatedAuthentication.SessionAuthenticationModule;

            var sessionToken = sessionAuthenticationModule.CreateSessionSecurityToken(claimsPrincipal, null,
                                    DateTime.UtcNow,
                                    DateTime.UtcNow.Add(ConfiguredSessionTokenLifeTime),
                                    createPersistentCookie);

            sessionAuthenticationModule.CookieHandler.RequireSsl = false;
            sessionAuthenticationModule.AuthenticateSessionSecurityToken(sessionToken, true);
        }

        public static void SignOutAndRefresh()
        {
            HttpContext context = HttpContext.Current;

            var sessionAuthenticationModule = FederatedAuthentication.SessionAuthenticationModule;
            sessionAuthenticationModule.SignOut();

            context.Response.Redirect(context.Request.RawUrl);
        }
        #endregion

        #region property getters/setters
        private static TimeSpan ConfiguredSessionTokenLifeTime
        {
            get
            {
                TimeSpan defaultTokenLifetime = SessionSecurityTokenHandler.DefaultTokenLifetime;
                if (FederatedAuthentication.SessionAuthenticationModule.ServiceConfiguration.SecurityTokenHandlers != null)
                {
                    SessionSecurityTokenHandler handler = FederatedAuthentication.SessionAuthenticationModule.ServiceConfiguration.SecurityTokenHandlers[typeof(SessionSecurityToken)] as SessionSecurityTokenHandler;
                    if (handler != null)
                    {
                        defaultTokenLifetime = handler.TokenLifetime;
                    }
                }
                return defaultTokenLifetime;
            }
        }
        #endregion
    }
}