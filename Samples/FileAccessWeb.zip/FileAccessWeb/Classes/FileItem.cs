﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Web;

namespace FileAccessWeb
{
    public class FileItem
    {
        #region Win32 API
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct SHFILEINFO
        {
            public IntPtr hIcon;
            public int iIcon;
            public uint dwAttributes;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string szDisplayName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
            public string szTypeName;
        }

        [Flags]
        private enum SHFILEINFO_FLAGS
        {
            Icon = 0x100,
            LargeIcon = 0,
            SmallIcon = 1,
            TypeName = 0x400,
            UseFileAttributes = 0x10
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("shell32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool SHGetFileInfo(string pszPath, FileAttributes dwFileAttributes, out SHFILEINFO psfi, uint cbfileInfo, SHFILEINFO_FLAGS uFlags);
        #endregion

        #region member varible and default property initialization
        public string Name { get; set; }
        public string Size { get; set; }
        public string Description { get; set; }
        public DateTime DateModified { get; set; }
        public string IconUrl { get; set; }
        #endregion

        #region constructors and destructors
        public FileItem(System.IO.FileInfo fileInfo)
        {
            this.Name = fileInfo.Name;
            this.Size = GetFileSize(fileInfo.Length);
            this.Description = GetFileDescription(fileInfo.FullName);
            this.IconUrl = GetIconUrl(fileInfo.Extension);
            this.DateModified = fileInfo.LastWriteTime;
        }
        #endregion

        #region private member functions
        private static string GetFileSize(long sizeInBytes)
        {
            float size = sizeInBytes;
            int rad = 0;
            while (size > 1024f && rad <= 4)
            {
                size /= 1024f;
                rad++;
            }

            string byteSize = null;
            switch (rad)
            {
                case 0:
                    byteSize = "B";
                    break;
                case 1:
                    byteSize = "KB";
                    break;
                case 2:
                    byteSize = "MB";
                    break;
                case 3:
                    byteSize = "GB";
                    break;
                case 4:
                    byteSize = "TB";
                    break;
            }

            return (Math.Round((double)size, 2).ToString(System.Globalization.CultureInfo.CurrentCulture) + " " + byteSize);
        }

        private static string GetFileDescription(string file)
        {
            SHFILEINFO shfileinfo;
            SHFILEINFO_FLAGS flags = SHFILEINFO_FLAGS.TypeName | SHFILEINFO_FLAGS.UseFileAttributes;
            GetFileInfo(file, out shfileinfo, flags, ((FileAttributes)0));
            return shfileinfo.szTypeName;
        }

        private static void GetFileInfo(string file, out SHFILEINFO fi, SHFILEINFO_FLAGS flags, FileAttributes fileAttr)
        {
            if (!SHGetFileInfo(file, fileAttr, out fi, (uint)Marshal.SizeOf(typeof(SHFILEINFO)), flags))
            {
                int error = Marshal.GetLastWin32Error();
                throw new IOException(string.Format(System.Globalization.CultureInfo.InvariantCulture, "SHGetFileInfo failed for file {0}", new object[] { file }), new System.ComponentModel.Win32Exception(error));
            }
        }

        private static string GetIconUrl(string extension)
        {
            const string cBaseUrl = "~/images/FileTypeIcons";

            string imagePath = HttpContext.Current.Server.MapPath(cBaseUrl);
            string imageFile = Path.Combine(imagePath, extension + ".png");
            var fi = new FileInfo(imageFile);

            if (fi.Exists)
            {
                return ResolveUrl(cBaseUrl + "/" + fi.Name);
            }

            return ResolveUrl(cBaseUrl + "/Generic.png");
        }

        private static string ResolveUrl(string relativeUrl)
        {
            const string appRelativeCharacterString = "~/";

            string url = new System.Web.UI.Control().ResolveUrl(relativeUrl);
            if (url.StartsWith(appRelativeCharacterString))     //Pokud je aplikace v IIS jako site, funkce Control.ResolveUrl URL nezmění
            {
                url = url.Substring(appRelativeCharacterString.Length);
            }

            return url;
        }
        #endregion
    }
}