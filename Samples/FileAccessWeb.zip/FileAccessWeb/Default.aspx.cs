﻿using System;
using System.Collections.Generic;
using System.Web.UI;

namespace FileAccessWeb
{
    public partial class Default : System.Web.UI.Page
    {
        #region event handlers
        protected override void OnInit(EventArgs e)
        {
            //Vypnutí cache stránky
            Page.Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            var files = new List<FileItem>();

            if (Page.User.Identity.IsAuthenticated)
            {
                //Get content of App_Data folder to all users,
                //but you can use Page.User.Identity.Name to get different directory by logged user.
                string directory = this.MapPath("~/App_Data");

                if (System.IO.Directory.Exists(directory))
                {
                    foreach (string fileName in System.IO.Directory.EnumerateFiles(directory))
                    {
                        var fi = new System.IO.FileInfo(fileName);

                        files.Add(new FileItem(fi));
                    }
                }
            }

            this.FileList.DataSource = files;
            this.FileList.DataBind();
        }
        #endregion

        #region action methods
        public string GetStringFieldToolTip(object value, int maxLength)
        {
            string str = value as string;

            if (!string.IsNullOrEmpty(str) && str.Length > maxLength)
            {
                return str;
            }

            return null;
        }
        #endregion
    }
}