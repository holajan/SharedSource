﻿using System;
using System.Web.UI;

namespace FileAccessWeb
{
    public partial class Error : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}