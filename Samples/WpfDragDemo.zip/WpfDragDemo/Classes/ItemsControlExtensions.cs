﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace System.Windows.Controls
{
    /// <summary>
    /// Provides useful extensions to ItemsControl instances.
    /// </summary>
    /// <QualityBand>Experimental</QualityBand>
    public static class ItemsControlExtensions
    {
        /// <summary>
        /// Gets the Panel that contains the containers of an ItemsControl.
        /// </summary>
        /// <param name="control">The ItemsControl.</param>
        /// <returns>
        /// The Panel that contains the containers of an ItemsControl, or null
        /// if the Panel could not be found.
        /// </returns>
        /// <exception cref="T:System.ArgumentNullException">
        /// <paramref name="control" /> is null.
        /// </exception>
        public static Panel GetItemsHost(this ItemsControl control)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }

            // Get the first live container
            DependencyObject container = control.ItemContainerGenerator.ContainerFromIndex(0);

            if (container != null)
            {
                return VisualTreeHelper.GetParent(container) as Panel;
            }

            FrameworkElement rootVisual = control.GetVisualChildren().FirstOrDefault() as FrameworkElement;
            if (rootVisual != null)
            {
                ItemsPresenter presenter = rootVisual.GetLogicalDescendents().OfType<ItemsPresenter>().FirstOrDefault();
                if (presenter != null && VisualTreeHelper.GetChildrenCount(presenter) > 0)
                {
                    return VisualTreeHelper.GetChild(presenter, 0) as Panel;
                }
            }
            return null;
        }

        /// <summary>
        /// Gets the ScrollViewer that contains the containers of an
        /// ItemsControl.
        /// </summary>
        /// <param name="control">The ItemsControl.</param>
        /// <returns>
        /// The ScrollViewer that contains the containers of an ItemsControl, or
        /// null if a ScrollViewer could not be found.
        /// </returns>
        /// <exception cref="T:System.ArgumentNullException">
        /// <paramref name="control" /> is null.
        /// </exception>
        public static ScrollViewer GetScrollHost(this ItemsControl control)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }

            Panel itemsHost = GetItemsHost(control);
            if (itemsHost == null)
            {
                return null;
            }

            // Walk up the visual tree from the ItemsHost to the
            // ItemsControl looking for a ScrollViewer that wraps
            // the ItemsHost.
            return itemsHost
                .GetVisualAncestors()
                .Where(c => c != control)
                .OfType<ScrollViewer>()
                .FirstOrDefault();
        }
    }
}