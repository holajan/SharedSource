﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace IMP.Windows.Controls
{
    /// <summary>
    /// Provides useful extensions to ScrollViewer instances.
    /// </summary>
    /// <QualityBand>Experimental</QualityBand>
    public static class ScrollViewerExtensions
    {
        #region private attached double VerticalOffset
        /// <summary>
        /// Gets the value of the VerticalOffset attached property for a specified ScrollViewer.
        /// </summary>
        /// <param name="element">The ScrollViewer from which the property value is read.</param>
        /// <returns>The VerticalOffset property value for the ScrollViewer.</returns>
        [SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "This is an attached property and is only intended to be set on ScrollViewer's")]
        private static double GetVerticalOffset(ScrollViewer element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            return (double)element.GetValue(VerticalOffsetProperty);
        }

        /// <summary>
        /// Sets the value of the VerticalOffset attached property to a specified ScrollViewer.
        /// </summary>
        /// <param name="element">The ScrollViewer to which the attached property is written.</param>
        /// <param name="value">The needed VerticalOffset value.</param>
        [SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "This is an attached property and is only intended to be set on ScrollViewer's")]
        private static void SetVerticalOffset(ScrollViewer element, double value)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            element.SetValue(VerticalOffsetProperty, value);
        }

        /// <summary>
        /// Identifies the VerticalOffset dependency property.
        /// </summary>
        private static readonly DependencyProperty VerticalOffsetProperty =
            DependencyProperty.RegisterAttached(
                "VerticalOffset",
                typeof(double),
                typeof(ScrollViewerExtensions),
                new PropertyMetadata(OnVerticalOffsetPropertyChanged));

        /// <summary>
        /// VerticalOffsetProperty property changed handler.
        /// </summary>
        /// <param name="dependencyObject">ScrollViewer that changed its VerticalOffset.</param>
        /// <param name="eventArgs">Event arguments.</param>
        private static void OnVerticalOffsetPropertyChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            ScrollViewer source = dependencyObject as ScrollViewer;
            if (source == null)
            {
                throw new ArgumentNullException("dependencyObject");
            }

            source.ScrollToVerticalOffset((double)eventArgs.NewValue);
        }
        #endregion private attached double VerticalOffset

        #region private attached double HorizontalOffset
        /// <summary>
        /// Gets the value of the HorizontalOffset attached property for a specified ScrollViewer.
        /// </summary>
        /// <param name="element">The ScrollViewer from which the property value is read.</param>
        /// <returns>The HorizontalOffset property value for the ScrollViewer.</returns>
        [SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "This is an attached property and is only intended to be set on ScrollViewer's")]
        private static double GetHorizontalOffset(ScrollViewer element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            return (double)element.GetValue(HorizontalOffsetProperty);
        }

        /// <summary>
        /// Sets the value of the HorizontalOffset attached property to a specified ScrollViewer.
        /// </summary>
        /// <param name="element">The ScrollViewer to which the attached property is written.</param>
        /// <param name="value">The needed HorizontalOffset value.</param>
        [SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "This is an attached property and is only intended to be set on ScrollViewer's")]
        private static void SetHorizontalOffset(ScrollViewer element, double value)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            element.SetValue(HorizontalOffsetProperty, value);
        }

        /// <summary>
        /// Identifies the HorizontalOffset dependency property.
        /// </summary>
        private static readonly DependencyProperty HorizontalOffsetProperty =
            DependencyProperty.RegisterAttached(
                "HorizontalOffset",
                typeof(double),
                typeof(ScrollViewerExtensions),
                new PropertyMetadata(OnHorizontalOffsetPropertyChanged));

        /// <summary>
        /// HorizontalOffsetProperty property changed handler.
        /// </summary>
        /// <param name="dependencyObject">ScrollViewer that changed its HorizontalOffset.</param>
        /// <param name="eventArgs">Event arguments.</param>
        private static void OnHorizontalOffsetPropertyChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            ScrollViewer source = dependencyObject as ScrollViewer;
            if (source == null)
            {
                throw new ArgumentNullException("dependencyObject");
            }

            source.ScrollToHorizontalOffset((double)eventArgs.NewValue);
        }
        #endregion private attached double HorizontalOffset

        /// <summary>
        /// Scrolls the content that is within the System.Windows.Controls.ScrollViewer to the specified vertical offset position.
        /// </summary>
        /// <param name="scrollViewer">The ScrollViewer.</param>
        /// <param name="offset">The position that the content scrolls to.</param>
        /// <param name="duration">The duration of the animation.</param>
        public static void ScrollToVerticalOffset(this ScrollViewer scrollViewer, double offset, Duration duration)
        {
            if (duration == TimeSpan.Zero)
            {
                scrollViewer.ScrollToVerticalOffset(offset);
            }
            else
            {
                Storyboard storyboard = new Storyboard();
                SetVerticalOffset(scrollViewer, scrollViewer.VerticalOffset);

                DoubleAnimation verticalOffsetAnimation = new DoubleAnimation { To = offset, Duration = duration };

                Storyboard.SetTarget(verticalOffsetAnimation, scrollViewer);
                Storyboard.SetTargetProperty(verticalOffsetAnimation, new PropertyPath(IMP.Windows.Controls.ScrollViewerExtensions.VerticalOffsetProperty));

                storyboard.Children.Add(verticalOffsetAnimation);

                storyboard.Begin();
            }
        }

        /// <summary>
        /// Scrolls the content that is within the System.Windows.Controls.ScrollViewer to the specified horizontal offset position.
        /// </summary>
        /// <param name="scrollViewer">The ScrollViewer.</param>
        /// <param name="offset">The position that the content scrolls to.</param>
        /// <param name="duration">The duration of the animation.</param>
        public static void ScrollToHorizontalOffset(this ScrollViewer scrollViewer, double offset, Duration duration)
        {
            if (duration == TimeSpan.Zero)
            {
                scrollViewer.ScrollToHorizontalOffset(offset);
            }
            else
            {
                Storyboard storyboard = new Storyboard();
                SetHorizontalOffset(scrollViewer, scrollViewer.HorizontalOffset);

                DoubleAnimation horizontalOffsetAnimation = new DoubleAnimation { To = offset, Duration = duration };

                Storyboard.SetTarget(horizontalOffsetAnimation, scrollViewer);
                Storyboard.SetTargetProperty(horizontalOffsetAnimation, new PropertyPath(ScrollViewerExtensions.HorizontalOffsetProperty));

                storyboard.Children.Add(horizontalOffsetAnimation);

                storyboard.Begin();
            }
        }
    }
}