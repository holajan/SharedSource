﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace IMP.Windows.Controls
{
    #region public types declarations
    /// <summary>
    /// Drop EventArgs for TreeViewDropTarget control
    /// </summary>
    public class TreeViewDropEventArgs : EventArgs
    {
        /// <summary>
        /// Drag target item
        /// </summary>
        public object TargetItem { get; private set; }

        /// <summary>
        /// Drag source items
        /// </summary>
        public IList<object> SourceItems { get; private set; }

        /// <summary>
        /// Drag drop event args
        /// </summary>
        public DragEventArgs DragData { get; private set; }

        /// <summary>
        /// Item drag event args
        /// </summary>
        public ItemDragEventArgs ItemDragData { get; private set; }

        /// <summary>
        /// TreeViewDropEventArgs constructor
        /// </summary>
        /// <param name="targetItem">Drag target item</param>
        /// <param name="sourceItems">Drag source items</param>
        /// <param name="dragData">Drag drop event args</param>
        internal TreeViewDropEventArgs(object targetItem, IList<object> sourceItems, DragEventArgs dragData)
        {
            if (targetItem == null)
            {
                throw new ArgumentNullException("targetItem");
            }
            if (sourceItems == null)
            {
                throw new ArgumentNullException("sourceItems");
            }
            if (dragData == null)
            {
                throw new ArgumentNullException("dragData");
            }

            this.TargetItem = targetItem;
            this.SourceItems = sourceItems;
            this.DragData = dragData;
            this.ItemDragData = dragData.Data.GetData(dragData.Data.GetFormats()[0]) as ItemDragEventArgs;
        }
    }

    /// <summary>
    /// EventArgs for TreeViewDropTarget ValidateDropTarget event
    /// </summary>
    public class TreeViewValidateDropTargetEventArgs : TreeViewDropEventArgs
    {
        /// <summary>
        /// Are Source items valid for specifed target 
        /// </summary>
        public bool IsValid { get; set; }

        /// <summary>
        /// TreeViewValidateDropTargetEventArgs constructor
        /// </summary>
        /// <param name="targetItem">Drag target item</param>
        /// <param name="sourceItems">Drag source items</param>
        /// <param name="dragData">Drag drop event args</param>
        internal TreeViewValidateDropTargetEventArgs(object targetItem, IList<object> sourceItems, DragEventArgs dragData)
            : base(targetItem, sourceItems, dragData)
        {
            this.IsValid = true;
        }
    }
    #endregion

    /// <summary>
    /// A drag drop target for the TreeView control.
    /// </summary>
    public class TreeViewDropTarget : ContentControl
    {
        #region member types declaration
        private enum ScrollDirection
        {
            None,
            Up,
            Down,
        }
        #endregion

        #region delegate and events
        /// <summary>
        /// Validate if source items are valid for specifed target 
        /// </summary>
        public event EventHandler<TreeViewValidateDropTargetEventArgs> ValidateDropTarget;

        /// <summary>
        /// Drag Drop on valid tree view item
        /// </summary>
        public event EventHandler<TreeViewDropEventArgs> DropOnTarget;
        #endregion

        #region member varible and default property initialization
        private DispatcherTimer DragDropNodeExpandTimer;
        private TreeViewItem DragDropPrevItem;

        private DispatcherTimer ScrollTimer;
        private ScrollDirection LastScrollDirection;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Initializes a new instance of the TreeViewDragDropTarget class.
        /// </summary>
        public TreeViewDropTarget()
        {
            this.VerticalContentAlignment = System.Windows.VerticalAlignment.Stretch;
            this.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Stretch;

            this.Loaded += new RoutedEventHandler(TreeViewDropTarget_Loaded);
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets the TreeView that is the drag drop target. 
        /// </summary>
        protected TreeView TreeView
        {
            get { return (base.Content as TreeView); }
        }
        #endregion

        #region private member functions
        private void TreeViewDropTarget_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.TreeView == null)
            {
                throw new InvalidOperationException("Content is not valid TreeView control!");
            }

            this.TreeView.AllowDrop = true;

            this.TreeView.DragEnter += new DragEventHandler(TreeView_DragEnter);
            this.TreeView.DragLeave += new DragEventHandler(TreeView_DragLeave);
            this.TreeView.DragOver += new DragEventHandler(TreeView_DragOver);
            this.TreeView.Drop += new DragEventHandler(TreeView_Drop);

            this.DragDropNodeExpandTimer = new DispatcherTimer();
            this.DragDropNodeExpandTimer.Interval = TimeSpan.FromMilliseconds(800);
            this.DragDropNodeExpandTimer.Tick += new EventHandler(DragDropNodeTimer_Tick);

            this.ScrollTimer = new DispatcherTimer();
            this.ScrollTimer.Interval = TimeSpan.FromMilliseconds(80);
            this.ScrollTimer.Tick += new EventHandler(ScrollTimer_Tick);
        }

        private void TreeView_DragEnter(object sender, DragEventArgs e)
        {
            this.DragDropNodeExpandTimer.Start();
        }

        private void TreeView_DragLeave(object sender, DragEventArgs e)
        {
            this.DragDropNodeExpandTimer.Stop();
            this.ScrollTimer.Stop();
        }

        private void DragDropNodeTimer_Tick(object sender, EventArgs e)
        {
            this.DragDropNodeExpandTimer.Stop();
            if (this.DragDropPrevItem != null)
            {
                this.DragDropPrevItem.IsExpanded = true;
            }
        }

        private void TreeView_DragOver(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.None;
            var target = GetMouseTreeViewItem(e, this.TreeView);
            if (target != null)
            {
                var sourceItems = GetSourceItems(e);
                if (sourceItems != null)
                {
                    //Check if item is valid for target
                    var args = new TreeViewValidateDropTargetEventArgs(target.DataContext, sourceItems, e);
                    if (this.ValidateDropTarget != null)
                    {
                        this.ValidateDropTarget(this, args);
                    }

                    if (args.IsValid)
                    {
                        e.Effects = DragDropEffects.Copy;
                    }
                }
            }

            if (target == null || target != this.DragDropPrevItem)
            {
                this.DragDropPrevItem = target;
                this.DragDropNodeExpandTimer.Stop();
                this.DragDropNodeExpandTimer.Start();
            }

            //Scroll up or down if needed
            BeginScroll(GetScrollDirection(e));

            e.Handled = true;
        }

        private void BeginScroll(ScrollDirection direction)
        {
            if (direction == ScrollDirection.None)
            {
                return;
            } 
            
            this.LastScrollDirection = direction;
            if (this.ScrollTimer.IsEnabled)
            {
                return;
            }

            var scrollViewer = this.TreeView.GetScrollHost();
            if (scrollViewer == null)
            {
                throw new InvalidOperationException("ScrollViewer not found!");
            }

            //Get the tree item header height
            double? treeItemHeight = GetTreeItemHeight();
            if (treeItemHeight == null)
            {
                return;
            }

            double verticalOffset = scrollViewer.VerticalOffset + (this.LastScrollDirection == ScrollDirection.Up ? -1 : 1) * treeItemHeight.Value * 2;
            scrollViewer.ScrollToVerticalOffset(verticalOffset, new Duration(ScrollTimer.Interval));

            this.ScrollTimer.Start();
        }

        private void ScrollTimer_Tick(object sender, EventArgs e)
        {
            this.ScrollTimer.Stop();
        }

        private ScrollDirection GetScrollDirection(DragEventArgs e)
        {
            var pt = e.GetPosition(this.TreeView);

            if (pt.Y < 40)
            {
                return ScrollDirection.Up;
            }
            else if (pt.Y > this.TreeView.ActualHeight - 40)
            {
                return ScrollDirection.Down;
            }
            return ScrollDirection.None;
        }

        private double? GetTreeItemHeight()
        {
            if (this.TreeView.Items.Count == 0)
            {
                return null;
            }

            var treeitem = this.TreeView.ItemContainerGenerator.ContainerFromItem(this.TreeView.Items[0]) as TreeViewItem;
            if (treeitem == null)
            {
                return null;
            }

            var scrollViewer = this.TreeView.GetScrollHost();

            var header = FindChildOf<ContentPresenter>(treeitem);
            if (((FrameworkElement)header).Name == "PART_Header")
            {
                Rect? itemRect = header.GetBoundsRelativeTo(scrollViewer);
                if (itemRect != null)
                {
                    return itemRect.Value.Height;
                }
            }

            return null;
        }

        private void TreeView_Drop(object sender, DragEventArgs e)
        {
            this.ScrollTimer.Stop();

            var target = GetMouseTreeViewItem(e, this.TreeView);
            if (target != null && e.Effects == DragDropEffects.Copy)
            {
                var sourceItems = GetSourceItems(e);
                if (sourceItems != null)
                {
                    var args = new TreeViewDropEventArgs(target.DataContext, sourceItems, e);
                    if (this.DropOnTarget != null)
                    {
                        this.DropOnTarget(this, args);
                    }
                }
            }
        }

        private static TreeViewItem GetMouseTreeViewItem(DragEventArgs e, Control control)
        {
            var pt = e.GetPosition(control);

            var hitResultsList = new List<UIElement>();
            VisualTreeHelper.HitTest(control, null, result =>
            {
                var element = result.VisualHit as UIElement;
                if (element != null)
                {
                    hitResultsList.Add(element);
                }
                return HitTestResultBehavior.Continue;
            }, new PointHitTestParameters(pt));

            var elements = hitResultsList;

            foreach (var element in elements)
            {
                var item = GetVisualParent<TreeViewItem>(element);
                if (item != null)
                {
                    return item;
                }
            }

            return null;
        }

        private static T GetVisualParent<T>(Visual element) where T : Visual
        {
            T item = default(T);
            var v = VisualTreeHelper.GetParent(element) as Visual;

            while (v != null)
            {
                item = v as T;
                if (item != null)
                {
                    return item;
                }

                v = VisualTreeHelper.GetParent(v) as Visual;
            }

            return null;
        }

        private static T FindChildOf<T>(UIElement element) where T : UIElement
        {
            foreach (var obj in GetChildren(element))
            {
                T elem = obj as T;
                if (elem != null)
                {
                    return elem;
                }

                elem = FindChildOf<T>(obj);
                if (elem != null)
                {
                    return elem;
                }
            }

            return null;
        }

        private static IEnumerable<UIElement> GetChildren(UIElement element)
        {
            int childrenCount = VisualTreeHelper.GetChildrenCount(element);

            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(element, i) as UIElement;
                if (child != null)
                {
                    yield return child;
                }
            }
        }

        private IList<object> GetSourceItems(DragEventArgs e)
        {
            var itemDragEventArgs = e.Data.GetData(e.Data.GetFormats()[0]) as ItemDragEventArgs;
            if (itemDragEventArgs == null)
            {
                return null;
            }

            var data = itemDragEventArgs.Data as System.Collections.IEnumerable;
            if (data == null)
            {
                return null;
            }

            var items = data.Cast<object>().ToList().AsReadOnly();
            return items.Count == 0 ? null : items;
        }
        #endregion
    }
}