﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;

namespace WpfDragDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //Naplnění testovacími daty
            var treeData = new ObservableCollection<Item>(from i in Enumerable.Range(1, 20)
                                                          select new Item() { Name = "Tree Root Item" + i.ToString(), Number = i });

            foreach (Item item in treeData)
            {
                item.Items = new ObservableCollection<Item>(from i in Enumerable.Range(1, 10)
                                                            select new Item() { Name = "Tree child Item " + item.Number.ToString() + " " + i.ToString(), Number = i });
            }

            TreeView.ItemsSource = treeData;

            DataGrid.ItemsSource = new ObservableCollection<Item>(from i in Enumerable.Range(1, 100)
                                                                  select new Item() { Name = "Grid Item " + i.ToString(), Number = i });
        }

        private void DataGrid_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed)
            {
                DataGridRow row = FindVisualParent<DataGridRow>(e.OriginalSource as FrameworkElement);
                if (row != null && row.IsSelected)
                {
                    var dataGrid = FindVisualParent<DataGrid>(row);
                    var eventArgs = new ItemDragEventArgs()
                    {
                        AllowedEffects = DragDropEffects.Copy,
                        Effects = DragDropEffects.Copy,
                        Data = dataGrid.SelectedItems.Cast<Item>().OrderBy(i => i.Number),
                        DragSource = dataGrid
                    };

                    var items = row.Item;
                    DragDropEffects finalEffects = DragDrop.DoDragDrop(dataGrid, eventArgs, eventArgs.AllowedEffects);
                    e.Handled = true;
                }
            }
        }

        private static T FindVisualParent<T>(UIElement element) where T : UIElement
        {
            UIElement parent = element;
            while (parent != null)
            {
                T correctlyTyped = parent as T;
                if (correctlyTyped != null)
                {
                    return correctlyTyped;
                }

                parent = VisualTreeHelper.GetParent(parent) as UIElement;
            }

            return null;
        }

        private void TreeViewDropTarget_ValidateDropTarget(object sender, IMP.Windows.Controls.TreeViewValidateDropTargetEventArgs e)
        {
            e.IsValid = ((Item)e.TargetItem).Name.StartsWith("Tree", StringComparison.Ordinal);
        }

        private void TreeViewDropTarget_DropOnTarget(object sender, IMP.Windows.Controls.TreeViewDropEventArgs e)
        {
            foreach (Item item in e.SourceItems)
            {
                ((Item)e.TargetItem).Items.Add(item);
            }
        }
    }

    public class Item
    {
        public string Name { get; set; }
        public int Number { get; set; }

        public ObservableCollection<Item> Items { get; set; }

        public Item()
        {
            Items = new ObservableCollection<Item>();
        }
    }
}
