﻿using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace IMP.Windows.Forms
{
    /// <summary>
    /// Template for dialog forms
    /// </summary>
    public partial class DialogFormTemplate : Form
    {
        #region member varible and default property initialization
        private FormBorderStyle originalFormBorderStyle = FormBorderStyle.FixedDialog;
        private SizeGripStyle originalSizeGripStyle = SizeGripStyle.Hide;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// DialogForm constructor
        /// </summary>
        public DialogFormTemplate()
        {
            InitializeComponent();

            Apply();
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Gets or sets the border style of the form.
        /// </summary>
        [
        DefaultValue((int)FormBorderStyle.FixedDialog), Browsable(true), DispId(-504),
        Category("Appearance"),
        Description("Indicates the appearance and behavior of the border and title bar of the form.")
        ]
        public new FormBorderStyle FormBorderStyle
        {
            get { return originalFormBorderStyle; }
            set
            {
                if (originalFormBorderStyle != value)
                {
                    originalFormBorderStyle = value;

                    Apply();
                }
            }
        }

        /// <summary>
        /// Gets or sets the style of the size grip to display in the lower-right corner of the form.
        /// </summary>
        [
        DefaultValue((int)SizeGripStyle.Hide), Browsable(true),
        Category("CatWindowStyle"), Description("Determines when the SizeGrip will be displayed for the form.")
        ]
        public new SizeGripStyle SizeGripStyle
        {
            get { return originalSizeGripStyle; }
            set
            {
                if (originalSizeGripStyle != value)
                {
                    originalSizeGripStyle = value;

                    Apply();
                }
            }
        }
        #endregion

        #region private member functions
        private void Apply()
        {
            if (originalFormBorderStyle == FormBorderStyle.FixedToolWindow)
            {
                base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            }
            else
            {
                base.FormBorderStyle = FormBorderStyle.Sizable;
            }

            if (originalFormBorderStyle != FormBorderStyle.Sizable && originalFormBorderStyle != FormBorderStyle.SizableToolWindow)
            {
                base.SizeGripStyle = SizeGripStyle.Hide;
            }
            else
            {
                base.SizeGripStyle = originalSizeGripStyle;
            }
        }

        /// <summary>
        /// Overrides Form.WndProc
        /// </summary>
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m); // IMPORTANT: allow the default handlers to handle the message

            const int WM_NCHITTEST = 0x0084;
            const int HTCLIENT = 0x0001;
            const int HTSIZE = 4;   //Size box (same as HTGROWBOX)
            const int HTLEFT = 10;
            const int HTRIGHT = 11;
            const int HTTOP = 12;
            const int HTTOPLEFT = 13;
            const int HTTOPRIGHT = 14;
            const int HTBOTTOM = 15;
            const int HTBOTTOMLEFT = 16;
            const int HTBOTTOMRIGHT = 17;
            const int HTBORDER = 18;

            if (m.Msg == WM_NCHITTEST && originalFormBorderStyle != FormBorderStyle.Sizable && originalFormBorderStyle != FormBorderStyle.SizableToolWindow)
            {
                //Disable sizing
                int result = m.Result.ToInt32();
                if (result == HTSIZE || result == HTLEFT || result == HTRIGHT || result == HTTOP || result == HTTOPLEFT ||
                    result == HTTOPRIGHT || result == HTBOTTOM || result == HTBOTTOMLEFT || result == HTBOTTOMRIGHT || result == HTBORDER)
                {
                    m.Result = new IntPtr(HTCLIENT);    //Use this result to tell Windows to handle that point of your form like client Area
                }
            }
        }
        #endregion
    }
}
