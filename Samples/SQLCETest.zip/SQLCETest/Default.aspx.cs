﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SQLCETest
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Get download counts
            var downloadCounts = (new SqlCompactDataSource()).GetDownloadCounts();

            //Add download count
            (new SqlCompactDataSource()).AddDownload("~/test/file.txt");
        }
    }
}