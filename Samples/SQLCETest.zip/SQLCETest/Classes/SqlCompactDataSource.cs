﻿using System;
using System.Collections.Generic;
using System.Data.SqlServerCe;
using System.IO;

namespace SQLCETest
{
    internal class SqlCompactDataSource
    {
        #region member varible and default property initialization
        private string ConnectionString;

        private static object s_SyncRoot = new object();
        #endregion

        #region constructors and destructors
        public SqlCompactDataSource(string connectionStringName = "ConnectionString")
        {
            this.ConnectionString = SqlCompactDatabaseHelper.GetConnectionString(connectionStringName);

            InitializeDatabase();
        }
        #endregion


        #region action methods
        public void AddDownload(string url)
        {
            lock (s_SyncRoot)
            {
                using (var connection = new SqlCeConnection(this.ConnectionString))
                {
                    using (var command = new SqlCeCommand())
                    {
                        connection.Open();
                        SqlCeTransaction transaction = connection.BeginTransaction();
                        try
                        {
                            command.Connection = connection;
                            command.Transaction = transaction;
                            command.CommandText = "SELECT Count FROM Downloads WHERE Url = @Url";
                            command.Parameters.AddWithValue("@Url", url.ToLowerInvariant());
                            if (command.ExecuteScalar() == null)
                            {
                                command.CommandText = @"INSERT INTO Downloads (Url, Count) VALUES (@Url, 1)";
                                command.ExecuteNonQuery();
                            }
                            else
                            {
                                command.CommandText = @"UPDATE Downloads SET Count = Count + 1 WHERE Url = @Url";
                                command.ExecuteNonQuery();
                            }

                            transaction.Commit(CommitMode.Immediate);
                        }
                        catch (SqlCeException)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
        }

        public Dictionary<string, int> GetDownloadCounts()
        {
            var list = new Dictionary<string, int>();

            using (var connection = new SqlCeConnection(this.ConnectionString))
            {
                using (var command = new SqlCeCommand())
                {
                    connection.Open();
                    command.Connection = connection;
                    command.CommandText = @"SELECT Url, Count FROM Downloads";


                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add((string)reader["Url"], Convert.ToInt32(reader["Count"]));
                        }
                    }
                }
            }

            return list;
        }
        #endregion

        #region private member functions
        private void InitializeDatabase()
        {
            lock (s_SyncRoot)
            {
                if (!File.Exists(SqlCompactDatabaseHelper.GetDataSourceFilePath(this.ConnectionString)))
                {
                    //Vytvoření databáze
                    using (var engine = new SqlCeEngine(this.ConnectionString))
                    {
                        engine.CreateDatabase();
                    }
                    using (var connection = new SqlCeConnection(this.ConnectionString))
                    {
                        using (var command = new SqlCeCommand())
                        {
                            connection.Open();
                            SqlCeTransaction transaction = connection.BeginTransaction();

                            //Vytvoření tabulky pokud neexistuje
                            try
                            {
                                command.Connection = connection;
                                command.Transaction = transaction;
                                command.CommandText = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Downloads'";
                                if (command.ExecuteScalar() == null)
                                {
                                    command.CommandText = @"CREATE TABLE Downloads
                                                        ([IDDownloads] int IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Downloads] PRIMARY KEY,
                                                            [Url] nvarchar(200) NOT NULL,
                                                            [Count] int NOT NULL,
                                                        CONSTRAINT [U_Downloads_FileName] UNIQUE ([Url]))";
                                    command.ExecuteNonQuery();
                                }

                                transaction.Commit(CommitMode.Immediate);
                            }
                            catch (SqlCeException)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }
                }
            }
        }
        #endregion
    }
}