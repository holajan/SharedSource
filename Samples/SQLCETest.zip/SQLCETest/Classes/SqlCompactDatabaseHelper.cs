﻿using System;
using System.Configuration;
using System.Data.Common;
using System.Web;

namespace SQLCETest
{
    internal static class SqlCompactDatabaseHelper
    {
        public static string GetConnectionString(string connectionStringName)
        {
            var settings = ConfigurationManager.ConnectionStrings[connectionStringName];
            if (settings == null)
            {
                return null;
            }

            return settings.ConnectionString;
        }

        public static string GetDataSourceFilePath(string connectionString)
        {
            var builder = new DbConnectionStringBuilder();
            builder.ConnectionString = connectionString;

            if (!builder.ContainsKey("Data Source"))
            {
                throw new ArgumentException("A 'Data Source' parameter was expected in the supplied connection string, but it was not found.");
            }

            return ResolveDataSourceFilePath(builder["Data Source"].ToString());
        }

        private static string ResolveDataSourceFilePath(string path)
        {
            var dirSeparators = new char[] { System.IO.Path.DirectorySeparatorChar };

            if (path.StartsWith("~/"))
            {
                return HttpContext.Current.Server.MapPath(path);
            }

            if (!path.StartsWith("|DataDirectory|", StringComparison.OrdinalIgnoreCase))
            {
                return path;
            }

            string data = AppDomain.CurrentDomain.GetData("DataDirectory") as string;
            if (string.IsNullOrEmpty(data))
            {
                data = AppDomain.CurrentDomain.BaseDirectory;
            }

            return data.TrimEnd(dirSeparators) + System.IO.Path.DirectorySeparatorChar + path.Substring("|DataDirectory|".Length).TrimStart(dirSeparators);
        }
    }
}