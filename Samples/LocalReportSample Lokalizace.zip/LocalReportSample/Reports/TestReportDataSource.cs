﻿using System;
using System.Linq;
using System.Collections.Generic;
using LocalReportSample.Models;

namespace LocalReportSample.Reports
{
    public class TestReportDataSource
    {
        #region action methods
        public IEnumerable<Person> GetPersons()
        {
            //Make some test data
            return new List<Person>
            {
                new Person() { ID = 1, FirstName = "John", LastName= "Smith", DateOfBirth = new DateTime(1968, 4, 22) },
                new Person() { ID = 2, FirstName = "Steven", LastName= "Thompson", DateOfBirth = new DateTime(1935, 7, 3) },
                new Person() { ID = 3, FirstName = "Alice", LastName= "Walters" },
                new Person() { ID = 4, FirstName = "Thomas", LastName= "Bradley" },
                new Person() { ID = 5, FirstName = "Edward", LastName= "Wideman", DateOfBirth = new DateTime(1978,11, 16)  },
                new Person() { ID = 6, FirstName = "Megan", LastName= "Gibson" }
            };
        }
        #endregion
    }
}