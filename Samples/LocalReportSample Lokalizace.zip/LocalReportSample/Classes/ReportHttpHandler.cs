﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Routing;
using Microsoft.Reporting.WebForms;
using LocalReportSample.Reports;
using IMP.Shared;

namespace LocalReportSample
{
    /// <summary>
    /// Handler pro export sestavy do PDF
    /// </summary>
    public class ReportHttpHandler : IHttpHandler
    {
        #region action methods
        /// <summary>
        /// Enables processing of HTTP Web requests by a custom HttpHandler that implements the System.Web.IHttpHandler interface.
        /// </summary>
        /// <param name="context">An System.Web.HttpContext object</param>
        public void ProcessRequest(HttpContext context)
        {
            context.Response.Cache.SetExpires(DateTime.MinValue);

            //Test
            System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");

            bool open = context.Request.QueryString["Export"] != "1";
            string reportUrl = context.Request.Url.Segments[context.Request.Url.Segments.Length - 1];

            Byte[] data = null;
            string exportFileName = null;
            if (reportUrl.StartsWith("test-report.", StringComparison.OrdinalIgnoreCase))
            {
                exportFileName = "TestReport.pdf";
                data = GenerateTestReport();
            }

            if (data == null)
            {
                context.Response.StatusCode = 404;
                context.Response.StatusDescription = "Not Found";
                return;
            }

            DownloadHandlerUtil.WriteFileToResponse(context.Response, data, exportFileName, !open, "application/pdf");
        }

        /// <summary>
        /// Gets a value indicating whether another request can use the System.Web.IHttpHandler instance.
        /// </summary>
        public bool IsReusable
        {
            get { return true; }
        }
        #endregion

        #region private member functions
        private Byte[] GenerateTestReport()
        {
            var report = new ReportDocument("TestReport", System.Reflection.Assembly.GetExecutingAssembly(), "LocalReportSample.Reports");
            report.LocalReport.DataSources.Add(new ReportDataSource("Persons", new TestReportDataSource().GetPersons()));

            return report.Export(ReportExportFormat.PDF);
        }
        #endregion
    }
}