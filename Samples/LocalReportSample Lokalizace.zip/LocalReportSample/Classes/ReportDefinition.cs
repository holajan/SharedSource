﻿using System;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace LocalReportSample
{
    internal class ReportDefinition
    {
        #region constants
        private const string cReportTagName = "Report";
        #endregion

        #region member varible and default property initialization
        private XDocument XmlDocument;

        private XNamespace ns;
        #endregion

        #region constructors and destructors
        private ReportDefinition(XDocument reportDefinitionXml)
        {
            this.XmlDocument = reportDefinitionXml;
            this.ns = reportDefinitionXml.Root.GetDefaultNamespace();
        }
        #endregion

        #region action methods
        /// <summary>
        /// Načtení XML definice reportu ze streamu
        /// </summary>
        /// <param name="inputStream">Vstupní streamu</param>
        /// <returns>ReportDefinition</returns>
        /// <exception cref="InvalidOperationException">Throws when <c>ReportDefinition XML</c> is invalid.</exception>
        public static ReportDefinition Load(System.IO.Stream inputStream)
        {
            if (inputStream == null)
            {
                throw new ArgumentNullException("inputStream");
            }

            //Načtení obsahu streamu
            XDocument reportDefinitionXml = XDocument.Load(new System.IO.StreamReader(inputStream));

            //Kontrola root elementu
            if (reportDefinitionXml.Root == null || reportDefinitionXml.Root.Name.LocalName != cReportTagName)
            {
                throw new InvalidOperationException("reportDefinition");
            }

            return new ReportDefinition(reportDefinitionXml);
        }

        /// <summary>
        /// Export definice do MemoryStreamu
        /// </summary>
        /// <returns>MemoryStream s definicí reportu</returns>
        public System.IO.MemoryStream ToStream()
        {
            var outputStream = new System.IO.MemoryStream();
            using (var writer = XmlWriter.Create(outputStream))
            {
                this.XmlDocument.WriteTo(writer);
            }

            outputStream.Position = 0;
            return outputStream;
        }

        /// <summary>
        /// Překlad hodnot reportu podle nastavených LocID
        /// </summary>
        /// <param name="localizationResource">ResourceManager s texty pro lokalizaci v dané kultuře</param>
        public void Localize(System.Resources.ResourceManager localizationResource)
        {
            XNamespace rd = @"http://schemas.microsoft.com/SQLServer/reporting/reportdesigner";

            if (localizationResource != null)
            {
                //Go through the nodes of XML document and localize
                //the text of nodes Value, ToolTip, Label, Description 
                foreach (XElement el in from i in this.XmlDocument.Root.Descendants()
                                        where i.Name == ns + "Value" || i.Name == ns + "ToolTip" || i.Name == ns + "Label" || i.Name == ns + "Description"
                                        select i)
                {
                    string value = (string)el;
                    string localizedValue = null;

                    if (el.Attribute(rd + "LocID") != null)
                    {
                        //Lokalizace textů podle nalezeného LocID
                        localizedValue = GetLocalizedValue((string)el.Attribute(rd + "LocID"), value, localizationResource);
                    }

                    if (localizedValue != null)
                    {
                        el.Value = localizedValue;
                    }
                }
            }
        }
        #endregion

        #region private member functions
        private static string GetLocalizedValue(string locID, string originalValue, System.Resources.ResourceManager localizationResource)
        {
            //Lokalizace textu
            if (string.IsNullOrEmpty(originalValue) || !originalValue.StartsWith("="))
            {
                return localizationResource.GetString(locID);
            }

            //Lokalizace hodnoty string.Format. Např.: =string.Format("from: {0} to: {1}", from, to)
            if (originalValue.StartsWith("=string.Format(\"", StringComparison.OrdinalIgnoreCase))
            {
                string text = localizationResource.GetString(locID);
                if (text == null)
                {
                    return null;
                }

                int index = originalValue.IndexOf("\",", 16);
                if (index == -1)
                {
                    return null;
                }

                return "=string.Format(" + Escape(text) + originalValue.Substring(index + 1);
            }

            return null;
        }

        private static string Escape(string input)
        {
            var writer = new System.IO.StringWriter();
            var provider = new Microsoft.CSharp.CSharpCodeProvider();
            provider.GenerateCodeFromExpression(new System.CodeDom.CodePrimitiveExpression(input), writer, null);
            return writer.GetStringBuilder().ToString();
        }
        #endregion
    }
}