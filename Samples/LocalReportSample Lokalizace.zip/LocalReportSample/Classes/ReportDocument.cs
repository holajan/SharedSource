using System;
using System.Linq;
using System.Reflection;
using Microsoft.Reporting.WebForms;

namespace LocalReportSample
{
    /// <summary>
    /// Podporovan� form�ty pro export reportu
    /// </summary>
    public enum ReportExportFormat
    {
        /// <summary>
        /// Export do MS Excelu (.xls)
        /// </summary>
        Excel = 1,
        /// <summary>
        /// Export do PDF
        /// </summary>
        PDF = 2,
        /// <summary>
        /// Export do MS Wordu (.doc)
        /// </summary>
        Word = 3,
        /// <summary>
        /// Export do MS Excelu (.xlsx)
        /// </summary>
        ExcelOpenXml = 4,
        /// <summary>
        /// Export do MS Wordu (.docx)
        /// </summary>
        WordOpenXml = 5
    }

    /// <summary>
    /// T��da pro na�ten� a operace s reportem
    /// </summary>
    public class ReportDocument
    {
        #region member varible and default property initialization
        private string m_ReportName;

        /// <summary>
        /// WebForms <c>LocalReport</c> object
        /// </summary>
        public LocalReport LocalReport { get; private set; }

        /// <summary>
        /// Kolekce parametr� reportu
        /// </summary>
        public ReportParameterCollection Parameters { get; private set; }
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Inicializace reportu
        /// </summary>
        /// <param name="reportName">N�zev reportu</param>
        /// <param name="reportsAssembly"><see cref="Assembly"/> obsahuj�c� definice report�</param>
        /// <param name="reportsNamespace">Namespace definic report�</param>
        /// <param name="localReport">WebForms <c>LocalReport</c> object (voliteln�)</param>
        public ReportDocument(string reportName, Assembly reportsAssembly, string reportsNamespace, LocalReport localReport = null)
        {
            if (reportName == null)
            {
                throw new ArgumentNullException("reportName");
            }
            if (reportsAssembly == null)
            {
                throw new ArgumentNullException("reportsAssembly");
            }
            if (reportsNamespace == null)
            {
                throw new ArgumentNullException("reportsNamespace");
            }
            if (reportsNamespace.Length == 0)
            {
                throw new ArgumentException("reportsNamespace is empty string", "reportsNamespace");
            }

            if (localReport == null)
            {
                localReport = new LocalReport();
            }
            localReport.EnableExternalImages = true;

            //Na�ten� XML definice reportu ze streamu
            var reportDefinition = ReportDefinition.Load(GetReportDefinition(reportName, reportsAssembly, reportsNamespace));
            //Lokalikace XML definice
            reportDefinition.Localize(GetLocalizationResource(reportsAssembly));
            //Export upraven� definice do MemoryStreamu a na�ten� reportu
            localReport.LoadReportDefinition(reportDefinition.ToStream());

            m_ReportName = reportName;
            this.LocalReport = localReport;
            this.Parameters = GetParameters(localReport.GetParameters());

            if (this.Parameters.ContainsKey("ReportName"))
            {
                this.Parameters["ReportName"].Value = reportName;
            }
        }
        #endregion

        #region action methods
        /// <summary>
        /// Export reportu do <see cref="byte"/> array
        /// </summary>
        /// <param name="outputFormat">V�stupn� form�t</param>
        /// <returns><see cref="byte"/> array s exportovan� reportem</returns>
        public byte[] Export(ReportExportFormat outputFormat)
        {
            if (outputFormat == 0)
            {
                throw new ArgumentException("Invalid outputFormat", "outputFormat");
            }

            //Synchronizace kolekce parametr� do reportu
            SetParameters(this.LocalReport, this.Parameters);

            Warning[] warnings;
            string[] streamids;
            string mimeType;
            string encoding;
            string extension;

            return this.LocalReport.Render(outputFormat.ToString(), null, out mimeType,
                                           out encoding, out extension, out streamids, out warnings);
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// N�zev reportu
        /// </summary>
        public string ReportName
        {
            get { return m_ReportName; }
        }

        /// <summary>
        /// Titulek reportu
        /// </summary>
        public string ReportTitle
        {
            get { return this.LocalReport.DisplayName; }
        }
        #endregion

        #region private member functions
        private static System.IO.Stream GetReportDefinition(string reportName, Assembly reportsAssembly, string reportsNamespace)
        {
            if (!reportName.EndsWith(".rdlc", StringComparison.Ordinal) && !reportName.EndsWith(".rdl", StringComparison.Ordinal))
            {
                reportName = reportName + ".rdlc";
            }

            return reportsAssembly.GetManifestResourceStream(reportsNamespace + "." + reportName);
        }

        private static ReportParameterCollection GetParameters(ReportParameterInfoCollection parameterInfoCollection)
        {
            var parameters = new ReportParameterCollection();

            foreach (var parameterInfo in parameterInfoCollection)
            {
                var param = new ReportParameter()
                {
                    ParameterName = parameterInfo.Name,
                    AllowBlank = parameterInfo.AllowBlank,
                    Nullable = parameterInfo.Nullable,
                    DataType = (ParameterDataType)parameterInfo.DataType,
                    MultiValue = parameterInfo.MultiValue,
                    Prompt = parameterInfo.Prompt,
                    PromptUser = parameterInfo.PromptUser,
                    ErrorMessage = parameterInfo.ErrorMessage,
                    Visible = parameterInfo.Visible
                };
                param.SetValueInternal(parameterInfo.Values);

                parameters.Add(parameterInfo.Name, param);
            }

            return parameters;
        }

        private static void SetParameters(LocalReport localReport, ReportParameterCollection parameters)
        {
            localReport.SetParameters(from p in parameters.Values
                                      select new Microsoft.Reporting.WebForms.ReportParameter(p.ParameterName, p.GetValueInternal(), p.Visible));
        }

        private static System.Resources.ResourceManager GetLocalizationResource(Assembly assembly)
        {
            string manifest = assembly.GetManifestResourceNames().FirstOrDefault(s => s.EndsWith(".Properties.Resources.resources", StringComparison.OrdinalIgnoreCase));
            if (manifest != null)
            {
                //Odstran�n� ".resources"
                string resourceSource = manifest.Substring(0, manifest.Length - ".resources".Length);

                return new System.Resources.ResourceManager(resourceSource, assembly);
            }

            return null;
        }
        #endregion
    }
}