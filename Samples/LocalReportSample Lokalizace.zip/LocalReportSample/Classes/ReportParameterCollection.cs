﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace LocalReportSample
{
    #region public enums declarations
    /// <summary>
    /// Datový typ parametru reportu
    /// </summary>
    public enum ParameterDataType
    {
        /// <summary>
        /// A Boolean data type that represents a true or false condition.
        /// </summary>
        Boolean = 0,
        /// <summary>
        /// A DateTime data type that represents the date and time.
        /// </summary>
        DateTime = 1,
        /// <summary>
        /// A Float data type that represents a floating point decimal value.
        /// </summary>
        Float = 2,
        /// <summary>
        /// An Integer data type.
        /// </summary>
        Integer = 3,
        /// <summary>
        /// A String data type that represents an array of characters.
        /// </summary>
        String = 4
    }
    #endregion

    /// <summary>
    /// Třída pro parametr reportu
    /// </summary>
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("\\{ ParameterName = {ParameterName}, DataType = {DataType}, Value = {m_Value} \\}")]
    public class ReportParameter
    {
        #region member varible and default property initialization
        /// <summary>
        /// Název parametru reportu
        /// </summary>
        public string ParameterName { get; internal set; }

        /// <summary>
        /// Povolení prázdného řetězce jako hodnoty parametru
        /// </summary>
        public bool AllowBlank { get; internal set; }

        /// <summary>
        /// Povolení hodnoty <c>null</c>
        /// </summary>
        public bool Nullable { get; internal set; }

        /// <summary>
        /// Datový typ parametru
        /// </summary>
        public ParameterDataType DataType { get; internal set; }

        /// <summary>
        /// Povolení více hodnot parametru
        /// </summary>
        public bool MultiValue { get; internal set; }

        /// <summary>
        /// Prompt pro UI
        /// </summary>
        public string Prompt { get; internal set; }

        /// <summary>
        /// <c>true</c> pokud má být zobrazen dotaz na parametr
        /// </summary>
        public bool PromptUser { get; internal set; }

        /// <summary>
        /// Chybová zpráva při validaci parametru
        /// </summary>
        public string ErrorMessage { get; internal set; }

        /// <summary>
        /// Viditelnost parametru
        /// </summary>
        public bool Visible { get; internal set; }

        /// <summary>
        /// Hodnoty parametru
        /// </summary>
        private object m_Value;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Konstruktor třídy
        /// </summary>
        internal ReportParameter() { }
        #endregion

        #region action methods
        internal string[] GetValueInternal()
        {
            if (m_Value == null)
            {
                return new string[0];
            }

            if (this.MultiValue)
            {
                System.Collections.IEnumerable list = m_Value as System.Collections.IEnumerable;
                if (list != null)
                {
                    switch (this.DataType)
                    {
                        case ParameterDataType.Boolean:
                            return (from bool b in list
                                    select b.ToString()).ToArray();
                        case ParameterDataType.DateTime:
                            return (from DateTime dt in list
                                    select dt.ToString("s", System.Globalization.CultureInfo.InvariantCulture)).ToArray();
                        case ParameterDataType.Float:
                            IEnumerable<decimal> decimalList = m_Value as IEnumerable<decimal>;
                            if (decimalList != null)
                            {
                                return (from d in decimalList
                                        select d.ToString(System.Globalization.CultureInfo.CurrentCulture)).ToArray();
                            }

                            IEnumerable<float> floatList = m_Value as IEnumerable<float>;
                            if (floatList != null)
                            {
                                return (from f in floatList
                                        select f.ToString(System.Globalization.CultureInfo.CurrentCulture)).ToArray();
                            }

                            return (from double d in list
                                    select d.ToString(System.Globalization.CultureInfo.CurrentCulture)).ToArray();
                        case ParameterDataType.Integer:
                            IEnumerable<int> intList = m_Value as IEnumerable<int>;
                            if (intList != null)
                            {
                                return (from i in intList
                                        select i.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray();
                            }

                            IEnumerable<byte> byteList = m_Value as IEnumerable<byte>;
                            if (byteList != null)
                            {
                                return (from b in byteList
                                        select b.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray();
                            }

                            IEnumerable<short> shortList = m_Value as IEnumerable<short>;
                            if (shortList != null)
                            {
                                return (from s in shortList
                                        select s.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray();
                            }

                            return (from long l in list
                                    select l.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray();
                        default:
                            return (from object b in list
                                    select b.ToString()).ToArray();
                    }
                }
            }

            switch (this.DataType)
            {
                case ParameterDataType.Boolean:
                    return new string[] { ((bool)m_Value).ToString() };
                case ParameterDataType.DateTime:
                    return new string[] { ((DateTime)m_Value).ToString("s", System.Globalization.CultureInfo.InvariantCulture) };
                case ParameterDataType.Float:
                    return new string[] { Convert.ToString(m_Value, System.Globalization.CultureInfo.CurrentCulture) };
                default:
                    return new string[] { Convert.ToString(m_Value, System.Globalization.CultureInfo.InvariantCulture) };
            }
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="values">Hodnoty parametru</param>
        internal void SetValueInternal(IList<string> values)
        {
            if (values == null)
            {
                throw new ArgumentNullException("values");
            }

            m_Value = null;
            if (values.Count == 0 || values[0] == null)  //Null
            {
                return;
            }

            if (values.Count == 1)
            {
                switch (this.DataType)
                {
                    case ParameterDataType.Boolean:
                        m_Value = Boolean.Parse(values[0]);
                        break;
                    case ParameterDataType.DateTime:
                        m_Value = ParseDateTime(values[0]);
                        break;
                    case ParameterDataType.Float:
                        m_Value = ParseDecimal(values[0]);
                        break;
                    case ParameterDataType.Integer:
                        m_Value = Int32.Parse(values[0], System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture);
                        break;
                    case ParameterDataType.String:
                        m_Value = values[0];
                        break;
                }
                return;
            }

            switch (this.DataType)
            {
                case ParameterDataType.Boolean:
                    m_Value = (from s in values
                               select Boolean.Parse(s)).ToList();
                    break;
                case ParameterDataType.DateTime:
                    m_Value = (from s in values
                               select ParseDateTime(s)).ToList();
                    break;
                case ParameterDataType.Float:
                    m_Value = (from s in values
                               select ParseDecimal(s)).ToList();
                    break;
                case ParameterDataType.Integer:
                    m_Value = (from s in values
                               select Int32.Parse(s, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture)).ToList();
                    break;
                case ParameterDataType.String:
                    m_Value = values.ToList();
                    break;
            }
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(bool? value)
        {
            if (this.DataType != ParameterDataType.Boolean && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(DateTime? value)
        {
            if (this.DataType != ParameterDataType.DateTime && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(decimal? value)
        {
            if (this.DataType != ParameterDataType.Float && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(float? value)
        {
            if (this.DataType != ParameterDataType.Float && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(double? value)
        {
            if (this.DataType != ParameterDataType.Float && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(int? value)
        {
            if (this.DataType != ParameterDataType.Integer && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(byte? value)
        {
            if (this.DataType != ParameterDataType.Integer && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(short? value)
        {
            if (this.DataType != ParameterDataType.Integer && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(long? value)
        {
            if (this.DataType != ParameterDataType.Integer && this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Nastavení hodnoty parametru
        /// </summary>
        /// <param name="value">Hodnota parametru</param>
        public void SetValue(string value)
        {
            if (this.DataType != ParameterDataType.String)
            {
                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }

            m_Value = value;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="bool"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="bool"/> nebo <c>null</c></returns>
        public bool? GetBooleanValue()
        {
            if (m_Value == null)
            {
                return null;
            }

            bool? b = m_Value as bool?;
            if (b == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return b;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="DateTime"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="DateTime"/> nebo <c>null</c></returns>
        public DateTime? GetDateTimeValue()
        {
            if (m_Value == null)
            {
                return null;
            }

            DateTime? dt = m_Value as DateTime?;
            if (dt == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return dt;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="decimal"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="decimal"/> nebo <c>null</c></returns>
        public decimal? GetDecimalValue()
        {
            if (m_Value == null)
            {
                return null;
            }

            decimal? d = m_Value as decimal?;
            if (d == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return d;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="float"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="float"/> nebo <c>null</c></returns>
        public float? GetSingleValue()
        {
            if (m_Value == null)
            {
                return null;
            }

            float? f = m_Value as float?;
            if (f == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return f;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="double"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="double"/> nebo <c>null</c></returns>
        public double? GetDoubleValue()
        {
            if (m_Value == null)
            {
                return null;
            }

            double? d = m_Value as double?;
            if (d == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return d;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="int"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="int"/> nebo <c>null</c></returns>
        public int? GetInt32Value()
        {
            if (m_Value == null)
            {
                return null;
            }

            int? i = m_Value as int?;
            if (i == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return i;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="byte"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="byte"/> nebo <c>null</c></returns>
        public byte? GetByteValue()
        {
            if (m_Value == null)
            {
                return null;
            }

            byte? b = m_Value as byte?;
            if (b == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return b;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="short"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="short"/> nebo <c>null</c></returns>
        public short? GetInt16Value()
        {
            if (m_Value == null)
            {
                return null;
            }

            short? s = m_Value as short?;
            if (s == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return s;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="long"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="long"/> nebo <c>null</c></returns>
        public long? GetInt64Value()
        {
            if (m_Value == null)
            {
                return null;
            }

            long? l = m_Value as long?;
            if (l == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return l;
        }

        /// <summary>
        /// Načtení hodnoty parametru typu <see cref="string"/>
        /// </summary>
        /// <returns>Hodnota parametru typu <see cref="string"/> nebo <c>null</c></returns>
        public string GetStringValue()
        {
            if (m_Value == null)
            {
                return null;
            }

            string s = m_Value as string;
            if (s == null)
            {
                throw new InvalidOperationException(string.Format("Invalid operation for value of type {0}", m_Value.GetType()));
            }

            return s;
        }

        /// <summary>
        /// Returns the string reprezentation of current object.
        /// </summary>
        /// <returns>String reprezentation of current object.</returns>
        public override string ToString()
        {
            return string.Format("{{ ParameterName = {0}, DataType = {1}, Value = {2} }}", ParameterName, DataType, Value == null ? "null" : '"' + Value.ToString() + '"');
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Hodnota parametru
        /// </summary>
        public object Value
        {
            get { return m_Value; }
            set
            {
                if (value == null)
                {
                    m_Value = null;
                    return;
                }

                switch (this.DataType)
                {
                    case ParameterDataType.Boolean:
                        if (value is bool || value is IEnumerable<bool>)
                        {
                            m_Value = value;
                            return;
                        }
                        break;
                    case ParameterDataType.DateTime:
                        if (value is DateTime || value is IEnumerable<DateTime>)
                        {
                            m_Value = value;
                            return;
                        }
                        break;
                    case ParameterDataType.Float:
                        if (value is float || value is double || value is decimal ||
                            value is IEnumerable<float> || value is IEnumerable<double> || value is IEnumerable<decimal>)
                        {
                            m_Value = value;
                            return;
                        }
                        break;
                    case ParameterDataType.Integer:
                        if (value is int || value is byte || value is short || value is long ||
                            value is IEnumerable<int> || value is IEnumerable<byte> || value is IEnumerable<short> || value is IEnumerable<long>)
                        {
                            m_Value = value;
                            return;
                        }
                        break;
                    case ParameterDataType.String:
                        m_Value = value;
                        return;
                }

                throw new InvalidOperationException(string.Format("Invalid value for parameter of type {0}", this.DataType));
            }
        }
        #endregion

        #region private member functions
        private static DateTime ParseDateTime(string s)
        {
            DateTime dateTimeValue;
            if (DateTime.TryParse(s, System.Globalization.CultureInfo.CurrentCulture, System.Globalization.DateTimeStyles.None, out dateTimeValue))
            {
                return dateTimeValue;
            }
            return DateTime.Parse(s, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
        }

        private static decimal ParseDecimal(string s)
        {
            decimal decimalValue;
            if (Decimal.TryParse(s, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.CurrentCulture, out decimalValue))
            {
                return decimalValue;
            }
            return Decimal.Parse(s, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture);
        }
        #endregion
    }

    /// <summary>
    /// Kolekce parametrů reportu
    /// </summary>
    [Serializable]
    public class ReportParameterCollection : Dictionary<string, ReportParameter>
    {
        #region constructors and destructors
        /// <summary>
        /// Konstruktor třídy
        /// </summary>
        internal ReportParameterCollection() { }

        /// <summary>
        /// Initializes a new instance of the ReportParameterCollection class with serialized data.
        /// </summary>
        /// <param name="info">A System.Runtime.Serialization.SerializationInfo object</param>
        /// <param name="context">A System.Runtime.Serialization.StreamingContext structure</param>
        protected ReportParameterCollection(SerializationInfo info, StreamingContext context) : base(info, context) { }
        #endregion
    }
}