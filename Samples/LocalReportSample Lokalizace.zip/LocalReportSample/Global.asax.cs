﻿using System;
using System.Web.Routing;

namespace LocalReportSample
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            //Register routes
            RouteTable.Routes.MapHttpHandler<ReportHttpHandler>("ReportHttpHandler", "test-report.pdf");
        }
    }
}