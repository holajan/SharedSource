﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace SharedControls
{
    /// <summary>
    /// Split Button control
    /// </summary>
    public class SplitButton : Button
    {
        #region delegate and events
        /// <summary>
        /// DropDown menu clicked
        /// </summary>
        public event EventHandler<CancelEventArgs> DropDownClick;
        #endregion

        #region member varible and default property initialization
        private Point mouseUpHitTestPos;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// SplitButton control constructor
        /// </summary>
        static SplitButton()
        {
            FrameworkElement.DefaultStyleKeyProperty.OverrideMetadata(typeof(SplitButton), new FrameworkPropertyMetadata(typeof(SplitButton)));
        }
        #endregion

        #region private member functions
        /// <summary>
        /// Overrides ButtonBase.OnMouseLeftButtonUp
        /// </summary>
        protected override void OnMouseLeftButtonUp(System.Windows.Input.MouseButtonEventArgs e)
        {
            mouseUpHitTestPos = e.GetPosition(this);

 	        base.OnMouseLeftButtonUp(e);
        }

        /// <summary>
        /// Overrides Button.OnClick
        /// </summary>
        protected override void OnClick()
        {
            var DropDownPlace = GetTemplateChild("DropDownPlace") as Rectangle;

            var Rect = GetBounds(DropDownPlace, this);

            if (Rect.Contains(mouseUpHitTestPos))   //Drop down area
            {
                //Show dropdown menu popup
                OnDropDownClick();
                return;
            }

            base.OnClick();
        }

        private static Rect GetBounds(UIElement element, UIElement parentElement)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            if (parentElement == null)
            {
                throw new ArgumentNullException("parentElement");
            }

            var gt = element.TransformToVisual(parentElement);
            if (gt == null)
            {
                return Rect.Empty;
            }

            var pos = gt.Transform(new Point(0, 0));

            return new Rect(pos, element.RenderSize);
        }

        /// <summary>
        /// Occurs when split button DropDown arrow is clicked
        /// </summary>
        protected virtual void OnDropDownClick()
        {
            //Raise DropDownClick event
            var e = new CancelEventArgs(false);
            if (DropDownClick != null)
            {
                DropDownClick(this, e);
            }
        }
        #endregion
    }
}