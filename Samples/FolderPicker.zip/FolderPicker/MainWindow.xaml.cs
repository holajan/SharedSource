﻿using System;
using System.Windows;
using IMP.Windows;

namespace FolderPicker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            var folderPickerDialog = new FolderPickerDialog();
            folderPickerDialog.Title = "Title";
            folderPickerDialog.FolderPath = txtFolder.Text;
            if (folderPickerDialog.ShowDialog() == CommonDialogResult.OK)
            {
                txtFolder.Text = folderPickerDialog.FolderPath;
            }
        }
    }
}
