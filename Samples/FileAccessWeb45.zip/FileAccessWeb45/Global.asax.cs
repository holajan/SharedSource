﻿using System;
using System.Configuration;
using System.Web;
using System.Web.Configuration;
using System.Web.Routing;
using System.Collections.Specialized;

namespace FileAccessWeb
{
    public class Global : System.Web.HttpApplication
    {
        #region event handlers
        protected void Application_Start(object sender, EventArgs e)
        {
            //Register routes
            RouteTable.Routes.MapPageRoute("Default", "", "~/Default.aspx");
            RouteTable.Routes.MapPageRoute("Login", "Login", "~/Login.aspx");
            RouteTable.Routes.MapPageRoute("Error", "Error", "~/Error.aspx");
            RouteTable.Routes.MapPageRoute("NotFound", "NotFound", "~/NotFound.aspx");
            RouteTable.Routes.MapHttpHandler<DownloadHandler>("Download", "{name}");
        }

        protected void Application_BeginRequest(Object sender, EventArgs e)
        {
            if (HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath == "~/" && !HttpContext.Current.Request.Path.EndsWith("/"))
            {
                Response.RedirectToRoute("");
                return;
            }

            if (HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.Equals("~/default.aspx", StringComparison.OrdinalIgnoreCase))
            {
                Response.RedirectToRoute("");
                return;
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            try
            {
                var ex = Server.GetLastError();
                if (ex == null)
                {
                    return;
                }

                var httpex = ex as HttpException;
                if (httpex != null && httpex.GetHttpCode() == 404)    //404 - file not found
                {
                    return;
                }

                //Zalogování chyby
                PublishException(ex);

                //Get the customErrors section.
                CustomErrorsSection customErrorsSection = (CustomErrorsSection)ConfigurationManager.GetSection("system.web/customErrors");

                if (customErrorsSection == null || customErrorsSection.Mode == CustomErrorsMode.Off)
                {
                    //Výchozí ASP.NET zobrazení chyby (při CustomErrorsMode=Off zobrazí a zaloguje ASP.NET error jinak udělá redirect na error page)
                    return;
                }

                if (!string.IsNullOrEmpty(customErrorsSection.DefaultRedirect))
                {
                    Server.ClearError();

                    //Redirect na custom error page
                    HttpContext.Current.Response.Redirect(customErrorsSection.DefaultRedirect);
                }
            }
            catch (Exception localEx)
            {
                PublishException(localEx);
            }
        }
        #endregion

        #region action methods
        /// <summary>
        /// Zápis <paramref name="ex"/> do logu
        /// </summary>
        /// <param name="ex"><see cref="System.Exception"/></param>
        public static void PublishException(System.Exception ex)
        {
            if (ex is System.Web.HttpUnhandledException)
            {
                TryPublishException(ex.InnerException);
                return;
            }

            TryPublishException(ex);
        }
        #endregion

        #region private member functions
        private static bool TryPublishException(Exception ex)
        {
            try
            {
                using (System.Security.Principal.WindowsIdentity.Impersonate(IntPtr.Zero))  //If some user is currently being impersonated, control reverts to the original user.
                {
                    string sourceName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

                    // Write the entry to the Event Log.
                    System.Diagnostics.EventLog.WriteEntry(sourceName, ex.ToString(), System.Diagnostics.EventLogEntryType.Error);
                }

                return true;
            }
            catch
            {
                //Ignore exception
                return false;
            }
        }
        #endregion
    }
}