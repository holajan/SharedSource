﻿using System;

namespace FileAccessWeb
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                var claimsPrincipal = AuthenticationManager.Authenticate(txtUsername.Text, txtPassword.Text);
                WIFAuthentication.SetAuthCookie(claimsPrincipal, chckRememberMe.Checked);

                Response.Redirect("~/");
            }
            catch (AuthenticationFailedException ex)
            {
                ErrorTextLabel.Text = ex.Message;
                ErrorTextLabel.Visible = true;
            }
        }
    }
}