﻿using System;
using System.Security.Claims;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FileAccessWeb
{
    public partial class Site : System.Web.UI.MasterPage
    {
        protected override void OnPreRender(EventArgs e)
        {
            PageTitleLabel.Text = Page.Title;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.User.Identity.IsAuthenticated)
            {
                string displayName = ClaimsPrincipal.Current.FindFirst("DisplayName").Value;
                var userNameLabel = (Label)loginView.FindControl("UserNameLabel");
                userNameLabel.Text = string.Format("Uživatel: <span class='bold'>{0}</span>", displayName);
            }
        }

        protected void loginStatus_LoggingOut(object sender, LoginCancelEventArgs e)
        {
            WIFAuthentication.SignOutAndRefresh();
        }
    }
}