﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;

namespace FileAccessWeb
{
    public partial class Default : System.Web.UI.Page
    {
        #region event handlers
        protected override void OnInit(EventArgs e)
        {
            //Vypnutí cache stránky
            Page.Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        }
        #endregion

        #region page methods
        public IEnumerable<FileItem> FileList_GetData()
        {
            //Get content of App_Data folder to all users,
            //but you can use Page.User.Identity.Name to get different directory by logged user.
            string directory = this.MapPath("~/App_Data");

            if (System.IO.Directory.Exists(directory))
            {
                return from f in System.IO.Directory.EnumerateFiles(directory)
                       select new FileItem(new System.IO.FileInfo(f));
            }

            return null;
        }
        #endregion
    }
}