using System; 
using System.Web;

namespace IMP.Web
{
    public class NotFoundHandler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            context.Response.StatusCode = 404;
            context.Response.StatusDescription = "Not Found";
        }

        public bool IsReusable
        {
            get { return true; }
        }
    }
}
