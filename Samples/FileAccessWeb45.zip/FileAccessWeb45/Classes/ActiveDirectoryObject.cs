using System;
using System.Net;
using System.DirectoryServices;
using System.Security.Principal;

namespace IMP.Security
{
    /// <summary>
    /// Wrapper nad objektem <see cref="DirectoryEntry"/> (LDAP) pro objekt z AD
    /// </summary>
    internal abstract class ActiveDirectoryObject
    {
        #region member varible and default property initialization
        /// <summary>
        /// Objekt <see cref="SecurityIdentifier"/>
        /// </summary>
        private SecurityIdentifier ObjectSID;

        /// <summary>
        /// Objekt <see cref="DirectoryEntry"/>
        /// </summary>
        protected DirectoryEntry Entry;

        /// <summary>
        /// <see cref="NetworkCredential"/> pro p�ihl�en� k AD
        /// </summary>
        protected NetworkCredential Credentials;
        #endregion

        #region constructors and destructors
        /// <summary>
        /// Konstruktor t��dy pro <c>SID</c> (Security ID) objektu v AD
        /// </summary>
        /// <param name="SID">SID (Security ID) objektu v AD</param>
        /// <param name="className">Entry SchemaClassName pro validaci typu instance</param>
        /// <param name="credentials"><see cref="NetworkCredential"/> pro p�ihl�en� k AD</param>
        /// <exception cref="EntryNotFoundException">Throws when SID is invalid or entry not found.</exception>
        /// <exception cref="InvalidSchemaClassNameException">Throws when <c>Entry.SchemaClassName</c> is invalid.</exception>
        protected ActiveDirectoryObject(SecurityIdentifier SID, string className, NetworkCredential credentials)
            : this("LDAP://<SID=" + ConvertSIDToHex(SID) + ">", className, credentials)
        {
            this.ObjectSID = SID;
        }

        /// <summary>
        /// Konstruktor t��dy podle <c>ActiveDirectoryName</c> (nap�: "CN=Domain Admins,CN=users,DC=fabrikam,DC=com")
        /// </summary>
        /// <param name="activeDirectoryName">LDAP identifikace objektu v AD (nap�: "CN=Domain Admins,CN=users,DC=fabrikam,DC=com")</param>
        /// <param name="className">Entry SchemaClassName pro validaci typu instance</param>
        /// <param name="credentials"><see cref="NetworkCredential"/> pro p�ihl�en� k AD</param>
        /// <exception cref="EntryNotFoundException">Throws when ActiveDirectoryName is invalid or entry not found.</exception>
        /// <exception cref="InvalidSchemaClassNameException">Throws when <c>Entry.SchemaClassName</c> is invalid.</exception>
        protected ActiveDirectoryObject(string activeDirectoryName, string className, NetworkCredential credentials)
        {
            this.Credentials = credentials;

            try
            {
                try
                {
                    if (activeDirectoryName.IndexOf("://", StringComparison.Ordinal) == -1)
                    {
                        activeDirectoryName = "LDAP://" + activeDirectoryName;
                    }

                    this.Entry = GetDirectoryEntry(activeDirectoryName, credentials);

                    //Validace objektu Entry
                    if (this.Entry == null || this.Entry.Name.Length == 0)
                    {
                        throw new EntryNotFoundException("Entry not found.");
                    }

                    if (!activeDirectoryName.StartsWith("LDAP://", StringComparison.Ordinal))
                    {
                        TryConnectLDAPEntry(ref this.Entry, credentials);
                    }
                }
                catch (EntryNotFoundException)
                {
                    throw;
                }
                catch (InvalidOperationException)
                {
                    throw;
                }
                catch (System.Exception ex)
                {
                    throw new InvalidOperationException(ex.Message, ex);
                }
            }
            catch (EntryNotFoundException)
            {
                throw;
            }
            catch (InvalidOperationException ex)
            {
                if (!TryConnectWinNTEntry(activeDirectoryName, ref this.Entry, credentials))
                {
                    throw new EntryNotFoundException(ex.Message, ex.InnerException);
                }
            }

            if (!string.Equals(this.Entry.SchemaClassName, className, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidSchemaClassNameException(string.Format("Invalid entry SchemaClassName '{0}', expected {1}'.", this.Entry.SchemaClassName, className));
            }
        }
        #endregion

        #region action methods
        /// <summary>
        /// V�pis v�ech vlastnost� objektu
        /// </summary>
        /// <returns><c>string</c></returns>
        public override string ToString()
        {
            var sb = new System.Text.StringBuilder();

            foreach (string key in this.Entry.Properties.PropertyNames)
            {
                sb.AppendLine(string.Format(System.Globalization.CultureInfo.CurrentCulture, "{0} = ", key));

                foreach (object objValue in this.Entry.Properties[key])
                {
                    sb.AppendLine(string.Format(System.Globalization.CultureInfo.CurrentCulture, "\t{0}", objValue));
                }
            }

            return sb.ToString();
        }
        #endregion

        #region property getters/setters
        /// <summary>
        /// SID (Security ID)
        /// </summary>
        public SecurityIdentifier SID
        {
            get
            {
                if (this.ObjectSID != null)
                {
                    return this.ObjectSID;
                }

                return new SecurityIdentifier((byte[])this.Entry.Properties["objectSid"].Value, 0);
            }
        }

        /// <summary>
        /// Popis objektu
        /// </summary>
        public string Description
        {
            get
            {
                string value = (string)this.Entry.Properties["description"].Value;
                if (string.IsNullOrEmpty(value))
                {
                    return null;
                }
                return value;
            }
        }

        /// <summary>
        /// Identifikace objektu v AD ve tvaru "CN=fullname,CN=Users,DC=domain,DC=local" 
        /// </summary>
        public string ActiveDirectoryName
        {
            get
            {
                try
                {
                    if (this.Entry.Properties["distinguishedName"].Value == null)
                    {
                        if (!this.Entry.Path.StartsWith("LDAP://", StringComparison.Ordinal))
                        {
                            return this.Entry.Path; //WinNT
                        }

                        return this.Entry.Path.Substring(this.Entry.Path.IndexOf("://", StringComparison.Ordinal) + 3);
                    }

                    return (string)this.Entry.Properties["distinguishedName"].Value;
                }
                catch
                {
                    return null;
                }
            }
        }
        #endregion

        #region private member functions
        /// <summary>
        /// Vrac� objekt <see cref="DirectoryEntry"/>.
        /// </summary>
        /// <param name="activeDirectoryName">Identifik�tor AD objektu</param>
        /// <param name="credential"><see cref="NetworkCredential"/> nebo <c>null</c></param>
        /// <returns>Objekt <see cref="DirectoryEntry"/></returns>
        private static DirectoryEntry GetDirectoryEntry(string activeDirectoryName, NetworkCredential credential)
        {
            if (credential == null)
            {
                return new DirectoryEntry(activeDirectoryName);
            }

            string domainName = ActiveDirectoryUtils.ExtractDomain(credential.UserName);
            if (domainName.Length == 0)
            {
                domainName = credential.Domain;

                if (domainName == null)
                {
                    domainName = "";
                }
            }

            string userName = ActiveDirectoryUtils.CombineLoginAndDomain(ActiveDirectoryUtils.ExtractLogin(credential.UserName), domainName);

            if (activeDirectoryName.StartsWith("LDAP://", StringComparison.Ordinal) && domainName.Length != 0 &&
                !((activeDirectoryName + "/").StartsWith("LDAP://" + domainName + "/", StringComparison.Ordinal)))
            {
                //Dopln�n� n�zvu dom�ny p�ed n�zev objektu AD
                activeDirectoryName = activeDirectoryName.Replace("LDAP://", "LDAP://" + domainName + '/');
            }

            return new DirectoryEntry(activeDirectoryName, userName, credential.Password);
        }

        /// <summary>
        /// Pokus o inicializaci <see cref="DirectoryEntry"/> p�es LDAP AD provider
        /// </summary>
        /// <param name="entry">Objekt <see cref="DirectoryEntry"/></param>
        /// <param name="credentials"><see cref="NetworkCredential"/> pro p�ihl�en� k AD</param>
        /// <returns><c>true</c> p�i �sp�chu</returns>
        private static bool TryConnectLDAPEntry(ref DirectoryEntry entry, NetworkCredential credentials)
        {
            try
            {
                try
                {
                    SecurityIdentifier SID = new SecurityIdentifier((byte[])entry.Properties["objectSid"].Value, 0);

                    DirectoryEntry LDAPEntry = GetDirectoryEntry("LDAP://<SID=" + ConvertSIDToHex(SID) + ">", credentials);

                    //Validace objektu LDAPEntry
                    if (LDAPEntry == null || LDAPEntry.Name.Length == 0)
                    {
                        return false;
                    }

                    entry = LDAPEntry;
                    return true;
                }
                catch (InvalidOperationException)
                {
                    return false;
                }
                catch (System.Exception ex)
                {
                    throw new InvalidOperationException(ex.Message, ex);
                }
            }
            catch (InvalidOperationException)
            {
                return false;
            }
        }

        /// <summary>
        /// Pokus o inicializaci <see cref="DirectoryEntry"/> p�es WinNT z LDAP SID Path
        /// </summary>
        /// <param name="activeDirectoryName">LDAP identifikace objektu v AD (nap�: "CN=Domain Admins,CN=users,DC=fabrikam,DC=com")</param>
        /// <param name="entry">WinNT <see cref="DirectoryEntry"/></param>
        /// <param name="credentials"><see cref="NetworkCredential"/> pro p�ihl�en� k AD</param>
        /// <returns><c>true</c> p�i �sp�chu</returns>
        private static bool TryConnectWinNTEntry(string activeDirectoryName, ref DirectoryEntry entry, NetworkCredential credentials)
        {
            try
            {
                try
                {
                    const string cLDAPSIDPathPrefix = "LDAP://<SID=";

                    if (!activeDirectoryName.StartsWith(cLDAPSIDPathPrefix, StringComparison.Ordinal))
                    {
                        //Nejedn� se o LDAP SID Path
                        return false;
                    }

                    string SIDHexString = activeDirectoryName.Substring(cLDAPSIDPathPrefix.Length, activeDirectoryName.Length - cLDAPSIDPathPrefix.Length - 1);

                    SecurityIdentifier SID = new SecurityIdentifier(GetBytesFromHexString(SIDHexString), 0);
                    NTAccount account = (NTAccount)SID.Translate(typeof(NTAccount));

                    DirectoryEntry winNTEntry = GetDirectoryEntry("WinNT://" + account.ToString().Replace("\\", "/"), credentials);

                    //Validace objektu WinNTEntry
                    if (winNTEntry == null || winNTEntry.Name.Length == 0)
                    {
                        return false;
                    }

                    entry = winNTEntry;
                    return true;
                }
                catch (InvalidOperationException)
                {
                    return false;
                }
                catch (System.Exception ex)
                {
                    throw new InvalidOperationException(ex.Message, ex);
                }
            }
            catch (InvalidOperationException)
            {
                return false;
            }
        }

        /// <summary>
        /// P�evod <c>SID</c>u na Hex string
        /// </summary>
        /// <param name="SID"><see cref="SecurityIdentifier"/></param>
        /// <returns>Hex string</returns>
        private static string ConvertSIDToHex(SecurityIdentifier SID)
        {
            byte[] buff = new byte[SID.BinaryLength];

            SID.GetBinaryForm(buff, 0);

            return GetHexStringFromBytes(buff);
        }

        /// <summary>
        /// <para>Returns a string from a byte array represented as a hexidecimal number (eg: 0F351A).</para>
        /// </summary>
        /// <param name="bytes">
        /// <para>The byte array to convert to forat as a hexidecimal number.</para>
        /// </param>
        /// <returns>
        /// <para>The formatted representation of the bytes as a hexidcimal number.</para>
        /// </returns>
        private static string GetHexStringFromBytes(byte[] bytes)
        {
            if (bytes == null)
            {
                throw new ArgumentNullException("bytes");
            }
            if (bytes.Length == 0)
            {
                return "";
            }

            var sb = new System.Text.StringBuilder(bytes.Length * 2);
            for (int i = 0; i < bytes.Length; i++)
            {
                sb.Append(bytes[i].ToString("X2", System.Globalization.CultureInfo.InvariantCulture));
            }
            return sb.ToString();
        }

        /// <summary>
        /// <para>Returns a byte array from a string representing a hexidecimal number.</para>
        /// </summary>
        /// <param name="hexidecimalNumber">
        /// <para>The string containing a valid hexidecimal number.</para>
        /// </param>
        /// <returns><para>The byte array representing the hexidecimal.</para></returns>
        private static byte[] GetBytesFromHexString(string hexidecimalNumber)
        {
            var sb = new System.Text.StringBuilder(hexidecimalNumber.ToUpper(System.Globalization.CultureInfo.CurrentCulture));

            if (sb[0].Equals('0') && sb[1].Equals('X'))
            {
                sb.Remove(0, 2);
            }

            if (sb.Length % 2 != 0)
            {
                throw new ArgumentException("String must represent a valid hexadecimal (e.g. : 0F99DD).");
            }

            byte[] hexBytes = new byte[sb.Length / 2];
            try
            {
                for (int i = 0; i < hexBytes.Length; i++)
                {
                    int stringIndex = i * 2;
                    hexBytes[i] = Convert.ToByte(sb.ToString(stringIndex, 2), 16);
                }
            }
            catch (FormatException ex)
            {
                throw new ArgumentException("String must represent a valid hexadecimal (e.g. : 0F99DD).", ex);
            }

            return hexBytes;
        }
        #endregion
    }

    /// <summary>
    /// Wrapper nad objektem <c>DirectoryEntry</c> (LDAP) pro u�ivatele Windows
    /// </summary>
    internal sealed class ActiveDirectoryUser : ActiveDirectoryObject
    {
        #region constructors and destructors
        /// <summary>
        /// Konstruktor t��dy pro <c>SID</c> (Security ID) u�ivatele Windows
        /// </summary>
        /// <param name="SID">SID (Security ID) u�ivatele Windows</param>
        /// <exception cref="EntryNotFoundException">Throws when SID is invalid or entry not found.</exception>
        /// <exception cref="InvalidSchemaClassNameException">Throws when <c>Entry.SchemaClassName</c> is invalid.</exception>
        public ActiveDirectoryUser(SecurityIdentifier SID) : base(SID, "user", null) { }

        /// <summary>
        /// Konstruktor t��dy pro <c>SID</c> (Security ID) u�ivatele Windows
        /// </summary>
        /// <param name="SID">SID (Security ID) u�ivatele Windows</param>
        /// <param name="credentials"><see cref="NetworkCredential"/> pro p�ihl�en� k AD</param>
        /// <exception cref="EntryNotFoundException">Throws when SID is invalid or entry not found.</exception>
        /// <exception cref="InvalidSchemaClassNameException">Throws when <c>Entry.SchemaClassName</c> is invalid.</exception>
        public ActiveDirectoryUser(SecurityIdentifier SID, NetworkCredential credentials) : base(SID, "user", credentials) { }

        /// <summary>
        /// Konstruktor t��dy pro LDAP <c>ActiveDirectoryName</c> u�ivatele Windows (nap�: "CN=Jeff Smith,CN=users,DC=fabrikam,DC=com")
        /// </summary>
        /// <param name="activeDirectoryName">LDAP identifilace u�ivatele Windows (nap�: "CN=Jeff Smith,CN=users,DC=fabrikam,DC=com")</param>
        /// <exception cref="EntryNotFoundException">Throws when ActiveDirectoryName is invalid or entry not found.</exception>
        /// <exception cref="InvalidSchemaClassNameException">Throws when <c>Entry.SchemaClassName</c> is invalid.</exception>
        public ActiveDirectoryUser(string activeDirectoryName) : base(activeDirectoryName, "user", null) { }

        /// <summary>
        /// Konstruktor t��dy pro LDAP <c>ActiveDirectoryName</c> u�ivatele Windows (nap�: "CN=Jeff Smith,CN=users,DC=fabrikam,DC=com")
        /// </summary>
        /// <param name="activeDirectoryName">LDAP identifilace u�ivatele Windows (nap�: "CN=Jeff Smith,CN=users,DC=fabrikam,DC=com")</param>
        /// <param name="credentials"><see cref="NetworkCredential"/> pro p�ihl�en� k AD</param>
        /// <exception cref="EntryNotFoundException">Throws when ActiveDirectoryName is invalid or entry not found.</exception>
        /// <exception cref="InvalidSchemaClassNameException">Throws when <c>Entry.SchemaClassName</c> is invalid.</exception>
        public ActiveDirectoryUser(string activeDirectoryName, NetworkCredential credentials) : base(activeDirectoryName, "user", credentials) { }
        #endregion

        #region property getters/setters
        /// <summary>
        /// Pln� jm�no u�ivatele
        /// </summary>
        public string FullName
        {
            get
            {
                string value;

                try
                {
                    value = (string)this.Entry.Properties["fullname"].Value;    //WinNT
                    if (value == null)
                    {
                        value = (string)this.Entry.Properties["name"].Value;    //LDAP
                    }
                }
                catch
                {
                    value = null;
                }

                if (string.IsNullOrEmpty(value))
                {
                    return this.Login;
                }
                return value;
            }
        }

        /// <summary>
        /// DisplayName u�ivatele
        /// </summary>
        public string DisplayName
        {
            get
            {
                string value;

                try
                {
                    value = (string)this.Entry.Properties["displayName"].Value;
                }
                catch
                {
                    value = null;
                }

                if (string.IsNullOrEmpty(value))
                {
                    return this.FullName;
                }
                return value;
            }
        }

        /// <summary>
        /// Titul u�ivatele
        /// </summary>
        public string Initials
        {
            get
            {
                string value = (string)this.Entry.Properties["initials"].Value;
                if (string.IsNullOrEmpty(value))
                {
                    return null;
                }
                return value;
            }
        }

        /// <summary>
        /// Jm�no u�ivatele
        /// </summary>
        public string FirstName
        {
            get
            {
                string value;

                try
                {
                    value = (string)this.Entry.Properties["givenName"].Value;
                }
                catch
                {
                    value = null;
                }

                if (string.IsNullOrEmpty(value))
                {
                    return null;
                }
                return value;
            }
        }

        /// <summary>
        /// P��jmen� u�ivatele
        /// </summary>
        public string LastName
        {
            get
            {
                string value;

                try
                {
                    value = (string)this.Entry.Properties["sn"].Value;
                }
                catch
                {
                    value = null;
                }

                if (string.IsNullOrEmpty(value))
                {
                    return null;
                }
                return value;
            }
        }

        /// <summary>
        /// P�ihla�ovac� jm�no u�ivatele
        /// </summary>
        public string Login
        {
            get
            {
                string value;

                try
                {
                    value = (string)this.Entry.Properties["sAMAccountName"].Value;    //LDAP
                    if (value == null)
                    {
                        return this.Entry.Name;
                    }
                }
                catch
                {
                    value = null;
                }

                if (string.IsNullOrEmpty(value))
                {
                    return null;
                }
                return value;
            }
        }

        /// <summary>
        /// P�ihla�ovac� jm�no u�ivatele ve tvaru "login@domain.local" 
        /// </summary>
        public string UserPrincipalName
        {
            get
            {
                string value = (string)Entry.Properties["userPrincipalName"].Value;
                if (string.IsNullOrEmpty(value))
                {
                    return null;
                }
                return value;
            }
        }

        /// <summary>
        /// Emailov� adresa u�ivatele 
        /// </summary>
        public string Email
        {
            get
            {
                string value = (string)this.Entry.Properties["mail"].Value;
                if (string.IsNullOrEmpty(value))
                {
                    return null;
                }
                return value;
            }
        }
        #endregion
    }

    /// <summary>
    /// Statick� t��da pro p��stup k AD (Active Directory) objekt�m
    /// </summary>
    internal static class ActiveDirectoryUtils
    {
        #region action methods
        /// <summary>
        /// Vrac� samotn� p�ihla�ovac� jm�no u�ivatele
        /// </summary>
        /// <param name="loginName">P�ihla�ovac� jm�no ve tvaru "domain\login" nebo "login@domain.local", p��padn� pouze login</param>
        /// <returns>P�ihla�ovac� jm�no u�ivatele</returns>
        public static string ExtractLogin(string loginName)
        {
            string strExp = loginName.Replace("/", "\\");

            int index = strExp.IndexOf('\\');
            if (index != -1)
            {
                strExp = strExp.Substring(index + 1);
            }
            else
            {
                index = strExp.IndexOf('@');
                if (index != -1)
                {
                    strExp = strExp.Substring(0, index);
                }
            }

            return strExp;
        }

        /// <summary>
        /// Vrac� n�zev domeny z p�ihla�ovac�ho jm�na u�ivatele
        /// </summary>
        /// <param name="loginName">P�ihla�ovac� jm�no ve tvaru "domain\login" nebo "login@domain.local", p��padn� pouze login</param>
        /// <returns>N�zev domeny u�ivatele</returns>
        public static string ExtractDomain(string loginName)
        {
            string strExp = loginName.Replace("/", "\\");

            int index = strExp.IndexOf('\\');
            if (index != -1)
            {
                strExp = strExp.Substring(0, index);
            }
            else
            {
                index = strExp.IndexOf('@');
                if (index != -1)
                {
                    strExp = strExp.Substring(index + 1);
                }
                else
                {
                    strExp = "";
                }
            }

            index = strExp.IndexOf('.');
            if (index != -1)
            {
                strExp = strExp.Substring(0, index);
            }

            return strExp.ToUpper(System.Globalization.CultureInfo.CurrentCulture);
        }

        /// <summary>
        /// Dopln�n� n�zvu dom�ny <c>Domain</c> do p�ihla�ovac�ho jm�na u�ivatele <c>LoginName</c> pokud dom�nu neobsahuje.
        /// </summary>
        /// <param name="loginName">P�ihla�ovac� jm�no ve tvaru "domain\login" nebo "login@domain.local", p��padn� pouze login</param>
        /// <param name="domainName">N�zev dom�ny, pokud nen� uveden v p�ihla�ovac�m jm�nu</param>
        /// <returns>P�ihla�ovac� jm�no u�ivatele v�etn� n�zvu dom�ny</returns>
        public static string CombineLoginAndDomain(string loginName, string domainName)
        {
            if (loginName.Length == 0 || domainName.Length == 0)
            {
                return loginName;
            }

            if (ExtractDomain(loginName).Length != 0)
            {
                //Dom�na v LoginName m� p�ednost, parametr Domain se ignoruje
                return loginName;
            }

            //Samotn� login, dopln�n� n�zvu dom�ny
            int index = domainName.IndexOf('.');
            if (index != -1)
            {
                domainName = domainName.Substring(0, index);
            }

            return domainName.ToUpper(System.Globalization.CultureInfo.CurrentCulture) + '\\' + loginName;
        }
        #endregion
    }

    /// <summary>
    /// T��da pro <c>Exception</c> p�i nenalezen� u�ivatele Windows v AD (Active Directory)
    /// </summary>
    internal class EntryNotFoundException : Exception
    {
        #region constructors and destructors
        /// <summary>
        /// Konstruktor t��dy
        /// </summary>
        /// <param name="message">Chybov� zpr�va</param>
        public EntryNotFoundException(string message) : base(message) { }

        /// <summary>
        /// Konstruktor t��dy
        /// </summary>
        /// <param name="message">Chybov� zpr�va</param>
        /// <param name="innerException">InnerException (voliteln�)</param>
        public EntryNotFoundException(string message, System.Exception innerException) : base(message, innerException) { }
        #endregion
    }

    /// <summary>
    /// T��da pro <c>Exception</c> p�i nespr�vn� t��d� Active Directory objektu
    /// </summary>
    internal class InvalidSchemaClassNameException : Exception
    {
        #region constructors and destructors
        /// <summary>
        /// Konstruktor t��dy
        /// </summary>
        /// <param name="message">Chybov� zpr�va</param>
        public InvalidSchemaClassNameException(string message) : base(message) { }

        /// <summary>
        /// Konstruktor t��dy
        /// </summary>
        /// <param name="message">Chybov� zpr�va</param>
        /// <param name="innerException">InnerException (voliteln�)</param>
        public InvalidSchemaClassNameException(string message, System.Exception innerException) : base(message, innerException) { }
        #endregion
    }
}