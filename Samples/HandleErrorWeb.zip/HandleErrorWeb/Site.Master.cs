﻿using System;
using System.Security.Claims;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HandleErrorWeb
{
    public partial class Site : System.Web.UI.MasterPage
    {

    }
}