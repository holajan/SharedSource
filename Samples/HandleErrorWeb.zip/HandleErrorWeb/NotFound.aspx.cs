﻿using System;
using System.Web.UI;

namespace HandleErrorWeb
{
    public partial class NotFound : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Response.StatusCode = 404;
            this.Response.StatusDescription = "Not Found";
        }
    }
}