﻿using System;
using System.Configuration;
using System.Web;
using System.Web.Configuration;
using System.Web.Routing;
using System.Collections.Specialized;

namespace HandleErrorWeb
{
    public class Global : System.Web.HttpApplication
    {
        #region event handlers
        protected void Application_Start(object sender, EventArgs e)
        {
            //Register routes
            var routes = RouteTable.Routes;
            routes.MapPageRoute("Default", "", "~/Default.aspx");
            routes.MapPageRoute("NotFound", "not-found", "~/NotFound.aspx");
        }

        protected void Application_BeginRequest(Object sender, EventArgs e)
        {
            if (HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath == "~/" && !HttpContext.Current.Request.Path.EndsWith("/"))
            {
                Response.RedirectToRoute("");
                return;
            }

            if (HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.Equals("~/default.aspx", StringComparison.OrdinalIgnoreCase))
            {
                Response.RedirectToRoute("");
                return;
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            var ex = Server.GetLastError();
            if (ex == null)
            {
                return;
            }

            var httpex = ex as HttpException;
            if (httpex != null && httpex.GetHttpCode() == 404)    //404 - file not found
            {
                return;
            }

            //Get the customErrors section.
            var customErrorsSection = (CustomErrorsSection)ConfigurationManager.GetSection("system.web/customErrors");
            if (customErrorsSection == null || customErrorsSection.Mode == CustomErrorsMode.Off)
            {
                //Výchozí ASP.NET zobrazení chyby (při CustomErrorsMode=Off zobrazí a zaloguje ASP.NET error jinak provede zobrazení error page)
                return;
            }

            //Transfer content to Error page
            var errorPageHandler = System.Web.UI.PageParser.GetCompiledPageInstance("~/error.aspx", HttpContext.Current.Server.MapPath("~/error.aspx"), HttpContext.Current);
            Server.Transfer(errorPageHandler, true);
        }
        #endregion
    }
}