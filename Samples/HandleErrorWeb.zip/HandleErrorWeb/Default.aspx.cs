﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;

namespace HandleErrorWeb
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Button_Click(object sender, EventArgs e)
        {
            throw new InvalidOperationException("Test");
        }
    }
}