﻿using System;
using System.Web.UI;

namespace HandleErrorWeb
{
    public partial class Error : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}