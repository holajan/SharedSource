using System;
using WindowsLive;

public partial class DefaultPage : System.Web.UI.Page
{
    #region member varible and default property initialization
    protected string FullName { get; private set; }
    protected string LoginUrl { get; private set; }
    #endregion

    #region event handlers
    protected void Page_Load(object sender, EventArgs e)
    {
        var client = new LiveAuthClient(Global.ClientId, Global.ClientSecret, Global.RedirectUri);
        this.LoginUrl = client.LoginUrl;

        var user = client.GetUserInfo(this);
        if (user != null)
        {
            //U�ivatel je ji� p�ihl�en
            this.FullName = user.FullName;
        }
    }

    protected void btnSignOut_Click(object sender, EventArgs e)
    {
        LiveAuthClient.SignOut();

        Response.Redirect(this.Request.RawUrl);
    }
    #endregion
}