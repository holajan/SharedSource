﻿using System;
using WindowsLive;

namespace OAuthTest
{
    public partial class Callback : System.Web.UI.Page
    {
        #region event handlers
        protected void Page_Load(object sender, EventArgs e)
        {
            LiveAuthClient.ProcessCallback(Global.ClientId, Global.ClientSecret, Global.RedirectUri);

            Response.Redirect("default.aspx");
        }
        #endregion
    }
}