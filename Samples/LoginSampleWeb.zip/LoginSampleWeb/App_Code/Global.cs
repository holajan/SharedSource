﻿using System;

public static class Global
{
    #region constants
    public const string ClientId = "0000000000000000";
    public const string ClientSecret = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
    public const string RedirectUri = "http://www.liveloginapp/LoginSampleWeb/callback.aspx";
    #endregion
}