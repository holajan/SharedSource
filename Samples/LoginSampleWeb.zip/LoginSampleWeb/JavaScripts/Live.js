﻿function logoutWindowsLive() {
    cleanLogoutFrame();

    var logoutFrame = createHiddenElement("iframe");
    logoutFrame.src = "//oauth.live.com/logout?ts=" + new Date().getTime();
    document.body.appendChild(logoutFrame);
    wl_app.logoutFrame = logoutFrame;

    //Clean logout iframe in 30s.
    window.setTimeout(cleanLogoutFrame, 30000);
}

function cleanLogoutFrame() {
    if (wl_app.logoutFrame != null) {
        document.body.removeChild(wl_app.logoutFrame);
        wl_app.logoutFrame = null;
    }
} 

function createHiddenElement(tagName) {
    var element = document.createElement(tagName);
    element.style.position = "absolute";
    element.style.top = "-1000px";
    element.style.width = "300px";
    element.style.height = "300px";

    return element;
}

var wl_app = { };