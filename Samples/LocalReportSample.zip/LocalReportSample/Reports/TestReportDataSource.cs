﻿using System;
using System.Linq;
using System.Collections.Generic;
using LocalReportSample.Models;

namespace LocalReportSample.Reports
{
    public class TestReportDataSource
    {
        #region action methods
        public IEnumerable<Person> GetPersons()
        {
            //Make some test data
            return new List<Person>
            {
                new Person() { ID = 1, FirstName = "John", LastName= "Smith", Age = 23 },
                new Person() { ID = 2, FirstName = "Steven", LastName= "Thompson", Age = 48 },
                new Person() { ID = 3, FirstName = "Alice", LastName= "Walters" },
                new Person() { ID = 4, FirstName = "Thomas", LastName= "Bradley" },
                new Person() { ID = 5, FirstName = "Edward", LastName= "Wideman", Age = 36 },
                new Person() { ID = 6, FirstName = "Megan", LastName= "Gibson" }
            };
        }
        #endregion
    }
}